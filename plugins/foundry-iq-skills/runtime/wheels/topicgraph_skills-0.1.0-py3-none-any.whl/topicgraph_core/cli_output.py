"""Shared CLI output: a short summary by default, the full JSON with --json, one next step per error."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Callable

NEXT_STEPS = {
    # Operator environment (doctor)
    "PYTHON_TOO_OLD": "use Python 3.12 or newer in the runtime environment, then run doctor again.",
    "AZ_CLI_MISSING": "install the Azure CLI, then run doctor again with --tenant-id.",
    "AZ_SIGNIN_REQUIRED": "stop and tell the user Azure sign-in is needed for this tenant; don't sign in for them.",
    "STATE_DIR_NOT_WRITABLE": "pass a writable --state-dir, or fix permissions on this one.",
    "MODEL_DEPLOYMENT_UNREACHABLE": "check --model-endpoint and --model-deployment, and that this identity can read the Azure OpenAI resource.",
    "CLI_ERROR": "run doctor, fix the first failed check, then retry.",
    "MCP_DEPENDENCY_UNAVAILABLE": "prepare the pinned Apps dependencies in the same Python environment used to launch MCP (see CONTRIBUTING.md for source; use the supplied setup launcher for a distribution), then reload topicgraph-skills.",
    # Arguments and inputs
    "INPUT_INVALID": "check the flags and input files named in the error, then retry.",
    "ARGS_INVALID": "pass tool arguments as a JSON object with only the listed properties.",
    "TOOL_NOT_FOUND": "call tools/list to see the available topicgraph_ tools.",
    "RESOURCE_NOT_FOUND": "call resources/list and use one of the advertised TopicGraph resource URIs.",
    "APP_ASSETS_INVALID": "reinstall the reviewed plugin package; its pinned Apps assets are incomplete or changed.",
    "AUTH_UNSUPPORTED": "set --auth (or TOPICGRAPH_SEARCH_AUTH) to query-key or entra.",
    "AZURE_LIVE_ARGS_REQUIRED": "add the missing flags listed above.",
    "COMMAND_UNSUPPORTED": "run --help and select a supported command.",
    "DATASET_INVALID": "pass --dataset as a lowercase slug (letters, digits, hyphens).",
    "SEARCH_SERVICE_INVALID": "pass --search-service as the service name, not a URL.",
    "ENDPOINT_INVALID": "pass a canonical https://<service>.search.windows.net origin without credentials, ports, paths, query or fragment.",
    "MODEL_ARGS_REQUIRED": "add the missing --model-* flags listed above; the build labels topics with that deployment.",
    "MODEL_SETTINGS_INVALID": "pass --model-endpoint as an https:// Azure OpenAI endpoint, with --model-deployment, --model-name and --model-api-version.",
    "MODEL_CALL_CAP_INVALID": "pass --model-call-cap as a positive whole number, or omit it for the default.",
    # Dataset fetch (tools/fetch_wiki_revisions.py)
    "MANIFEST_INVALID": "restore the pinned manifest.json from git; don't edit it.",
    "FETCH_FAILED": "check the network, then run the fetch again; it resumes where it stopped.",
    "REVISION_MISMATCH": "delete the output directory and fetch again; if it repeats, the pinned revision is no longer served.",
    "PROFILE_NOT_FOUND": "pass --profile as a JSON file path or one of the bundled profile names.",
    "BUILD_PROFILE_INVALID": "fix the build profile named in the error, then run plan again.",
    "READER_INVALID": "pass --reader as a principal object ID (GUID).",
    "SOURCE_REQUIRED": "pass --documents or --endpoint, not both.",
    "DESCRIPTOR_REQUIRED": "publish a build from this account, or pass --descriptor (or set TOPICGRAPH_DESCRIPTOR) with the file the builder gave you.",
    "CURRENT_AMBIGUOUS": "pass --descriptor (or set TOPICGRAPH_DESCRIPTOR) for the build you mean.",
    "CURRENT_INVALID": "publish the build again, or pass --descriptor (or set TOPICGRAPH_DESCRIPTOR) to skip the record.",
    "DESCRIPTOR_INVALID": "ask the builder for a fresh descriptor from apply or verify.",
    "QUERY_INVALID": "check the query arguments named in the error, then retry.",
    "SOURCE_SEED_INVALID": "fix the seed JSONL: unique ids with id, text, source, title and a 384-dim vector.",
    "SOURCE_INDEX_INVALID": "name the seed source index with the topicgraph-src- prefix.",
    "PAGE_SIZE_INVALID": "pass --page-size between 1 and 1000.",
    "LIMIT_INVALID": "pass a limit between 1 and 100.",
    "CURSOR_INVALID": "drop the cursor and start from the first page.",
    "LEVEL_INVALID": "run status to see the levels this generation has.",
    "LEVEL_NOT_FOUND": "run status to see the levels this generation has.",
    "TOPIC_NOT_FOUND": "run list-topics to see valid topic IDs.",
    "CHUNK_NOT_FOUND": "run list-members to see chunk IDs in a topic.",
    "SOURCE_NAMES_INVALID": "point --source-names (or TOPICGRAPH_SOURCE_NAMES) at the Entity Graph descriptor or source manifest JSON for this source index, or unset it.",
    # Source inspection
    "SOURCE_IDENTITY_INVALID": "run doctor to check reader access on the source index, then run plan again.",
    "SOURCE_TARGET_MISMATCH": "pass source settings that name this Search service and source index.",
    "SOURCE_FIELDS_INVALID": "map distinct, retrievable key and text fields, a vector field, and optional title and source fields.",
    "SOURCE_KEY_INVALID": "pass --key-field as the source index key.",
    "SOURCE_VECTOR_INVALID": "check --vector-field names a vector field with a positive dimension.",
    "NATIVE_SOURCE_INCOMPATIBLE": "review the observed profile, metric and stored-vector settings with the source owner; any compatible replacement requires separate approval.",
    "SOURCE_COUNT_UNAVAILABLE": "run doctor to check reader access on the source index.",
    "SOURCE_INSPECT_FAILED": "run doctor to check reader access on the source index.",
    "SOURCE_CHANGED": "the source changed; wait until it is frozen, then run plan again.",
    # Build
    "PLAN_CHANGED": "run plan again and approve the new plan ID.",
    "PLAN_ID_MISMATCH": "pass the plan ID printed by the plan you approved.",
    "PLAN_NOT_FOUND": "run plan first, or pass --plan-file.",
    "PLAN_BOUND_FLAG": "drop those flags from apply; to change them, run plan again and approve the new plan ID.",
    "WRITE_CONFIRMATION_REQUIRED": "add --confirm-writes once the plan is approved.",
    "MODEL_CALL_BUDGET_EXHAUSTED": "make a new plan with a higher --model-call-cap, review and approve it, then apply it; the build resumes.",
    "MODEL_ACCESS_DENIED": "ask for Cognitive Services OpenAI User on the model resource, then run doctor.",
    "MODEL_DEPLOYMENT_NOT_FOUND": "fix --model-deployment to a deployment on the Azure OpenAI account, then run doctor again.",
    "MODEL_DEPLOYMENT_NOT_READY": "wait for the model deployment to finish provisioning, or fix --model-deployment.",
    "MODEL_DEPLOYMENT_NOT_CHAT": "ask the user to pick a deployment that reports chatCompletion from `entity-graph-provision discover`, then run doctor again.",
    "MODEL_RETIRED": "deploy a GenerallyAvailable chat model, then plan again with its --model-deployment and --model-name.",
    "MODEL_ACCOUNT_NOT_FOUND": "check --subscription-id, --model-resource-group and the account in --model-endpoint.",
    "MODEL_ARM_ACCESS_DENIED": "ask for Reader on the Azure OpenAI account, or omit --subscription-id to skip the deployment check.",
    "SOURCE_REVERT_FAILED": "run reconcile with this plan to clean up the source index, then rerun apply with --resume-after-reconcile.",
    "RELEASE_MISSING": "rerun apply with the same plan; the build resumes and writes its release.",
    "RELEASE_INVALID": "keep the build output for review and report it; do not upload this release.",
    "RELEASE_DOCUMENT_INVALID": "keep the build output for review and report it; do not upload this release.",
    "PUBLICATION_SCHEMA_MISMATCH": "inspect the new index in the portal, then run reconcile with the same plan.",
    "SOURCE_VECTORS_NOT_STORED": "pick a vector field that is stored, or rebuild the source index with stored vectors.",
    "SOURCE_VECTORS_NOT_RETRIEVABLE": "ask the source index owner to make the vector field retrievable (or pick one that is), then plan again.",
    "DEPENDENCY_UNAVAILABLE": "reinstall the plugin so its pinned dependencies are present, then run doctor.",
    "AZURE_DEPENDENCY_MISSING": "reinstall the plugin with its azure extra, then run doctor.",
    "GENERATION_INVALID": "pass the generation ID that apply or generations printed.",
    "GENERATION_CHANGED": "use the retained physical descriptor explicitly; a same-content generation cannot be rebound to a different plan in this state directory.",
    "GENERATION_EXISTS": "run verify on the existing generation instead of apply.",
    "GENERATION_REQUIRED": "pass --generation-id with the ID that apply or verify printed.",
    "GENERATION_UNKNOWN": "run apply first, or pass --generation-id from its output; if apply stopped, run status and reconcile before any retry.",
    "REPRODUCIBILITY_DEVIATION": "run reconcile; do not publish this generation.",
    "RECONCILE_REQUIRED": "run reconcile, review it, then apply again with --resume-after-reconcile.",
    "RECONCILE_UNSUPPORTED": "run plan again; reconcile needs a plan with a target index.",
    "STATE_INVALID": "point --state-dir at the directory this plan was made in, or run plan again.",
    "PUBLISHER_BUSY": "wait for the other publish to finish, then run status.",
    "BUILD_FAILED": "run topic-graph-build status to see where apply stopped, then reconcile before any retry.",
    "WRITE_FAILED": "run reconcile before any retry; never repeat an unknown-outcome write.",
    "UPLOAD_FAILED": "run reconcile before any retry; never repeat an unknown-outcome write.",
    "READBACK_MISMATCH": "run reconcile, then verify.",
    "READBACK_NOT_SETTLED": "wait a minute for Search to finish indexing, then run reconcile and verify.",
    # Search service and publication
    "TENANT_REQUIRED": "pass --build-args with the file connect saved; it names the tenant.",
    "TENANT_MISMATCH": ("you are signed in to a different tenant. To browse topics, run it again without "
                        "--tenant-id; otherwise stop and tell the user. Don't sign in for them."),
    "TOKEN_INVALID": "stop and tell the user the Azure sign-in has expired; don't sign in for them.",
    "ARM_REQUEST_FAILED": "run doctor, then check --subscription-id and --resource-group.",
    "SEARCH_REQUEST_FAILED": "run doctor to check sign-in and Search reader access.",
    "SEARCH_SERVICE_NOT_FOUND": "check --subscription-id, --resource-group and --search-service.",
    "SEARCH_SERVICE_MISMATCH": "check --search-service names the service in this resource group.",
    "SEARCH_HEADROOM_INSUFFICIENT": "inspect capacity and eligible incomplete staging indexes; completed generations are retained and require separately managed decommissioning.",
    "SEARCH_STATISTICS_INVALID": "obtain complete numeric Search index statistics before replanning.",
    "PLACEMENT_UNSUPPORTED": "publish into the same Search service and tenant as the source.",
    "INDEX_COLLISION": "run plan again; the target index already exists.",
    "INDEX_EXISTS": "run verify on the existing generation instead of apply.",
    "INDEX_INVALID": "use the generation index name printed by apply or generations.",
    "INDEX_MISSING": "run status; the generation index is gone, so run plan and apply again.",
    "SCHEMA_UNSUPPORTED": "upgrade the plugin; this release schema is not supported.",
    "DOCUMENT_INVALID": "run plan again; report this as a build bug.",
    "DUPLICATE_DOCUMENT": "run reconcile; never overwrite another document.",
    "PUBLICATION_APPROVAL_REQUIRED": "pass every approval flag named in the error.",
    "PUBLICATION_BATCH_INVALID": "use an upload batch size between 1 and 1000.",
    "PUBLICATION_DOCUMENT_TOO_LARGE": "reduce the named document payload and create a new plan; do not retry this write.",
    "PUBLICATION_PERMISSION_DENIED": "ask for Search Service Contributor and Search Index Data Contributor, then run doctor.",
    "PUBLICATION_READBACK_FAILED": "run doctor to check reader access, then verify.",
    "PUBLICATION_RESULT_INCOMPLETE": "run reconcile before any retry.",
    "PUBLICATION_TARGET_INVALID": "pass --dataset as a lowercase slug.",
    "PUBLICATION_TARGET_MISMATCH": "run plan again; the target index must belong to --dataset.",
    "PUBLICATION_UPLOAD_FAILED": "run reconcile before any retry; never repeat an unknown-outcome write.",
    "PUBLICATION_VERIFY_FAILED": "run reconcile, then verify.",
    "PUBLICATION_VERIFY_REQUIRED": "run verify first.",
    # Native binary runner and adapters
    "NATIVE_ARTIFACTS_MISSING": "check that the native binary completed and wrote all output artifacts to the artifact directory.",
    "NATIVE_ARTIFACTS_INVALID": "check native build logs and ensure output artifacts are complete and valid.",
    "NATIVE_SOURCE_BINDING_INVALID": "inspect the source and prepare a new plan with its exact vector field, tenant and Search API binding.",
    "NATIVE_BINARY_NOT_FOUND": "run topic-graph-build download-native or topic-graph-build plan to download the pinned release from Azure/foundry-iq-tool-releases, or pass --native-binary.",
    "NATIVE_PLATFORM_UNSUPPORTED": "use Windows x64/ARM64, Linux x64/ARM64, or macOS Apple Silicon (ARM64); macOS Intel is not supported.",
    "NATIVE_BINARY_CHECKSUM_REQUIRED": "download a verified release from Azure/foundry-iq-tool-releases or supply a trusted expected_sha256 to NativeRunner.",
    "NATIVE_BINARY_UNREADABLE": "check that the native binary file is readable.",
    "NATIVE_BINARY_NOT_EXECUTABLE": "grant execute permission to the native binary with chmod +x.",
    "BINARY_HASH_MISMATCH": "ensure topicgraph matches the approved release receipt SHA-256 hash or re-run download-native.",
    "NATIVE_CACHE_INVALID": "set TOPICGRAPH_NATIVE_CACHE or FOUNDRY_IQ_RUNTIME_CACHE to an absolute path outside the repository and working directory.",
    "NATIVE_RELEASE_NOT_FOUND": "check network connectivity to api.github.com/repos/Azure/foundry-iq-tool-releases/releases, or pass --native-binary with a verified local release.",
    "NATIVE_RELEASE_CHANGED": "run plan or download-native again to review and approve the pinned release tag and digest.",
    "NATIVE_RELEASE_MISMATCH": "do not use this download; the published asset differs from the one this plugin pins. Report it to the plugin maintainers.",
    "NATIVE_DOWNLOAD_FAILED": "verify network access to github.com/Azure/foundry-iq-tool-releases and retry download-native with the approved plan ID.",
    "NATIVE_SCHEMA_VERSION_UNSUPPORTED": "upgrade the topicgraph-skills plugin to a version that supports this native output schema version.",
    "PLAN_ID_REQUIRED": "pass --plan-id with the plan ID printed by the plan or download-native command you approved.",
    "CONFIG_INVALID": "fix the invalid configuration keys or values in the native build config.",
    "NATIVE_CLI_PROTOCOL_ERROR": "ensure the native CLI outputs a valid topicgraph-cli-v1 JSON envelope on stdout.",
    "NATIVE_COMMAND_UNSUPPORTED": "use a supported native CLI command (validate, plan, or execute).",
    "NATIVE_EXECUTION_TIMEOUT": "increase native CLI execution timeout or reduce dataset size.",
    "NATIVE_EXECUTION_FAILED": "rerun apply with the same plan; the build resumes where it stopped.",
    "NATIVE_USAGE_ERROR": "upgrade the plugin; the build tool rejected the command it was given.",
    "NATIVE_CANCELLED": "rerun apply with the same plan; the build resumes where it stopped.",
    "NATIVE_INTERRUPTED": "run reconcile with this plan to clean up the source index, then apply with --resume-after-reconcile.",
    "NATIVE_CONFIG_MISSING": "rerun apply with the same plan to recreate the build configuration, then reconcile.",
    "NATIVE_CLEANUP_FAILED": "fix the reported problem, then run reconcile again with the same plan.",
    "NATIVE_AUTHENTICATION_UNSUPPORTED": "prepare and approve a new plan so the build uses refreshable Entra credentials, or remove the temporary scoring profile from the source index by hand.",
    "NATIVE_RESUME_REJECTED": "delete the reported build folder to start the build over, then rerun apply with the same plan.",
    "PUBLISH_APPROVAL_REQUIRED": "add --approve-publish once selecting this descriptor locally is approved.",
    "PUBLISH_BINDING_MISMATCH": "use the same resource, dataset, source, vector field and TOPICGRAPH_HOME as the approved plan.",
    "PUBLICATION_CHANGED": "select the retained descriptor with topic-graph-consume --descriptor <file> --endpoint <endpoint> --auth entra --tenant-id <tenant>; do not replay stale publish approval.",
    "PUBLICATION_UNCERTAIN": "run reconcile with the build plan ID before any retry; do not roll back automatically.",
    "DESCRIPTOR_CHANGED": "preserve the immutable descriptor and inspect the conflicting file; never overwrite it.",
    "QUERY_ONLY_VIOLATION": "use the descriptor from verify; it binds one topic index and its source index.",
    "READ_ACCESS_DENIED": "ask the builder to grant Search Index Data Reader on the topic index and its source index, then run doctor.",
    "READERS_MISSING": "run plan with --reader for each listed reader (or --drop-reader), then apply.",
    "READER_GRANTS_FORBIDDEN": "ask an owner of the Search service to run this, or drop --reader.",
    "READER_GRANTS_UNREADABLE": "ask for rights to read role assignments on the Search service, then plan again.",
    "READER_GRANTS_UNSUPPORTED": "drop --reader and --drop-reader; this backend has no role assignments.",
    "READER_GRANT_FAILED": "run reconcile before any retry.",
    "READER_REVOKE_FAILED": "remove the listed read grant by hand, then run generations.",
    # Retire
    "RETIRE_BINDING_MISMATCH": "run plan-retire again with the same resource, dataset, source and vector field.",
    "RETIRE_PLAN_STALE": "run plan-retire again and approve the new plan.",
    "RETIRE_TARGET_PROTECTED": "run generations; only journal-owned, unexposed incomplete staging indexes qualify. Completed generations are retained.",
    "RETIRE_TARGET_UNKNOWN": "run generations to see the retirable indexes.",
    "RETIRE_DELETE_FAILED": "run generations before any retry; never repeat an unknown-outcome delete.",
    "RETIRE_READBACK_FAILED": "run reconcile with the retire plan to inspect index existence and remaining grants.",
    # Consume
    "TOPIC_GRAPH_LEGACY_FORM": "rebuild with the pinned TopicGraph build tool and publish to a new topic index; "
                               "community-form graphs from build tool 1.0.7 or earlier are not read.",
    "TOPIC_INDEX_INVALID": "ask the builder to rebuild and publish again; this topic index is inconsistent.",
    "TOPIC_INDEX_TOO_LARGE": "this topic index is larger than consume reads; ask the builder for a smaller build.",
}


def add_json_option(parser: argparse.ArgumentParser, *, subcommand: bool = False) -> None:
    """Accept --json before or after the subcommand; SUPPRESS keeps a subparser from resetting it."""
    parser.add_argument("--json", action="store_true", default=argparse.SUPPRESS if subcommand else False,
                        help="Print the full JSON result instead of a short summary")


def add_version_option(parser: argparse.ArgumentParser) -> None:
    from importlib.metadata import PackageNotFoundError, version
    try:
        installed = version("topicgraph-skills")
    except PackageNotFoundError:
        installed = "unknown"
    parser.add_argument("--version", action="version", version=f"%(prog)s {installed}")


def next_step(code: str) -> str:
    return NEXT_STEPS.get(code) or NEXT_STEPS["CLI_ERROR"]


def error_body(exc: BaseException, default_code: str) -> dict[str, Any]:
    """The one blocked envelope: status, UPPER_SNAKE code, message, exactly one next step, and the
    parsed `service_error` when a service response caused the failure."""
    from topicgraph_core.service_errors import find, with_summary

    code = getattr(exc, "code", None) or default_code
    message = str(exc)
    if message.startswith(f"{code}: "):
        message = message[len(code) + 2:]
    embedded = None
    if "Next step:" in message:
        message, embedded = (part.strip() for part in message.split("Next step:", 1))
    step = getattr(exc, "next_step", None) or embedded or next_step(code)
    service_error = find(exc)
    if service_error and service_error.get("message") and service_error["message"] not in message:
        message = with_summary(message, service_error)
    body: dict[str, Any] = {"status": "blocked", "error_code": code, "error": message, "next_step": step}
    if service_error:
        body["service_error"] = service_error
    return body


def emit(result: Any, as_json: bool, summary: Callable[[Any], str] | None, *, compact: bool = True) -> None:
    if as_json or summary is None:
        print(json.dumps(result, sort_keys=True, ensure_ascii=False, allow_nan=False,
                         separators=(",", ":") if compact else None))
    else:
        print(summary(result))


def emit_error(exc: BaseException, as_json: bool, default_code: str) -> int:
    body = error_body(exc, default_code)
    if as_json:
        print(json.dumps(body, sort_keys=True, ensure_ascii=False), file=sys.stderr)
    else:
        print(f"Blocked. {body['error_code']}: {body['error']}\nNext step: {body['next_step']}", file=sys.stderr)
    return 2


def mb(value: Any) -> str:
    size = int(value or 0)
    return f"{size / 1_000_000:.1f} MB" if size >= 100_000 else f"{size / 1_000:.1f} KB"
