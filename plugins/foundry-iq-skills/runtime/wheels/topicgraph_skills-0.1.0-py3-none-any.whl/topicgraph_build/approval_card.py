"""One approval card format for every topic-graph-build write gate: apply, publish and retire.

The card is display-only. It is attached to command output after the plan is saved, so it never feeds a plan digest.
"""

from __future__ import annotations

import math
from typing import Any

from topicgraph_core.cli_output import mb


# Measured live: apply took about 4 min for 7,296 chunks; each naming call took about 2.4 s.
_MIN_PER_1K_CHUNKS = (0.3, 0.7)
_NAMING_SECONDS_PER_CALL = 2.4


def _minutes(low: float, high: float) -> tuple[int, int]:
    lo = max(1, math.floor(low))
    return lo, max(lo + 1, math.ceil(high))


def build(*, what: str, account: dict[str, Any], plan_id: str, changes: list[str],
          minutes: tuple[int, int], one_time_usd: float | None = 0.0, ongoing: str = "none",
          cost_items: list[str] | None = None, bullets: list[str] | None = None,
          details: list[str] | None = None) -> dict[str, Any]:
    """The card text: a headline, what happens (bullets, or numbered changes), time and cost.

    No tenant or plan ID: the agent passes the plan ID, so the user never types one. Anything
    technical goes in ``details``, shown only when the user asks.
    """
    subscription = account.get("subscription_name") or f"{(account.get('subscription_id') or '')[:8]}…"
    group = f"{account.get('resource_group')} (existing)"
    if cost_items:
        cost_block = ["Cost:", *(f"  - {item}" for item in cost_items)]
    else:
        one_time_text = f"about ${one_time_usd:.2f}" if one_time_usd is not None else "unknown"
        cost_block = [f"Cost: {one_time_text} one-time; ongoing: {ongoing}"]
    body = ([f"- {line}" for line in bullets] if bullets is not None else
            [f"Changes ({len(changes)}):", *(f"  {n}. {change}" for n, change in enumerate(changes, 1))])
    lines = [f"APPROVAL: {what}",
             *([f"Subscription: {subscription} · Resource group: {group}"] if account.get("resource_group") else []),
             *body,
             f"Time: about {minutes[0]}–{minutes[1]} min",
             *cost_block,
             *([f"Details: {len(details)} more line(s) on how it works. Ask to see them."] if details else []),
             "No automatic retry or cleanup.",
             # No plan ID on the card: the agent passes plan_id; the user never types it.
             "Approve this card to go ahead. Nothing changes until you do."]
    result = {"what": what, "subscription": subscription, "resource_group": group,
              "plan_id": plan_id, "changes": changes, "minutes": list(minutes),
              "one_time_usd": round(one_time_usd, 2) if one_time_usd is not None else None, "ongoing": ongoing,
              "details": list(details or []), "text": "\n".join(lines)}
    if cost_items is not None:
        result["cost_items"] = list(cost_items)
    return result


def apply_minutes(plan: dict[str, Any]) -> tuple[int, int]:
    """Measured: about 4 min per 7,300 chunks, plus about 2.4 s per naming call."""
    chunks = int(plan["source"]["expected_count"]) / 1000
    naming = plan["model_call_cap"] * _NAMING_SECONDS_PER_CALL / 60
    return _minutes(chunks * _MIN_PER_1K_CHUNKS[0], chunks * _MIN_PER_1K_CHUNKS[1] + naming + 1)


def for_apply(plan: dict[str, Any], account: dict[str, Any]) -> dict[str, Any]:
    """Headline and three bullets: what it reads, what it creates, the model calls."""
    source = plan["source"]
    temporary = plan["source_temporary_changes"]
    model = plan["model"]
    cap = plan["model_call_cap"]
    count = int(source["expected_count"])
    leaf = int((plan.get("profile") or {}).get("max_leaf_size") or 0)
    topics = max(1, math.ceil(count / leaf)) if leaf else None
    target = f"{plan['target_index_prefix']}<release content ID>"
    bullets = [
        f"Reads {count:,} passages from {source['index']} in place; its documents don't change.",
        f"Creates a new topic index {target} on {plan['search_service']}.",
        f"Names {f'about {topics:,} topics' if topics else 'the topics'} with {model['deployment']} "
        f"({model['name']}), at most {cap:,} model calls.",
    ]
    changes = [
        f"Read {count:,} chunks from {source['index']} in place.",
        "Generate topics locally on this machine from the chunk vectors.",
        f"Name topics with your model deployment {model['deployment']} ({model['name']}): at most {cap:,} calls.",
        f"Create a new search index {target} on {plan['search_service']}.",
        f"Upload the release's topic documents to {target}.",
    ]
    details = [
        f"While it builds, the build tool will {'; '.join(temporary['changes'])} and remove it when it "
        "finishes (if it reports it could not, run reconcile to clean up).",
        "Topics are generated locally on this machine from the chunk vectors.",
        "Search tokens refresh through Entra credentials for the approved tenant; interactive sign-in is disabled.",
        f"The model call cap ({cap:,}) is enforced by the build tool's call budget.",
    ]
    native_dl = plan.get("native_download")
    if isinstance(native_dl, dict) and native_dl.get("asset_name"):
        changes.insert(0, f"Download, verify and execute native binary {native_dl['asset_name']}.")
        bullets[0] = "Downloads the Topic Graph build tool once, then r" + bullets[0][1:]
        details.insert(0, f"Download if needed, verify and execute native binary {native_dl['asset_name']} "
                          f"(release {native_dl['tag']}, digest {native_dl['asset_digest']}) from GitHub repo "
                          f"{native_dl['repository']} in the per-user runtime cache.")
    readers = plan.get("reader_grants")
    if readers and readers.get("grant"):
        many = len(readers["grant"])
        bullets.append(f"Lets {many} {'person' if many == 1 else 'people'} read the new index.")
        changes.append(f"Grant read access to {many} identit{'y' if many == 1 else 'ies'} on the new index.")
        details.append(f"Readers also need Search Index Data Reader on the source index "
                       f"{readers.get('source_index') or source['index']} to open member chunks. "
                       "This build doesn't grant it; ask the source index owner.")
    sku = (plan.get("source_binding") or {}).get("search_sku")
    serverless = isinstance(sku, str) and sku.casefold() == "serverless"
    ongoing = "unknown (billable Serverless compute/storage; existing Blob/model usage excluded)" if serverless else "none"
    cost_items = [f"Model naming ({model['deployment']}): up to {cap:,} calls at your deployment's pricing; "
                  "this card can't price it",
                  "Search Serverless: billable compute and indexed storage, amount unknown" if serverless
                  else "Search: uses the existing service capacity (ongoing: none)"]
    card = build(what=f"build topics from {source['index']}", account=account, plan_id=plan["plan_id"],
                 changes=changes, minutes=apply_minutes(plan), one_time_usd=None, ongoing=ongoing,
                 cost_items=cost_items, bullets=bullets, details=details)
    card["model_call_cap"] = cap
    return card


def for_publish(generation_id: str, physical_index: str, account: dict[str, Any]) -> dict[str, Any]:
    changes = [f"Select the verified physical index {physical_index} for new readers on this machine."]
    details = [f"The new topics are in index {physical_index}; older topic indexes stay until you retire them.",
               "Other computers and readers that are already running keep their current topics until they "
               "get the new descriptor."]
    return build(what="use the new topics", account=account, plan_id=generation_id, changes=changes,
                 minutes=(1, 2), bullets=["Make the new topics the ones this computer uses."], details=details)


def for_retire(plan: dict[str, Any], account: dict[str, Any]) -> dict[str, Any]:
    changes = [f"Delete the search index {plan['index']} ({plan['document_count']:,} docs, {mb(plan['storage_bytes'])})."]
    bullets = [f"Delete the unused topic index {plan['index']} ({plan['document_count']:,} documents, "
               f"{mb(plan['storage_bytes'])}).", "Your published topics and your documents' index don't change."]
    readers = plan.get("reader_grants") or []
    if readers:
        changes.append(f"Remove {len(readers)} reader grant(s) on that index.")
        bullets.append(f"Remove read access for {len(readers)} {'person' if len(readers) == 1 else 'people'} on it.")
    return build(what=f"delete the unused topic index {plan['index']}", account=account, plan_id=plan["plan_id"],
                 changes=changes, minutes=(1, 2), bullets=bullets)


def for_native_download(spec: dict[str, Any], account: dict[str, Any] | None = None) -> dict[str, Any]:
    acct = account or {}
    changes = [f"Download, verify and extract native package {spec['asset_name']} into the per-user runtime cache."]
    details = [f"Package {spec['asset_name']} (release {spec['tag']}, digest {spec['asset_digest']}) "
               f"from GitHub repo {spec['repository']} ({spec['asset_url']}).",
               "The download is checked against GitHub's SHA-256 digest before it is unpacked, and the check "
               "is recorded."]
    return build(what="download the Topic Graph build tool", account=acct, plan_id=spec["plan_id"],
                 changes=changes, minutes=(1, 2), one_time_usd=0.0,
                 bullets=["Download the Topic Graph build tool once and check it before it runs on this computer."],
                 details=details)
