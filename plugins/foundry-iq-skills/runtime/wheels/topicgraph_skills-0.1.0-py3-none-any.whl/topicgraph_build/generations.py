"""Retain completed generations; retire only owned, unexposed staging indexes."""

from __future__ import annotations

from typing import Any

from topicgraph_adapters.azure_source import get_field
from topicgraph_build.reader_grants import REVOKE_ACTIONS
from topicgraph_core.contracts import PUBLICATION_VERSION, ContractError, digest
from topicgraph_core.current import checked_current
from topicgraph_core.service_errors import from_exception, summary
from topicgraph_build.live import publication_binding
from topicgraph_core.state import State

RETIRE_PLAN_VERSION = "topicgraph-retire-v2"


RELEASE_FIELDS = {"id", "subject_id", "predicate", "object_vector"}


def _release_generation(store: Any, index: str, prefix: str) -> str | None:
    """The release content ID in a TopicGraph index name, when the index has the release shape."""
    suffix = index.removeprefix(prefix)
    if not 12 <= len(suffix) <= 64 or any(c not in "0123456789abcdef" for c in suffix):
        return None
    definition = store.index_client.get_index(index)
    names = {get_field(field, "name") for field in get_field(definition, "fields", [])}
    return suffix if RELEASE_FIELDS <= names else None


def _stats(store: Any, index: str) -> dict[str, int]:
    data = store.index_stats(index)
    return {"document_count": int(data.get("documentCount") or 0), "storage_bytes": int(data.get("storageSize") or 0)}


def list_generations(store: Any, state: State, *, dataset: str, source_index: str) -> dict[str, Any]:
    """Read-only. Only names under topicgraph-{dataset}- (plus the named source index) are inspected."""
    prefix = f"topicgraph-{dataset}-"
    names = sorted(name for name in store.index_client.list_index_names()
                   if name.startswith(prefix) or name == source_index)
    current = checked_current((store.endpoint, source_index))
    active = current["physical_index"] if current and current["endpoint"].rstrip("/") == store.endpoint.rstrip("/") else None
    rows = []
    for name in names:
        row: dict[str, Any] = {"index": name, **_stats(store, name)}
        if name == source_index:
            row["role"] = "source"
        elif (generation := _release_generation(store, name, prefix)) is None:
            row["role"] = "unrecognized"
        else:
            row["generation_id"] = generation
            owner = state.staging_owner(name)
            if name == active:
                row["role"] = "local-current"
            elif state.protected_index(name):
                row["role"] = "retained"
            elif owner is None:
                row["role"] = "unknown"
            elif state.retiring_index(name):
                row["role"] = "retiring"
            elif state.unresolved_writes(owner["plan_id"]):
                row["role"] = "unresolved"
            elif any(e["operation_id"] == owner["plan_id"] and e["stage"] == "apply" and e["state"] == "failed"
                     for e in state.events()) or state.has_reconcile(owner["plan_id"]):
                row["role"] = "incomplete-owned"
            else:
                row["role"] = "protected"
            row["owner_plan_id"] = owner["plan_id"] if owner else None
        rows.append(row)
    return {
        "local_current_physical_index": active, "generations": rows,
        "retire_candidates": [row["index"] for row in rows if row["role"] == "incomplete-owned"],
    }


def plan_retire(store: Any, state: State, args: Any, index: str) -> dict[str, Any]:
    listing = list_generations(store, state, dataset=args.dataset, source_index=args.source_index)
    row = next((row for row in listing["generations"] if row["index"] == index), None)
    if row is None:
        raise ContractError("RETIRE_TARGET_UNKNOWN", f"No topicgraph-{args.dataset}- generation named {index}")
    if row["role"] != "incomplete-owned":
        raise ContractError("RETIRE_TARGET_PROTECTED", f"{index} is {row['role']}; completed, exposed and unknown indexes are retained")
    owner = state.staging_owner(index)
    if owner["detail"]["binding"] != publication_binding(args, store.endpoint):
        raise ContractError("RETIRE_BINDING_MISMATCH", "Staging ownership belongs to another resource or corpus")
    if owner["generation_id"] != row["generation_id"]:
        raise ContractError("RETIRE_TARGET_PROTECTED", "This index holds another release's content")
    documents = store.readback(index)
    definition = store.index_client.get_index(index)
    definition = definition.as_dict() if callable(getattr(definition, "as_dict", None)) else dict(definition)
    data = {
        "version": RETIRE_PLAN_VERSION, "publication_version": PUBLICATION_VERSION,
        "binding": publication_binding(args, store.endpoint),
        "tenant_id": args.tenant_id, "subscription_id": args.subscription_id,
        "resource_group": args.resource_group, "search_service": args.search_service, "endpoint": store.endpoint,
        "dataset": args.dataset, "owner_plan_id": owner["plan_id"],
        "definition_digest": digest(definition), "inventory_digest": digest(sorted(documents, key=lambda d: d["id"])),
        "source_index": args.source_index, "index": index, "generation_id": owner["generation_id"],
        "document_count": row["document_count"], "storage_bytes": row["storage_bytes"],
    }
    grants = getattr(store, "reader_grants", None)
    readers = grants.list(index) if grants is not None else []
    if readers:
        grants.check_can_manage(index, REVOKE_ACTIONS)
        data["reader_grants"] = [{"principal_id": r["principal_id"], "role": r["role"],
                                  "assignment_id": r["assignment_id"]} for r in readers]
    planned = {"plan_id": digest(data), **data}
    state.record(planned["plan_id"], row.get("generation_id"), "retire-plan", "planned",
                 expected={"documents": row["document_count"]})
    return planned


def _check_plan(planned: dict[str, Any], plan_id: str, args: Any, endpoint: str) -> None:
    body = {key: value for key, value in planned.items() if key != "plan_id"}
    if planned.get("version") != RETIRE_PLAN_VERSION or digest(body) != plan_id or planned.get("plan_id") != plan_id:
        raise ContractError("PLAN_ID_MISMATCH", "Retire plan file does not match --plan-id")
    bound = {"tenant_id": args.tenant_id, "subscription_id": args.subscription_id,
             "resource_group": args.resource_group, "search_service": args.search_service, "endpoint": endpoint,
             "dataset": args.dataset, "source_index": args.source_index,
             "binding": publication_binding(args, endpoint)}
    if any(planned.get(key) != value for key, value in bound.items()):
        raise ContractError("RETIRE_BINDING_MISMATCH", "Retire plan was made for a different service, dataset or source")


def retire(store: Any, state: State, args: Any, planned: dict[str, Any], plan_id: str) -> dict[str, Any]:
    """Delete one owned unexposed staging index once; never reuse it."""
    _check_plan(planned, plan_id, args, store.endpoint)
    index = planned["index"]
    with state.publisher_lock():
        fresh = plan_retire(store, state, args, index)
        drift = [key for key in ("owner_plan_id", "definition_digest", "inventory_digest", "generation_id", "document_count", "reader_grants")
                 if fresh.get(key) != planned.get(key)]
        if drift:
            raise ContractError("RETIRE_PLAN_STALE", "Service changed since the retire plan: " + ", ".join(drift))
        state.record_write(plan_id, planned["generation_id"], "delete", "retire", index)
        try:
            store.index_client.delete_index(index)
        except Exception as exc:
            info = from_exception(exc)
            state.record_write(plan_id, planned["generation_id"], "delete", "retire", index,
                               status="ambiguous", error_code="RETIRE_DELETE_FAILED",
                               detail={"service_error": info} if info else None)
            raise ContractError("RETIRE_DELETE_FAILED", "Delete failed or outcome unknown; run generations before any retry",
                                service_error=info) from exc
        exists = store.target_exists(index)
        if exists:
            state.record_write(plan_id, planned["generation_id"], "delete", "retire", index,
                               status="failed", error_code="RETIRE_READBACK_FAILED")
            raise ContractError("RETIRE_READBACK_FAILED", "Index still exists after delete; reconcile before further action")
        state.record_write(plan_id, planned["generation_id"], "delete", "retire", index, status="confirmed")
        revoked = _revoke_readers(store, state, plan_id, planned, index)
    result = {"state": "retired", "index": index, "generation_id": planned["generation_id"],
              "readback": {"index_exists": False}}
    if revoked:
        result["readback"]["reader_grants_left"] = 0
        result["reader_grants_revoked"] = revoked
    return result


def reconcile_retire(store: Any, state: State, args: Any, planned: dict[str, Any]) -> dict[str, Any]:
    _check_plan(planned, planned["plan_id"], args, store.endpoint)
    with state.publisher_lock():
        exists = store.target_exists(planned["index"])
        remaining = store.reader_grants.list(planned["index"]) if store.reader_grants is not None else []
        result = {"index": planned["index"], "index_exists": exists, "reader_grants_left": len(remaining),
                  "recovery": "No automatic retry or reuse. Inspect the staging index and any remaining grants before separately approving recovery."}
        state.record_write(planned["plan_id"], planned["generation_id"], "reconcile", "retire-readback",
                           planned["index"], status="reconciled", detail=result)
        return result


def _revoke_readers(store: Any, state: State, plan_id: str, planned: dict[str, Any], index: str) -> int:
    """Deleting an index leaves its role assignments behind, so remove the planned ones and re-read."""
    rows = planned.get("reader_grants") or []
    if not rows:
        return 0
    generation = planned["generation_id"]
    for row in rows:
        state.record_write(plan_id, generation, "delete", "reader-revoke", index,
                           detail={"principal_id": row["principal_id"]})
        try:
            store.reader_grants.revoke(row["assignment_id"])
        except Exception as exc:
            info = from_exception(exc)
            state.record_write(plan_id, generation, "delete", "reader-revoke", index, status="ambiguous",
                               error_code="READER_REVOKE_FAILED", detail={"service_error": info} if info else None)
            error = ContractError("READER_REVOKE_FAILED", f"The index is gone, but removing the read grant for "
                                  f"{row['principal_id']} failed or its outcome is unknown"
                                  + (f" ({summary(info)})" if info else "") + ". Next step: check role "
                                  f"assignments on {index} and remove any that remain; don't rerun retire.")
            error.service_error = info
            raise error from exc
        state.record_write(plan_id, generation, "delete", "reader-revoke", index, status="confirmed")
    left = store.reader_grants.list(index)
    if left:
        raise ContractError("RETIRE_READBACK_FAILED", f"{len(left)} reader grant(s) still exist on {index}")
    return len(rows)
