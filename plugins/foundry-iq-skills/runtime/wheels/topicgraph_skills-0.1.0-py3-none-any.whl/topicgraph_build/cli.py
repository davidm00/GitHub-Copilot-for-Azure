"""topic-graph-build CLI: approval-gated Azure builds through the verified native executable."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

from topicgraph_build import approval_card
from topicgraph_build.cli_summary import (OUTPUT_ONLY, apply_command, browse_settings, fill_defaults,
                                          save_artifacts, summarize)
from topicgraph_build.execution import BuildService
from topicgraph_build.generations import RETIRE_PLAN_VERSION, list_generations, plan_retire, reconcile_retire, retire
from topicgraph_build.live import create_live_store
from topicgraph_build.planner import DEFAULT_MODEL_API_VERSION, approve_plan
from topicgraph_build.planner import plan as make_plan
from topicgraph_build.profiles import BUNDLED_PROFILES, load_profile
from topicgraph_build.reader_grants import GRANT_ACTIONS, reader, source_access_note
from topicgraph_core.cli_output import add_json_option, add_version_option, emit, emit_error
from topicgraph_core.doctor import emit_doctor
from topicgraph_core.contracts import (ContractError, Source, source_identity,
                                 canonical_json, digest)
from topicgraph_core.current import checked_current, publication_context, scope_of
from topicgraph_core.contracts import require_publication_version
from topicgraph_build.live import publication_binding
from topicgraph_core.service_errors import find
from topicgraph_core.source_names import discover_entity_names
from topicgraph_core.state import State


LIVE_REQUIRED = ["tenant_id", "subscription_id", "resource_group", "search_service", "source_index",
                 "key_field", "text_field", "vector_field", "embedding_model_id",
                 "dataset"]
MODEL_REQUIRED = ["model_endpoint", "model_deployment", "model_name"]


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="topic-graph-build",
        description="Preview TopicGraph native Build; gated live Azure requires explicit tenant/resource approvals."
    )
    parser.add_argument("--state-dir", type=Path, default=Path(".topicgraph-state"))
    parser.add_argument("--profile", default="build-config",
                        help=f"Build profile: a JSON file, or a bundled name ({', '.join(BUNDLED_PROFILES)})")
    parser.add_argument(
        "--backend", choices=["azure"], default="azure",
        help="Azure Search (Entra/RBAC only); topic generation requires the verified native executable",
    )
    parser.add_argument("--tenant-id", help="Azure tenant ID; no default identity tenant is assumed")
    parser.add_argument("--subscription-id", help="Azure subscription ID for the Search service")
    parser.add_argument("--resource-group", help="Azure resource group for the Search service")
    parser.add_argument("--search-service", help="Azure Search service name (not a URL)")
    parser.add_argument("--source-index", help="Physical source index name")
    parser.add_argument("--key-field", help="Source key field")
    parser.add_argument("--text-field", help="Source text field")
    parser.add_argument("--source-field", help="Optional source citation field, such as a document URL, kept as evidence")
    parser.add_argument("--title-field", help="Optional source title field used as labeling evidence")
    parser.add_argument("--vector-field", help="Source vector field")
    parser.add_argument("--embedding-model-id", help="Owner-provided embedding model identity")
    parser.add_argument("--dataset", help="Lowercase TopicGraph dataset slug used in target index names")
    parser.add_argument("--native-binary", type=Path, help="Explicit path to the topicgraph native binary for your platform")
    add_json_option(parser)
    add_version_option(parser)
    commands = parser.add_subparsers(dest="command", required=True)
    doctor = commands.add_parser("doctor", help="Read only: check this machine, sign-in, state, journal and reader access")
    doctor.add_argument("--model-endpoint", help="Also check this Azure OpenAI endpoint (metadata only)")
    doctor.add_argument("--model-deployment", help="Labeling deployment to check alongside --model-endpoint")
    doctor.add_argument("--model-resource-group",
                        help="Resource group of the Azure OpenAI account for the read-only ARM deployment check; "
                             "defaults to --resource-group")
    doctor.add_argument("--model-subscription-id",
                        help="Subscription ID of the Azure OpenAI account when different from --subscription-id")
    doctor.add_argument("--model-name",
                        help="Model to check for deprecation when the deployment doesn't exist yet: <name>-<version> or <name>")
    commands.add_parser("inspect")
    plan = commands.add_parser("plan", help="Read only: print the plan and save it under --state-dir/plans")
    readers = plan.add_argument_group(
        "reader grants (live only)",
        "Search Index Data Reader grants from the selected previous descriptor are carried to the new index. "
        "The reader set enters the plan ID.")
    readers.add_argument("--reader", action="append", default=[], metavar="PRINCIPAL_ID",
                         help="Also grant this principal object ID read access to the new index (repeatable)")
    readers.add_argument("--drop-reader", action="append", default=[], metavar="PRINCIPAL_ID",
                         help="Don't carry this principal's read access to the new index (repeatable)")
    readers.add_argument("--previous-descriptor", type=Path,
                         help="Previous physical descriptor for reader carry-forward; defaults to matching local current")
    model = plan.add_argument_group(
        "topic labeling model (live only)",
        "The build labels topics with this Azure OpenAI chat deployment, Entra auth only. The model settings "
        "and call cap enter the plan ID.")
    model.add_argument("--model-endpoint", help="Azure OpenAI endpoint URL")
    model.add_argument("--model-deployment", help="Chat deployment name")
    model.add_argument("--model-name", help="Model behind the deployment, such as gpt-4.1-mini")
    model.add_argument("--model-api-version", default=DEFAULT_MODEL_API_VERSION,
                       help=f"Azure OpenAI API version (default {DEFAULT_MODEL_API_VERSION})")
    model.add_argument("--model-call-cap", type=int,
                       help="Most labeling calls the build may make; defaults to about ten per expected leaf topic, "
                            "at least 50")
    apply = commands.add_parser("apply")
    apply.add_argument("--plan-id", required=True)
    apply.add_argument("--plan-file", type=Path, help="Defaults to the plan saved by plan in --state-dir")
    apply.add_argument("--confirm-writes", action="store_true", help="Required for --backend azure before any live write")
    apply.add_argument("--resume-after-reconcile", action="store_true", help="Resume a live plan after reconcile confirms unresolved writes")
    latest = "Defaults to the latest built generation in --state-dir"
    verify = commands.add_parser("verify")
    verify.add_argument("--generation-id", help=latest)
    publish = commands.add_parser("publish")
    publish.add_argument("--generation-id", help=latest)
    publish.add_argument("--approve-publish", action="store_true", help="Approve local descriptor selection, not a service-wide cutover")
    reconcile = commands.add_parser("reconcile")
    reconcile.add_argument("--plan-id")
    reconcile.add_argument("--plan-file", type=Path, help="Defaults to the saved plan named by --plan-id")
    commands.add_parser("status")
    commands.add_parser("generations", help="Live only, read only: list physical generations and retention protection")
    plan_retire = commands.add_parser("plan-retire", help="Plan deletion of one owned, unexposed incomplete staging index")
    plan_retire.add_argument("--index", required=True, help="Physical generation index to retire")
    for name in ("status", "generations", "plan-retire"):
        command = commands.choices[name]
        command.add_argument("--plan-id", help="Explicit saved build plan supplying this command's source authority")
        command.add_argument("--plan-file", type=Path, help="Exact build plan; otherwise loaded from --state-dir using --plan-id")
    retire = commands.add_parser("retire", help="Delete only the unexposed staging index in the approved retire plan")
    retire.add_argument("--plan-id", required=True)
    retire.add_argument("--plan-file", type=Path, help="Defaults to the retire plan saved by plan-retire")
    retire.add_argument("--confirm-writes", action="store_true", help="Required before the delete request")
    dl = commands.add_parser(
        "download-native",
        help="Check or download the TopicGraph native binary this plugin pins from Azure/foundry-iq-tool-releases into the per-user cache",
    )
    dl.add_argument("--plan-id", help="Exact download plan ID shown by the approval card")
    dl.add_argument("--approve-download", action="store_true", help="Confirm downloading and extracting the reviewed native release")
    dl.add_argument("--confirm-writes", action="store_true", help="Alias for --approve-download")
    for sub in commands.choices.values():
        add_json_option(sub, subcommand=True)
    return parser


def _reader_plan(args: argparse.Namespace, store: Any, publication: dict[str, Any]) -> dict[str, Any] | None:
    """Carry readers from the exact physical descriptor bound in the plan."""
    requested = [reader(pid) for pid in getattr(args, "reader", [])]
    dropped = sorted({reader(pid)["principal_id"] for pid in getattr(args, "drop_reader", [])})
    if set(dropped) & {row["principal_id"] for row in requested}:
        raise ContractError("READER_INVALID", "A reader cannot be requested and dropped in the same plan")
    grants = getattr(store, "reader_grants", None)
    previous = publication.get("previous_descriptor")
    current_index = previous["physical_index"] if previous else None
    if grants is None and (requested or current_index):
        raise ContractError("READER_GRANTS_UNSUPPORTED", "This backend can't grant readers")
    current = grants.list(current_index) if current_index else []
    carried = [{k: v for k, v in row.items() if k != "assignment_id"} for row in current if row["principal_id"] not in dropped]
    wanted: dict[tuple[str, str], dict[str, Any]] = {(r["principal_id"], r["role_definition_id"]): r for r in carried}
    for row in requested:
        wanted.setdefault((row["principal_id"], row["role_definition_id"]), row)
    if not wanted and not dropped:
        return None
    grant = [wanted[key] for key in sorted(wanted)]
    if grant:
        grants.check_can_manage(current_index or "the new index", GRANT_ACTIONS)
    approval = f"grant read access to {len(grant)} identit{'y' if len(grant) == 1 else 'ies'} on the new index"
    if grant:
        approval += f"; {source_access_note(args.source_index)}"
    return {"from_index": current_index, "grant": grant, "dropped": dropped, "source_index": args.source_index,
            "approval": approval}


def _plan_native_binary(args: argparse.Namespace, service: BuildService) -> dict[str, Any] | None:
    """Bind the native release at plan time, even when its verified binary is already cached."""
    from topicgraph_adapters.native_runner import NativeRunner

    runner = getattr(getattr(service, "native_adapter", None), "runner", None)
    if runner is not None and not isinstance(runner, NativeRunner):
        # An injected runner (tests) never executes a downloaded binary.
        return None
    runner = runner or NativeRunner(getattr(args, "native_binary", None))
    has_override = bool(
        getattr(args, "native_binary", None)
        or os.environ.get("TOPICGRAPH_BUILD_BINARY")
        or os.environ.get("TOPICGRAPH_NATIVE_BINARY")
    )
    if has_override:
        runner.resolve_and_verify()
        return None
    from topicgraph_adapters.native_download import REPOSITORY, inspect_pinned_release

    try:
        info = inspect_pinned_release()
    except ContractError:
        raise
    except (OSError, ValueError, KeyError) as exc:
        try:
            runner.resolve_and_verify()
            return None
        except ContractError:
            raise ContractError(
                "NATIVE_BINARY_NOT_FOUND",
                f"TopicGraph native binary is not installed and the pinned release from {REPOSITORY} "
                f"could not be resolved: {exc}",
            ) from exc
    return {
        "repository": info["repository"],
        "tag": info["tag"],
        "asset_name": info["asset_name"],
        "asset_url": info["asset_url"],
        "asset_digest": info["asset_digest"],
        "rid": info["rid"],
    }


def _live_plan(args: argparse.Namespace, service: BuildService, store: Any, source: Source,
               live: dict[str, Any], state: State) -> dict[str, Any]:
    """Bind the plan to the exact service, source definition, headroom, model and native release so apply can detect drift."""
    missing = ["--" + name.replace("_", "-") for name in MODEL_REQUIRED if not getattr(args, name, None)]
    if missing:
        raise ContractError("MODEL_ARGS_REQUIRED", "The build labels topics with a model; plan needs: " + ", ".join(missing))
    native_download = _plan_native_binary(args, service)
    inspected = service.inspect(source)
    profile = load_profile(args.profile)
    publication = publication_context(publication_binding(args, live["endpoint"]), args.previous_descriptor)
    fields = {"key": args.key_field, "text": args.text_field, "vector": args.vector_field,
              "title": args.title_field or None, "source": args.source_field or None}
    model = {"endpoint": args.model_endpoint, "deployment": args.model_deployment, "name": args.model_name,
             "api_version": args.model_api_version}
    base = make_plan(source, profile, target_service=source.service, fields=fields, model=model, dataset=args.dataset,
                     publication=publication, inspected=inspected, model_call_cap=args.model_call_cap)
    data = {k: v for k, v in base.items() if k != "plan_id"}
    source_binding = store.source_binding(inspected)
    data.update({
        "backend": "azure", "tenant_id": args.tenant_id, "subscription_id": args.subscription_id,
        "resource_group": args.resource_group, "search_service": args.search_service,
        "endpoint": live["endpoint"], "dataset": args.dataset,
        "source_binding": source_binding,
        "source_binding_digest": digest(source_binding),
        "warnings": inspected.get("warnings", []),
        "headroom": inspected.get("headroom"), "index_stats": inspected.get("index_stats"),
    })
    reader_grants = _reader_plan(args, store, publication)
    if reader_grants is not None:
        data["reader_grants"] = reader_grants
    names = discover_entity_names(source.service, source.index) if fields["source"] else None
    if names:
        data["source_names"] = names
    if native_download is not None:
        data["native_download"] = native_download
    result = {"plan_id": digest(data), **data}
    state.record(result["plan_id"], None, "plan", "planned", expected={"evidence": source.expected_count})
    return result


def _load_plan(path: Path) -> dict[str, Any]:
    """A plan file, without the display-only approval card an agent may have saved from --json output."""
    return {k: v for k, v in json.loads(path.read_text(encoding="utf-8")).items() if k not in OUTPUT_ONLY}


def _account(args: argparse.Namespace, live: dict[str, Any]) -> dict[str, Any]:
    return {"tenant_id": args.tenant_id, "subscription_id": args.subscription_id,
            "resource_group": args.resource_group, **live["names"]()}


def _run_azure(args: argparse.Namespace) -> dict[str, Any]:
    if args.command in ("apply", "retire") and not args.confirm_writes:
        raise ContractError("WRITE_CONFIRMATION_REQUIRED", f"Live {args.command} requires --confirm-writes before any Azure request")
    planned = _load_plan(args.plan_file) if args.command == "apply" else None
    state = State(args.state_dir / "operations")
    bound = planned
    if args.command in ("reconcile", "retire"):
        bound = _load_plan(args.plan_file)
    administrative = args.command in ("status", "generations", "plan-retire")
    if administrative and args.plan_file is not None:
        bound = _load_plan(args.plan_file)
        if not isinstance(bound.get("source"), dict) or "publication" not in bound:
            raise ContractError("PLAN_CHANGED", "Administrative source authority must be an exact saved build plan")
    if args.command in ("verify", "publish"):
        bound = state.generation(args.generation_id)
    if bound is not None and administrative:
        expected = args.plan_id or bound.get("plan_id")
        if bound.get("plan_id") != expected or digest({k: v for k, v in bound.items() if k != "plan_id"}) != expected:
            raise ContractError("PLAN_ID_MISMATCH", "Source authority must match the exact saved plan")
        require_publication_version(bound)
    missing = ["--" + name.replace("_", "-") for name in LIVE_REQUIRED if not getattr(args, name)]
    if missing:
        raise ContractError("AZURE_LIVE_ARGS_REQUIRED", "Missing required live Azure flags: " + ", ".join(missing))
    if args.command in ("apply", "reconcile", "retire"):
        require_publication_version(planned if planned is not None else _load_plan(args.plan_file))
    if args.command in ("verify", "publish"):
        require_publication_version(state.generation(args.generation_id))
    if planned is not None:
        approve_plan(planned, args.plan_id)
    store, source, live = create_live_store(args)
    if planned is not None and planned["publication"]["binding"] != publication_binding(args, live["endpoint"]):
        raise ContractError("PUBLISH_BINDING_MISMATCH", "Resource, dataset, source and vector field must match the approved plan")
    from topicgraph_adapters.native_adapter import NativeBuildAdapter
    from topicgraph_adapters.native_runner import NativeRunner

    service = BuildService(store, state, args.state_dir / "scratch",
                           native_adapter=NativeBuildAdapter(runner=NativeRunner(binary_path=args.native_binary)),
                           output_root=args.state_dir / "topicgraph-output")
    if args.command == "inspect":
        return service.inspect(source)
    if args.command == "plan":
        planned_now = _live_plan(args, service, store, source, live, state)
        command = apply_command(args.state_dir, planned_now["plan_id"])
        return {**planned_now, "approval_card": approval_card.for_apply(planned_now, _account(args, live)),
                "apply_command": command,
                "next_step": ("Show the card and ask one Approve/Stop question; after approval run "
                              "apply_command exactly, in this conversation, and wait. Never retype --state-dir.")}
    if planned is not None:
        if isinstance(planned.get("native_download"), dict):
            from topicgraph_adapters.native_download import ensure_cached_release
            receipt = ensure_cached_release(expected_spec=planned["native_download"])
            service.native_adapter.runner = NativeRunner(
                binary_path=Path(receipt["binary_path"]),
                expected_sha256=receipt["binary_sha256"],
            )
        low, high = approval_card.apply_minutes(planned)
        if not args.json:
            print(f"Starting now; this takes about {low}-{high} min. I'll report when it's done.",
                  file=sys.stderr, flush=True)
        return service.apply(planned, args.plan_id, resume_after_reconcile=args.resume_after_reconcile).to_dict()
    if args.command == "reconcile":
        recovery_plan = _load_plan(args.plan_file)
        if recovery_plan.get("version") == RETIRE_PLAN_VERSION:
            return reconcile_retire(store, state, args, recovery_plan)
        return service.reconcile(recovery_plan)
    if args.command == "verify":
        record = state.generation(args.generation_id)
        descriptor = record["descriptor"]
        counts = service.verify(args.generation_id, descriptor["physical_index"], source_identity(record["source"]))
        result = {"generation_id": args.generation_id, "counts": counts, "timings_ms": record.get("timings_ms", {}),
                  "release": record.get("release")}
        if "topicgraph_output" in record:
            result["topicgraph_output"] = record["topicgraph_output"]
        result["approval_card"] = approval_card.for_publish(args.generation_id, descriptor["physical_index"],
                                                            _account(args, live))
        return result
    if args.command == "publish":
        record = state.generation(args.generation_id)
        if record["publication"]["binding"] != publication_binding(args, live["endpoint"]):
            raise ContractError("PUBLISH_BINDING_MISMATCH", "Resource, dataset, source and vector field must match the approved plan")
        published = service.publish(args.generation_id, approved=args.approve_publish).to_dict()
        browse = browse_settings(args, published)
        browse["current"] = checked_current(scope_of(published))
        warnings = service.source_reader_warnings(args.generation_id)
        return {**published, "browse": browse, **({"warnings": warnings} if warnings else {}),
                "next_step": "Run browse.command exactly, in this conversation, to show the user the topics."}
    if args.command == "status":
        return service.status()
    if args.command == "generations":
        return list_generations(store, state, dataset=args.dataset, source_index=args.source_index)
    if args.command == "plan-retire":
        retire_plan = plan_retire(store, state, args, args.index)
        return {**retire_plan, "approval_card": approval_card.for_retire(retire_plan, _account(args, live))}
    if args.command == "retire":
        return retire(store, state, args, _load_plan(args.plan_file), args.plan_id)
    raise ContractError("COMMAND_UNSUPPORTED", args.command)


def _plan_bound_flags(parser: argparse.ArgumentParser, extras: list[str]) -> list[str]:
    """Plan-only options passed to apply: everything the plan subcommand defines that apply doesn't."""
    commands = next(a for a in parser._actions if isinstance(a, argparse._SubParsersAction))
    def options(name: str) -> set[str]:
        return {s for a in commands.choices[name]._actions for s in a.option_strings}
    plan_only = options("plan") - options("apply")
    return sorted({token.split("=", 1)[0] for token in extras if token.split("=", 1)[0] in plan_only})


def _arm_parts(resource_id: str | None) -> tuple[str | None, str | None]:
    parts = str(resource_id or "").split("/")
    lowered = [part.lower() for part in parts]
    group = parts[lowered.index("resourcegroups") + 1] if "resourcegroups" in lowered[:-1] else None
    return (parts[2] if len(parts) > 2 and lowered[1] == "subscriptions" else None), group


def _with_build_args(parser: argparse.ArgumentParser, argv: list[str]) -> list[str]:
    """Fill flags from ``--build-args <file>``, the binding Entity Graph connect saved.

    The run's Search service and chat deployment are reused, so nobody retypes or re-picks them.
    Flags given on the command line win.
    """
    if "--build-args" not in argv:
        return argv
    at = argv.index("--build-args")
    if at + 1 >= len(argv):
        raise ContractError("INPUT_INVALID", "--build-args needs the file connect saved, such as .entity/build-args.json")
    rest = argv[:at] + argv[at + 2:]
    try:
        data = json.loads(Path(argv[at + 1]).read_text(encoding="utf-8"))
        target = data["target"]
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise ContractError("INPUT_INVALID", f"--build-args {argv[at + 1]} isn't a build-args file from "
                            f"entity-graph-provision connect ({exc})") from exc
    endpoint = str(target.get("search_endpoint") or "")
    model_sub, model_group = _arm_parts(target.get("chat_openai_resource_id") or target.get("openai_resource_id"))
    front = {"--tenant-id": data.get("tenant_id"), "--subscription-id": target.get("subscription_id"),
             "--resource-group": target.get("resource_group"),
             "--search-service": endpoint.split("//")[-1].split(".")[0] or None,
             "--embedding-model-id": data.get("embedding_model")}
    after = {"--model-endpoint": target.get("chat_openai_endpoint") or target.get("openai_endpoint"),
             "--model-deployment": data.get("chat_deployment"), "--model-name": data.get("chat_model"),
             "--model-resource-group": model_group, "--model-subscription-id": model_sub}
    commands = next(a.choices for a in parser._actions if isinstance(a, argparse._SubParsersAction))
    index = next((i for i, token in enumerate(rest) if token in commands), None)
    known = set(commands[rest[index]]._option_string_actions) if index is not None else set()
    given = {token for token in rest if token.startswith("--")}
    head = [part for flag, value in front.items() if value and flag not in given for part in (flag, str(value))]
    tail = [part for flag, value in after.items()
            if value and flag in known and flag not in given for part in (flag, str(value))]
    if index is None:
        return head + rest
    return head + rest[:index + 1] + tail + rest[index + 1:]


def _parse(argv: list[str]) -> argparse.Namespace:
    parser = _parser()
    argv = _with_build_args(parser, argv)
    args, extras = parser.parse_known_args(argv)
    if extras and getattr(args, "command", None) == "apply":
        bound = _plan_bound_flags(parser, extras)
        if bound:
            raise ContractError(
                "PLAN_BOUND_FLAG",
                f"{', '.join(bound)} {'is' if len(bound) == 1 else 'are'} bound by plan {args.plan_id}; "
                "apply reads model and reader settings from the saved plan, so drop them from the apply command")
    return parser.parse_args(argv)


def _run_download_native(args: argparse.Namespace) -> dict[str, Any]:
    from topicgraph_adapters.native_download import ensure_cached_release, inspect_pinned_release

    try:
        info = inspect_pinned_release()
    except ContractError:
        raise
    except (OSError, ValueError, KeyError) as exc:
        raise ContractError("NATIVE_RELEASE_NOT_FOUND", str(exc)) from exc

    approved = bool(getattr(args, "approve_download", False) or getattr(args, "confirm_writes", False))
    if info["cached"] and not approved:
        receipt = info["receipt"]
        return {**receipt, "status": "ready", "reused": True, "plan_id": info["plan_id"]}
    if not approved:
        return {
            **{k: v for k, v in info.items() if k != "receipt"},
            "status": "needs_approval",
            "reused": False,
            "approval_card": approval_card.for_native_download(info),
        }
    if not getattr(args, "plan_id", None):
        raise ContractError("PLAN_ID_REQUIRED", "download-native with --approve-download requires --plan-id")
    if args.plan_id != info["plan_id"]:
        raise ContractError(
            "PLAN_ID_MISMATCH",
            f"--plan-id {args.plan_id} does not match current release plan {info['plan_id']}",
        )
    try:
        receipt = ensure_cached_release(expected_spec=info)
    except ContractError:
        raise
    except (OSError, ValueError, KeyError) as exc:
        raise ContractError("NATIVE_DOWNLOAD_FAILED", str(exc)) from exc
    return {**receipt, "status": "ready", "plan_id": info["plan_id"]}


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else list(argv)
    try:
        args = _parse(argv)
    except ContractError as exc:
        return emit_error(exc, "--json" in argv, "INPUT_INVALID")
    try:
        fill_defaults(args)
        if args.command == "doctor":
            from topicgraph_build.doctor import run_doctor

            return emit_doctor(run_doctor(args), args.json, "topic-graph-build")
        if args.command == "download-native":
            result = _run_download_native(args)
            emit(result, args.json, lambda r: summarize(args, argv, r) or canonical_json(r))
            return 0
        result = _run_azure(args)
        save_artifacts(args, result)
        emit(result, args.json, lambda r: summarize(args, argv, r) or canonical_json(r))
        return 0
    except (ContractError, ValueError, OSError, KeyError) as exc:
        return emit_error(exc, args.json, "INPUT_INVALID")
    except Exception as exc:  # an SDK error the service answered: report what it said instead of a traceback
        if find(exc) is None:
            raise
        return emit_error(exc, args.json, "CLI_ERROR")


if __name__ == "__main__":
    raise SystemExit(main())
