"""Runner for the TopicGraph build executable published at Azure/foundry-iq-tool-releases.

Resolves the self-contained executable for the host platform, verifies its SHA-256
against the recorded download receipt, and runs `--version`, `preflight`, `build` and `cleanup` without a shell.
The exit code decides the outcome; machine-readable state is read only from
`<outputDirectory>/topicGraph/run-manifest.json`, never from stdout.
"""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from topicgraph_core.contracts import ContractError

from .native_download import (
    REPOSITORY as RELEASE_REPOSITORY,
    SUPPORTED_RIDS,
    _parse_checksums_file,
    binary_filename,
    read_cached_receipt,
)

# No binary SHA-256 is pinned here: verification uses the receipt recorded when the GitHub
# release was downloaded, or an explicit expected_sha256 (tests may populate this table).
NATIVE_BINARY_SHA256_BY_RID: dict[str, str] = {}
BUILD_SUBDIRECTORY = "topicGraph"
RUN_MANIFEST = "run-manifest.json"
LINUX_PACKAGE_BINARY = Path("/usr/bin/topicgraph")
CONFIG_ROOT_KEYS = {"search", "authentication", "models", "credentials", "execution", "outputDirectory"}
MODEL_PARAMETERS = ("resourceUri", "deploymentId", "modelName", "modelApiVersion")
EXIT_ERROR_CODES = {
    1: "NATIVE_EXECUTION_FAILED",
    2: "NATIVE_USAGE_ERROR",
    130: "NATIVE_CANCELLED",
}


def get_host_rid() -> str:
    """Return the .NET runtime identifier for this host."""
    machine = platform.machine().lower()
    architecture = {
        "amd64": "x64",
        "x86_64": "x64",
        "x64": "x64",
        "aarch64": "arm64",
        "arm64": "arm64",
    }.get(machine)
    operating_system = {
        "win32": "win",
        "linux": "linux",
        "darwin": "osx",
    }.get(sys.platform)
    if f"{operating_system}-{architecture}" not in SUPPORTED_RIDS:
        raise ContractError(
            "NATIVE_PLATFORM_UNSUPPORTED",
            f"No TopicGraph build supports platform {sys.platform!r} "
            f"with architecture {machine!r}.",
        )
    return f"{operating_system}-{architecture}"


def binary_name_for(rid: str) -> str:
    return binary_filename(rid)


def build_directory(output_directory: Path) -> Path:
    """Directory the executable owns for checkpoints, logs and releases."""
    return Path(output_directory) / BUILD_SUBDIRECTORY


def config_output_directory(config_path: Path) -> Path | None:
    """Resolve `outputDirectory` from a config file, relative to the file as the executable does."""
    try:
        data = json.loads(Path(config_path).read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError):
        return None
    value = data.get("outputDirectory") if isinstance(data, dict) else None
    if not isinstance(value, str) or not value.strip():
        return None
    path = Path(value)
    return path if path.is_absolute() else Path(config_path).parent / path


@dataclass(frozen=True)
class NativeCliResult:
    """Outcome of one TopicGraph executable invocation."""

    command: str  # "preflight" | "build" | "cleanup"
    exit_code: int
    data: dict[str, Any] | None  # run-manifest.json after a successful run
    error_code: str | None
    error: str | None
    stdout: str
    stderr: str
    support_log_path: Path | None = None
    manifest_path: Path | None = None

    @property
    def succeeded(self) -> bool:
        return self.exit_code == 0


def compute_binary_sha256(path: Path) -> str:
    """Compute uppercase SHA-256 hex digest of a binary file."""
    hasher = hashlib.sha256()
    with open(path, "rb") as stream:
        while chunk := stream.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest().upper()


def _receipt_hash_for_binary(path: Path, rid: str) -> str | None:
    resolved = path.resolve()
    parent = resolved.parent
    for _ in range(5):
        candidate_receipt = parent / "receipt.json"
        if candidate_receipt.is_file():
            try:
                data = json.loads(candidate_receipt.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                data = None
            if (
                isinstance(data, dict)
                and (
                    data.get("schema_version") == 1
                    or data.get("version") in (1, "topicgraph-native-receipt-v1")
                )
                and data.get("repository") == RELEASE_REPOSITORY
                and (
                    "asset_digest" not in data
                    or (isinstance(data.get("asset_digest"), str) and data["asset_digest"].startswith("sha256:"))
                )
                and isinstance(data.get("binary_sha256"), str)
                and isinstance(data.get("binary_path"), str)
                and Path(data["binary_path"]).resolve() == resolved
            ):
                return data["binary_sha256"].upper()
        if parent.parent == parent:
            break
        parent = parent.parent

    try:
        cached = read_cached_receipt(rid)
    except Exception:
        cached = None
    if cached and Path(cached["binary_path"]).resolve() == resolved:
        return str(cached["binary_sha256"]).upper()

    checksums = _parse_checksums_file(resolved.parent / "checksums.sha256")
    if resolved.name in checksums:
        return checksums[resolved.name].upper()
    return None


def resolve_binary_path(path: Path | str | None = None) -> Path:
    """Resolve the host's TopicGraph binary, in priority order.

    Checks:
    1. Explicit path parameter if provided.
    2. Environment variable TOPICGRAPH_BUILD_BINARY or TOPICGRAPH_NATIVE_BINARY.
    3. Verified per-user cached GitHub release receipt for the host RID.
    4. On Linux, the installed package at /usr/bin/topicgraph.
    5. PATH via the host's binary name.

    Missing candidates fall through to the next location.
    """
    rid = get_host_rid()
    binary_name = binary_filename(rid)
    candidates: list[Path] = []
    if path is not None:
        candidates.append(Path(path))

    for variable in ("TOPICGRAPH_BUILD_BINARY", "TOPICGRAPH_NATIVE_BINARY"):
        env_path = os.environ.get(variable)
        if env_path:
            candidates.append(Path(env_path))

    try:
        cached = read_cached_receipt(rid)
    except Exception:
        cached = None
    if cached and isinstance(cached.get("binary_path"), str):
        candidates.append(Path(cached["binary_path"]))
    if rid.startswith("linux-"):
        candidates.append(LINUX_PACKAGE_BINARY)

    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()

    which_binary = shutil.which(binary_name)
    if which_binary:
        candidate = Path(which_binary)
        candidates.append(candidate)
        if candidate.is_file():
            return candidate.resolve()

    raise ContractError(
        "NATIVE_BINARY_NOT_FOUND",
        f"TopicGraph native binary for {rid} not found. "
        f"Checked: {[str(c) for c in candidates]} and PATH for {binary_name}. "
        f"Run `topic-graph-build download-native` or `topic-graph-build plan` to download the pinned release from {RELEASE_REPOSITORY}.",
    )


def verify_binary(path: Path, expected_sha256: str | None = None) -> str:
    """Verify an explicit SHA-256, a recorded GitHub release receipt, or a test RID override."""
    if not path.is_file():
        raise ContractError(
            "NATIVE_BINARY_NOT_FOUND", f"Binary file does not exist: {path}"
        )
    rid = get_host_rid()
    allowed_hashes: set[str] = set()
    if expected_sha256 is None:
        receipt_hash = _receipt_hash_for_binary(path, rid)
        if receipt_hash:
            allowed_hashes.add(receipt_hash.upper())
        for table in (NATIVE_BINARY_SHA256_BY_RID,):
            if rid in table and table[rid]:
                allowed_hashes.add(table[rid].upper())
        if not allowed_hashes:
            raise ContractError(
                "NATIVE_BINARY_CHECKSUM_REQUIRED",
                f"No verified release receipt or expected SHA-256 is recorded for {path} ({rid}). "
                f"Download a verified release from {RELEASE_REPOSITORY} or supply expected_sha256.",
            )
    else:
        clean = expected_sha256.removeprefix("sha256:").removeprefix("SHA256:").upper()
        allowed_hashes.add(clean)
    try:
        actual_hash = compute_binary_sha256(path)
    except OSError as exc:
        raise ContractError(
            "NATIVE_BINARY_UNREADABLE", f"Cannot read native binary: {exc}"
        ) from exc
    if actual_hash.upper() not in allowed_hashes:
        expected_str = expected_sha256 or next(iter(sorted(allowed_hashes)), "")
        raise ContractError(
            "BINARY_HASH_MISMATCH",
            f"Native binary SHA-256 mismatch. Expected {expected_str}, got {actual_hash}",
        )
    return actual_hash


def validate_native_config(config: dict[str, Any] | Path) -> dict[str, Any]:
    """Validate the required fields of a nested TopicGraph configuration."""
    if isinstance(config, Path):
        try:
            with open(config, "r", encoding="utf-8-sig") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as exc:
            raise ContractError(
                "CONFIG_INVALID", f"Cannot load configuration file: {exc}"
            ) from exc
    elif isinstance(config, dict):
        data = config
    else:
        raise ContractError(
            "CONFIG_INVALID", "Configuration must be a dict or Path to JSON file"
        )

    if not isinstance(data, dict):
        raise ContractError("CONFIG_INVALID", "Configuration must be a JSON object")
    unknown = sorted(set(data) - CONFIG_ROOT_KEYS)
    if unknown:
        raise ContractError("CONFIG_INVALID", f"Unknown configuration keys: {', '.join(unknown)}")
    search = data.get("search")
    if not isinstance(search, dict):
        raise ContractError(
            "CONFIG_INVALID", "Configuration missing required 'search' section"
        )
    for field in ("endpoint", "sourceIndex", "vectorField"):
        val = search.get(field)
        if not isinstance(val, str) or not val.strip():
            raise ContractError(
                "CONFIG_INVALID", f"search.{field} must be a non-empty string"
            )

    auth = data.get("authentication")
    if not isinstance(auth, dict) or "mode" not in auth:
        raise ContractError(
            "CONFIG_INVALID", "Configuration missing 'authentication.mode'"
        )

    models = data.get("models")
    if models is not None:
        if not isinstance(models, list) or len(models) > 1:
            raise ContractError("CONFIG_INVALID", "models must be a list with at most one entry")
        for model in models:
            params = model.get("azureOpenAIParameters") if isinstance(model, dict) else None
            if (not isinstance(model, dict) or model.get("kind") != "azureOpenAI" or not isinstance(params, dict)
                    or any(not isinstance(params.get(k), str) or not params[k].strip() for k in MODEL_PARAMETERS)):
                raise ContractError("CONFIG_INVALID", "Each model needs kind azureOpenAI and non-empty "
                                    + ", ".join(MODEL_PARAMETERS))

    credentials = data.get("credentials")
    if credentials is not None and not isinstance(credentials, dict):
        raise ContractError("CONFIG_INVALID", "credentials must be an object")

    execution = data.get("execution")
    if execution is not None and (
        not isinstance(execution, dict)
        or not set(execution) <= {"topicGraph", "sitemap"}
        or any(not isinstance(execution[key], dict) for key in execution)
    ):
        raise ContractError(
            "CONFIG_INVALID", "execution may only contain the 'topicGraph' and 'sitemap' sections"
        )

    output_dir = data.get("outputDirectory")
    if not isinstance(output_dir, str) or not output_dir.strip():
        raise ContractError(
            "CONFIG_INVALID", "Configuration missing top-level 'outputDirectory'"
        )

    return data


def find_support_log(output_directory: Path | None) -> Path | None:
    """Return the newest build log under `topicGraph/logs`, if any."""
    if output_directory is None:
        return None
    logs_dir = build_directory(output_directory) / "logs"
    if not logs_dir.is_dir():
        return None
    logs = sorted(logs_dir.glob("topicgraph-*.log"), key=os.path.getmtime)
    return logs[-1] if logs else None


def read_run_manifest(output_directory: Path) -> tuple[Path, dict[str, Any]]:
    """Read and minimally validate `topicGraph/run-manifest.json`."""
    manifest_path = build_directory(output_directory) / RUN_MANIFEST
    if not manifest_path.is_file():
        raise ContractError(
            "NATIVE_ARTIFACTS_MISSING", f"Missing {BUILD_SUBDIRECTORY}/{RUN_MANIFEST} in {output_directory}"
        )
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ContractError("NATIVE_ARTIFACTS_INVALID", f"Cannot read {manifest_path}: {exc}") from exc
    if not isinstance(data, dict):
        raise ContractError("NATIVE_ARTIFACTS_INVALID", f"{manifest_path} must contain a JSON object")
    return manifest_path, data


class NativeRunner:
    """Runs TopicGraph executable commands."""

    def __init__(
        self,
        binary_path: Path | str | None = None,
        expected_sha256: str | None = None,
        verify_on_init: bool = False,
    ):
        """Verify against an explicit trusted checksum or the packaged host pin."""
        self._binary_path: Path | None = None
        self._raw_path = binary_path
        self._expected_sha256 = expected_sha256
        if verify_on_init:
            self.resolve_and_verify()

    @property
    def binary_path(self) -> Path:
        if self._binary_path is None:
            self._binary_path = resolve_binary_path(self._raw_path)
        return self._binary_path

    def resolve_and_verify(self) -> Path:
        """Resolve path and verify SHA-256."""
        path = self.binary_path
        verify_binary(path, self._expected_sha256)
        if sys.platform != "win32" and not os.access(path, os.X_OK):
            raise ContractError(
                "NATIVE_BINARY_NOT_EXECUTABLE",
                f"TopicGraph executable is not executable: {path}. "
                "Grant execute permission (chmod +x) before running it.",
            )
        return path

    def version(self, timeout: float = 15.0) -> str:
        """Invoke `<binary> --version` and return the trimmed version string."""
        binary = self.resolve_and_verify()
        try:
            proc = subprocess.run(
                [str(binary), "--version"],
                shell=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
            )
        except subprocess.TimeoutExpired as exc:
            raise ContractError("NATIVE_EXECUTION_TIMEOUT", "topicgraph --version timed out") from exc
        except OSError as exc:
            raise ContractError("NATIVE_EXECUTION_FAILED", f"Failed to execute topicgraph --version: {exc}") from exc
        if proc.returncode != 0:
            raise ContractError("NATIVE_EXECUTION_FAILED", f"topicgraph --version failed (exit {proc.returncode}): {proc.stderr}")
        return (proc.stdout or "").strip()

    def run(
        self,
        command: str,
        config_path: Path | str,
        extra_flags: list[str] | None = None,
        timeout: float | None = 600.0,
        cwd: Path | None = None,
        env: dict[str, str] | None = None,
    ) -> NativeCliResult:
        """Run `preflight`, `build` or `cleanup` with `--config` and return the exit-code outcome.

        ``env`` overlays the inherited environment, so a search token never has to be written to disk.
        """
        if command not in ("preflight", "build", "cleanup"):
            raise ContractError(
                "NATIVE_COMMAND_UNSUPPORTED",
                f"Unsupported TopicGraph command '{command}'. Must be preflight, build, or cleanup.",
            )
        config_path = Path(config_path).resolve()
        if not config_path.is_file():
            raise ContractError("CONFIG_INVALID", f"Configuration file not found: {config_path}")
        binary = self.resolve_and_verify()
        args = [str(binary), command, "--config", str(config_path), *(extra_flags or [])]
        try:
            proc = subprocess.run(
                args,
                shell=False,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                cwd=cwd,
                env={**os.environ, **env} if env else None,
            )
        except subprocess.TimeoutExpired as exc:
            raise ContractError(
                "NATIVE_EXECUTION_TIMEOUT",
                f"topicgraph {command} timed out after {timeout} seconds; "
                "committed work is kept, so rerun with resume and run cleanup if asked",
            ) from exc
        except OSError as exc:
            raise ContractError(
                "NATIVE_EXECUTION_FAILED",
                f"Failed to execute TopicGraph executable: {exc}",
            ) from exc

        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
        output_dir = config_output_directory(config_path)
        manifest_path: Path | None = None
        manifest_data: dict[str, Any] | None = None
        if proc.returncode == 0 and output_dir is not None and (build_directory(output_dir) / RUN_MANIFEST).is_file():
            manifest_path, manifest_data = read_run_manifest(output_dir)
        error_code = None if proc.returncode == 0 else EXIT_ERROR_CODES.get(proc.returncode, "NATIVE_INTERNAL_FAILURE")
        return NativeCliResult(
            command=command,
            exit_code=proc.returncode,
            data=manifest_data,
            error_code=error_code,
            error=None if proc.returncode == 0 else (stderr.strip() or stdout.strip()[-2000:]),
            stdout=stdout,
            stderr=stderr,
            support_log_path=find_support_log(output_dir),
            manifest_path=manifest_path,
        )

    def preflight(self, config_path: Path | str, timeout: float | None = 600.0,
                  env: dict[str, str] | None = None) -> NativeCliResult:
        return self.run("preflight", config_path, timeout=timeout, env=env)

    def build(self, config_path: Path | str, *, resume: bool = False, extra_flags: list[str] | None = None,
              env: dict[str, str] | None = None, timeout: float | None = None) -> NativeCliResult:
        """``build`` needs exactly one of ``--fresh``/``--resume``; resuming a completed build verifies and reuses it."""
        flags = ["--resume" if resume else "--fresh", *(extra_flags or [])]
        return self.run("build", config_path, extra_flags=flags, timeout=timeout, env=env)

    def cleanup(self, config_path: Path | str, timeout: float | None = 600.0,
                env: dict[str, str] | None = None) -> NativeCliResult:
        return self.run("cleanup", config_path, timeout=timeout, env=env)
