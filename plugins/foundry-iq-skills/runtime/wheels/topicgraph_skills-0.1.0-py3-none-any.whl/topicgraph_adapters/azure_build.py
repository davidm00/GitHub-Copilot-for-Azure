"""Connect separately authorized Search source and publisher adapters."""

from __future__ import annotations

from typing import Any

from topicgraph_adapters.azure_publication import AzurePublicationAdapter
from topicgraph_adapters.azure_source import AzureSourceAdapter
from topicgraph_core.contracts import ContractError, Source


class AzureBuildStore:
    def __init__(self, source: AzureSourceAdapter, publisher: AzurePublicationAdapter):
        if source.approval.resource != publisher.approval.resource or source.approval.tenant != publisher.approval.tenant:
            raise ContractError("PLACEMENT_UNSUPPORTED", "Cross-service/tenant publication is not validated")
        self.source = source
        self.publisher = publisher

    def inspect(self, identity: Source) -> dict[str, Any]:
        return self.source.inspect(identity)

    def generation_index_name(self, content_id: str) -> str:
        dataset = self.publisher.approval.dataset
        if not dataset or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in dataset):
            raise ContractError("PUBLICATION_TARGET_INVALID", "Approved dataset must be a Search-safe lowercase slug")
        if not content_id or any(c not in "0123456789abcdef" for c in content_id):
            raise ContractError("PUBLICATION_TARGET_INVALID", "Release content identity must be lowercase hex")
        name = f"topicgraph-{dataset}-{content_id}"
        if len(name) > 128:
            raise ContractError("PUBLICATION_TARGET_INVALID", "Generated index name exceeds Search limit")
        return name

    def create_generation_index(self, index: str, schema: dict[str, Any]) -> dict[str, Any]:
        return self.publisher.create_generation_index(index, schema)

    def upload_batch(self, index: str, documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
        return self.publisher.upload_batch(index, documents)

    def readback(self, index: str) -> list[dict[str, Any]]:
        return self.publisher.readback(index)

    def verify(self, index: str, expected: list[dict[str, Any]]) -> str:
        return self.publisher.verify(index, expected)
