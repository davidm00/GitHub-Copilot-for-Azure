"""Approval-gated publisher of TopicGraph releases into new Azure AI Search indexes.

The release schema is opaque: it is copied, named and created with a raw REST call, because the SDK
index model drops properties such as ``graphProfile``. Only ``object_vector`` is changed, to retrievable,
so readers can fetch topic centroids.
"""

from __future__ import annotations

import copy
import json
import math
import time
from dataclasses import dataclass
from typing import Any

from topicgraph_core.contracts import ContractError, digest
from topicgraph_core.service_errors import describe, from_exception, from_response

from .azure_source import get_field

# Leave 1 MiB below Search's 16 MiB request limit for SDK serialization changes.
MAX_UPLOAD_BYTES = 15 * 1024 * 1024
INDEX_API_VERSION = "2026-11-01-preview"
KEY_FIELD = "id"
VECTOR_FIELD = "object_vector"
VECTOR_TOLERANCE = 1e-6
UPLOAD_ROUTE_ATTEMPTS = 3


def _upload_batches(documents: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    envelope_bytes = len(b'{"value": []}')
    batches: list[list[dict[str, Any]]] = []
    batch: list[dict[str, Any]] = []
    size = envelope_bytes
    for doc in documents:
        try:
            action_bytes = len(json.dumps(
                {"@search.action": "upload", **doc}, ensure_ascii=True, allow_nan=False,
            ).encode("utf-8"))
        except (TypeError, ValueError) as exc:
            raise ContractError("RELEASE_DOCUMENT_INVALID",
                                f"Document {doc[KEY_FIELD]!r} cannot encode as finite JSON") from exc
        if envelope_bytes + action_bytes > MAX_UPLOAD_BYTES:
            raise ContractError("PUBLICATION_DOCUMENT_TOO_LARGE",
                                f"Document {doc[KEY_FIELD]!r} exceeds the {MAX_UPLOAD_BYTES}-byte request limit")
        added = action_bytes + (2 if batch else 0)
        if size + added > MAX_UPLOAD_BYTES:
            batches.append(batch)
            batch, size, added = [], envelope_bytes, action_bytes
        batch.append(doc)
        size += added
    if batch:
        batches.append(batch)
    return batches


def normalize(doc: dict[str, Any]) -> dict[str, Any]:
    """The comparable content of a document: no ``@search.*`` annotations and no empty values."""
    return {key: value for key, value in doc.items()
            if not key.startswith("@search.") and value is not None and value != "" and value != []}


def index_definition(index: str, schema: dict[str, Any]) -> dict[str, Any]:
    """The release schema named for ``index``, with centroid vectors made retrievable."""
    if "name" in schema:
        raise ContractError("RELEASE_INVALID", "Release schema must not name its index")
    definition = copy.deepcopy(schema)
    definition["name"] = index
    vectors = [field for field in definition.get("fields") or [] if field.get("name") == VECTOR_FIELD]
    if len(vectors) != 1:
        raise ContractError("RELEASE_INVALID", f"Release schema needs exactly one {VECTOR_FIELD} field")
    vectors[0]["retrievable"] = True
    return definition


@dataclass(frozen=True)
class PublicationApproval:
    tenant: str
    resource: str
    dataset: str
    replication_approval: str
    write_approval: str


def _status(exc: Exception) -> int | None:
    return get_field(exc, "status_code", get_field(get_field(exc, "response"), "status_code"))


def _denied(operation: str, exc: BaseException | None = None) -> ContractError:
    return ContractError("PUBLICATION_PERMISSION_DENIED", f"Insufficient Search rights for {operation}",
                         service_error=from_exception(exc))


def _is_sdk_client(client: Any) -> bool:
    return type(client).__module__.startswith("azure.")


def _literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


class AzurePublicationAdapter:
    """Injected index admin and document-client factory, with no credential creation.

    Builds immutable physical indexes only. Descriptor publication is local
    and requires no Search routing mutation.
    """

    def __init__(
        self, index_client: Any, search_client_factory: Any,
        *, approval: PublicationApproval, batch_size: int = 500,
    ):
        if not 1 <= batch_size <= 1000:
            raise ContractError("PUBLICATION_BATCH_INVALID", "Batch size must be 1..1000")
        self.index_client = index_client
        self.search_client_factory = search_client_factory
        self.approval = approval
        self.batch_size = batch_size
        self.confirmed_ids: set[str] = set()
        self.verified_indexes: set[str] = set()
        self.verified_fingerprints: dict[str, str] = {}

    def _approve(self, index: str, *, write: bool = True) -> None:
        a = self.approval
        required = [a.tenant, a.resource, a.dataset]
        if write:
            required += [a.replication_approval, a.write_approval]
        if not all(required):
            raise ContractError("PUBLICATION_APPROVAL_REQUIRED", "Named tenant/service/dataset, replication and write approvals required")
        planned_prefix = f"topicgraph-{a.dataset}-"
        if not index.startswith("topicgraph-") or not (index.startswith(planned_prefix) and index[len(planned_prefix):]):
            raise ContractError("PUBLICATION_TARGET_MISMATCH", "Physical generation index must belong to the approved dataset")

    def search_client(self, index: str) -> Any:
        client = self.search_client_factory(index)
        bound = get_field(client, "index_name")
        if bound is not None and bound != index:
            raise ContractError("PUBLICATION_TARGET_MISMATCH", "Document client bound to wrong physical index")
        return client

    def create_generation_index(self, index: str, schema: dict[str, Any]) -> dict[str, Any]:
        self._approve(index)
        definition = index_definition(index, schema)
        try:
            self.index_client.get_index(index)
        except Exception as exc:
            if _status(exc) != 404:
                raise _denied("index inspection", exc) from exc
        else:
            raise ContractError("GENERATION_EXISTS", "Never overwrite an existing generation index; verify exact retries instead")
        try:
            if _is_sdk_client(self.index_client):
                from azure.core.rest import HttpRequest

                request = HttpRequest("PUT", f"/indexes({_literal(index)})", params={"api-version": INDEX_API_VERSION},
                                      headers={"If-None-Match": "*"}, json=definition)
                response = self.index_client.send_request(request)
                if response.status_code not in (200, 201):
                    raise ContractError("PUBLICATION_PERMISSION_DENIED",
                                        f"Index creation returned HTTP {response.status_code}",
                                        service_error=from_response(response))
            else:
                self.index_client.create_index(definition)
            observed = self.index_client.get_index(index)
        except ContractError:
            raise
        except Exception as exc:
            raise _denied("index creation/readback", exc) from exc
        if get_field(observed, "name") != index:
            raise ContractError("PUBLICATION_SCHEMA_MISMATCH", "Created index does not match the requested name")
        return definition

    def upload_batch(self, index: str, documents: list[dict[str, Any]]) -> list[dict[str, Any]]:
        self._approve(index)
        if not documents or len(documents) > self.batch_size:
            raise ContractError("PUBLICATION_BATCH_INVALID", "Supply a nonempty bounded document batch")
        if any(doc.get("@search.action", "upload") != "upload" for doc in documents):
            raise ContractError("RELEASE_DOCUMENT_INVALID", "Release documents may only be uploaded")
        # upload_documents adds the upload action itself; release files carry it for raw REST publishers.
        prepared = [{key: value for key, value in doc.items() if key != "@search.action"} for doc in documents]
        ids = [doc.get(KEY_FIELD) for doc in prepared]
        if any(not isinstance(key, str) or not key for key in ids):
            raise ContractError("RELEASE_DOCUMENT_INVALID", "Every document needs an id")
        if len(set(ids)) != len(ids) or any(key in self.confirmed_ids for key in ids):
            raise ContractError("RELEASE_DOCUMENT_INVALID", "Duplicate or previously confirmed document ID")
        client = self.search_client(index)
        results: dict[str, dict[str, Any]] = {}
        for batch in _upload_batches(prepared):
            confirmed = self._upload_once(client, batch)
            self.confirmed_ids.update(confirmed)
            results.update(confirmed)
        return [results[key] for key in ids]

    @staticmethod
    def _upload_once(client: Any, prepared: list[dict[str, Any]], key_field: str = KEY_FIELD) -> dict[str, dict[str, Any]]:
        """One attempt per batch, except 404s while a just-created index's route propagates (nothing was written).

        Any other failure is final and left for the journal and reconcile to resolve.
        """
        for attempt in range(UPLOAD_ROUTE_ATTEMPTS):
            try:
                response = list(client.upload_documents(documents=prepared))
                break
            except Exception as exc:
                if _status(exc) == 404 and attempt + 1 < UPLOAD_ROUTE_ATTEMPTS:
                    time.sleep(2 ** attempt)
                    continue
                raise ContractError("PUBLICATION_UPLOAD_FAILED", "Upload failed; no unconfirmed document may be published",
                                    service_error=from_exception(exc)) from exc
        returned = [get_field(item, "key") for item in response]
        if len(returned) != len(prepared) or set(returned) != {doc[key_field] for doc in prepared}:
            raise ContractError("PUBLICATION_RESULT_INCOMPLETE", "Batch results must account for each document exactly once")
        results: dict[str, dict[str, Any]] = {}
        for item in response:
            key = get_field(item, "key")
            if get_field(item, "succeeded") is not True:
                status = get_field(item, "status_code", get_field(item, "statusCode"))
                message = get_field(item, "error_message", get_field(item, "errorMessage"))
                raise ContractError("PUBLICATION_UPLOAD_FAILED", f"Document {key!r} failed indexing (status {status})",
                                    service_error=describe(status, message))
            results[key] = {"key": key, "succeeded": True}
        return results

    def _retrievable_fields(self, index: str) -> list[str]:
        try:
            definition = self.index_client.get_index(index)
        except Exception as exc:
            if _status(exc) == 404:
                raise ContractError("INDEX_MISSING", "Physical generation index does not exist",
                                    service_error=from_exception(exc)) from exc
            raise ContractError("PUBLICATION_READBACK_FAILED", "Cannot inspect physical generation index",
                                service_error=from_exception(exc)) from exc
        return [get_field(field, "name") for field in get_field(definition, "fields", [])
                if get_field(field, "retrievable", True) is not False and not get_field(field, "hidden", False)]

    def readback(self, index: str) -> list[dict[str, Any]]:
        """Every document, paged in key order with ``id gt '<last>'`` and checked against ``$count``."""
        self._approve(index, write=False)
        select = self._retrievable_fields(index)
        client = self.search_client(index)
        last: str | None = None
        result: list[dict[str, Any]] = []
        while True:
            where = None if last is None else f"{KEY_FIELD} gt {_literal(last)}"
            try:
                page = list(client.search(search_text="*", filter=where, order_by=[f"{KEY_FIELD} asc"],
                                          select=select, top=self.batch_size))
            except Exception as exc:
                if _status(exc) == 404:
                    raise ContractError("INDEX_MISSING", "Physical generation index does not exist",
                                    service_error=from_exception(exc)) from exc
                raise ContractError("PUBLICATION_READBACK_FAILED", "Cannot verify physical generation index",
                                    service_error=from_exception(exc)) from exc
            if len(page) > self.batch_size:
                raise ContractError("PUBLICATION_READBACK_FAILED", "Readback exceeded bounded page")
            for row in page:
                row = normalize(dict(row))
                key = row.get(KEY_FIELD)
                if not isinstance(key, str) or not key or (last is not None and key <= last):
                    raise ContractError("PUBLICATION_READBACK_FAILED", "Duplicate, missing or unordered document keys")
                last = key
                result.append(row)
            if len(page) < self.batch_size:
                break
        try:
            count = client.get_document_count()
        except Exception as exc:
            if _status(exc) == 404:
                raise ContractError("INDEX_MISSING", "Physical generation index does not exist",
                                    service_error=from_exception(exc)) from exc
            raise ContractError("PUBLICATION_READBACK_FAILED", "Document count read permission required",
                                service_error=from_exception(exc)) from exc
        if count != len(result):
            raise ContractError("READBACK_NOT_SETTLED",
                                f"Search is still indexing: document count {count} differs from keyset scan {len(result)}")
        return result

    def verify(self, index: str, expected: list[dict[str, Any]]) -> str:
        """Read every document back, compare it to the release, and return the inventory digest."""
        self._approve(index, write=False)
        if not expected or len({doc[KEY_FIELD] for doc in expected}) != len(expected):
            raise ContractError("PUBLICATION_VERIFY_FAILED", "Complete expected document inventory required")
        actual = {doc[KEY_FIELD]: doc for doc in self.readback(index)}
        wanted = {doc[KEY_FIELD]: normalize(doc) for doc in expected}
        if set(actual) != set(wanted):
            raise ContractError("PUBLICATION_VERIFY_FAILED", "Physical index inventory differs from the release")
        for key, projected in wanted.items():
            if not same_document(projected, actual[key]):
                raise ContractError("PUBLICATION_VERIFY_FAILED", f"Physical document {key!r} differs from the release")
        fingerprint = inventory_digest(list(wanted.values()))
        self.verified_indexes.add(index)
        self.verified_fingerprints[index] = fingerprint
        return fingerprint


def same_document(expected: dict[str, Any], observed: dict[str, Any]) -> bool:
    """Release and read-back documents match, allowing float rounding in the centroid vector
    and in double fields (Search may return a double one unit in the last place away)."""
    left, right = normalize(expected), normalize(observed)
    if VECTOR_FIELD in left and VECTOR_FIELD in right:
        a, b = left.pop(VECTOR_FIELD), right.pop(VECTOR_FIELD)
        if len(a) != len(b) or any(abs(float(x) - float(y)) > VECTOR_TOLERANCE for x, y in zip(a, b)):
            return False
    if set(left) != set(right):
        return False
    return all(_same_value(left[key], right[key]) for key in left)


def _same_value(expected: Any, observed: Any) -> bool:
    if (isinstance(expected, float) or isinstance(observed, float)) and all(
            isinstance(value, (int, float)) and not isinstance(value, bool)
            for value in (expected, observed)):
        return math.isclose(float(expected), float(observed), rel_tol=1e-12, abs_tol=1e-15)
    if isinstance(expected, list) and isinstance(observed, list):
        return len(expected) == len(observed) and all(
            _same_value(a, b) for a, b in zip(expected, observed))
    if isinstance(expected, dict) and isinstance(observed, dict):
        return set(expected) == set(observed) and all(
            _same_value(expected[key], observed[key]) for key in expected)
    return expected == observed


def inventory_digest(documents: list[dict[str, Any]]) -> str:
    """Digest of a release's comparable content, independent of document order and upload annotations."""
    return digest(sorted((normalize(doc) for doc in documents), key=lambda doc: doc[KEY_FIELD]))
