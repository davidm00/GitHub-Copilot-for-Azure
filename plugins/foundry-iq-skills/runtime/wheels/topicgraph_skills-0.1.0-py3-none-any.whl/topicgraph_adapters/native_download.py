"""Download, verify, extract, and cache the TopicGraph native binary this plugin pins.

Uses the public GitHub Releases API for `Azure/foundry-iq-tool-releases` (no PAT required).
`native-release.json` pins one release tag and each platform asset's `sha256:` digest, so a newer
TopicGraph release never reaches users until the plugin moves its pin
(`tools/pin_native_release.py`). The published asset must carry the pinned digest, and the
downloaded archive must match it, extracts `.zip` (Windows/macOS) or `.deb` (Linux, pure-Python `ar` +
`data.tar.*` without root or package installation) with zip-slip/symlink protection into a
per-user cache under the plugin runtime data directory, and records `receipt.json` binding
the extracted executable's SHA-256.

Note on `.rpm`: `platform_asset` maps Linux hosts to `.deb`, every release on
`Azure/foundry-iq-tool-releases` publishes `.deb` for `linux-x64` and `linux-arm64`, and
pure-Python `.deb` extraction (`ar` + `tarfile`) runs without root or `dpkg` on any Linux
distribution (including RHEL/Fedora), so `.rpm` extraction is not needed.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import platform
import re
import shutil
import stat
import sys
import tarfile
import tempfile
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote
from urllib.request import Request, urlopen
import zipfile

from topicgraph_core.contracts import ContractError, canonical_json, digest

REPOSITORY = "Azure/foundry-iq-tool-releases"
GITHUB_REPO = REPOSITORY
PACKAGE_PREFIX = "topicGraphBuildTool-"
RECEIPT_SCHEMA_VERSION = 1
_HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")

SYSTEMS: dict[str, tuple[str, str]] = {
    "Windows": ("win", "zip"),
    "Linux": ("linux", "deb"),
    "Darwin": ("osx", "zip"),
    "win32": ("win", "zip"),
    "linux": ("linux", "deb"),
    "darwin": ("osx", "zip"),
}
ARCHITECTURES: dict[str, str] = {
    "amd64": "x64",
    "x86_64": "x64",
    "x64": "x64",
    "arm64": "arm64",
    "aarch64": "arm64",
}
# macOS Intel is unsupported: the plugin ships no darwin-x86_64 Python dependency locks.
SUPPORTED_RIDS = frozenset({"win-x64", "win-arm64", "linux-x64", "linux-arm64", "osx-arm64"})


def compute_sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with open(path, "rb") as stream:
        while chunk := stream.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest().upper()


def host_rid(system: str | None = None, machine: str | None = None) -> str:
    sys_name = system if system is not None else platform.system()
    mach_name = (machine if machine is not None else platform.machine()).lower()
    rid = (
        f"{SYSTEMS[sys_name][0]}-{ARCHITECTURES[mach_name]}"
        if sys_name in SYSTEMS and mach_name in ARCHITECTURES
        else None
    )
    if rid not in SUPPORTED_RIDS:
        raise ContractError(
            "NATIVE_PLATFORM_UNSUPPORTED",
            f"Unsupported platform: {sys_name} {mach_name}.",
        )
    return rid


def binary_filename(rid: str | None = None) -> str:
    resolved_rid = rid or host_rid()
    return "topicgraph.exe" if resolved_rid.startswith("win-") else "topicgraph"


def native_cache_root() -> Path:
    """Return the per-user native binary cache directory outside the repo and CWD."""
    explicit = os.environ.get("TOPICGRAPH_NATIVE_CACHE")
    if explicit:
        path = Path(explicit).expanduser()
        if not path.is_absolute():
            raise ContractError(
                "NATIVE_CACHE_INVALID",
                "TOPICGRAPH_NATIVE_CACHE must be an absolute path.",
            )
        return path.resolve()

    runtime_cache = os.environ.get("FOUNDRY_IQ_RUNTIME_CACHE")
    if runtime_cache:
        base = Path(runtime_cache).expanduser()
        if not base.is_absolute():
            raise ContractError(
                "NATIVE_CACHE_INVALID",
                "FOUNDRY_IQ_RUNTIME_CACHE must be an absolute external cache path.",
            )
        path = base.resolve() / "topicgraph" / "native"
    elif os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA")
        base = Path(local_app_data) if local_app_data else (Path.home() / "AppData" / "Local")
        path = base.resolve() / "foundry-iq-skills" / "runtimes" / "topicgraph" / "native"
    else:
        xdg = os.environ.get("XDG_CACHE_HOME")
        base = Path(xdg) if xdg else (Path.home() / ".cache")
        path = base.resolve() / "foundry-iq-skills" / "runtimes" / "topicgraph" / "native"

    cwd = Path.cwd().resolve()
    project = next(
        (
            folder
            for folder in (cwd, *cwd.parents)
            if (folder / ".git").exists()
            or (folder / "pyproject.toml").is_file()
            or (folder / "package.json").is_file()
        ),
        None,
    )
    if project is not None and path.is_relative_to(project):
        raise ContractError(
            "NATIVE_CACHE_INVALID",
            f"Native binary cache {path} must not be inside the repository or project directory {project}.",
        )
    if cwd not in (Path.home().resolve(), Path(cwd.anchor)) and path.is_relative_to(cwd):
        raise ContractError(
            "NATIVE_CACHE_INVALID",
            f"Native binary cache {path} must not be inside the current working directory {cwd}.",
        )
    return path


PIN_FILE = Path(__file__).with_name("native-release.json")


def pinned() -> dict[str, Any]:
    """The release tag and per-platform asset digests this plugin version is built and tested against."""
    pin = json.loads(PIN_FILE.read_text(encoding="utf-8"))
    tag, assets = pin.get("tag"), pin.get("assets")
    if (pin.get("repository") != REPOSITORY or not isinstance(tag, str) or not tag
            or any(c in tag for c in "/\\:") or not isinstance(assets, dict)
            or set(assets) != set(SUPPORTED_RIDS)
            or not all(isinstance(d, str) and d.startswith("sha256:") and _HEX64.fullmatch(d[7:])
                       for d in assets.values())):
        raise ValueError(f"{PIN_FILE.name} is not a valid TopicGraph release pin.")
    return pin


def pinned_release(*, urlopen_fn: Callable[..., Any] | None = None) -> dict[str, Any]:
    """The pinned release's GitHub metadata; never a newer one."""
    tag = pinned()["tag"]
    request = Request(
        f"https://api.github.com/repos/{REPOSITORY}/releases/tags/{quote(tag)}",
        headers={"Accept": "application/vnd.github+json", "User-Agent": "topicgraph-downloader"},
    )
    with (urlopen_fn or urlopen)(request, timeout=30) as response:
        release = json.load(response)
    if not isinstance(release, dict) or release.get("tag_name") != tag:
        raise ValueError(f"GitHub did not return the pinned TopicGraph release {tag}.")
    if release.get("draft") or not release.get("published_at"):
        raise ValueError(f"The pinned TopicGraph release {tag} is not published.")
    return release


def pinned_asset(
    release: dict[str, Any], *, system: str | None = None, machine: str | None = None
) -> tuple[dict[str, Any], str, str, str]:
    """This platform's asset in the pinned release; its published digest must be the pinned one."""
    asset = platform_asset(release, system=system, machine=machine)
    name, url, expected_digest = validate_asset_metadata(asset)
    want = pinned()["assets"][host_rid(system, machine)].lower()
    if expected_digest != want:
        raise ContractError(
            "NATIVE_RELEASE_MISMATCH",
            f"{name} in TopicGraph release {release.get('tag_name')} is published with digest {expected_digest}, "
            f"not the {want} this plugin pins.",
        )
    return asset, name, url, expected_digest


def platform_asset(
    release: dict[str, Any],
    *,
    system: str | None = None,
    machine: str | None = None,
) -> dict[str, Any]:
    sys_name = system if system is not None else platform.system()
    mach_name = (machine if machine is not None else platform.machine()).lower()
    if sys_name not in SYSTEMS or mach_name not in ARCHITECTURES:
        raise ValueError(f"Unsupported platform: {sys_name} {mach_name}.")
    operating_system, extension = SYSTEMS[sys_name]
    rid = f"{operating_system}-{ARCHITECTURES[mach_name]}"
    if rid not in SUPPORTED_RIDS:
        raise ValueError(f"Unsupported platform: {sys_name} {mach_name}.")
    suffix = f"-{rid}.{extension}"
    matches = [
        asset
        for asset in (release.get("assets") or [])
        if isinstance(asset, dict)
        and isinstance(asset.get("name"), str)
        and asset["name"].startswith(PACKAGE_PREFIX)
        and asset["name"].endswith(suffix)
    ]
    if len(matches) != 1:
        raise ValueError(
            f"Expected one {suffix} package in {release.get('tag_name')}; found {len(matches)}."
        )
    return matches[0]


def validate_asset_metadata(asset: dict[str, Any]) -> tuple[str, str, str]:
    name = asset.get("name")
    if (
        not isinstance(name, str)
        or not name
        or name in (".", "..")
        or any(character in name for character in "/\\:")
    ):
        raise ValueError(f"Unsafe asset filename: {name!r}.")
    url = asset.get("browser_download_url")
    if not isinstance(url, str) or not url.startswith(
        f"https://github.com/{REPOSITORY}/releases/download/"
    ):
        raise ValueError("Asset URL does not belong to the expected GitHub repository.")
    expected = asset.get("digest")
    if (
        not isinstance(expected, str)
        or not expected.lower().startswith("sha256:")
        or not _HEX64.fullmatch(expected[7:])
    ):
        raise ValueError("GitHub did not provide a SHA-256 digest for this asset.")
    return name, url, expected.lower()


def download_asset(
    asset: dict[str, Any],
    output_directory: Path,
    *,
    urlopen_fn: Callable[..., Any] | None = None,
) -> Path:
    fn = urlopen_fn or urlopen
    name, url, expected = validate_asset_metadata(asset)
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    destination = output_directory / name
    request = Request(url, headers={"User-Agent": "topicgraph-downloader"})
    hasher = hashlib.sha256()
    created = complete = False
    try:
        with destination.open("xb") as output:
            created = True
            with fn(request, timeout=60) as response:
                while chunk := response.read(1024 * 1024):
                    output.write(chunk)
                    hasher.update(chunk)
        if f"sha256:{hasher.hexdigest()}" != expected:
            raise ValueError("Downloaded file does not match GitHub's SHA-256 digest.")
        complete = True
    finally:
        if created and not complete:
            destination.unlink(missing_ok=True)
    return destination.resolve()


def _validate_relative_member_path(raw_name: str, extract_dir: Path) -> Path | None:
    if not raw_name or raw_name.startswith(("/", "\\")) or "\\" in raw_name or ":" in raw_name:
        raise ValueError(f"Unsafe archive entry path: {raw_name!r}")
    trimmed = raw_name
    while trimmed.startswith("./"):
        trimmed = trimmed[2:]
    if not trimmed or trimmed == ".":
        return None
    parts = trimmed.split("/")
    if any(part in ("", ".", "..") for part in parts if part != ""):
        if any(part in (".", "..") for part in parts):
            raise ValueError(f"Path traversal in archive entry: {raw_name!r}")
    rel = Path(*[p for p in parts if p])
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"Unsafe archive entry path: {raw_name!r}")
    root = extract_dir.resolve()
    target = (root / rel).resolve()
    if target != root and not target.is_relative_to(root):
        raise ValueError(f"Archive entry escapes extraction root: {raw_name!r}")
    return target


def _extract_zip_safely(archive_path: Path, extract_dir: Path) -> None:
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive_path, "r") as zf:
        for info in zf.infolist():
            mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(mode):
                raise ValueError(f"Symlink entries are forbidden in native package: {info.filename!r}")
            target = _validate_relative_member_path(info.filename, extract_dir)
            if target is None or info.is_dir():
                if target is not None:
                    target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info, "r") as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)


def _extract_deb_data_tar_bytes(deb_path: Path) -> bytes:
    data = deb_path.read_bytes()
    if not data.startswith(b"!<arch>\n"):
        raise ValueError(f"Invalid .deb archive header in {deb_path.name}")
    offset = 8
    extended_names = b""
    while offset + 60 <= len(data):
        header = data[offset : offset + 60]
        if header[58:60] != b"`\n":
            raise ValueError(f"Malformed ar member header in {deb_path.name}")
        raw_name = header[0:16].decode("ascii", errors="replace").strip()
        try:
            size = int(header[48:58].decode("ascii").strip())
        except ValueError as exc:
            raise ValueError(f"Malformed ar member size in {deb_path.name}") from exc
        if size < 0 or offset + 60 + size > len(data):
            raise ValueError(f"Truncated ar member in {deb_path.name}")
        payload = data[offset + 60 : offset + 60 + size]
        offset += 60 + size + (size % 2)
        if raw_name == "//":
            extended_names = payload
            continue
        if raw_name.startswith("/") and raw_name[1:].isdigit() and extended_names:
            idx = int(raw_name[1:])
            end = extended_names.find(b"\n", idx)
            raw_name = extended_names[idx : (end if end != -1 else len(extended_names))].decode(
                "ascii", errors="replace"
            )
        name = raw_name.rstrip("/")
        if name.startswith("data.tar"):
            return payload
    raise ValueError(f"No data.tar.* member found in {deb_path.name}")


def _extract_deb_safely(archive_path: Path, extract_dir: Path) -> None:
    extract_dir.mkdir(parents=True, exist_ok=True)
    tar_bytes = _extract_deb_data_tar_bytes(archive_path)
    with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:*") as tf:
        for member in tf.getmembers():
            if member.issym() or member.islnk():
                raise ValueError(f"Symlink or hardlink entries are forbidden in native package: {member.name!r}")
            if member.isdev() or member.isfifo():
                raise ValueError(f"Special device entries are forbidden in native package: {member.name!r}")
            target = _validate_relative_member_path(member.name, extract_dir)
            if target is None or member.isdir():
                if target is not None:
                    target.mkdir(parents=True, exist_ok=True)
                continue
            if not member.isfile():
                raise ValueError(f"Unsupported tar entry type for {member.name!r}")
            extracted_stream = tf.extractfile(member)
            if extracted_stream is None:
                raise ValueError(f"Cannot read tar entry {member.name!r}")
            target.parent.mkdir(parents=True, exist_ok=True)
            with extracted_stream, target.open("wb") as dst:
                shutil.copyfileobj(extracted_stream, dst)


def _parse_checksums_file(checksums_path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not checksums_path.is_file():
        return result
    for line in checksums_path.read_text(encoding="utf-8", errors="replace").splitlines():
        text = line.strip()
        if not text:
            continue
        parts = text.split(None, 1)
        if len(parts) == 2 and _HEX64.fullmatch(parts[0]):
            fname = parts[1].strip().lstrip("*").replace("\\", "/").rsplit("/", 1)[-1]
            result[fname] = parts[0].upper()
    return result


def extract_package(archive_path: Path, extract_dir: Path, *, rid: str | None = None) -> tuple[Path, str]:
    """Safely extract `.zip` or `.deb` archive and return `(binary_path, binary_sha256)`."""
    archive_path = Path(archive_path)
    extract_dir = Path(extract_dir)
    if archive_path.name.endswith(".zip"):
        _extract_zip_safely(archive_path, extract_dir)
    elif archive_path.name.endswith(".deb"):
        _extract_deb_safely(archive_path, extract_dir)
    else:
        raise ValueError(f"Unsupported package extension: {archive_path.name!r}")

    bin_name = binary_filename(rid)
    candidates = [
        extract_dir / bin_name,
        extract_dir / "usr" / "bin" / bin_name,
        extract_dir / "usr" / "local" / "bin" / bin_name,
        extract_dir / "usr" / "lib" / "topicgraphbuildtool" / bin_name,
        extract_dir / "opt" / "topicgraphbuildtool" / bin_name,
    ]
    found: Path | None = next((c for c in candidates if c.is_file() and not c.is_symlink()), None)
    if found is None:
        matches = [
            p for p in sorted(extract_dir.rglob(bin_name))
            if p.is_file() and not p.is_symlink()
        ]
        if len(matches) != 1:
            raise ValueError(f"Expected one {bin_name} in extracted package; found {len(matches)}.")
        found = matches[0]

    resolved_bin = found.resolve()
    if not resolved_bin.is_relative_to(extract_dir.resolve()):
        raise ValueError("Extracted binary resolved outside extraction directory.")
    if os.name != "nt":
        resolved_bin.chmod(0o755)
    actual_sha = compute_sha256(resolved_bin)
    checksums = _parse_checksums_file(resolved_bin.parent / "checksums.sha256")
    if bin_name in checksums and checksums[bin_name] != actual_sha:
        raise ValueError(
            f"Extracted {bin_name} SHA-256 ({actual_sha}) does not match package checksums.sha256 ({checksums[bin_name]})."
        )
    return resolved_bin, actual_sha


def receipt_path_for_rid(rid: str | None = None, *, cache_root: Path | None = None) -> Path:
    resolved_rid = rid or host_rid()
    root = (cache_root or native_cache_root()).resolve()
    return root / resolved_rid / "receipt.json"


def read_cached_receipt(rid: str | None = None, *, cache_root: Path | None = None) -> dict[str, Any] | None:
    """Read and validate the cached receipt for `rid`, verifying the binary still matches on disk."""
    path = receipt_path_for_rid(rid, cache_root=cache_root)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or data.get("schema_version") != RECEIPT_SCHEMA_VERSION:
        return None
    required_str = (
        "repository",
        "tag",
        "rid",
        "asset_name",
        "asset_url",
        "asset_digest",
        "binary_path",
        "binary_sha256",
    )
    if any(not isinstance(data.get(k), str) or not data[k] for k in required_str):
        return None
    if data["repository"] != REPOSITORY or not data["asset_digest"].startswith("sha256:"):
        return None
    if not _HEX64.fullmatch(data["binary_sha256"]):
        return None
    bin_path = Path(data["binary_path"])
    if not bin_path.is_file() or bin_path.is_symlink():
        return None
    try:
        if compute_sha256(bin_path) != data["binary_sha256"].upper():
            return None
    except OSError:
        return None
    return data


def inspect_pinned_release(
    *,
    system: str | None = None,
    machine: str | None = None,
    cache_root: Path | None = None,
    urlopen_fn: Callable[..., Any] = urlopen,
) -> dict[str, Any]:
    """Query GitHub for the pinned release's asset for this platform and check cache state."""
    rid = host_rid(system, machine)
    release = pinned_release(urlopen_fn=urlopen_fn)
    _, name, url, expected_digest = pinned_asset(release, system=system, machine=machine)
    tag = str(release.get("tag_name") or "")
    if not tag or any(c in tag for c in "/\\:") or tag in (".", ".."):
        raise ValueError(f"Invalid release tag: {tag!r}")
    cached = read_cached_receipt(rid, cache_root=cache_root)
    is_cached = bool(
        cached
        and cached.get("tag") == tag
        and cached.get("asset_name") == name
        and cached.get("asset_digest") == expected_digest
    )
    spec = {
        "repository": REPOSITORY,
        "tag": tag,
        "published_at": str(release.get("published_at") or ""),
        "rid": rid,
        "asset_name": name,
        "asset_url": url,
        "asset_digest": expected_digest,
    }
    plan_id = "tg-native-" + digest(spec)[:16]
    return {
        **spec,
        "plan_id": plan_id,
        "cached": is_cached,
        "receipt": cached if is_cached else None,
    }


def ensure_cached_release(
    *,
    expected_spec: dict[str, Any] | None = None,
    system: str | None = None,
    machine: str | None = None,
    cache_root: Path | None = None,
    urlopen_fn: Callable[..., Any] = urlopen,
) -> dict[str, Any]:
    """Download, verify, extract, and record the pinned release (or reuse it from the cache)."""
    rid = host_rid(system, machine)
    root = (cache_root or native_cache_root()).resolve()
    release = pinned_release(urlopen_fn=urlopen_fn)
    asset, name, url, expected_digest = pinned_asset(release, system=system, machine=machine)
    tag = str(release.get("tag_name") or "")
    if not tag or any(c in tag for c in "/\\:") or tag in (".", ".."):
        raise ValueError(f"Invalid release tag: {tag!r}")

    if expected_spec is not None:
        for key, actual in (
            ("repository", REPOSITORY),
            ("tag", tag),
            ("asset_name", name),
            ("asset_digest", expected_digest),
        ):
            if expected_spec.get(key) and expected_spec[key] != actual:
                raise ContractError(
                    "NATIVE_RELEASE_CHANGED",
                    f"The pinned TopicGraph release {key} changed since the plan ({expected_spec[key]} -> {actual}); re-run plan to review and approve it.",
                )

    cached = read_cached_receipt(rid, cache_root=root)
    if (
        cached is not None
        and cached.get("tag") == tag
        and cached.get("asset_name") == name
        and cached.get("asset_digest") == expected_digest
    ):
        return {**cached, "reused": True}

    digest_short = expected_digest.split(":", 1)[1][:16]
    version_dir = root / rid / f"{tag}-{digest_short}"
    pkg_dir = version_dir / "package"
    ext_dir = version_dir / "extracted"
    if version_dir.exists():
        shutil.rmtree(version_dir)
    pkg_dir.mkdir(parents=True, exist_ok=True)
    archive_path = download_asset(asset, pkg_dir, urlopen_fn=urlopen_fn)
    binary_path, binary_sha = extract_package(archive_path, ext_dir, rid=rid)
    receipt = {
        "schema_version": RECEIPT_SCHEMA_VERSION,
        "repository": REPOSITORY,
        "tag": tag,
        "published_at": str(release.get("published_at") or ""),
        "rid": rid,
        "asset_name": name,
        "asset_url": url,
        "asset_digest": expected_digest,
        "archive_path": str(archive_path),
        "binary_path": str(binary_path),
        "binary_sha256": binary_sha,
    }
    version_receipt_path = version_dir / "receipt.json"
    rid_receipt_path = receipt_path_for_rid(rid, cache_root=root)
    for target_receipt in (version_receipt_path, rid_receipt_path):
        target_receipt.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_name = tempfile.mkstemp(prefix="receipt-", suffix=".tmp", dir=target_receipt.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write(canonical_json(receipt))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(tmp_name, target_receipt)
        finally:
            Path(tmp_name).unlink(missing_ok=True)
    return {**receipt, "reused": False}
