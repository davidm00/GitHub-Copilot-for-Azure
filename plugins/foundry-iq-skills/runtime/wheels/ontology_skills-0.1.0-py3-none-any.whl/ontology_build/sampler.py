"""Deterministic hierarchy sampling and shard packing.

Levels use Topic Graph's numbering: level 0 holds the broadest (root) topics and each
child is one level deeper. Branches may end at different depths.

Two phases so the plan can be priced without reading corpus text:
`select()` at plan time (no text; shards packed assuming `excerpt_chars` per passage) and
`attach_excerpts()` at propose time.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import replace
from fractions import Fraction
import math
from typing import Literal

from ontology_build.reader import EvidenceText, Membership, Representative
from ontology_core import hashing
from ontology_core.errors import Blocked
from ontology_core.model import Passage, Sample, Shard

MIN_TOPICS_FOR_LEVEL = 20
MIN_PASSAGES = 120
MAX_PASSAGES = 800
PASSAGES_PER_TOPIC = 4
DEFAULT_EXCERPT_CHARS = 1200
DEFAULT_SHARD_CHARS = 60000
CITED_EXCERPT_CHARS = 400
DEFAULT_BROADEST_TOPICS = 40
MAX_DIVERSE_CANDIDATES = 512
MAX_REPRESENTATIVES_PER_TOPIC = 32
SelectionMode = Literal["level_cut", "broadest_first"]


def levels(representatives: list[Representative]) -> dict[int, int]:
    """`{level: topic count}`, ascending by level."""
    counts = Counter(r.level for r in representatives)
    return {level: counts[level] for level in sorted(counts)}


def default_level(representatives: list[Representative]) -> int:
    """Broadest (smallest) level with >= `MIN_TOPICS_FOR_LEVEL` topics, else the deepest."""
    counts = levels(representatives)
    eligible = [level for level, n in counts.items() if n >= MIN_TOPICS_FOR_LEVEL]
    if eligible:
        return min(eligible)
    return max(counts) if counts else 0


def default_passages(topics_at_level: int, available_chunks: int) -> int:
    """`min(clamp(4n, 120, 800), available_chunks)`: the plan's clamp, capped at the chunks that exist."""
    clamped = max(MIN_PASSAGES, min(MAX_PASSAGES, PASSAGES_PER_TOPIC * topics_at_level))
    return max(0, min(clamped, available_chunks))


def frontier(representatives: list[Representative], level: int) -> list[Representative]:
    """Topics at `level` plus branches that end above it (smaller level, no children).

    Every root-to-leaf branch is covered exactly once.
    """
    parents = {rep.parent_id for rep in representatives if rep.parent_id is not None}
    return sorted((rep for rep in representatives
                   if rep.level == level or (rep.level < level and rep.topic_id not in parents)),
                  key=lambda rep: rep.topic_id)


def broadest_first(representatives: list[Representative],
                   sample_topics: int = DEFAULT_BROADEST_TOPICS) -> list[Representative]:
    """Top `sample_topics` across all levels, broadest first (level asc, member_count desc, id asc)."""
    ordered = sorted(representatives, key=lambda r: (r.level, -r.member_count, r.topic_id))
    return ordered[:max(1, sample_topics)]


def diverse_member_ids(
    members: list[str],
    count: int,
    *,
    vectors: dict[str, list[float]] | None = None,
    seed: str = "",
) -> list[str]:
    """Pick the most centroid-typical chunk first, then farthest-point picks by cosine similarity.

    Falls back to `_leaf_order(members, seed)` when vectors are unavailable or incomplete.
    """
    unique = list(dict.fromkeys(members))
    count = max(1, count)
    if len(unique) <= count:
        return unique
    if not vectors or any(m not in vectors for m in unique):
        return _leaf_order(unique, seed)[:count]

    cand_limit = min(len(unique), MAX_DIVERSE_CANDIDATES, max(64, count * 16))
    candidates = sorted(unique)[:cand_limit]
    normed: list[list[float]] = []
    for cid in candidates:
        vec = [float(x) for x in vectors[cid]]
        norm = math.sqrt(sum(x * x for x in vec))
        if norm == 0.0:
            return _leaf_order(unique, seed)[:count]
        normed.append([x / norm for x in vec])

    dim = len(normed[0])
    centroid = [sum(row[d] for row in normed) / len(normed) for d in range(dim)]
    c_norm = math.sqrt(sum(x * x for x in centroid))
    if c_norm == 0.0:
        return _leaf_order(unique, seed)[:count]
    centroid = [x / c_norm for x in centroid]

    def dot(a: list[float], b: list[float]) -> float:
        return sum(x * y for x, y in zip(a, b))

    first_idx = max(range(len(candidates)), key=lambda i: (dot(normed[i], centroid), -i))
    chosen = [first_idx]
    chosen_set = {first_idx}
    max_sim = [dot(normed[i], normed[first_idx]) for i in range(len(candidates))]
    while len(chosen) < min(count, len(candidates)):
        next_idx = min(
            (i for i in range(len(candidates)) if i not in chosen_set),
            key=lambda i: (round(max_sim[i], 12), i),
        )
        chosen.append(next_idx)
        chosen_set.add(next_idx)
        for i in range(len(candidates)):
            if i not in chosen_set:
                sim = dot(normed[i], normed[next_idx])
                if sim > max_sim[i]:
                    max_sim[i] = sim
    return [candidates[i] for i in chosen]


def evidence_id(chunk_id: str, *, taken: set[str] | None = None) -> str:
    """`"E" + sha256(chunk_id)[:10]`, or `[:12]` if that collides with `taken`."""
    short = hashing.evidence_id(chunk_id)
    if taken and short in taken:
        return hashing.evidence_id(chunk_id, 12)
    return short


def _leaf_order(chunks: list[str], seed: str) -> list[str]:
    return sorted(set(chunks), key=lambda c: (hashing.sha256_text(seed + c), c))


def _allocate(total: int, topics: list[Representative], capacity: dict[str, int]) -> dict[str, int]:
    """One passage per topic with chunks, then the rest by largest remainder on `member_count`
    (ties to the smaller `topic_id`), never above a topic's chunk capacity. Spill-over from
    full topics is re-split the same way among the rest."""
    alloc = {r.topic_id: min(1, capacity[r.topic_id]) for r in topics}
    weight = {r.topic_id: max(r.member_count, 0) for r in topics}
    while True:
        remaining = total - sum(alloc.values())
        open_ids = sorted(c for c in alloc if alloc[c] < capacity[c])
        if remaining <= 0 or not open_ids:
            return alloc
        weights = {c: weight[c] for c in open_ids}
        if sum(weights.values()) == 0:
            weights = {c: 1 for c in open_ids}
        denom = sum(weights.values())
        quota = {c: Fraction(remaining * weights[c], denom) for c in open_ids}
        given = 0
        for c in open_ids:
            add = min(int(quota[c]), capacity[c] - alloc[c])
            alloc[c] += add
            given += add
        leftover = remaining - given
        ranked = sorted(open_ids, key=lambda c: (-(quota[c] - int(quota[c])), c))
        for c in ranked:
            if leftover <= 0:
                break
            if alloc[c] < capacity[c]:
                alloc[c] += 1
                leftover -= 1


def select(representatives: list[Representative], members: list[Membership], *, plan_id_seed: str,
           level: int | None, passages: int | None, excerpt_chars: int = DEFAULT_EXCERPT_CHARS,
           shard_chars: int = DEFAULT_SHARD_CHARS,
           vectors: dict[str, list[float]] | None = None,
           selection_mode: SelectionMode = "level_cut",
           sample_topics: int = DEFAULT_BROADEST_TOPICS) -> Sample:
    """Runs the sampling steps. Returns a `Sample` with `plan_id=""`, passages without `source_id`/`excerpt`,
    and shards packed by `excerpt_chars` per passage. Terminal topics use their own
    memberships, including branches that end above the requested level.

    An explicit `passages` above the chunks available is capped (with a warning). A topic whose
    passages exceed one shard keeps only the passages that fit, with a warning.

    Raises:
        Blocked("LEVEL_OUT_OF_RANGE"): explicit `level` has no topics.
        Blocked("PASSAGE_BUDGET_TOO_SMALL", n=<topics>): explicit `passages` < topics at level.
    """
    if excerpt_chars < 1 or shard_chars < 1:
        raise ValueError("excerpt_chars and shard_chars must be >= 1")
    counts = levels(representatives)
    if level is None:
        level = default_level(representatives)
    elif level not in counts:
        raise Blocked("LEVEL_OUT_OF_RANGE",
                      f"level {level} has no topics; levels are "
                      + (", ".join(f"{lv} ({n})" for lv, n in counts.items()) or "none"),
                      details={"levels": {str(k): v for k, v in counts.items()}})
    warnings: list[str] = []

    # 1. The tree: terminal memberships may occur at any level in a ragged hierarchy.
    children: dict[str, list[Representative]] = defaultdict(list)
    for rep in representatives:
        if rep.parent_id is not None:
            children[rep.parent_id].append(rep)
    leaf_chunks: dict[str, list[str]] = defaultdict(list)
    for m in members:
        leaf_chunks[m.topic_id].append(m.chunk_id)

    order_cache: dict[str, list[str]] = {}

    def order(rep: Representative) -> list[str]:
        """Every chunk under `rep` in pick order: hashed at a leaf, recursive round-robin above."""
        if rep.topic_id in order_cache:
            return order_cache[rep.topic_id]
        if not children.get(rep.topic_id):
            result = _leaf_order(leaf_chunks.get(rep.topic_id, []), plan_id_seed)
        else:
            kids = sorted(children.get(rep.topic_id, []), key=lambda r: (-r.member_count, r.topic_id))
            lists = [order(k) for k in kids]
            result, seen = [], set()
            for i in range(max((len(x) for x in lists), default=0)):
                for lst in lists:
                    if i < len(lst) and lst[i] not in seen:
                        seen.add(lst[i])
                        result.append(lst[i])
        order_cache[rep.topic_id] = result
        return result

    # 2-3. The level's topics and the passage budget.
    if selection_mode == "broadest_first":
        at_level = broadest_first(representatives, sample_topics)
    else:
        at_level = frontier(representatives, level)
    n = len(at_level)
    capacity = {r.topic_id: len(order(r)) for r in at_level}
    available = sum(capacity.values())
    if passages is None:
        passages = default_passages(n, available)
    else:
        if passages < n:
            raise Blocked("PASSAGE_BUDGET_TOO_SMALL",
                          f"{passages} passages cannot cover the {n} topics at level {level}", n=n)
        if passages > available:
            warnings.append(f"passages capped at the {available} chunks available (asked for {passages})")
            passages = available
    empty = [c for c, cap in capacity.items() if cap == 0]
    if empty:
        warnings.append(f"{len(empty)} topics at level {level} have no terminal members and get no passages")

    # 4-5. Allocate, then take each topic's first k chunks in pick order (or embedding-diverse order).
    alloc = _allocate(passages, at_level, capacity)

    # 7. Pack whole topics into shards; a topic over one shard is truncated at a passage boundary.
    per_shard = max(1, shard_chars // excerpt_chars)
    picked: list[tuple[str, list[str]]] = []
    used_chunks: set[str] = set()
    for rep in at_level:
        k = alloc[rep.topic_id]
        if k == 0:
            continue
        if k > per_shard:
            warnings.append(f"topic {rep.topic_id} truncated from {k} to {per_shard} passages "
                            f"to fit one shard of {shard_chars} chars")
            k = per_shard
        pool = order(rep)
        if vectors is not None or selection_mode == "broadest_first":
            unused = [c for c in pool if c not in used_chunks]
            candidates_for_rep = unused if len(unused) >= k else (unused + [c for c in pool if c in used_chunks])
            chosen_chunks = (diverse_member_ids(candidates_for_rep, k, vectors=vectors, seed=plan_id_seed)
                             if vectors is not None else candidates_for_rep[:k])
        else:
            chosen_chunks = pool[:k]
        used_chunks.update(chosen_chunks)
        picked.append((rep.topic_id, chosen_chunks))

    # 6. Evidence IDs, stable in passage order.
    taken: set[str] = set()
    eid_of: dict[str, str] = {}
    out_passages: list[Passage] = []
    representative_levels = {rep.topic_id: rep.level for rep in representatives}
    for topic_id, chunks in picked:
        for chunk in chunks:
            if chunk in eid_of:
                continue
            eid = evidence_id(chunk, taken=taken)
            taken.add(eid)
            eid_of[chunk] = eid
            out_passages.append(Passage(evidence_id=eid, chunk_id=chunk, topic_id=topic_id,
                                        level=representative_levels[topic_id]))

    shards: list[Shard] = []
    current: Shard | None = None
    used = 0
    for topic_id, chunks in picked:
        eids = [p.evidence_id for p in out_passages if p.topic_id == topic_id]
        if not eids:
            continue
        size = len(eids) * excerpt_chars
        if current is None or used + size > shard_chars:
            current = Shard(index=len(shards), topic_ids=[], evidence_ids=[])
            shards.append(current)
            used = 0
        current.topic_ids.append(topic_id)
        current.evidence_ids.extend(eids)
        used += size

    return Sample(plan_id="", level=level, excerpt_chars=excerpt_chars, shard_chars=shard_chars,
                  passages=out_passages, shards=shards, warnings=warnings)


def excerpt(text: str, excerpt_chars: int) -> str:
    """First `excerpt_chars` chars, cut back to the last whitespace, whitespace-collapsed."""
    if len(text) > excerpt_chars:
        head = text[:excerpt_chars]
        if not text[excerpt_chars].isspace():
            cut = max((i for i, ch in enumerate(head) if ch.isspace()), default=-1)
            if cut > 0:
                head = head[:cut]
        text = head
    return " ".join(text.split())


def attach_excerpts(sample: Sample, evidence: dict[str, EvidenceText], *, plan_id: str) -> Sample:
    """Copy of `sample` with `plan_id` set and `source_id`/`excerpt` filled for every passage.

    Raises:
        Blocked("SOURCE_INDEX_ROWS"): a sampled chunk is missing from `evidence`.
    """
    missing = [p.chunk_id for p in sample.passages if p.chunk_id not in evidence]
    if missing:
        raise Blocked("SOURCE_INDEX_ROWS",
                      f"{len(missing)} sampled chunks have no source evidence text",
                      details={"missing": missing[:20]})
    passages = [replace(p, source_id=evidence[p.chunk_id].source_id,
                        excerpt=excerpt(evidence[p.chunk_id].text, sample.excerpt_chars))
                for p in sample.passages]
    shards = [Shard(index=s.index, topic_ids=list(s.topic_ids), evidence_ids=list(s.evidence_ids))
              for s in sample.shards]
    return Sample(plan_id=plan_id, level=sample.level, excerpt_chars=sample.excerpt_chars,
                  shard_chars=sample.shard_chars, passages=passages, shards=shards, warnings=list(sample.warnings))


def estimate_input_chars(sample: Sample, *, audit_mode: str = "full") -> dict[str, int]:
    """Upper-bound excerpt chars per call: `{"shard-0": n, ..., "audit": n}` (audit per plan audit_mode).

    A passage counts `len(excerpt)` once text is attached, else `excerpt_chars`. `audit_mode="full"` counts
    every passage; `"cited"` counts at most `CITED_EXCERPT_CHARS` per passage (any passage may be cited).
    """
    if audit_mode not in ("full", "cited"):
        raise ValueError(f"unknown audit_mode {audit_mode!r}")
    size = {p.evidence_id: len(p.excerpt) if p.excerpt is not None else sample.excerpt_chars for p in sample.passages}
    out = {f"shard-{s.index}": sum(size.get(e, sample.excerpt_chars) for e in s.evidence_ids) for s in sample.shards}
    cap = CITED_EXCERPT_CHARS if audit_mode == "cited" else None
    out["audit"] = sum(v if cap is None else min(v, cap) for v in size.values())
    return out
