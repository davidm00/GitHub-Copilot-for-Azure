"""Execution-grounded critique (`ontology-build critique --mode grounded`).

Adapted from an earlier ontology refinement and gap-analysis toolkit:
- For each competency question, runs server-side KB NL->GQL (`POST /knowledgebases/{kb}/retrieve`
  with `graphParameters.includeQuery=true`) against the built entity graph (or uses an injected
  `kb_retriever` collaborator for offline testing).
- Classifies each question outcome as `ONTOLOGY_GAP`, `EXTRACTION_MISS`, `GQL_PLANNING`,
  `TRUE_NEGATIVE`, `ANSWERED`, or `graph_error` (with expected-answer oracle verification when
  `expected` is present on the question).
- Converts ONLY `ONTOLOGY_GAP` findings into proposed change ops (`add_class`,
  `add_object_property`, `add_datatype_property`), using the existing critique record and
  `ontology-build revise --from-critique <id>` approval path. Never mutates the ontology automatically.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation
from enum import Enum
import json
from pathlib import Path
import re
from typing import Any, Callable, Iterator
import unicodedata

from ontology_core import azure_auth, http, lint, names, service_errors, state
from ontology_core.errors import Blocked
from ontology_core.model import DATATYPE_RANGES, EvidenceRecord, Ontology
from ontology_core.state import StatePaths

SEARCH_API_VERSION = "2026-11-01-preview"


class GapKind(str, Enum):
    unknown_node_label = "unknown_node_label"
    unknown_edge_label = "unknown_edge_label"
    domain_range_mismatch = "domain_range_mismatch"
    edge_direction = "edge_direction"
    invalid_gql = "invalid_gql"


class FailureClass(str, Enum):
    answered = "ANSWERED"
    ontology_gap = "ONTOLOGY_GAP"
    extraction_miss = "EXTRACTION_MISS"
    gql_planning = "GQL_PLANNING"
    true_negative = "TRUE_NEGATIVE"
    graph_error = "graph_error"


@dataclass
class Gap:
    kind: GapKind
    value: str
    suggest: dict[str, Any] | None = None
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["kind"] = self.kind.value
        return {k: v for k, v in d.items() if v not in (None, "")}


_TOKEN_RE = re.compile(
    r"\(\s*\w*\s*:\s*(?:`([^`]+)`|([A-Za-z_][A-Za-z0-9_]*))\s*\)"
    r"|(<-|-)\s*\[\s*\w*\s*:\s*(?:`([^`]+)`|([A-Za-z_][A-Za-z0-9_]*))\s*\]\s*(->|-)"
)
_NODE_RE = re.compile(r"\(\s*\w*\s*:\s*(?:`([^`]+)`|([A-Za-z_][A-Za-z0-9_]*))")
_EDGE_RE = re.compile(r"-\s*\[\s*\w*\s*:\s*(?:`([^`]+)`|([A-Za-z_][A-Za-z0-9_]*))\s*\]\s*-")


def extract_triples(gql: str) -> list[tuple[str, str, str, str]]:
    """Return `(left_label, edge_label, right_label, direction)` tuples for every hop in `gql`."""
    tokens: list[tuple[str, Any]] = []
    for mt in _TOKEN_RE.finditer(gql or ""):
        node_lbl = mt.group(1) or mt.group(2)
        if node_lbl is not None:
            tokens.append(("node", node_lbl))
        else:
            ld = mt.group(3)
            edge_lbl = mt.group(4) or mt.group(5)
            rd = mt.group(6)
            direction = "->" if rd == "->" else ("<-" if ld == "<-" else "-")
            tokens.append(("edge", (edge_lbl, direction)))
    out: list[tuple[str, str, str, str]] = []
    for i in range(len(tokens) - 2):
        if tokens[i][0] == "node" and tokens[i + 1][0] == "edge" and tokens[i + 2][0] == "node":
            left = tokens[i][1]
            edge, direction = tokens[i + 1][1]
            right = tokens[i + 2][1]
            out.append((left, edge, right, direction))
    return out


def analyze_gql(gql: str, ontology: Ontology, *, executable: bool = False) -> list[Gap]:
    """Contrastive check of `gql` against `ontology`."""
    if not isinstance(gql, str) or not gql.strip() or "MATCH" not in gql.upper() or "RETURN" not in gql.upper():
        return [Gap(kind=GapKind.invalid_gql, value=gql or "", detail="query must contain MATCH and RETURN")]
    gaps: list[Gap] = []
    known_classes = {c.name for c in ontology.classes}
    known_props = {p.name: p for p in ontology.properties}
    datatype_nodes = set(DATATYPE_RANGES) | {"xsd:string", "xsd:double", "xsd:boolean", "xsd:dateTime", "xsd:integer"}

    for m in _NODE_RE.finditer(gql):
        lbl = m.group(1) or m.group(2)
        if lbl and lbl not in known_classes and lbl not in datatype_nodes:
            norm = names.normalize_class(lbl) or lbl
            gaps.append(Gap(
                kind=GapKind.unknown_node_label,
                value=norm,
                suggest={"op": "add_class", "name": norm, "description": f"Entity class {norm} required by query."},
                detail=f"unknown node label {lbl!r}",
            ))

    for left, edge_raw, right, direction in extract_triples(gql):
        edge_name = edge_raw.removeprefix("prop:")
        subj, obj = (right, left) if direction == "<-" else (left, right)
        prop = known_props.get(edge_name)
        if prop is None:
            norm_edge = names.normalize_property(edge_name) or edge_name
            norm_subj = names.normalize_class(subj) or subj
            is_dt = obj in datatype_nodes
            norm_obj = obj.removeprefix("xsd:").capitalize() if is_dt else (names.normalize_class(obj) or obj)
            if is_dt and norm_obj not in DATATYPE_RANGES:
                norm_obj = "String"
            gaps.append(Gap(
                kind=GapKind.unknown_edge_label,
                value=norm_edge,
                suggest={
                    "op": "add_datatype_property" if is_dt else "add_object_property",
                    "name": norm_edge,
                    "domain": norm_subj,
                    "range": norm_obj,
                    "description": f"Relationship {norm_edge} from {norm_subj} to {norm_obj}.",
                },
                detail=f"unknown edge label {edge_raw!r} ({subj} -> {obj})",
            ))
            continue
        if prop.kind == "object":
            if (prop.domain, prop.range) == (obj, subj):
                gaps.append(Gap(
                    kind=GapKind.edge_direction,
                    value=edge_name,
                    detail=f"reversed direction on {edge_name}: expected {prop.domain}->{prop.range}, got {subj}->{obj}",
                ))
            elif prop.domain != subj or prop.range != obj:
                norm_subj = names.normalize_class(subj) or subj
                norm_obj = names.normalize_class(obj) or obj
                qual_name = f"{names.to_lower_camel(norm_subj)}{edge_name[:1].upper() + edge_name[1:]}"
                gaps.append(Gap(
                    kind=GapKind.domain_range_mismatch,
                    value=edge_name,
                    suggest={
                        "op": "add_object_property",
                        "name": qual_name,
                        "domain": norm_subj,
                        "range": norm_obj,
                        "description": f"Relationship {qual_name} from {norm_subj} to {norm_obj}.",
                    },
                    detail=f"domain/range mismatch on {edge_name}: schema has {prop.domain}->{prop.range}, query used {subj}->{obj}",
                ))
    return gaps


def classify_outcome(
    query: str,
    exec_gql: str | None,
    rows: list[dict[str, Any]],
    ontology: Ontology,
    *,
    ideal_gql: str | None = None,
    expected: Any = None,
    graph_error: str | None = None,
) -> tuple[FailureClass, list[Gap], bool | None]:
    """Classify a single grounded query execution into `FailureClass` and return `(fclass, gaps, expected_match)`."""
    if graph_error:
        return FailureClass.graph_error, [], None

    expected_match = expected_matches_rows(expected, rows, query)
    ideal_gaps = analyze_gql(ideal_gql, ontology) if ideal_gql else []
    ontology_gaps = [
        g for g in ideal_gaps
        if g.kind in {GapKind.unknown_node_label, GapKind.unknown_edge_label, GapKind.domain_range_mismatch}
    ]
    exec_gaps = analyze_gql(exec_gql or "", ontology, executable=True) if exec_gql else [
        Gap(kind=GapKind.invalid_gql, value="", detail="no GQL emitted by KB retrieve")
    ]

    if rows:
        if expected_match is False:
            if ontology_gaps:
                return FailureClass.ontology_gap, ontology_gaps, False
            return FailureClass.gql_planning, exec_gaps, False
        return FailureClass.answered, [], expected_match

    # 0 rows returned
    if expected_match is True and _is_negative_expected(expected):
        return FailureClass.answered, [], True
    if ontology_gaps:
        return FailureClass.ontology_gap, ontology_gaps, expected_match
    if exec_gaps:
        # Check if exec_gaps themselves indicate missing schema terms when ideal_gql was not provided
        schema_exec_gaps = [
            g for g in exec_gaps
            if g.kind in {GapKind.unknown_node_label, GapKind.unknown_edge_label, GapKind.domain_range_mismatch}
        ]
        if schema_exec_gaps:
            return FailureClass.ontology_gap, schema_exec_gaps, expected_match
        return FailureClass.gql_planning, exec_gaps, expected_match
    if expected is not None and not _is_negative_expected(expected):
        return FailureClass.extraction_miss, [], False
    return FailureClass.true_negative, [], expected_match


# --------------------------------------------------------------------------- expected-answer oracle


def _scalar_values(value: Any) -> Iterator[str]:
    if isinstance(value, dict):
        for key, item in value.items():
            if str(key).startswith("@search."):
                continue
            yield from _scalar_values(item)
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            yield from _scalar_values(item)
    elif value is not None:
        yield str(value)


def _normalise_answer(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value)).casefold()
    return " ".join(part for part in re.split(r"[\W_]+", text, flags=re.UNICODE) if part)


def _is_negative_expected(expected: Any) -> bool:
    return _normalise_answer(expected or "") in {"not in corpus", "unanswerable", "none"}


_ANSWER_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "because", "by", "for",
    "from", "in", "is", "it", "of", "on", "or", "that", "the", "to",
    "was", "were", "with",
}
_NUMERIC_RE = re.compile(
    r"(?<![\w.])[-+]?(?:\d{1,3}(?:[,\s]\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?|\.\d+)(?:[eE][-+]?\d+)?(?!\w)",
    re.UNICODE,
)


def _numeric_values(value: Any) -> set[Decimal]:
    numbers: set[Decimal] = set()
    for scalar in _scalar_values(value):
        norm = unicodedata.normalize("NFKC", scalar)
        for m in _NUMERIC_RE.finditer(norm):
            raw = re.sub(r"[,\s]", "", m.group(0))
            try:
                numbers.add(Decimal(raw))
            except InvalidOperation:
                continue
    return numbers


def expected_matches_rows(expected: Any, rows: list[dict[str, Any]], query: str = "") -> bool | None:
    """Return expected-answer agreement against `rows`, or `None` when `expected` is None/empty."""
    if expected is None:
        return None
    expected_values = [norm for v in _scalar_values(expected) if (norm := _normalise_answer(v))]
    if not expected_values:
        return None
    if len(expected_values) == 1 and _is_negative_expected(expected):
        return not rows
    if not rows:
        return False
    expected_nums = _numeric_values(expected) - _numeric_values(query)
    if expected_nums and not expected_nums.issubset(_numeric_values(rows)):
        return False
    row_values = [norm for v in _scalar_values(rows) if (norm := _normalise_answer(v))]
    row_blob = " ".join(row_values)
    if all(any(ev == rv or f" {ev} " in f" {rv} " or f" {ev} " in f" {row_blob} " for rv in row_values)
           for ev in expected_values):
        return True
    exp_tokens = set(_normalise_answer(expected).split()) - set(_normalise_answer(query).split()) - _ANSWER_STOPWORDS
    if not exp_tokens:
        exp_tokens = set(_normalise_answer(expected).split()) - _ANSWER_STOPWORDS
    row_tokens = set(row_blob.split())
    matched = exp_tokens & row_tokens
    return bool(exp_tokens and matched) and (len(matched) / len(exp_tokens) >= 0.6)


# --------------------------------------------------------------------------- KB retrieval & grounded critique


def parse_kb_retrieve_response(data: dict[str, Any]) -> tuple[str | None, list[dict[str, Any]], str]:
    """Extract `(executed_gql, rows, answer_text)` from a KB `/retrieve` JSON response."""
    activities = data.get("activity") or data.get("activities") or []
    gql: str | None = None
    for act in activities:
        if isinstance(act, dict) and str(act.get("type") or "").casefold() == "graphsearch":
            args = act.get("graphSearchArguments") or {}
            if isinstance(args, dict) and isinstance(args.get("gql"), str):
                gql = args["gql"]
                break
    rows: list[dict[str, Any]] = []
    for ref in data.get("references") or []:
        if not isinstance(ref, dict):
            continue
        src = ref.get("sourceData")
        if isinstance(src, dict) and isinstance(src.get("rows"), list):
            for r in src["rows"]:
                if isinstance(r, dict):
                    rows.append(r)
                elif isinstance(r, list) and isinstance(src.get("columns"), list):
                    rows.append(dict(zip(src["columns"], r)))
        elif str(ref.get("type") or "").casefold() == "graphsearch" and isinstance(src, dict):
            rows.append(src)
    answer = ""
    resp = data.get("response")
    if isinstance(resp, list) and resp and isinstance(resp[0], dict):
        content = resp[0].get("content")
        if isinstance(content, list) and content and isinstance(content[0], dict):
            answer = str(content[0].get("text") or "")
    return gql, rows, answer


def live_kb_retriever(
    *,
    search_endpoint: str,
    kb_name: str,
    ks_name: str,
    tenant_id: str,
) -> Callable[[str], dict[str, Any]]:
    """Return a callable `retrieve(query) -> dict` invoking `POST /knowledgebases/{kb_name}/retrieve`."""
    endpoint = search_endpoint.rstrip("/")
    url = f"{endpoint}/knowledgebases/{kb_name}/retrieve?api-version={SEARCH_API_VERSION}"
    policy = http.EgressPolicy(search_endpoint=endpoint, physical_index=kb_name)

    def retrieve(query: str) -> dict[str, Any]:
        tok = azure_auth.token(tenant_id, "search")
        body = {
            "messages": [{"role": "user", "content": [{"type": "text", "text": query}]}],
            "outputMode": "extractiveData",
            "includeActivity": True,
            "knowledgeSourceParams": [{
                "knowledgeSourceName": ks_name,
                "kind": "azureBlob",
                "includeReferences": True,
                "includeReferenceSourceData": True,
                "graphParameters": {
                    "includeQuery": True,
                    "provenance": {
                        "kind": "hydrate",
                        "hydrateDocuments": {"top": 5},
                    },
                },
            }],
        }
        resp = http.request(
            policy, "POST", url,
            headers={"Authorization": f"Bearer {tok}", "Content-Type": "application/json"},
            json_body=body,
        )
        if resp.status != 200:
            info = resp.service_error()
            raise KbRetrieveError(f"KB retrieve {service_errors.summary(info)}", info)
        return json.loads(resp.body.decode("utf-8"))

    return retrieve


class KbRetrieveError(RuntimeError):
    """A failed knowledge-base retrieve; `service_error` is the parsed, redacted service response."""

    def __init__(self, message: str, service_error: dict[str, Any]) -> None:
        super().__init__(message)
        self.service_error = service_error


def run_grounded_critique(
    paths: StatePaths,
    *,
    version: int | None = None,
    queries_path: Path,
    kb_retriever: Callable[[str], dict[str, Any]],
    ideal_gql_by_id: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Run execution-grounded critique over `queries_path` against `version` and save `critiques/<id>.json`.

    Only `ONTOLOGY_GAP` outcomes generate findings and proposed change ops for `ontology-build revise`.
    """
    n = state.resolve_version(paths, version)
    meta, ontology = state.load_version(paths, n)
    evidence_records = state.load_grounding_evidence(paths, n)
    default_eids = [r.evidence_id for r in evidence_records[:3]] or ["E0000000001"]

    raw_lines = [line.strip() for line in Path(queries_path).expanduser().read_text(encoding="utf-8").splitlines() if line.strip()]
    questions = [json.loads(line) for line in raw_lines]

    lint_findings = lint.lint(ontology)
    classes_counter: Counter[str] = Counter()
    detail: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = [
        {"fingerprint": f.fingerprint, "severity": f.severity, "source": "lint", "rationale": f.message, "evidence": []}
        for f in lint_findings
    ]
    seen_fingerprints = {f["fingerprint"] for f in findings}
    ops: list[dict[str, Any]] = []
    seen_ops: set[tuple[str, str]] = set()

    for q in questions:
        qid = str(q["id"])
        qtext = str(q["query"])
        expected = q.get("expected")
        q_eids = [e for e in (q.get("evidence") or []) if isinstance(e, str)] or default_eids
        ideal = (ideal_gql_by_id or {}).get(qid) or q.get("ideal_gql")
        graph_err: str | None = None
        graph_service_error: dict[str, Any] | None = None
        exec_gql: str | None = None
        rows: list[dict[str, Any]] = []
        try:
            kb_resp = kb_retriever(qtext)
            exec_gql, rows, _ = parse_kb_retrieve_response(kb_resp)
        except Exception as exc:  # noqa: BLE001
            graph_err = f"{type(exc).__name__}: {exc}"
            graph_service_error = service_errors.from_exception(exc)
            if (graph_service_error and graph_service_error.get("message")
                    and str(graph_service_error["message"]) not in graph_err):
                graph_err += f" ({service_errors.summary(graph_service_error)})"

        fclass, gaps, exp_match = classify_outcome(
            qtext, exec_gql, rows, ontology,
            ideal_gql=ideal, expected=expected, graph_error=graph_err,
        )
        classes_counter[fclass.value] += 1
        entry: dict[str, Any] = {
            "id": qid,
            "query": qtext,
            "expected": expected,
            "expected_match": exp_match,
            "gql": exec_gql,
            "ideal_gql": ideal,
            "row_count": len(rows),
            "failure_class": fclass.value,
            "graph_error": graph_err,
            "gaps": [g.to_dict() for g in gaps],
        }
        if graph_service_error:
            entry["service_error"] = graph_service_error
        detail.append(entry)

        if fclass == FailureClass.ontology_gap:
            for g in gaps:
                if not g.suggest:
                    continue
                fp = f"ontology_gap:{g.value}"
                if fp not in seen_fingerprints:
                    seen_fingerprints.add(fp)
                    findings.append({
                        "fingerprint": fp,
                        "severity": "high",
                        "source": "grounded",
                        "rationale": f"Query {qid} hit ontology gap ({g.kind.value}): {g.detail or g.value}",
                        "evidence": q_eids[:5],
                    })
                op_key = (g.suggest["op"], g.suggest["name"])
                if op_key not in seen_ops and len(ops) < 20:
                    seen_ops.add(op_key)
                    # If an add_*_property references an unknown domain/range class, also add the class op first
                    if g.suggest["op"] in {"add_object_property", "add_datatype_property"}:
                        for endpoint_key in ("domain", "range"):
                            if g.suggest["op"] == "add_datatype_property" and endpoint_key == "range":
                                continue
                            cls_name = g.suggest[endpoint_key]
                            if not ontology.find_class(cls_name) and ("add_class", cls_name) not in seen_ops and len(ops) < 19:
                                seen_ops.add(("add_class", cls_name))
                                ops.append({
                                    "op": "add_class",
                                    "finding": fp,
                                    "name": cls_name,
                                    "description": f"Entity class {cls_name} required by {g.suggest['name']}.",
                                    "evidence": q_eids[:5],
                                })
                    ops.append({
                        **g.suggest,
                        "finding": fp,
                        "evidence": q_eids[:5],
                    })

    answered_count = classes_counter.get(FailureClass.answered.value, 0)
    q_score = max(1, min(5, round(1 + 4 * (answered_count / max(1, len(questions))))))
    scores = {
        "connectivity": 4,
        "specificity": 4,
        "domain_range_correctness": 5 if not ops else 3,
        "redundancy": 4,
        "grounding": 4,
        "question_coverage": q_score,
    }
    from ontology_core import hashing
    digest16 = hashing.sha256_json({"schema_id": meta.schema_id, "detail": detail})[:16]
    cid = f"crit-{digest16}"
    record = {
        "critique_id": cid,
        "plan_id": f"oplan-{digest16}",
        "mode": "grounded",
        "round": None,
        "version": n,
        "schema_id": meta.schema_id,
        "created_at": state.utc_now(),
        "prompt_sha256": meta.prompt_sha256 or ("0" * 64),
        "queries": len(questions),
        "lint": [f.to_dict() for f in lint_findings],
        "scores": scores,
        "total": sum(scores.values()),
        "max_total": 30,
        "findings": findings,
        "ops": ops,
        "judge_warnings": [],
        "classification": dict(classes_counter),
        "ontology_gap_queries": [d["id"] for d in detail if d["failure_class"] == FailureClass.ontology_gap.value],
        "detail": detail,
    }
    path = paths.critique(cid)
    state.write_json(path, record)
    return {
        "status": "ok",
        "mode": "grounded",
        "critique_id": cid,
        "version": n,
        "schema_id": meta.schema_id,
        "classification": dict(classes_counter),
        "ontology_gap_queries": record["ontology_gap_queries"],
        "findings": len(findings),
        "ops": len(ops),
        "next_step": (f"ontology-build revise --from-critique {cid}" if ops else f"ontology-build approve --version {n} --schema-id {meta.schema_id}"),
    }
