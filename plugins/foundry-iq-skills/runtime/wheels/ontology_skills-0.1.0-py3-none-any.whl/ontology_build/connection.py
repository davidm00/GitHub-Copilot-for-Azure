"""Topic Graph output doctor, inspection and text-free planning."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ontology_build.reader import OntologyReader
from ontology_core import doctor, hashing, state
from ontology_core.errors import Blocked
from ontology_core.journal import Journal, StateLock
from ontology_core.model import Config
from ontology_core.state import StatePaths

PLAN_HINT = "ontology-build plan --model-max-spend-usd <usd>"


def doctor_context(paths: StatePaths, *, tenant_id: str | None = None,
                   model_endpoint: str | None = None, model_deployment: str | None = None,
                   subscription_id: str | None = None, model_resource_group: str | None = None,
                   plugin_root: str | None = None) -> doctor.DoctorContext:
    config: Config | None = None
    try:
        config = state.load_config(paths) if paths.config.is_file() else None
    except Blocked:
        # The state-dir doctor check reports a malformed saved config.
        config = None
    same_tenant = config is not None and (tenant_id is None or tenant_id == config.tenant_id)
    return doctor.DoctorContext(
        state_dir=paths.root, config=config,
        tenant_id=tenant_id or (config.tenant_id if config else None),
        tenant_name=config.tenant_name if same_tenant and config else None,
        topicgraph_input_path=paths.descriptor if config is not None or paths.descriptor.is_file() else None,
        model_endpoint=model_endpoint or (config.model.endpoint if config else None),
        model_deployment=model_deployment or (config.model.deployment if config else None),
        subscription_id=subscription_id or (config.model.subscription_id if config else None),
        model_resource_group=model_resource_group or (config.model.resource_group if config else None),
        plugin_root=doctor.plugin_root_from(plugin_root),
    )


def next_step_after_doctor(paths: StatePaths) -> str:
    from ontology_consume import service

    try:
        return str(service.status(paths)["next_step"])
    except Blocked as exc:
        return exc.next_step


def run_doctor(ctx: doctor.DoctorContext, paths: StatePaths, *,
               checks: tuple[str, ...] = doctor.CHECKS) -> dict[str, Any]:
    results = doctor.run(ctx, checks=checks)
    ok_next = next_step_after_doctor(paths) if checks == doctor.CHECKS else "ontology-consume status"
    return doctor.result(results, next_step_if_ok=ok_next)


def _data(result: dict[str, Any], check: str) -> dict[str, Any]:
    return next((c.get("data", {}) for c in result.get("checks", []) if c["name"] == check), {})


def local_descriptor(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        raise Blocked("TOPICGRAPH_INPUT_INVALID", "The saved Topic Graph input cannot be read.") from None
    if not isinstance(raw, dict) or raw.get("version") != "topicgraph-output-v1":
        raise Blocked("TOPICGRAPH_INPUT_INVALID", "This saved input is unsupported; connect a Topic Graph build output folder in a new state directory.")
    return raw


def reader_for(paths: StatePaths, config: Config | None = None) -> tuple[Config, OntologyReader]:
    from ontology_build.topicgraph_reader import TopicGraphReader

    config = config or state.load_config(paths)
    local = local_descriptor(paths.descriptor)
    if local is None:
        raise Blocked("TOPICGRAPH_INPUT_INVALID", "The saved Topic Graph input is missing; rerun connect.")
    if hashing.sha256_bytes(paths.descriptor.read_bytes()) != config.topicgraph.descriptor_sha256:
        raise Blocked("TOPICGRAPH_INPUT_CHANGED", "The saved Topic Graph input differs from the connected binding.")
    if (local.get("structure_id"), local.get("endpoint"), local.get("index")) != (
        config.topicgraph.generation_id, config.topicgraph.search_endpoint, config.topicgraph.physical_index
    ):
        raise Blocked("TOPICGRAPH_INPUT_CHANGED", "The saved Topic Graph input differs from the connected source.")
    return config, TopicGraphReader(local, config.tenant_id)


def inspect(paths: StatePaths) -> dict[str, Any]:
    from ontology_build import reader as reader_contract, sampler

    config, reader = reader_for(paths)
    manifest = reader.manifest()
    representatives, members = reader.representatives(), reader.members(None)
    reader_contract.check_manifest(manifest, representatives, members)
    per_level = sampler.levels(representatives)
    level = sampler.default_level(representatives)
    rows = []
    for n in sorted(per_level):
        reps = [r for r in representatives if r.level == n]
        labeled = sum(1 for r in reps if r.label)
        chunks = {m.chunk_id for m in members if m.level == n}
        rows.append({"level": n, "topics": per_level[n], "members": sum(r.member_count for r in reps),
                     "chunks": len(chunks), "label_coverage": round(labeled / len(reps), 3) if reps else 0.0,
                     "sampled_topics": len(sampler.frontier(representatives, n))})
    passages = sampler.default_passages(len(sampler.frontier(representatives, level)),
                                        len({m.chunk_id for m in members}))
    return {
        "status": "ok", "tenant_id": config.tenant_id, "tenant_name": config.tenant_name,
        "generation_id": config.topicgraph.generation_id, "health": manifest.health,
        "level_numbering": "level 0 is the broadest, same numbering as Topic Graph",
        "levels": rows, "default_level": level, "default_passages": passages,
        "input_kind": "topicgraph-output-v1",
        "source_consistency": "passage text is read from the source index as it is now, not as it was at build time",
        "provenance": {key: manifest.payload.get(key) for key in
                       ("structure_id", "manifest_sha256", "labels_sha256", "source", "source_schema_sha256")},
        "next_step": PLAN_HINT,
    }


def plan_request(*, max_spend_usd: float, seed: str | None = None, level: int | None = None,
                 passages: int | None = None, excerpt_chars: int = 1200, shard_chars: int = 60000,
                 reasoning_effort: str = "low", max_output_tokens: int = 8000, max_tokens: int | None = None) -> Any:
    from ontology_build import planning

    return planning.PlanRequest(max_spend_usd=max_spend_usd, seed=Path(seed).expanduser() if seed else None,
                                level=level, passages=passages, excerpt_chars=excerpt_chars, shard_chars=shard_chars,
                                reasoning_effort=reasoning_effort,  # type: ignore[arg-type]
                                max_output_tokens=max_output_tokens, max_tokens=max_tokens)


def plan(paths: StatePaths, request: Any) -> dict[str, Any]:
    from ontology_build import planning

    config, reader = reader_for(paths)
    seed = planning.load_seed(paths, request.seed)
    built, sample = planning.build_plan(config, reader, request, seed=seed)
    planning.require_within_cap(built, request)
    with StateLock(paths, "plan"):
        planning.save_plan(paths, Journal(paths), built)
    return dict(planning.result(built, sample))
