"""Source-neutral hierarchy and evidence contracts for ontology induction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from ontology_core.errors import Blocked


@dataclass(frozen=True)
class Manifest:
    payload: dict[str, Any]
    digest: str

    @property
    def health(self) -> str:
        return str(self.payload.get("health"))

    @property
    def counts(self) -> dict[str, int]:
        return dict(self.payload.get("counts") or {})


@dataclass(frozen=True)
class Representative:
    topic_id: str
    parent_id: str | None
    level: int
    member_count: int
    label: str | None
    label_status: str | None
    summary: str | None = None

    @property
    def label_hint(self) -> str | None:
        return self.label if self.label_status == "named" else None


@dataclass(frozen=True)
class Membership:
    topic_id: str
    chunk_id: str
    level: int


@dataclass(frozen=True)
class EvidenceText:
    chunk_id: str
    source_id: str
    text: str


class OntologyReader(Protocol):
    def manifest(self) -> Manifest: ...

    def representatives(self) -> list[Representative]: ...

    def members(self, level: int | None = None) -> list[Membership]: ...

    def evidence(self, chunk_ids: list[str]) -> dict[str, EvidenceText]: ...


def check_manifest(manifest: Manifest, representatives: list[Representative], members: list[Membership]) -> None:
    if manifest.health != "verified":
        raise Blocked("TOPICGRAPH_STRUCTURE_INVALID", f"Structure manifest health is {manifest.health!r}, not 'verified'")
    actual = {"representative": len(representatives), "membership": len(members)}
    differences = {k: {"manifest": manifest.counts.get(k), "rows": v}
                   for k, v in actual.items() if manifest.counts.get(k) != v}
    if differences:
        raise Blocked("TOPICGRAPH_STRUCTURE_INVALID", "Structure manifest counts differ from reconstructed membership.",
                      details={"counts": differences})
