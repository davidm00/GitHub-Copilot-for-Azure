"""The approval card for every gate: a headline, a few plain bullets, time and cost.

    APPROVAL: <what, one line>
    - <what it reads, sends or saves, in plain words>
    Time: about X–Y min
    Cost: about $X, at most $Y (your cap is $Z)
    If it stops part way, running it again reuses the finished calls; they aren't charged again.
    Approve this card to go ahead. Nothing changes until you do.

No plan or schema ID, tenant or subscription: the agent passes the IDs, so the user never types one, and
this plugin never creates Azure resources.
"""

from __future__ import annotations

import math
from typing import Any

from ontology_core.state import StatePaths

SECONDS_PER_CALL = (20, 90)
"""Rough wall-clock range per model call, for the Time line."""

RESUME = "If it stops part way, running it again reuses the finished calls; they aren't charged again."
APPROVE = "Approve this card to go ahead. Nothing changes until you do."


def things(classes: int, relationships: int, attributes: int) -> str:
    """Plain counts: "23 types of things, 40 links between them and 22 attributes"."""
    def n(count: int, one: str, many: str) -> str:
        return f"{count} {one if count == 1 else many}"
    return (f"{n(classes, 'type of thing', 'types of things')}, "
            f"{n(relationships, 'link between them', 'links between them')} and "
            f"{n(attributes, 'attribute', 'attributes')}")


def _usd(value: Any) -> str:
    try:
        return f"${float(value):.2f}"
    except (TypeError, ValueError):
        return "$?"


def _usd_up(value: Any) -> str:
    """Rounded up to the cent, so "at most" is never below the budget the user is asked to approve."""
    try:
        return f"${math.ceil(round(float(value) * 100, 6)) / 100:.2f}"
    except (TypeError, ValueError):
        return "$?"


def _minutes(calls: int) -> str:
    low, high = (max(1, math.ceil(calls * s / 60)) for s in SECONDS_PER_CALL)
    return f"Time: about {low}–{max(high, low + 1)} min"


def card(what: str, bullets: list[str], *tail: str) -> list[str]:
    return [f"APPROVAL: {what}", *[f"- {b}" for b in bullets], *tail, APPROVE]


def for_plan(paths: StatePaths, result: dict[str, Any]) -> list[str]:
    """The card for a saved `plan` (propose, critique or refine): approving it allows the model spend."""
    est, caps = result.get("estimate") or {}, result.get("caps") or {}
    calls = int(result.get("calls") or est.get("calls") or 0)
    kind = result.get("kind") or "propose"
    samples = int(result.get("judge_samples") or 1)
    reviews = (f"{samples} reviews per version, using the middle score" if samples > 1
               else "1 review per version")
    model = f" ({result['judge_deployment']}" if result.get("judge_deployment") else ""
    if model:
        model += f" at {result['judge_endpoint']})" if result.get("judge_endpoint") else ")"
    v = result.get("version")
    if kind == "critique":
        what = f"have a reviewer model check ontology v{v}"
        bullets = [f"Asks a reviewer model{model} to check v{v}: {calls} call(s), {reviews}",
                   "Saves its suggestions; the ontology itself doesn't change"]
    elif kind == "refine":
        what = f"improve ontology v{v} with a reviewer model, up to {result.get('rounds')} rounds"
        bullets = [f"Asks a reviewer model{model} to check and fix v{v}: up to {calls} call(s), "
                   f"{result.get('rounds')} rounds at most, {reviews}",
                   "Saves each improved version as a draft you review before anything uses it"]
    else:
        what = "propose an ontology from your topics"
        bullets = [f"Reads {result.get('passages')} passages from your index (it changes nothing there)",
                   f"Makes {calls} call(s) to your chat model",
                   "Saves a draft you review before anything uses it"]
        requested = result.get("requested_passages", result.get("passages"))
        if requested != result.get("passages"):
            bullets.append(f"Picked {result.get('passages')} of the {requested} requested passages")
        if result.get("warnings"):
            bullets.append(f"{len(result['warnings'])} sampling warning(s) are in the plan result")
    expected = est.get("expected_usd", est.get("usd"))
    cost = (f"Cost: about {_usd(expected)}, at most {_usd_up(est.get('usd'))} "
            f"(your cap is {_usd(caps.get('max_spend_usd'))})")
    return card(what, bullets, _minutes(calls), cost, RESUME)


def for_review(paths: StatePaths, result: dict[str, Any]) -> list[str]:
    """The card for approving a reviewed version. The agent passes its schema ID; the user never sees it."""
    n, props = result["version"], result["properties"]
    counts = things(result["classes"]["count"], props.get("object", 0), props.get("datatype", 0))
    return card(f"use ontology v{n}", [f"v{n} has {counts}",
                                       "It becomes the ontology the next steps use"],
                "Cost: none; nothing in Azure changes.")
