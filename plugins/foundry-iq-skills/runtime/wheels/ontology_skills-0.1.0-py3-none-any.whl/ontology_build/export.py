"""`export` and `import`."""

from __future__ import annotations

import dataclasses
from pathlib import Path
from typing import Any, Literal

from ontology_core import diff as diff_mod
from ontology_core import hygiene, jsonld_profile, jsonld_write, owl_read, state
from ontology_core.errors import Blocked
from ontology_core.journal import Journal, StateLock
from ontology_core.model import ExportTopicGraph, ExportManifest, JsonLdExportManifest, Ontology, Version
from ontology_core.state import StatePaths

ExportFormat = Literal["jsonld"]
FALLBACK_SOURCE = "ontology"


def _export_version(paths: StatePaths, version: int | None) -> int:
    if version is not None:
        n = state.resolve_version(paths, version)
        approval = state.load_approval(paths, n)
        if approval is None:
            meta = state.read_record(paths.version_json(n), Version)
            raise Blocked("NOT_APPROVED", f"v{n} is not approved", n=n, id=meta.schema_id)
        return n
    approved = state.latest_approved_version(paths)
    if approved is not None:
        return approved
    latest = state.resolve_version(paths, None)
    meta = state.read_record(paths.version_json(latest), Version)
    raise Blocked("NOT_APPROVED", "no version is approved yet", n=latest, id=meta.schema_id)


def _base_iri(paths: StatePaths, base_iri: str | None) -> str:
    if base_iri:
        return jsonld_write.validate_base_iri(base_iri)
    source = FALLBACK_SOURCE
    if paths.config.is_file():
        source = state.load_config(paths).topicgraph.source_index or FALLBACK_SOURCE
    return jsonld_write.default_base_iri(source)


def record_current(paths: StatePaths, n: int, meta: Version, ontology: Ontology, approved_at: str, *,
                   data: bytes | None = None, iri: str | None = None, exported_to: str | None = None) -> dict[str, Any]:
    """Point the per-user `current` record at approved version `n` (see `ontology_core.current`)."""
    from ontology_core import current

    iri = iri or _base_iri(paths, None)
    if data is None:
        flat_ontology = dataclasses.replace(
            ontology,
            classes=[dataclasses.replace(c, parent=None) for c in ontology.classes],
        )
        data = jsonld_write.write(
            flat_ontology, base_iri=iri, version_info=jsonld_write.version_info(n, meta.schema_id)
        )
    generation = meta.topicgraph_generation_id
    if generation is None and meta.origin != "import" and paths.config.is_file():
        generation = state.load_config(paths).topicgraph.generation_id
    return current.record(jsonld=data, ontology_iri=iri, classes=len(ontology.classes),
                          properties=len(ontology.properties), source_generation=generation,
                          approved_at=approved_at, schema_id=meta.schema_id, version=n, state_dir=paths.root,
                          exported_to=exported_to)


def export(paths: StatePaths, *, output: Path, version: int | None = None, fmt: str = "jsonld",
           base_iri: str | None = None, force: bool = False) -> dict[str, Any]:
    """Write the approved version as OWL in JSON-LD (.jsonld) with an export manifest.
    `version=None` means latest approved. The profile is validated before writing.

    Raises: EXPORT_FORMAT_UNSUPPORTED, VERSION_NOT_FOUND, NOT_APPROVED, SCHEMA_ID_MISMATCH, OUTPUT_EXISTS,
        BASE_IRI_INVALID, PROFILE_VIOLATION, JSONLD_EXPORT_UNSUPPORTED, JSONLD_PROFILE_VIOLATION, STATE_LOCKED.
    """
    if fmt != "jsonld":
        raise Blocked("EXPORT_FORMAT_UNSUPPORTED", f"format {fmt!r} is not supported; export writes OWL in JSON-LD (.jsonld)")
    if Path(output).suffix.lower() != ".jsonld":
        raise Blocked("EXPORT_FORMAT_UNSUPPORTED", "export requires a .jsonld output path")
    n = _export_version(paths, version)
    meta, ontology = state.load_version(paths, n)
    approval = state.load_approval(paths, n)
    if approval is None or approval.schema_id != meta.schema_id:
        raise Blocked("NOT_APPROVED", f"the approval for v{n} is for a different schema ID", n=n, id=meta.schema_id)
    target = Path(output).expanduser().resolve()
    if target.exists() and not force:
        raise Blocked("OUTPUT_EXISTS", f"{target} already exists")
    iri = _base_iri(paths, base_iri)
    data = jsonld_write.write(ontology, base_iri=iri, version_info=jsonld_write.version_info(n, meta.schema_id))
    jsonld_profile.require_valid(data, file=str(target))
    with StateLock(paths, "export"):
        jsonld_sha = _write_output(target, data)
        aliases_file = _write_aliases_file(target, ontology, meta.schema_id)
        topicgraph = None
        if meta.origin == "propose" and paths.config.is_file():
            binding = state.load_config(paths).topicgraph
            topicgraph = ExportTopicGraph(search_endpoint=binding.search_endpoint, physical_index=binding.physical_index,
                            generation_id=meta.topicgraph_generation_id or binding.generation_id,
                            source_index=binding.source_index)
        manifest = ExportManifest(
            schema_id=meta.schema_id, version=n, format="jsonld", jsonld_sha256=jsonld_sha,
            output=str(target), base_iri=iri, tool_version=state.tool_version(),
            created_at=state.utc_now(), plan_id=meta.plan_id, prompt_sha256=meta.prompt_sha256,
            model=meta.model, topicgraph=topicgraph)
        manifest_path = paths.export_manifest(meta.schema_id)
        journal = Journal(paths)
        sha = state.write_record(manifest_path, manifest)
        journal.append("artifact_written", path=paths.relative(manifest_path), sha256=sha)
        journal.append("export_written", version=n, schema_id=meta.schema_id, format="jsonld", output=str(target),
                       sha256=jsonld_sha)
    pointer = record_current(paths, n, meta, ontology, approval.approved_at, data=data, iri=iri,
                             exported_to=str(target))
    result: dict[str, Any] = {
        "status": "ok",
        "version": n,
        "schema_id": meta.schema_id,
        "format": "jsonld",
        "profile": "inline-jsonld-v1",
        "output": str(target),
        "jsonld_sha256": jsonld_sha,
        "base_iri": iri,
        "current": pointer["path"],
        "manifest": str(manifest_path),
        "next_step": f"entity-graph-build attach-ontology --ontology {target}",
    }
    if aliases_file is not None:
        result["aliases_output"] = str(aliases_file[0])
        result["aliases_sha256"] = aliases_file[1]
    return result


def _write_aliases_file(target: Path, ontology: Ontology, schema_id: str) -> tuple[Path, str] | None:
    """Write `<target>.aliases.json` when any class or property has lexical aliases."""
    class_aliases = {c.name: list(c.aliases) for c in sorted(ontology.classes, key=lambda item: item.name) if c.aliases}
    prop_aliases = {p.name: list(p.aliases) for p in sorted(ontology.properties, key=lambda item: item.name) if p.aliases}
    if not class_aliases and not prop_aliases:
        return None
    aliases_path = target.with_name(target.name + ".aliases.json")
    payload = {
        "schema_id": schema_id,
        "version": ontology.version,
        "classes": class_aliases,
        "properties": prop_aliases,
    }
    from ontology_core import hashing
    sha = _write_output(aliases_path, hashing.canonical_bytes(payload))
    return aliases_path, sha


def _write_output(target: Path, data: bytes) -> str:
    """Atomic write of a user-chosen file: its directory is created with default permissions, not user-only."""
    state.ensure_dir(target.parent, private=False)
    return state.atomic_write(target, data)


def import_file(paths: StatePaths, file: Path, *, as_seed: bool = False) -> dict[str, Any]:
    """Import an ontology file as a new version (origin `import`), or as `v0` with every item `seed=True` when
    `as_seed` and no v0 exists. Runs hygiene with `evidence_ids=None`.

    Returns `{status:"ok", version, schema_id, classes, properties, hygiene, next_step}`.

    Raises: IMPORT_UNSUPPORTED_FORMAT, IMPORT_INVALID, IMPORT_HAS_IMPORTS, EMPTY_ONTOLOGY, STATE_LOCKED.
    """
    source = Path(file).expanduser()
    if not source.is_file():
        raise Blocked("IMPORT_INVALID", f"{source} does not exist or is not a file",
                      next_step="pass the path of an existing .owl, .rdf or .ttl file")
    read = owl_read.read_file(source)
    paths = state.ensure_state(paths.root)
    with StateLock(paths, "import"):
        existing = state.list_versions(paths)
        seed_slot = as_seed and 0 not in existing
        n = 0 if seed_slot else state.next_version(paths)
        ontology, report = hygiene.clean(read.raw, None, None, version=n, origin="import")
        if seed_slot:
            ontology = _as_seed(ontology)
        warnings = list(read.warnings) + list(report.warnings)
        if as_seed and not seed_slot:
            warnings.append("seed_exists: v0 already exists; imported as a normal version")
        report = dataclasses.replace(report, warnings=warnings)
        parent = existing[-1] if existing else None
        prev = state.load_version(paths, parent)[1] if parent is not None else None
        change = None if n == 0 else diff_mod.diff(prev, ontology)
        schema_id = ontology.schema_id()
        meta = Version(version=n, schema_id=schema_id, origin="import", tool_version=state.tool_version(),
                       created_at=state.utc_now(), hygiene=report, parent_version=parent)
        state.write_version(paths, Journal(paths), version=meta, ontology=ontology, evidence=[], diff=change)
    return {
        "status": "ok",
        "version": n,
        "schema_id": schema_id,
        "seed": seed_slot,
        "file": str(source),
        **ontology.counts(),
        "hygiene": {"dropped": len(report.dropped), "renamed": len(report.renamed), "warnings": warnings},
        "next_step": f"ontology-build review --version {n}",
    }


def _as_seed(ontology: Ontology) -> Ontology:
    return dataclasses.replace(
        ontology,
        classes=[dataclasses.replace(c, seed=True) for c in ontology.classes],
        properties=[dataclasses.replace(p, seed=True) for p in ontology.properties],
    )
