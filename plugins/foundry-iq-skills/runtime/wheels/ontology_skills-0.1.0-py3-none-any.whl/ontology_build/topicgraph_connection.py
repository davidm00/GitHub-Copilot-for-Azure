"""Connect a Topic Graph build output folder; no published Topic Graph index or visibility attestation is used."""

from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any

from ontology_build import connection
from ontology_build.topicgraph_reader import TopicGraphReader, create_descriptor, resolve_output
from ontology_core import doctor, hashing, state
from ontology_core.errors import Blocked
from ontology_core.journal import Journal, StateLock
from ontology_core.model import Config, ModelBinding, TopicGraphBinding
from ontology_core.state import StatePaths


def connect(paths: StatePaths, *, tenant_id: str, topicgraph_output: str, structure_id: str | None = None,
            labels_id: str | None = None, accept_current_source: bool, model_endpoint: str, model_deployment: str,
            input_price_per_1m: float, output_price_per_1m: float, subscription_id: str | None = None,
            model_resource_group: str | None = None) -> dict[str, Any]:
    tenant_id = (tenant_id or "").strip()
    try:
        uuid.UUID(tenant_id)
    except ValueError:
        raise Blocked("TENANT_REQUIRED", "--tenant-id must be a tenant GUID") from None
    if accept_current_source is not True:
        raise Blocked("SOURCE_CURRENT_READ_REQUIRED",
                      "Passage text is read from the source index as it is now, not as it was at build time.")
    structure_dir, labels = resolve_output(Path(topicgraph_output), structure_id=structure_id, labels_id=labels_id)
    descriptor = create_descriptor(structure_dir, labels, accept_current_source=True)
    existing = state.load_config(paths) if paths.config.is_file() else None
    endpoint = model_endpoint.rstrip("/")
    if existing is not None:
        saved = connection.local_descriptor(paths.descriptor)
        original = {k: v for k, v in (saved or {}).items() if k != "source_schema_sha256"}
        if (original != descriptor or existing.tenant_id != tenant_id
                or existing.model.endpoint != endpoint or existing.model.deployment != model_deployment):
            raise Blocked("CONFIG_CONFLICT", "this state directory is already bound to different inputs or a model")
    ctx = doctor.DoctorContext(
        state_dir=paths.root, tenant_id=tenant_id, model_endpoint=endpoint, model_deployment=model_deployment,
        subscription_id=subscription_id, model_resource_group=model_resource_group,
        plugin_root=doctor.plugin_root_from(None))
    ctx.cache["topicgraph_input"] = descriptor
    if existing is not None and saved is not None:
        ctx.cache["topicgraph_input"] = saved
    verdict = doctor.result(doctor.run(ctx, checks=doctor.CHECKS), next_step_if_ok=connection.PLAN_HINT)
    if verdict["status"] != "ok":
        return {**verdict, "tenant_id": tenant_id, "tenant_name": ctx.tenant_name}
    descriptor["source_schema_sha256"] = hashing.sha256_json(ctx.cache["source_schema"])
    TopicGraphReader(descriptor, tenant_id)
    deployment = connection._data(verdict, "model_deployment")
    paths = state.ensure_state(paths.root)
    with StateLock(paths, "connect"):
        current = state.load_config(paths) if paths.config.is_file() else None
        if current != existing:
            raise Blocked("CONFIG_CONFLICT", "the state binding changed while connecting; rerun connect")
        journal = Journal(paths)
        raw = hashing.canonical_bytes(descriptor)
        descriptor_sha = state.atomic_write(paths.descriptor, raw)
        journal.append("artifact_written", path=paths.relative(paths.descriptor), sha256=descriptor_sha)
        config = Config(
            tool_version=state.tool_version(), tenant_id=tenant_id, tenant_name=ctx.tenant_name,
            created_at=existing.created_at if existing else state.utc_now(),
            topicgraph=TopicGraphBinding(
                descriptor_sha256=descriptor_sha, search_endpoint=descriptor["endpoint"],
                physical_index=descriptor["index"], source_index=descriptor["index"],
                generation_id=descriptor["structure_id"],
                embedding_model_id=f"source-field:{descriptor['vector_field']}"),
            model=ModelBinding(
                endpoint=endpoint, deployment=model_deployment, input_price_per_1m=input_price_per_1m,
                output_price_per_1m=output_price_per_1m, subscription_id=subscription_id,
                resource_group=model_resource_group, model_name=deployment.get("model_name"),
                model_version=deployment.get("model_version")))
        config_sha = state.save_config(paths, config)
        journal.append("artifact_written", path=paths.relative(paths.config), sha256=config_sha)
        journal.append("connected", tenant_id=tenant_id, generation_id=descriptor["structure_id"],
                       model_deployment=model_deployment)
    return {
        "status": "ok", "tenant_id": tenant_id, "tenant_name": ctx.tenant_name,
        "input_kind": "topicgraph-output-v1", "generation_id": descriptor["structure_id"],
        "source_endpoint": descriptor["endpoint"], "source_index": descriptor["index"],
        "structure_dir": descriptor["structure_dir"], "labels_file": descriptor["labels_file"],
        "source_consistency": "passage text is read from the source index as it is now, not as it was at build time",
        "model_deployment": model_deployment, "reconnected": existing is not None,
        "checks": verdict["checks"], "next_step": "ontology-build inspect",
    }
