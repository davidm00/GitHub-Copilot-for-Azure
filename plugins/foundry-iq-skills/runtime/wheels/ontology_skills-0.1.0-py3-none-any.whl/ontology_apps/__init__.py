"""Optional official-SDK MCP Apps adapter for ontology presentation."""
