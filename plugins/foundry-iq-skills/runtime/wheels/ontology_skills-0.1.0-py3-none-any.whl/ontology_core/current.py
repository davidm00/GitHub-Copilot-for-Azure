"""The per-user `current` pointers to approved ontologies (docs/contract.md).

`approve` and `export` write one pointer per ontology state folder, `<home>/current/<folder>-<hash>.json`,
and copy the OWL JSON-LD bytes to `<home>/ontologies/<schema_id>.jsonld`, so a consumer can say "use the
current approved ontology" instead of passing a file path. Independent runs (separate state folders) never
replace each other's pointer; with more than one, a reader names the state folder. `<home>` is
`$ONTOLOGY_HOME`, else `%LOCALAPPDATA%\\ontology` on Windows, else `$XDG_STATE_HOME/ontology`
(default `~/.local/state/ontology`).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from ontology_core import hashing
from ontology_core.errors import Blocked

POINTER_SCHEMA = "ontology-current-v1"
KIND = "ontology"
REQUIRED = ("schema", "kind", "path", "sha256", "ontology_iri", "classes", "properties", "source_generation",
            "approved_at", "schema_id", "version", "state_dir")


def _is_windows() -> bool:
    return os.name == "nt"


def home() -> Path:
    override = os.environ.get("ONTOLOGY_HOME")
    if override:
        return Path(override).expanduser()
    if _is_windows():
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ("App" + "Data") / "Local")
        return Path(base) / "ontology"
    base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    return Path(base) / "ontology"


def pointer_path(state_dir: str | os.PathLike[str]) -> Path:
    """The pointer for one ontology state folder."""
    resolved = Path(state_dir).resolve()
    return home() / "current" / f"{resolved.name}-{hashing.sha256_bytes(str(resolved).encode())[:12]}.json"


def record(*, jsonld: bytes, ontology_iri: str, classes: int, properties: int, source_generation: str | None,
           approved_at: str, schema_id: str, version: int, state_dir: Path,
           exported_to: str | None = None) -> dict[str, Any]:
    """Copy `jsonld` into the home dir and point this state folder's pointer at it. Returns the pointer."""
    from ontology_core import state

    target = home() / "ontologies" / f"{schema_id.replace(':', '-')}.jsonld"
    sha = state.atomic_write(target, jsonld)
    pointer: dict[str, Any] = {
        "schema": POINTER_SCHEMA, "kind": KIND, "path": str(target), "sha256": sha, "ontology_iri": ontology_iri,
        "classes": classes, "properties": properties, "source_generation": source_generation,
        "approved_at": approved_at, "schema_id": schema_id, "version": version,
        "state_dir": str(Path(state_dir).resolve()), "exported_to": exported_to,
    }
    state.write_json(pointer_path(state_dir), pointer, canonical=True)
    return pointer


def load(*, required: bool = True, state_dir: str | os.PathLike[str] | None = None) -> dict[str, Any] | None:
    """Read and verify the pointer for `state_dir`, or the only pointer when none is named.

    `required=False` returns None when there is no pointer yet.

    Raises:
        Blocked("NO_CURRENT"): no pointer and `required`.
        Blocked("CURRENT_AMBIGUOUS"): no `state_dir` and pointers from several state folders.
        Blocked("CURRENT_INVALID"): unreadable, incomplete, or the file's bytes no longer match.
    """
    if state_dir is not None:
        path = pointer_path(state_dir)
    else:
        paths = sorted((home() / "current").glob("*.json"))
        if len(paths) > 1:
            folders = ", ".join(str(_read(p).get("state_dir", p.stem)) for p in paths)
            raise Blocked("CURRENT_AMBIGUOUS", f"approved ontologies exist for {len(paths)} state folders "
                          f"({folders}); pass --state-dir to choose one")
        path = paths[0] if paths else home() / "current"
    if not path.is_file():
        if not required:
            return None
        raise Blocked("NO_CURRENT", f"no approved ontology recorded under {home() / 'current'}")
    return _verified(path)


def _read(path: Path) -> dict[str, Any]:
    import json

    try:
        pointer = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise Blocked("CURRENT_INVALID", f"{path} is unreadable: {exc}") from exc
    return pointer if isinstance(pointer, dict) else {}


def _verified(path: Path) -> dict[str, Any]:
    pointer = _read(path)
    missing = [k for k in REQUIRED if not isinstance(pointer, dict) or k not in pointer]
    if missing or pointer.get("schema") != POINTER_SCHEMA:
        raise Blocked("CURRENT_INVALID", f"{path} is incomplete (missing {', '.join(missing) or 'schema'})")
    target = Path(pointer["path"])
    if not target.is_file() or hashing.sha256_bytes(target.read_bytes()) != pointer["sha256"]:
        raise Blocked("CURRENT_INVALID", f"{target} is missing or no longer matches sha256 {pointer['sha256'][:12]}…")
    return pointer


def scope(state_dir: str) -> str | None:
    """The state folder `current` reads: an explicit --state-dir always; the default folder only when it
    has a pointer, otherwise the only pointer there is."""
    from ontology_core.output import DEFAULT_STATE_DIR

    if state_dir != DEFAULT_STATE_DIR or pointer_path(state_dir).is_file():
        return state_dir
    return None


def result(state_dir: str | os.PathLike[str] | None = None) -> dict[str, Any]:
    """The `current` verb's `--json` result."""
    pointer = load(state_dir=state_dir)
    assert pointer is not None
    return {"status": "ok", **{k: v for k, v in pointer.items() if k != "schema"},
            "pointer": str(pointer_path(pointer["state_dir"])),
            "next_step": f"load the JSON-LD ontology file at {pointer['path']}"}
