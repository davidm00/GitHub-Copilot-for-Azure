"""Parse a failed service response into a safe, structured `service_error`.

`describe(status, body, headers)` returns `{"status", "code", "message", "details", "request_id"}` (only
`status` is always present). Every string is redacted (bearer tokens, JWTs, SAS signatures, account and
access keys, `key=` values) and truncated. The raw body, request body and request headers are never kept.
The same API exists in each foundry-iq runtime; there are no cross-runtime imports.
"""

from __future__ import annotations

import html
import json
import re
from collections.abc import Mapping
from typing import Any

MAX_MESSAGE = 2000
MAX_DETAIL_MESSAGE = 500
MAX_DETAILS = 10
MAX_CODE = 200
REDACTED = "[REDACTED]"
REQUEST_ID_HEADERS = ("x-ms-request-id", "request-id", "apim-request-id", "x-request-id", "x-ms-client-request-id")

_SECRETS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-._~+/]+=*"), "Bearer " + REDACTED),
    (re.compile(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*"), REDACTED),
    (re.compile(r"(?i)\bsig=[^&\s\"'<>;,]+"), "sig=" + REDACTED),
    (re.compile(r"(?i)\b(AccountKey|SharedAccessKey)=[^;\s\"'<>]+"), r"\1=" + REDACTED),
    (re.compile(r"(?i)(\"(?:api[-_]?key|apikey|key)\"\s*:\s*)\"[^\"]*\""), r'\1"' + REDACTED + '"'),
    (re.compile(r"(?i)\b(api[-_]?key|apikey|key)(\s*=\s*)(?!\[REDACTED\])[^&;,\s\"'<>]+"), r"\1\2" + REDACTED),
)
_TAGS = re.compile(r"<[^>]*>")
_SCRIPTS = re.compile(r"(?is)<(script|style)\b.*?</\1\s*>")
_SPACE = re.compile(r"\s+")


def redact(text: str) -> str:
    """`text` with every known secret shape replaced by `[REDACTED]`."""
    for pattern, replacement in _SECRETS:
        text = pattern.sub(replacement, text)
    return text


def _clean(value: Any, limit: int) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (dict, list)) else str(value)
    text = redact(_SPACE.sub(" ", value).strip())
    if not text:
        return None
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _detail(code: Any, message: Any, target: Any = None) -> dict[str, str] | None:
    item: dict[str, str] = {}
    for key, value, limit in (("code", code, MAX_CODE), ("message", message, MAX_DETAIL_MESSAGE),
                              ("target", target, MAX_CODE)):
        cleaned = _clean(value, limit)
        if cleaned is not None:
            item[key] = cleaned
    return item or None


def _error_object(err: Mapping[str, Any]) -> tuple[Any, Any, Any, list[dict[str, str]]]:
    code = err.get("code") if err.get("code") is not None else err.get("type")
    message = err.get("message")
    if isinstance(message, Mapping):
        message = message.get("value")
    details: list[dict[str, str]] = []
    raw_details = err.get("details")
    if isinstance(raw_details, list):
        for item in raw_details:
            if isinstance(item, Mapping):
                d = _detail(item.get("code"), item.get("message"), item.get("target"))
                if d:
                    details.append(d)
    inner = err.get("innererror") or err.get("innerError")
    depth = 0
    while isinstance(inner, Mapping) and depth < 5:
        d = _detail(inner.get("code"), inner.get("message"))
        if d:
            details.append(d)
        inner = inner.get("innererror") or inner.get("innerError")
        depth += 1
    return code, message, err.get("target"), details


def _parse_json(obj: Any) -> tuple[Any, Any, Any, list[dict[str, str]]] | None:
    if not isinstance(obj, Mapping):
        return None
    err = obj.get("error")
    if isinstance(err, Mapping):
        return _error_object(err)
    if isinstance(err, str) and err.strip():
        return err, obj.get("error_description") or obj.get("message"), None, []
    odata = obj.get("odata.error")
    if isinstance(odata, Mapping):
        return _error_object(odata)
    code = obj.get("code", obj.get("Code"))
    message = obj.get("message", obj.get("Message"))
    if code is not None or message is not None:
        if isinstance(message, Mapping):
            message = message.get("value")
        return _error_object({"code": code, "message": message, "details": obj.get("details"),
                              "innererror": obj.get("innererror"), "target": obj.get("target")})
    return None


def _xml_tag(text: str, tag: str) -> str | None:
    match = re.search(rf"(?is)<{tag}\b[^>]*>(.*?)</{tag}\s*>", text)
    return html.unescape(_TAGS.sub(" ", match.group(1))) if match else None


def _parse(text: str) -> tuple[Any, Any, Any, list[dict[str, str]]]:
    stripped = text.strip()
    if not stripped:
        return None, None, None, []
    if stripped[:1] in "{[":
        try:
            parsed = _parse_json(json.loads(stripped))
        except ValueError:
            parsed = None
        if parsed is not None:
            return parsed
    if stripped.startswith("<") and re.search(r"(?i)<Code\b", stripped) and not re.search(r"(?i)<html\b", stripped):
        code, message = _xml_tag(stripped, "Code"), _xml_tag(stripped, "Message")
        auth = _xml_tag(stripped, "AuthenticationErrorDetail")
        details = [d for d in [_detail("AuthenticationErrorDetail", auth)] if d] if auth else []
        if code or message:
            return code, message, None, details
    if "<" in stripped and ">" in stripped:
        stripped = html.unescape(_TAGS.sub(" ", _SCRIPTS.sub(" ", stripped)))
    return None, stripped, None, []


def _text(body: bytes | str | None) -> str:
    if body is None:
        return ""
    if isinstance(body, (bytes, bytearray, memoryview)):
        return bytes(body).decode("utf-8-sig", errors="replace")
    return str(body)


def _headers(headers: Any) -> dict[str, str]:
    if not headers:
        return {}
    try:
        items = headers.items()
    except AttributeError:
        return {}
    return {str(k).lower(): str(v) for k, v in items}


def describe(status: int | None, body: bytes | str | None, headers: Mapping[str, str] | None = None) -> dict:
    """The parsed service error for one failed response. Never includes the raw body."""
    try:
        status_value = int(status) if status is not None else None
    except (TypeError, ValueError):
        status_value = None
    info: dict[str, Any] = {"status": status_value}
    lower = _headers(headers)
    code, message, target, details = _parse(_text(body))
    code = _clean(code, MAX_CODE) or _clean(lower.get("x-ms-error-code"), MAX_CODE)
    message = _clean(message, MAX_MESSAGE)
    if code:
        info["code"] = code
    if message:
        info["message"] = message
    target = _clean(target, MAX_CODE)
    if target:
        info["target"] = target
    if details:
        info["details"] = details[:MAX_DETAILS]
    request_id = next((_clean(lower[h], MAX_CODE) for h in REQUEST_ID_HEADERS if lower.get(h)), None)
    if request_id:
        info["request_id"] = request_id
    return info


def _int_status(value: Any) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) and 100 <= value <= 599 else None


def _response_body(response: Any) -> bytes | str | None:
    for name in ("content", "body", "text"):
        try:
            value = getattr(response, name, None)
            if callable(value):
                value = value()
        except Exception:  # noqa: BLE001 - an unread, consumed or closed stream has no body to report
            continue
        if isinstance(value, (bytes, bytearray, str)):
            return value
    return None


def from_exception(exc: BaseException) -> dict | None:
    """The service error carried by an SDK/HTTP exception (azure.core `HttpResponseError`, openai
    `APIStatusError`, urllib `HTTPError`, or anything duck-typed with a status), else None."""
    existing = getattr(exc, "service_error", None)
    if isinstance(existing, dict):
        return existing
    azure_error = False
    try:
        from azure.core.exceptions import HttpResponseError

        azure_error = isinstance(exc, HttpResponseError)
    except ImportError:  # pragma: no cover - azure-core is a dependency
        pass
    response = getattr(exc, "response", None)
    status = (_int_status(getattr(exc, "status_code", None)) or _int_status(getattr(exc, "status", None))
              or _int_status(getattr(response, "status_code", None)) or _int_status(getattr(response, "status", None)))
    body: bytes | str | None = None
    headers: Any = getattr(response, "headers", None)
    if response is not None:
        body = _response_body(response)
    if status is None:
        status = _int_status(getattr(exc, "code", None))
    if status is not None and body is None and callable(getattr(exc, "read", None)):
        try:
            body = exc.read()  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            body = None
        headers = headers or getattr(exc, "headers", None) or getattr(exc, "hdrs", None)
    if status is None and not azure_error and response is None:
        return None
    info = describe(status, body, headers)
    if "code" not in info or "message" not in info:
        err = getattr(exc, "error", None)
        code = getattr(err, "code", None) or getattr(exc, "error_code", None)
        if code is None and isinstance(getattr(exc, "code", None), str):
            code = getattr(exc, "code")
        message = getattr(err, "message", None) or getattr(exc, "message", None)
        if message is None and isinstance(getattr(exc, "body", None), Mapping):
            message = exc.body.get("message")  # type: ignore[attr-defined]
        if message is None:
            message = str(exc) or None
        if "code" not in info and _clean(code, MAX_CODE):
            info["code"] = _clean(code, MAX_CODE)
        if "message" not in info and _clean(message, MAX_MESSAGE):
            info["message"] = _clean(message, MAX_MESSAGE)
    try:  # a response stream can be read only once; later callers reuse the parsed error
        exc.service_error = info  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        pass
    return info


def summary(info: dict) -> str:
    """One line: `HTTP 400 InvalidRequestParameter: <message> (request id <id>)`, omitting absent parts."""
    head = " ".join(p for p in (f"HTTP {info['status']}" if info.get("status") is not None else "",
                                str(info.get("code") or "")) if p)
    message = info.get("message")
    if message:
        text = f"{head}: {message}" if head else str(message)
    elif info.get("code"):
        text = head
    else:
        text = f"{head}: no service error body" if head else "no service error body"
    if info.get("request_id"):
        text += f" (request id {info['request_id']})"
    return text
