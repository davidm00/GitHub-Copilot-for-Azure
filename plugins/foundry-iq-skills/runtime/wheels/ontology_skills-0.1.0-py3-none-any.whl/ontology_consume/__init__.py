"""Read-only ontology browsing (no Azure, no model)."""
