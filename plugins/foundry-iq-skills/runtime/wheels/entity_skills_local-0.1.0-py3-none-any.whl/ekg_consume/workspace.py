"""Write the Graph Playground config from what this machine has published.

Reads only local published state (Entity Graph, Topic Graph, ontology and grounding homes);
it makes no Azure calls. The only write is the operator config file itself.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from ekg_core.cli import Blocked, add_command, new_parser, parse, report, say
from ekg_core.descriptors import current_pointer_path, resolve_current
from ekg_core.validation import validate_deployment_descriptor
from ekg_core.files import atomic_write_text

PROG = "foundry-iq-workspace"
CONFIG_NAME = "knowledge-apps.json"
MIN_NODE = (22, 13)
_ORIGIN = re.compile(r"https://[A-Za-z0-9.-]+(?::\d+)?")
_UUID = re.compile(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}")
_PASS_THROUGH = ("FOUNDRY_IQ_RUNTIME_CACHE", "FOUNDRY_IQ_PYTHON", "AZURE_CONFIG_DIR",
                 "AZURE_EXTENSION_DIR")


def _state_home(variable: str, folder: str) -> Path:
    override = os.environ.get(variable)
    if override:
        return Path(override).expanduser()
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / folder
    base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    return Path(base) / folder


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _origin(value: Any) -> str | None:
    if isinstance(value, str) and _ORIGIN.fullmatch(value.rstrip("/")):
        return value.rstrip("/")
    return None


def _entity() -> tuple[dict[str, Any] | None, str]:
    selected = os.environ.get("ENTITY_DESCRIPTOR")
    try:
        path = Path(selected).expanduser().resolve() if selected else resolve_current()
    except FileNotFoundError:
        return None, f"no Entity Graph is published under {current_pointer_path().parent}"
    except ValueError as error:
        return None, str(error)
    try:
        descriptor = _read_json(path)
    except (OSError, ValueError) as error:
        return None, f"the published descriptor {path} is unreadable: {error}"
    errors = validate_deployment_descriptor(descriptor) if isinstance(descriptor, dict) else ["not an object"]
    if errors:
        return None, f"the published descriptor {path} is invalid: {'; '.join(errors)}"
    return {"descriptor_path": str(path)}, f"Entity Graph {path.name}"


def _newest(folder: Path) -> tuple[Path | None, str]:
    """The most recently written record in `folder`, and a note when it was chosen from several."""
    paths = sorted(folder.glob("*.json"), key=lambda p: (p.stat().st_mtime_ns, p.name)) if folder.is_dir() else []
    if not paths:
        return None, ""
    return paths[-1], f" (newest of {len(paths)})" if len(paths) > 1 else ""


def _topicgraph() -> tuple[dict[str, Any] | None, str]:
    folder = _state_home("TOPICGRAPH_HOME", "topicgraph") / "current"
    current, more = _newest(folder)
    if current is None:
        return None, f"no Topic Graph is published (nothing in {folder})"
    try:
        record = _read_json(current)
    except (OSError, ValueError) as error:
        return None, f"{current} is unreadable: {error}"
    descriptor = Path(str(record.get("descriptor") or ""))
    endpoint = _origin(record.get("endpoint"))
    if not descriptor.is_absolute() or not descriptor.is_file():
        return None, f"{current} names a missing descriptor"
    if endpoint is None:
        return None, f"{current} has no HTTPS Search endpoint"
    if record.get("auth", "entra") != "entra":
        return None, "the published Topic Graph uses key authentication; the Graph Playground needs Entra"
    scope: dict[str, Any] = {"descriptor_path": str(descriptor), "endpoint": endpoint, "auth": "entra"}
    tenant = record.get("tenant_id")
    if isinstance(tenant, str) and _UUID.fullmatch(tenant):
        scope["tenant_id"] = tenant
    return scope, f"Topic Graph generation {record.get('generation_id') or descriptor.stem}{more}"


def _ontology() -> tuple[dict[str, Any] | None, str]:
    folder = _state_home("ONTOLOGY_HOME", "ontology") / "current"
    current, more = _newest(folder)
    if current is None:
        return None, f"no ontology is approved (nothing in {folder})"
    try:
        record = _read_json(current)
    except (OSError, ValueError) as error:
        return None, f"{current} is unreadable: {error}"
    state_dir, version = Path(str(record.get("state_dir") or "")), record.get("version")
    if not state_dir.is_absolute() or not state_dir.is_dir():
        return None, f"{current} names a missing ontology state folder"
    if type(version) is not int or version < 0:
        return None, f"{current} has no approved version number"
    return {"state_dir": str(state_dir), "version": version}, f"ontology version {version}{more}"


def _grounding(entity: dict[str, Any] | None) -> tuple[dict[str, Any] | None, str]:
    folder = _state_home("GROUNDING_HOME", "grounding-skills") / "descriptors"
    built = []
    for path in sorted(folder.glob("*.json")) if folder.is_dir() else ():
        try:
            record = _read_json(path)
        except (OSError, ValueError):
            continue
        if isinstance(record, dict) and record.get("index") and _origin(record.get("endpoint")):
            built.append((str(record.get("created_at") or ""), path.name, record))
    if not built:
        return None, f"no grounding index is built (nothing in {folder})"
    record = max(built)[2]
    scope: dict[str, Any] = {"index": record["index"], "endpoint": _origin(record["endpoint"])}
    if isinstance(record.get("graph_name"), str) and record["graph_name"]:
        scope["graph_name"] = record["graph_name"]
    if entity:
        scope["descriptor_path"] = entity["descriptor_path"]
    more = f" (newest of {len(built)})" if len(built) > 1 else ""
    return scope, f"grounding index {record['index']}{more}"


def _env() -> dict[str, str]:
    env = {"PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}
    if os.name == "nt":
        env["SystemRoot"] = os.environ.get("SystemRoot") or r"C:\Windows"
    env.update({name: os.environ[name] for name in _PASS_THROUGH if os.environ.get(name)})
    return env


def _node() -> dict[str, Any]:
    node = shutil.which("node")
    if not node:
        return {"found": False, "ok": False}
    try:
        text = subprocess.run([node, "--version"], capture_output=True, text=True, timeout=15).stdout.strip()
        found = tuple(int(part) for part in text.lstrip("v").split(".")[:2])
    except (OSError, ValueError, subprocess.SubprocessError):
        return {"found": True, "ok": False}
    return {"found": True, "version": text, "ok": found >= MIN_NODE}


def build_config(port: int = 0) -> tuple[dict[str, Any], dict[str, str]]:
    """The operator config for every published domain, and why each other domain is absent."""
    domains: dict[str, Any] = {}
    notes: dict[str, str] = {}
    entity, notes["entity"] = _entity()
    found = {"entity": entity, "topicgraph": None, "ontology": None, "grounding": None}
    found["topicgraph"], notes["topicgraph"] = _topicgraph()
    found["ontology"], notes["ontology"] = _ontology()
    found["grounding"], notes["grounding"] = _grounding(entity)
    for name in ("entity", "topicgraph", "ontology", "grounding"):
        if found[name] is not None:
            binding: dict[str, Any] = {"scope": found[name], "env": _env()}
            if name == "entity":
                binding["timeoutMs"] = 120000
            if name == "topicgraph" and entity is not None:
                # Lets Topic Graph show original document names for passages from this entity build.
                binding["env"]["ENTITY_DESCRIPTOR"] = entity["descriptor_path"]
            domains[name] = binding
    python = os.environ.get("FOUNDRY_IQ_BOOTSTRAP_PYTHON") or getattr(sys, "_base_executable", sys.executable)
    return {"python": python, "port": port, "domains": domains}, notes


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def write_config(output: Path, *, replace: bool, port: int) -> dict[str, Any]:
    plugin = os.environ.get("PLUGIN_ROOT")
    output = output.expanduser()
    if not output.is_absolute():
        output = Path.cwd() / output
    if plugin and _inside(output, Path(plugin)):
        raise Blocked("WORKSPACE_OUTPUT_INVALID",
                      f"{output} is inside the installed plugin; the Graph Playground config must live outside it")
    config, notes = build_config(port)
    if not config["domains"]:
        raise Blocked("WORKSPACE_NOTHING_PUBLISHED",
                      "nothing is published on this machine yet: " + "; ".join(notes.values()))
    config["cwd"] = str(output.parent)
    text = json.dumps(config, indent=2) + "\n"
    if output.exists() and output.read_text(encoding="utf-8") != text and not replace:
        raise Blocked("WORKSPACE_CONFIG_EXISTS", f"{output} already exists with different settings",
                      path=str(output))
    atomic_write_text(output, text)
    launcher = Path(plugin) / "apps-host" / "launch.mjs" if plugin else None
    launch = (f'node "{launcher}" --config "{output}"' if launcher
              else f'node "<installed plugin>\\apps-host\\launch.mjs" --config "{output}"')
    node = _node()
    included = list(config["domains"])
    skipped = {name: notes[name] for name in ("entity", "topicgraph", "ontology", "grounding")
               if name not in config["domains"]}
    names = {"entity": "Knowledge graph", "topicgraph": "Topics", "ontology": "Ontology",
             "grounding": "Grounding"}
    step = launch if node["ok"] else (
        f"install Node.js {MIN_NODE[0]}.{MIN_NODE[1]} or later, then run: {launch}")
    tabs = [names[n] for n in included]
    tabs_text = tabs[0] if len(tabs) == 1 else ", ".join(tabs[:-1]) + " and " + tabs[-1]
    return {
        "status": "ready",
        "summary": (f"Set up the Graph Playground with the {tabs_text} tab{'s' if len(tabs) > 1 else ''} ({output})."
                    + (f" Not included: {'; '.join(f'{names[n]}: {why}' for n, why in skipped.items())}."
                       if skipped else "")),
        "config": str(output),
        "included": {name: notes[name] for name in included},
        "skipped": skipped,
        "node": node,
        "launch": launch,
        "next_step": step,
    }


def _parser():
    parser, commands = new_parser(PROG, "Set up the Graph Playground.", "0.1.0")
    config = add_command(commands, "config",
                         "write knowledge-apps.json from the graphs published on this machine "
                         "(local files only; no Azure calls)")
    config.add_argument("--output", default=str(Path.cwd() / CONFIG_NAME),
                        help=f"config file to write (default: ./{CONFIG_NAME}); must be outside the plugin")
    config.add_argument("--replace", action="store_true",
                        help="overwrite an existing config that has different settings")
    config.add_argument("--port", type=int, default=0,
                        help="localhost port for the Graph Playground (default: 0, any free port)")
    return parser


def main(argv: list[str] | None = None) -> None:
    args = parse(_parser(), argv)
    try:
        if not 0 <= args.port <= 65535:
            raise Blocked("USAGE", "--port must be 0..65535")
        result = write_config(Path(args.output), replace=args.replace, port=args.port)
    except Blocked as blocked:
        report(blocked, prog=PROG, command=args.command)
    except OSError as error:
        report(Blocked("LOCAL_IO", str(error)), prog=PROG, command=args.command, cause=error)
    say(result, args, prog=PROG)
