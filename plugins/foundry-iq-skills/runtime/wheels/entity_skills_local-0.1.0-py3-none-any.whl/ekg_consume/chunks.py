"""Deterministic edge-list reads scoped to centroid-selected source chunks."""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any

from .adapters import QueryAdapter
from .gql import validate_query_text
from .runtime import require_capability
from .service import (
    GRAPH_ROUND_TRIP_LIMIT, _adapter, _index, _managed_search_api_version, _source,
)

_SCOPE_FIELDS = {
    "topic_id", "generation_id", "source_endpoint", "source_index", "requested_top", "chunk_ids",
}


def validate_chunk_scope(scope: Any) -> dict[str, Any]:
    if not isinstance(scope, dict) or set(scope) != _SCOPE_FIELDS:
        raise ValueError("chunk_scope requires topic, generation, source and selected chunk IDs")
    for field in _SCOPE_FIELDS - {"requested_top", "chunk_ids"}:
        value = scope[field]
        if type(value) is not str or not value.strip() or len(value) > 2048 \
                or any(ord(char) < 32 for char in value):
            raise ValueError(f"chunk_scope.{field} must be bounded nonempty text")
    top = scope["requested_top"]
    ids = scope["chunk_ids"]
    if type(top) is not int or not 1 <= top <= 1000:
        raise ValueError("chunk_scope.requested_top must be 1..1000")
    if not isinstance(ids, list) or len(ids) > top or any(
        type(key) is not str or not key or len(key) > 512 or "|" in key
        or any(ord(char) < 32 for char in key) for key in ids
    ) or len(set(ids)) != len(ids):
        raise ValueError("chunk_scope.chunk_ids must be distinct bounded chunk keys without '|'")
    return scope


def _filter(field: str, ids: list[str]) -> str:
    """One search.in() over '|'-delimited keys; validate_chunk_scope rejects keys containing '|'."""
    if any("|" in key for key in ids):
        raise ValueError("chunk keys cannot contain '|'")
    values = "|".join(ids).replace("'", "''")
    return f"search.in({field}, '{values}', '|')"


def _identity(parts: list[Any]) -> str:
    return hashlib.sha256(json.dumps(parts, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def graph_from_chunks(descriptor: dict[str, Any], query: str, chunk_scope: dict[str, Any],
                      *, adapter: QueryAdapter | None = None) -> dict[str, Any]:
    scope = validate_chunk_scope(chunk_scope)
    validate_query_text(query)
    require_capability(descriptor, "graph_retrieval")
    if _managed_search_api_version(descriptor) is None:
        raise ValueError("chunk graph reads require a managed graph")
    endpoint = (descriptor.get("endpoints") or {}).get("search", "")
    if scope["source_endpoint"].rstrip("/").lower() != endpoint.rstrip("/").lower() \
            or scope["source_index"] != _index(descriptor, "content"):
        raise ValueError("The Topic Graph and Knowledge Graph must use the same source index and service")
    client = _adapter(descriptor, adapter)
    selected = set(scope["chunk_ids"])
    assertions: list[dict[str, Any]] = []
    after = None
    pages = 0
    if selected:
        for _ in range(GRAPH_ROUND_TRIP_LIMIT):
            rows = client.search_edges(_index(descriptor, "graph"),
                                       filter=_filter("chunk_id", scope["chunk_ids"]), after=after)
            pages += 1
            for row in rows:
                key = row.get("id")
                if type(key) is not str or not key or after is not None and key <= after \
                        or row.get("chunk_id") not in selected:
                    raise RuntimeError("The edge index returned an invalid or out-of-scope assertion")
                after = key
                assertions.append(row)
            if len(rows) < 1000:
                break
        else:
            raise RuntimeError("Chunk graph exceeded its page budget; select fewer chunks")
    supported = sorted({row["chunk_id"] for row in assertions})
    documents = client.search_grounding(
        _index(descriptor, "content"), filter=_filter("uid", supported), top=len(supported),
        select="uid,blob_url,snippet,snippet_parent_id",
    ) if supported else []
    evidence = {}
    for doc in documents:
        key = doc.get("uid")
        if key not in supported or key in evidence or not doc.get("blob_url"):
            raise RuntimeError("The source index returned invalid chunk evidence")
        evidence[key] = _source(doc, descriptor)
    if set(evidence) != set(supported):
        raise RuntimeError("Graph evidence is stale or unavailable; refresh the graph before retrying")
    nodes: dict[str, dict[str, Any]] = {}
    edges: dict[str, dict[str, Any]] = {}
    provenance = []

    def node(row: dict[str, Any], role: str) -> str:
        graph = row.get("graph_name")
        name, kind, canonical = row.get(role), row.get(role + "_type"), row.get(role + "_id")
        literal = None
        if role == "object" and not canonical:
            for field in ("object_string", "object_double", "object_bool", "object_datetime"):
                if row.get(field) is not None:
                    literal = row[field]
                    break
        if literal is not None:
            name = json.dumps(literal, ensure_ascii=False) if not isinstance(literal, str) else literal
        if not isinstance(name, str) or not name or not isinstance(kind, str) or not kind:
            raise RuntimeError("The edge index returned an assertion without typed endpoints")
        key = _identity([graph, "literal" if literal is not None else "entity",
                         kind, name if literal is not None else canonical or name])
        nodes.setdefault(key, {
            "id": key, "name": row.get(role + "_id_display_name") or name, "type": kind,
            **({"canonical_id": canonical} if canonical and literal is None else {}),
            "graph_name": graph,
            **({"literal": True, "value": literal} if literal is not None else {}),
        })
        return key

    for row in assertions:
        predicate = row.get("predicate")
        if not isinstance(predicate, str) or not predicate:
            raise RuntimeError("The edge index returned an assertion without a predicate")
        source, target = node(row, "subject"), node(row, "object")
        key = _identity([row.get("graph_name"), row.get("edge_hash") or [source, predicate, target]])
        edge = edges.setdefault(key, {
            "id": key, "from_id": source, "to_id": target, "predicate": predicate, "provenance": [],
            "graph_name": row.get("graph_name"), "fact_id": row.get("edge_hash"),
        })
        item = {**evidence[row["chunk_id"]], "edgeId": row["id"], "chunkId": row["chunk_id"]}
        item["role_confidence"] = {
            role: row[field] for role, field in (
                ("subject", "s_confidence"), ("predicate", "p_confidence"),
                ("object", "o_confidence"), ("edge", "edge_confidence"),
            ) if type(row.get(field)) in (int, float) and math.isfinite(row[field])
        }
        confidence = row.get("edge_confidence")
        if type(confidence) in (int, float) and math.isfinite(confidence):
            item["confidence"] = confidence
            edge["confidence"] = max(edge.get("confidence", confidence), confidence)
        edge["provenance"].append(item)
        provenance.append(item)
    return {
        "query": query, "query_mode": "traverse", "answer": None,
        "nodes": list(nodes.values()), "edges": list(edges.values()), "paths": [],
        "provenance": provenance, "capabilities_used": ["graph_retrieval"],
        "telemetry": {
            "topic_id": scope["topic_id"], "generation_id": scope["generation_id"],
            "requested_chunks": scope["requested_top"], "selected_chunks": len(selected),
            "chunks_with_edges": len(supported), "assertions": len(assertions),
            "unique_edges": len(edges), "edge_pages": pages, "complete": True,
            "retrieval": "centroid_chunks",
        },
    }
