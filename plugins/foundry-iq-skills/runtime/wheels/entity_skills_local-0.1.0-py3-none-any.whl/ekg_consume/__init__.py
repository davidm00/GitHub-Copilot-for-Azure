"""Read-only consumption contracts."""

from .runtime import CapabilityError, capabilities

__all__ = ["CapabilityError", "capabilities"]
