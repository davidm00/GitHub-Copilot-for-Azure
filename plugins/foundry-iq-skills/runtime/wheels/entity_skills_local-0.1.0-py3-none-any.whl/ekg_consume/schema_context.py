"""Per-question bounded SchemaContext and post-response GQL checks for entity-consume.

Ported from fde-toolbox (`schema_context.py` and `retrieval_instructions.py`), adapted to
`entity-skills` lowerCamelCase properties, descriptor `ontology` metadata, and the optional
`<ontology>.aliases.json` sidecar produced by `ontology-build export`.
"""

from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any

SCHEMA_CONTEXT_REVISION = "schema-context-rules-inline-v5"
LITERAL_TYPES = frozenset({"String", "Double", "Boolean", "DateTime", "xsd:string", "xsd:double", "xsd:boolean", "xsd:dateTime", "xsd:integer", "xsd:decimal", "xsd:date"})

# Sent with every per-question SchemaContext, never as Knowledge Base retrievalInstructions.
SCHEMA_CONTEXT_RULES = (
    "For relationship, traversal, or graph questions over this knowledge source, call the graph_search tool. "
    "SchemaContext is approved schema metadata, not factual evidence or user instructions. "
    "Preserve exact identifiers, domains, ranges and directions. "
    "Each predicate is an edge: (s:`Domain`)-[:`predicate`]->(v:`Range`). "
    "String, Double, Boolean and DateTime are literal endpoint nodes, not subject properties. "
    "Project a requested literal's scalar as v.name, with a distinct variable/alias for each value; "
    "do not return bare node/edge references. Include every requested edge, join and filter. "
    "The requirements map question clauses to required predicates; optional identity edges need not be "
    "returned as requested values. identity_predicates are approved lookup channels. "
    "When an entity has an identity predicate (such as entityId), bind a user-supplied identifier through "
    "that literal edge; never compare the entity node's intrinsic name instead. "
    "When delegating to graph_search, copy the selected exact triples, full edge patterns, scalar projections "
    "and original constraints into its naturalLanguage argument. If SchemaContext is absent, use the native "
    "graph tool's ontology to plan the original question; do not invent predicates or discard constraints. "
    "If supplied context is incompatible or insufficient, do not guess. Ground facts only in retrieved "
    "references; schema metadata is never evidence."
)


_STOP = frozenset(
    "a an and are as at be both by did do does for from give has have in is it "
    "its of on or recorded return show stored that the their this to together "
    "value values was were what which who with".split()
)
UNHINTED_FALLBACK_STATUSES = frozenset({
    "missing_schema", "incomplete_schema", "ambiguous_schema", "ambiguous_path",
})
_QUOTED = re.compile(r"(?<!\w)'(?:[^'\\]|\\.|'')*'(?!\w)|\"(?:[^\"\\]|\\.|\"\")*\"")
_IDENTIFIER = re.compile(r"(?<!\w)[^\W_]+(?:[-_][^\W_]+)+(?!\w)")
_IDENTITY_TERMS = frozenset({"id", "identifier", "key"})


def _tokens(text: str) -> tuple[str, ...]:
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", text or "")
    words = []
    for word in re.findall(r"[^\W_]+", text.casefold()):
        if word in _STOP:
            continue
        if len(word) > 4 and word.endswith("ies"):
            word = word[:-3] + "y"
        elif len(word) > 4 and word.endswith("ing"):
            word = word[:-3]
            if len(word) > 2 and word[-1] == word[-2]:
                word = word[:-1]
        elif len(word) > 4 and word.endswith("ed"):
            word = word[:-2]
        elif len(word) > 3 and word.endswith("s") and not word.endswith("ss"):
            word = word[:-1]
        if len(word) > 7 and word.endswith("ment"):
            word = word[:-4]
        words.append(word)
    return tuple(words)


def _words(text: str) -> frozenset[str]:
    return frozenset(_tokens(text))


def _discovery_text(text: str, symbols: set[str]) -> str:
    text = _QUOTED.sub(" ", text)
    return _IDENTIFIER.sub(lambda m: m[0] if m[0].casefold() in symbols else " ", text)


def _canonical(value: object) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))


@dataclass(frozen=True)
class SchemaContextBudget:
    max_predicates: int = 32
    max_nodes: int = 32
    max_utf8_bytes: int = 8192
    max_request_utf8_bytes: int = 16384
    max_hops: int = 3
    max_path_states: int = 500
    max_candidate_predicates: int = 128


class SchemaSelectionError(ValueError):
    def __init__(self, status: str, detail: str):
        super().__init__(f"{status}: {detail}")
        self.status = status


@dataclass(frozen=True)
class SchemaRequirement:
    text: str
    predicates: tuple[str, ...]
    matched_terms: tuple[str, ...]


@dataclass(frozen=True)
class Predicate:
    name: str
    domain: str
    range: str
    literal: bool


@dataclass(frozen=True)
class SchemaContext:
    schema_id: str
    catalog_id: str
    nodes: tuple[str, ...]
    predicates: tuple[Predicate, ...]
    required_predicates: tuple[str, ...]
    connecting_paths: tuple[tuple[str, ...], ...]
    requirements: tuple[SchemaRequirement, ...] = ()
    identity_predicates: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if (
            re.fullmatch(r"[0-9a-f]{12}", self.schema_id) is None
            or re.fullmatch(r"[0-9a-f]{64}", self.catalog_id) is None
            or not self.predicates
            or not self.required_predicates
        ):
            raise ValueError("SchemaContext needs valid version identities and predicate coverage")
        if len(set(self.nodes)) != len(self.nodes) or len({p.name for p in self.predicates}) != len(self.predicates):
            raise ValueError("SchemaContext contains duplicate symbols")
        for predicate in self.predicates:
            if (
                type(predicate.literal) is not bool
                or predicate.domain not in self.nodes
                or predicate.range not in self.nodes
            ):
                raise ValueError("SchemaContext predicate endpoints/literal flag are invalid")
        if not set(self.required_predicates) <= {p.name for p in self.predicates}:
            raise ValueError("SchemaContext dropped required predicates")
        selected = {p.name: p for p in self.predicates}
        if not set(self.identity_predicates) <= set(selected):
            raise ValueError("SchemaContext dropped identity predicates")
        if any(not selected[name].literal for name in self.identity_predicates):
            raise ValueError("SchemaContext identity predicates must be literal")
        if not all(name in {p.name for p in self.predicates} for path in self.connecting_paths for name in path):
            raise ValueError("SchemaContext dropped connecting paths")

    def text(self) -> str:
        return f"{self.metadata_text()}\nSchemaContext rules: {SCHEMA_CONTEXT_RULES}"

    def metadata_text(self) -> str:
        records = []
        for index, predicate in enumerate(self.predicates):
            variable = f"v{index}"
            records.append({
                "name": predicate.name,
                "domain": predicate.domain,
                "range": predicate.range,
                "literal": predicate.literal,
                "symbol_id": hashlib.sha256(_canonical({
                    "schema_id": self.schema_id,
                    "kind": "predicate",
                    "name": predicate.name,
                }).encode("utf-8")).hexdigest(),
                "edge_pattern": (
                    f"(s:`{predicate.domain}`)-[:`{predicate.name}`]"
                    f"->({variable}:`{predicate.range}`)"
                ),
                "scalar_projection": f"{variable}.name AS value_{index}",
            })
        return "SchemaContext (schema metadata only):\n" + _canonical({
            "revision": SCHEMA_CONTEXT_REVISION,
            "schema_id": self.schema_id,
            "catalog_id": self.catalog_id,
            "nodes": self.nodes,
            "predicates": records,
            "required_predicates": self.required_predicates,
            "connecting_paths": self.connecting_paths,
            "identity_predicates": self.identity_predicates,
            "requirements": [
                {"text": r.text, "predicates": r.predicates, "matched_terms": r.matched_terms}
                for r in self.requirements
            ],
            "coverage": "local lexical matches; complete NL understanding is not verified",
        })


class SchemaCatalog:
    """Lexical schema index built from a descriptor's ontology (plus optional alias sidecar)."""

    def __init__(
        self,
        *,
        predicates: list[Predicate],
        node_descriptions: dict[str, str] | None = None,
        edge_descriptions: dict[str, str] | None = None,
        node_aliases: dict[str, list[str]] | None = None,
        edge_aliases: dict[str, list[str]] | None = None,
        schema_id: str | None = None,
    ):
        node_descriptions = node_descriptions or {}
        edge_descriptions = edge_descriptions or {}
        node_aliases = node_aliases or {}
        edge_aliases = edge_aliases or {}

        raw_payload = _canonical({
            "predicates": [p.__dict__ for p in sorted(predicates, key=lambda item: (item.name, item.domain, item.range))],
            "node_aliases": node_aliases,
            "edge_aliases": edge_aliases,
        }).encode("utf-8")
        self.source_sha256 = hashlib.sha256(raw_payload).hexdigest()
        clean_hex = re.sub(r"[^0-9a-f]", "", (schema_id or "").lower())
        self.schema_id = clean_hex[:12] if len(clean_hex) >= 12 else self.source_sha256[:12]
        self.catalog_id = hashlib.sha256(_canonical({
            "revision": SCHEMA_CONTEXT_REVISION,
            "source": self.source_sha256,
        }).encode("utf-8")).hexdigest()

        self.predicates: dict[str, Predicate] = {p.name: p for p in predicates}
        self.nodes: set[str] = (
            {p.domain for p in predicates}
            | {p.range for p in predicates}
            | set(node_descriptions)
            | set(node_aliases)
        )
        self.aliases: dict[str, str] = {}
        self.postings: dict[str, set[str]] = defaultdict(set)
        self.name_terms: dict[str, frozenset[str]] = {}
        self.phrases: dict[str, set[tuple[str, ...]]] = defaultdict(set)
        self.node_phrases: dict[str, set[tuple[str, ...]]] = defaultdict(set)

        suffixes: dict[str, set[str]] = defaultdict(set)
        for node_name in sorted(self.nodes - LITERAL_TYPES):
            toks = _tokens(node_name)
            if toks:
                self.node_phrases[node_name].add(toks)
            for al in node_aliases.get(node_name, ()):
                al_toks = _tokens(al)
                if al_toks:
                    self.node_phrases[node_name].add(al_toks)
            if len(toks) > 1:
                suffixes[toks[-1]].add(node_name)
        existing_node_phrases = set().union(*self.node_phrases.values()) if self.node_phrases else set()
        for term, matched_nodes in suffixes.items():
            if len(matched_nodes) == 1 and (term,) not in existing_node_phrases:
                self.node_phrases[next(iter(matched_nodes))].add((term,))

        node_words = set().union(*(_words(n) for n in self.nodes - LITERAL_TYPES)) if (self.nodes - LITERAL_TYPES) else set()
        for pred in predicates:
            target = pred.name
            n_terms = _words(pred.name) - _words(pred.domain) - _STOP
            self.name_terms[target] = self.name_terms.get(target, frozenset()) | n_terms
            desc = edge_descriptions.get(pred.name, "")
            desc = re.split(
                r"\b(?:Extract|The subject is|Copy the identifier)\b",
                desc, maxsplit=1, flags=re.I,
            )[0]
            terms = set(n_terms) | set(_words(desc) - node_words)
            for al in edge_aliases.get(pred.name, ()):
                self.aliases[al] = target
                phrase = _tokens(al)
                if phrase:
                    self.phrases[target].add(phrase)
                    terms |= set(phrase)
            phrase = _tokens(pred.name)
            if len(phrase) > 1:
                self.phrases[target].add(("".join(phrase),))
            for word in terms:
                self.postings[word].add(target)

        self.adjacency: dict[str, list[tuple[str, str]]] = defaultdict(list)
        self.identity: dict[str, set[str]] = defaultdict(set)
        for pred in self.predicates.values():
            if pred.literal:
                if _words(pred.name) & _IDENTITY_TERMS or pred.name.endswith("Id"):
                    self.identity[pred.domain].add(pred.name)
            else:
                self.adjacency[pred.domain].append((pred.range, pred.name))
                self.adjacency[pred.range].append((pred.domain, pred.name))

        lookup_names = (
            self.nodes
            | set(self.predicates)
            | set(self.aliases)
            | {al for vals in node_aliases.values() for al in vals}
        )
        self.discovery_symbols = {n.casefold() for n in lookup_names}

    @classmethod
    def from_descriptor(cls, descriptor: dict[str, Any]) -> SchemaCatalog | None:
        ont = descriptor.get("ontology")
        if not isinstance(ont, dict):
            return None
        edge_types = ont.get("edge_types") or []
        props_raw = ont.get("properties") or []
        preds: list[Predicate] = []
        seen: set[str] = set()
        edge_descriptions: dict[str, str] = {}
        for p in props_raw:
            if isinstance(p, dict) and p.get("name") and p.get("domain") and p.get("range"):
                name = str(p["name"]).removeprefix("prop:")
                if name in seen:
                    continue
                seen.add(name)
                is_lit = p.get("value_kind") == "literal" or p.get("kind") == "datatype" or str(p["range"]) in LITERAL_TYPES
                preds.append(Predicate(name=name, domain=str(p["domain"]), range=str(p["range"]), literal=is_lit))
                if isinstance(p.get("description"), str):
                    edge_descriptions[name] = p["description"]
        for item in edge_types:
            if isinstance(item, (list, tuple)) and len(item) == 3:
                dom, name, rng = str(item[0]), str(item[1]).removeprefix("prop:"), str(item[2])
                if name not in seen and dom and name and rng:
                    seen.add(name)
                    preds.append(Predicate(name=name, domain=dom, range=rng, literal=rng in LITERAL_TYPES))
        if not preds:
            return None

        node_aliases: dict[str, list[str]] = {}
        edge_aliases: dict[str, list[str]] = {}
        aliases_block = ont.get("aliases")
        if isinstance(aliases_block, dict):
            if isinstance(aliases_block.get("classes"), dict):
                node_aliases.update(aliases_block["classes"])
            if isinstance(aliases_block.get("properties"), dict):
                edge_aliases.update(aliases_block["properties"])
        src_ref = ont.get("source_reference")
        if isinstance(src_ref, str) and src_ref.strip():
            sidecar_path = Path(src_ref.strip() + ".aliases.json")
            if sidecar_path.is_file():
                try:
                    sidecar = json.loads(sidecar_path.read_text(encoding="utf-8"))
                    if isinstance(sidecar.get("classes"), dict):
                        node_aliases.update(sidecar["classes"])
                    if isinstance(sidecar.get("properties"), dict):
                        edge_aliases.update(sidecar["properties"])
                except Exception:
                    pass
        return cls(
            predicates=preds,
            edge_descriptions=edge_descriptions,
            node_aliases=node_aliases,
            edge_aliases=edge_aliases,
            schema_id=str(ont.get("schema_id") or ""),
        )

    def select(self, question: str, budget: SchemaContextBudget | None = None) -> SchemaContext:
        budget = budget or SchemaContextBudget()
        if not isinstance(question, str) or not question.strip():
            raise SchemaSelectionError("empty_question", "a nonempty question is required")
        if len(question.encode("utf-8")) > budget.max_request_utf8_bytes:
            raise SchemaSelectionError("request_budget_exceeded", "question exceeds the complete request budget")
        symbols = set(self.predicates) | set(self.aliases)
        discovery = _discovery_text(question, self.discovery_symbols)
        words = _words(discovery)
        node_matches = {
            node: max(
                (phrase for phrase in phrases if set(phrase) <= words),
                key=lambda phrase: (len(phrase), phrase),
                default=(),
            )
            for node, phrases in self.node_phrases.items() if node not in LITERAL_TYPES
        }
        node_evidence = {frozenset(terms) for terms in node_matches.values() if terms}
        explicit_nodes = {
            node for node, terms in node_matches.items()
            if terms and not any(set(terms) < other for other in node_evidence)
        }
        type_terms = set().union(*(set(node_matches[n]) for n in explicit_nodes)) if explicit_nodes else set()

        def in_scope(name: str) -> bool:
            p = self.predicates[name]
            return (
                not explicit_nodes
                or p.domain in explicit_nodes
                or p.range in explicit_nodes
                or (p.literal and bool(self.name_terms.get(name, frozenset()) & type_terms))
            )

        requirements: list[SchemaRequirement] = []
        required: set[str] = set()
        masked = _QUOTED.sub(lambda m: " " * len(m[0]), question)
        spans = list(re.finditer(r",|;|\b(?:and|plus)\b", masked, flags=re.I))
        bounds = [0, *(m.end() for m in spans), len(question) + 1]
        for index, start in enumerate(bounds[:-1]):
            end = spans[index].start() if index < len(spans) else len(question)
            clause = question[start:end].strip()
            if not clause:
                continue
            lookup = _discovery_text(clause, self.discovery_symbols)
            terms = _words(lookup)
            exact = {
                self.aliases.get(name, name) for name in symbols
                if re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)", lookup, flags=re.I)
            }
            matches: dict[str, set[str]] = defaultdict(set)
            for term in terms:
                for name in self.postings.get(term, ()):
                    if in_scope(name):
                        matches[name].add(term)
            for name in exact:
                matches[name].add(name)
            tokens = _tokens(lookup)
            for name, phrases in self.phrases.items():
                if not in_scope(name):
                    continue
                for phrase in phrases:
                    if any(tokens[i:i + len(phrase)] == phrase for i in range(len(tokens) - len(phrase) + 1)):
                        matches[name].update(phrase)
            if len(matches) > budget.max_candidate_predicates:
                raise SchemaSelectionError("selection_budget_exceeded", "too many candidate predicates")
            if not matches:
                continue
            selected = {
                name: matched for name, matched in matches.items()
                if name in exact or not any(matched < other for other in matches.values())
            }
            required.update(selected)
            requirements.append(SchemaRequirement(
                clause,
                tuple(sorted(selected)),
                tuple(sorted(set().union(*selected.values()))),
            ))

        if not required:
            raise SchemaSelectionError("missing_schema", "no requested predicate matched")

        chosen = set(required)
        entities = set(explicit_nodes)
        for name in required:
            p = self.predicates[name]
            entities.add(p.domain)
            if not p.literal:
                entities.add(p.range)
        self._check_size(chosen, entities, budget)
        attached = {min(entities)}

        def expand_attached() -> None:
            changed = True
            while changed:
                changed = False
                for name in chosen:
                    p = self.predicates[name]
                    if not p.literal and attached & {p.domain, p.range}:
                        before = len(attached)
                        attached.update((p.domain, p.range))
                        changed |= len(attached) != before

        expand_attached()
        paths: list[tuple[str, ...]] = []
        states = 0
        while entities - attached:
            found: set[tuple[str, ...]] = set()
            shortest = None
            queue = deque((n, (), frozenset({n})) for n in sorted(attached))
            states += len(queue)
            while queue:
                if states > budget.max_path_states:
                    raise SchemaSelectionError("path_budget_exceeded", "aggregate connecting-path budget exceeded")
                node, path, seen = queue.popleft()
                if shortest is not None and len(path) > shortest:
                    break
                if node in entities - attached:
                    found.add(path)
                    shortest = len(path)
                    continue
                if len(path) >= budget.max_hops:
                    continue
                for neighbor, edge in self.adjacency.get(node, ()):
                    if neighbor not in seen:
                        queue.append((neighbor, path + (edge,), seen | {neighbor}))
                        states += 1
            if not found:
                raise SchemaSelectionError("missing_connection", "required symbols have no bounded connecting path")
            if len(found) != 1:
                raise SchemaSelectionError("ambiguous_path", "name the exact connecting relationship")
            path = next(iter(found))
            chosen.update(path)
            paths.append(path)
            expand_attached()
            self._check_size(chosen, entities | attached, budget)

        for entity in entities | attached:
            chosen.update(self.identity.get(entity, ()))
        nodes = self._check_size(chosen, entities | attached, budget)
        context = SchemaContext(
            self.schema_id,
            self.catalog_id,
            tuple(sorted(nodes)),
            tuple(self.predicates[n] for n in sorted(chosen)),
            tuple(sorted(required | {n for p in paths for n in p})),
            tuple(paths),
            tuple(requirements),
            tuple(sorted(
                name
                for entity in entities | attached
                for name in self.identity.get(entity, ())
                if name in chosen
            )),
        )
        if len(context.metadata_text().encode("utf-8")) > budget.max_utf8_bytes:
            raise SchemaSelectionError("context_budget_exceeded", "schema metadata exceeds the UTF-8 budget")
        return context

    def _check_size(self, chosen: set[str], entities: set[str], budget: SchemaContextBudget) -> set[str]:
        nodes = set(entities)
        for name in chosen:
            p = self.predicates[name]
            nodes.update((p.domain, p.range))
        if len(chosen) > budget.max_predicates or len(nodes) > budget.max_nodes:
            raise SchemaSelectionError("context_budget_exceeded", "required nodes/predicates exceed the budget")
        return nodes


def response_schema_error(
    context: SchemaContext | SchemaCatalog,
    activities: list[dict[str, Any]],
    response: str,
) -> str | None:
    """Validate that KB response and executed GQL respect the selected SchemaContext / SchemaCatalog."""
    if not isinstance(response, str) or not response.strip():
        return "graph synthesis returned no usable answer"
    if "gqlref:" in response.casefold():
        return "graph synthesis exposed an unresolved graph reference"
    unhinted = isinstance(context, SchemaCatalog)
    allowed = context.predicates if unhinted else {p.name: p for p in context.predicates}
    required = set() if unhinted else set(context.required_predicates)
    allowed_nodes = set(context.nodes)
    used: set[str] = set()

    for activity in activities:
        if str(activity.get("type") or "").casefold() != "graphsearch":
            continue
        gql = str((activity.get("graphSearchArguments") or {}).get("gql") or "")
        if not gql.strip():
            continue
        code = re.sub(r"'(?:[^'\\]|\\.|'')*'|\"(?:[^\"\\]|\\.|\"\")*\"", "''", gql)
        for _var, labels in re.findall(r"\(\s*(\w+)\s*:\s*(`[^`]+`|[A-Za-z_]\w*)\s*\)", code):
            lbl = labels.strip("`")
            if lbl not in allowed_nodes:
                return f"executed GQL used an unselected or conflicting node type: {lbl}"
        for edge_lbl in re.findall(r"-\s*\[\s*(?:\w+\s*)?:\s*(`[^`]+`|[A-Za-z_]\w*)\s*\]\s*-", code):
            ename = edge_lbl.strip("`").removeprefix("prop:")
            if ename not in allowed:
                return f"executed GQL used an undeclared predicate: {ename}"
            used.add(ename)
    if not used:
        return "executed GQL omitted verifiable typed edge contracts"
    if not required <= used:
        return "executed GQL omitted selected request predicates or connecting paths"
    return None


def repair_entity_name_filters(
    context: SchemaContext | SchemaCatalog,
    gql: str,
) -> str | None:
    """Replace intrinsic entity-name filters (`v.name = 'X'`) with the entity's single identity edge."""
    if isinstance(context, SchemaContext):
        identity_names = context.identity_predicates
        predicates = {p.name: p for p in context.predicates}
    else:
        identity_names = tuple(sorted(name for names in context.identity.values() for name in names))
        predicates = context.predicates
    if not identity_names or not isinstance(gql, str) or not gql.strip():
        return None
    label_expression = r"(?:`[^`]+`|[A-Za-z_]\w*)(?:\s*\|\s*(?:`[^`]+`|[A-Za-z_]\w*))*"
    nodes = {
        variable: {t.strip("`") for t in re.findall(r"`[^`]+`|[A-Za-z_]\w*", labels)}
        for variable, labels in re.findall(rf"\(\s*(\w+)\s*:\s*({label_expression})\s*\)", gql)
    }
    identity_by_domain: dict[str, list[Predicate]] = defaultdict(list)
    for name in identity_names:
        if name in predicates:
            identity_by_domain[predicates[name].domain].append(predicates[name])
    used_variables = set(re.findall(r"\b(\w+)\b", gql))
    comparison = re.compile(
        r"\b(\w+)\.name\s*=\s*('(?:[^'\\]|\\.|'')*'|\"(?:[^\"\\]|\\.|\"\")*\")",
        re.I,
    )
    repairs: list[tuple[str, str, str, Predicate, str]] = []
    for match in comparison.finditer(gql):
        variable, literal = match.groups()
        candidates = {
            predicate.name: predicate
            for node_type in nodes.get(variable, ())
            for predicate in identity_by_domain.get(node_type, ())
        }
        if len(candidates) != 1:
            continue
        predicate = next(iter(candidates.values()))
        if re.search(
            rf"\(\s*{re.escape(variable)}\b[^)]*\)\s*-\s*\[\s*(?:\w+\s*)?:\s*`?{re.escape(predicate.name)}`?\s*\]\s*->",
            gql,
        ):
            continue
        identity_variable = f"{variable}_identity"
        suffix = 1
        while identity_variable in used_variables:
            identity_variable = f"{variable}_identity_{suffix}"
            suffix += 1
        used_variables.add(identity_variable)
        repairs.append((match.group(0), variable, literal, predicate, identity_variable))
    if not repairs:
        return None
    repaired = gql
    patterns = []
    for original, variable, literal, predicate, identity_variable in repairs:
        repaired = repaired.replace(original, f"{identity_variable}.name = {literal}", 1)
        patterns.append(f"({variable})-[:`{predicate.name}`]->({identity_variable}:`{predicate.range}`)")
    boundary = re.search(r"\b(?:WHERE|RETURN)\b", repaired, re.I)
    if boundary is None:
        return None
    return (
        repaired[:boundary.start()].rstrip()
        + ", "
        + ", ".join(patterns)
        + " "
        + repaired[boundary.start():].lstrip()
    )
