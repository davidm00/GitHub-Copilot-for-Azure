"""`graph-playground`: open the Graph Playground in the browser and print its link.

It finds what this machine has published (the same generator as `foundry-iq-workspace config`) and a
Node.js 22.13 or later (PATH first, then nvm, fnm and Volta), writes the config to its own state folder,
starts the packaged launcher in the background, waits for its ready line and opens the link.
`graph-playground stop` closes it. Read-only: no Azure calls.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import signal
import socket
import subprocess
import time
import webbrowser
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from ekg_core.cli import Blocked, add_command, new_parser, parse, report, say
from ekg_core.files import atomic_write_text
from ekg_consume.workspace import MIN_NODE, build_config

PROG = "graph-playground"
READY = re.compile(r"Graph Playground ready: (http://127\.0\.0\.1:\d+)")
FAILED = re.compile(r"Apps host startup failed \[[^\]]*\]: (.+)")
START_TIMEOUT_S = 180
TABS = {"entity": "Knowledge graph", "topicgraph": "Topics", "ontology": "Ontology", "grounding": "Grounding"}
_VERSION = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)")

Version = tuple[int, int, int]


def _parse_version(text: str | None) -> Version | None:
    match = _VERSION.match((text or "").strip())
    return (int(match[1]), int(match[2]), int(match[3])) if match else None


def node_version(node: Path) -> Version | None:
    try:
        out = subprocess.run([str(node), "--version"], capture_output=True, text=True, timeout=15).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    return _parse_version(out)


def managed_nodes(env: Mapping[str, str], home: Path, windows: bool) -> list[tuple[Version, Path]]:
    """Node.js versions installed by nvm, fnm or Volta in their usual places, newest first."""
    exe = "node.exe" if windows else "node"
    bin_exe = exe if windows else "bin/node"
    local, roaming = env.get("LOCALAPPDATA"), env.get("APPDATA")
    places: list[tuple[str | Path | None, str]] = []
    if windows:  # nvm-windows: <root>\v22.19.0\node.exe
        places += [(env.get("NVM_HOME"), exe), (roaming and Path(roaming) / "nvm", exe),
                   (local and Path(local) / "nvm", exe)]
    else:  # nvm: ~/.nvm/versions/node/v22.19.0/bin/node
        places.append((Path(env.get("NVM_DIR") or home / ".nvm") / "versions" / "node", bin_exe))
    fnm = [env.get("FNM_DIR")] + ([roaming and str(Path(roaming) / "fnm")] if windows
                                  else [str(home / ".local" / "share" / "fnm"), str(home / ".fnm")])
    places += [(Path(d) / "node-versions", f"installation/{bin_exe}") for d in fnm if d]
    volta = env.get("VOLTA_HOME") or (local and str(Path(local) / "Volta") if windows else str(home / ".volta"))
    if volta:
        places.append((Path(volta) / "tools" / "image" / "node", bin_exe))
    found: dict[Path, Version] = {}
    for root, inner in places:
        if not root or not Path(root).is_dir():
            continue
        for child in Path(root).iterdir():
            version, path = _parse_version(child.name), child / inner
            if version and path.is_file():
                found[path] = version
    return sorted(((v, p) for p, v in found.items()), key=lambda item: item[0], reverse=True)


def find_node(env: Mapping[str, str] | None = None, home: Path | None = None, *,
              windows: bool = os.name == "nt",
              version_of: Callable[[Path], Version | None] = node_version) -> dict[str, str]:
    """The Node.js to run the launcher: PATH's when it is new enough, else the newest 22.13+ that nvm,
    fnm or Volta installed. Raises Blocked("NODE_REQUIRED") with one plain line when there is none."""
    env = os.environ if env is None else env
    on_path = shutil.which("node", path=env.get("PATH"))
    path_version = version_of(Path(on_path)) if on_path else None
    if path_version and path_version[:2] >= MIN_NODE:
        return {"path": on_path, "version": ".".join(map(str, path_version))}
    for listed, path in managed_nodes(env, home or Path.home(), windows):
        if listed[:2] >= MIN_NODE and (actual := version_of(path)) and actual[:2] >= MIN_NODE:
            return {"path": str(path), "version": ".".join(map(str, actual))}
    need = f"{MIN_NODE[0]}.{MIN_NODE[1]}"
    have = f" (this computer has {'.'.join(map(str, path_version))})" if path_version else ""
    raise Blocked("NODE_REQUIRED", f"The Graph Playground needs Node.js {need} or later{have}.")


def _state_root() -> Path:
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    else:
        base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    return Path(base) / "foundry-iq" / "graph-playground"


def state_dir(workspace: Path) -> Path:
    """This workspace's own Playground folder (config, log, running state), outside the workspace."""
    key = hashlib.sha256(str(workspace.resolve()).casefold().encode("utf-8")).hexdigest()[:16]
    return _state_root() / key


def _alive(pid: int) -> bool:
    if os.name == "nt":
        out = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                             capture_output=True, text=True, check=False).stdout
        return f'"{pid}"' in out
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _answers(url: str) -> bool:
    host, port = url.removeprefix("http://").rsplit(":", 1)
    try:
        with socket.create_connection((host, int(port)), timeout=2):
            return True
    except OSError:
        return False


def _running(folder: Path) -> dict[str, Any] | None:
    path = folder / "playground.json"
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if isinstance(state, dict) and _alive(int(state.get("pid", 0))) and _answers(str(state.get("url", ""))):
        return state
    path.unlink(missing_ok=True)
    return None


def _start_options() -> dict[str, Any]:
    if os.name != "nt":
        return {"start_new_session": True}
    # A hidden console (not none), so the Python servers the launcher starts open no windows either.
    return {"creationflags": subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP}


def _start(command: list[str], log: Path, cwd: Path) -> subprocess.Popen:
    with log.open("w", encoding="utf-8") as out:
        options = _start_options()
        kwargs = dict(stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT, cwd=str(cwd),
                      close_fds=True)
        if os.name == "nt":
            try:  # Outlive the calling shell's job when it allows that.
                return subprocess.Popen(command, **kwargs,
                                        creationflags=options["creationflags"]
                                        | subprocess.CREATE_BREAKAWAY_FROM_JOB)
            except OSError:
                pass
        return subprocess.Popen(command, **kwargs, **options)


def _stop_tree(pid: int) -> None:
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, check=False)
    else:
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)  # the launcher closes its own servers
        except ProcessLookupError:
            return
    deadline = time.monotonic() + 15
    while _alive(pid) and time.monotonic() < deadline:
        time.sleep(0.25)
    if os.name != "nt" and _alive(pid):
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except ProcessLookupError:
            pass


def _wait_ready(process: subprocess.Popen, log: Path, timeout: float) -> str:
    deadline = time.monotonic() + timeout
    while True:
        text = log.read_text(encoding="utf-8", errors="replace") if log.is_file() else ""
        if ready := READY.search(text):
            return ready[1]
        if process.poll() is not None:
            failed = FAILED.search(text)
            raise Blocked("PLAYGROUND_FAILED", "The Graph Playground didn't start: "
                          + (failed[1].strip() if failed else "the launcher stopped early."), log=str(log))
        if time.monotonic() >= deadline:
            _stop_tree(process.pid)
            raise Blocked("PLAYGROUND_FAILED",
                          f"The Graph Playground didn't start within {int(timeout)} seconds.", log=str(log))
        time.sleep(0.25)


def _opened(url: str, tabs: list[str], *, already: bool, browser: bool,
            not_included: dict[str, str]) -> dict[str, Any]:
    summary = (f"The Graph Playground is already open: {url}" if already
               else f"I opened the Graph Playground in your browser: {url}" if browser
               else f"The Graph Playground is running: {url}")
    return {"status": "ready", "url": url, "tabs": tabs, "already_running": already,
            "not_included": not_included, "summary": summary, "stop_command": f"{PROG} stop",
            "next_step": f"Give the user the link {url}. To close it later, run `{PROG} stop`."}


def open_playground(*, browser: bool = True, port: int = 0, timeout: float = START_TIMEOUT_S,
                    node: dict[str, str] | None = None) -> dict[str, Any]:
    workspace = Path.cwd()
    folder = state_dir(workspace)
    running = _running(folder)
    if running:
        if browser:
            webbrowser.open(running["url"])
        return _opened(running["url"], running.get("tabs", []), already=True, browser=browser,
                       not_included=running.get("not_included", {}))
    plugin = os.environ.get("PLUGIN_ROOT")
    launcher = Path(plugin) / "apps-host" / "launch.mjs" if plugin else None
    if launcher is None or not launcher.is_file():
        raise Blocked("PLAYGROUND_UNAVAILABLE", "The plugin's Graph Playground files are missing.")
    node = node or find_node()
    config, notes = build_config(port)
    if not config["domains"]:
        raise Blocked("WORKSPACE_NOTHING_PUBLISHED",
                      "Nothing is published on this machine yet: " + "; ".join(notes.values()))
    config["cwd"] = str(workspace)
    folder.mkdir(parents=True, exist_ok=True)
    config_path = folder / "config.json"
    atomic_write_text(config_path, json.dumps(config, indent=2) + "\n")
    log = folder / "launch.log"
    process = _start([node["path"], str(launcher), "--config", str(config_path)], log, workspace)
    url = _wait_ready(process, log, timeout)
    tabs = [TABS[name] for name in config["domains"]]
    not_included = {TABS[name]: why for name, why in notes.items() if name not in config["domains"]}
    atomic_write_text(folder / "playground.json", json.dumps(
        {"pid": process.pid, "url": url, "workspace": str(workspace), "tabs": tabs,
         "not_included": not_included, "node": node["version"]}, indent=2) + "\n")
    if browser:
        webbrowser.open(url)
    return _opened(url, tabs, already=False, browser=browser, not_included=not_included)


def stop_playground() -> dict[str, Any]:
    folder = state_dir(Path.cwd())
    path = folder / "playground.json"
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = None
    pid = int(state.get("pid", 0)) if isinstance(state, dict) else 0
    if not pid or not _alive(pid):
        path.unlink(missing_ok=True)
        return {"status": "ok", "stopped": False, "summary": "The Graph Playground isn't running."}
    _stop_tree(pid)
    path.unlink(missing_ok=True)
    return {"status": "ok", "stopped": True, "summary": "Closed the Graph Playground."}


def _parser():
    parser, commands = new_parser(PROG, "Open the Graph Playground in your browser.", "0.1.0")
    opened = add_command(commands, "open", "open the Graph Playground and print its link (the default)")
    opened.add_argument("--no-browser", action="store_true", help="start it and print the link only")
    opened.add_argument("--port", type=int, default=0, help="localhost port (default: any free port)")
    add_command(commands, "stop", "close the Graph Playground this folder opened")
    return parser


def main(argv: list[str] | None = None) -> None:
    import sys

    argv = list(sys.argv[1:] if argv is None else argv)
    if not [a for a in argv if a != "--json"]:
        argv = ["open", *argv]
    args = parse(_parser(), argv)
    try:
        if args.command == "stop":
            result = stop_playground()
        else:
            if not 0 <= args.port <= 65535:
                raise Blocked("USAGE", "--port must be 0..65535")
            result = open_playground(browser=not args.no_browser, port=args.port)
    except Blocked as blocked:
        report(blocked, prog=PROG, command=args.command)
    except OSError as error:
        report(Blocked("LOCAL_IO", str(error)), prog=PROG, command=args.command, cause=error)
    say(result, args, prog=PROG)
