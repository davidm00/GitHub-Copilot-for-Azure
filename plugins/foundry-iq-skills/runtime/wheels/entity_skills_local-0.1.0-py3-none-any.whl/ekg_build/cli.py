from __future__ import annotations
import argparse
import json
import sys
from dataclasses import asdict
from pathlib import Path
from ekg_core import grounding, package_version
from ekg_core.cli import Blocked, add_command, new_parser, parse, report, say
from ekg_core.models import (
    BuildSpec, KnowledgeSourceKind, OntologyMode, RequestedOutcome,
    SourceKind, SourceLocator, SourceManifest, Target, manifest_item_from_json,
)
from .adapters import AzureDataPlane
from .deployment import descriptor, publish
from .executor import BuildExecutor
from .managed_pipeline import SEARCH_API_VERSION, search_api_version, uses_direct_blob_source
from .planner import plan
from .preflight import preflight
from .status import read_build_status

PROG = "entity-graph-build"
DEFAULT_SAMPLE = 50
_DEFAULTS = {
    "reader": [], "descriptor": [], "generation": [], "plan_id": None, "confirm_writes": False,
    "wait": False, "output": None, "chat_capacity": None, "trial_report": None, "upload_concurrency": 16, "consume_log": None, "run_id": None,
    "build_journal": None, "tenant_id": None, "search_endpoint": None, "sample": None,
    "storage_endpoint": None, "search_resource_id": None, "storage_resource_id": None,
    "dataset": "microsoft-earnings-calls", "limit": None,
}
# The review verb each gated verb's approval comes from.
_PLAN_VERB = {"apply": "plan", "retire": "plan-retire", "update": "plan-update",
              "attach-ontology": "plan-attach-ontology"}


def _spec_arguments() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--source-kind", choices=[kind.value for kind in SourceKind])
    parser.add_argument("--source-reference")
    parser.add_argument("--source-resource-id")
    parser.add_argument("--source-container")
    parser.add_argument("--source-prefix")
    parser.add_argument("--source-library-id")
    parser.add_argument("--source-description",
                        help="required: a short factual summary of the corpus (subject matter, "
                             "document types, main coverage) that the agent drafts from sampled "
                             "documents; sent as the Knowledge Source description and part of "
                             "the plan ID")
    parser.add_argument("--requested-outcome", choices=[item.value for item in RequestedOutcome])
    parser.add_argument("--knowledge-source-kind",
                        choices=[item.value for item in KnowledgeSourceKind])
    parser.add_argument("--ontology", choices=[mode.value for mode in OntologyMode],
                        default=OntologyMode.DEFERRED.value)
    parser.add_argument("--ontology-path")
    parser.add_argument("--search-endpoint")
    parser.add_argument("--storage-endpoint")
    parser.add_argument("--openai-endpoint")
    parser.add_argument("--content-understanding-endpoint",
                        help="https://<name>.services.ai.azure.com; needed only for PDFs, "
                             "Office files and images")
    parser.add_argument("--search-resource-id")
    parser.add_argument("--storage-resource-id")
    parser.add_argument("--cache-storage-resource-id",
                        help="ARM ID of the dedicated StorageV2 account for the Knowledge "
                             "Source enrichment cache (defaults to --storage-resource-id)")
    parser.add_argument("--openai-resource-id")
    parser.add_argument("--embedding-openai-endpoint")
    parser.add_argument("--embedding-openai-resource-id")
    parser.add_argument("--chat-openai-endpoint")
    parser.add_argument("--chat-openai-resource-id")
    parser.add_argument("--kb-openai-endpoint")
    parser.add_argument("--kb-openai-resource-id")
    parser.add_argument("--embedding-deployment")
    parser.add_argument("--embedding-model")
    parser.add_argument("--embedding-dimensions", type=int)
    parser.add_argument("--chat-deployment")
    parser.add_argument("--chat-model")
    parser.add_argument("--kb-chat-deployment")
    parser.add_argument("--kb-chat-model", "--kb-model", dest="kb_chat_model")
    parser.add_argument("--search-identity-resource-id")
    parser.add_argument("--use-system-identity", action="store_true",
                        help="authenticate Search to Storage and OpenAI using its system-assigned managed identity")
    parser.add_argument("--location")
    parser.add_argument("--tenant-id")
    parser.add_argument("--extraction-parallelism", type=int,
                        help="requested managed extraction page parallelism (1..64, new plans default 64); "
                             "effective packing/concurrency must be read back")
    parser.add_argument("--ingestion-interval",
                        help="Knowledge Source indexer schedule, PT5M..P1D (default: the "
                             "service's P1D); set PT5M so a build longer than one 2-hour "
                             "indexer run continues unattended")
    parser.add_argument("--grounding-index",
                        help="name of an existing Search index with an edgeList graph profile "
                             "to ground extraction against; validated read-only, never created")
    parser.add_argument("--search-sku")
    parser.add_argument("--build-journal")
    parser.add_argument("--subscription-id")
    parser.add_argument("--resource-group")
    parser.add_argument("--storage-container", default="source-documents")
    parser.add_argument("--source-manifest")
    parser.add_argument("--sample", type=int, nargs="?", const=DEFAULT_SAMPLE, default=None,
                        metavar="N",
                        help=f"trial build: stage only N documents of --source-manifest "
                             f"(default {DEFAULT_SAMPLE}), chosen deterministically, under a "
                             "trial prefix; never publishable")
    parser.add_argument("--run-id")
    parser.add_argument("--descriptor", action="append", default=[],
                        help="the published descriptor: plan/apply carry its index readers "
                             "forward; publish proposes cleanup against it; plan-update/update "
                             "update it in place; plan-attach-ontology/attach-ontology take the "
                             "deferred build's descriptor; verify takes an attached build's")
    parser.add_argument("--reader", action="append", default=[],
                        help="<object-id>:User|ServicePrincipal|Group to grant Search Index "
                             "Data Reader on the new generation's indexes (repeatable); "
                             "index-scoped readers of --descriptor carry forward")
    return parser


def _generation_arguments() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--search-endpoint", required=True)
    parser.add_argument("--tenant-id", required=True)
    parser.add_argument("--descriptor", action="append", default=[],
                        help="serving descriptor whose generation is protected (repeatable)")
    parser.add_argument("--storage-endpoint")
    parser.add_argument("--storage-resource-id")
    parser.add_argument("--search-resource-id")
    return parser


def _gate(parser: argparse.ArgumentParser, what: str) -> None:
    parser.add_argument("--plan-id", help=f"the approved {what} plan ID")
    parser.add_argument("--confirm-writes", action="store_true",
                        help="confirm the Azure writes of the approved plan")


def _parser():
    parser, commands = new_parser(PROG, "Plan, apply, publish and maintain an Entity Graph build.",
                                  package_version())
    spec = _spec_arguments()
    generation = _generation_arguments()
    from ekg_core import doctor
    doctor.add_arguments(add_command(
        commands, "doctor", "Check this operator environment (read-only, no Azure writes)."),
        build=True)
    capacity = argparse.ArgumentParser(add_help=False)
    capacity.add_argument(
        "--chat-capacity", type=int,
        help="chat deployment capacity in thousands of TPM, for estimates only "
             "(not part of the plan ID)")
    capacity.add_argument(
        "--trial-report",
        help="a GO `entity-graph-build trial-report --json` result for this corpus; its measured time "
             "and cost replace the plan-time estimate (not part of the plan ID)")
    capacity.add_argument(
        "--upload-concurrency", type=int, default=16,
        help="parallel blob uploads while staging the corpus (default 16; not part of the "
             "plan ID)")
    add_command(commands, "plan", "Review the build plan and its plan ID (read-only).",
                [spec, capacity])
    for name, text in (("preflight", "Check the build inputs (read-only)."),
                       ("descriptor", "Show the descriptor this build would publish."),
                       ("inspect", "Inspect the live target (read-only)."),
                       ("verify", "Verify the built indexes (read-only)."),
                       ("reconcile", "Settle an unknown-outcome build from the journal."),
                       ("progress", "Show managed synchronization progress (read-only)."),
                       ("failures", "List documents that failed ingestion, their indexer errors "
                                    "and an acceptance ID (read-only)."),
                       ("plan-update", "Review an in-place update of a published build.")):
        add_command(commands, name, text, [spec])
    add_command(commands, "accept-failures",
                "Accept exactly the reviewed failed documents so the build can continue "
                "(writes one local record; no Azure writes).", [spec]).add_argument(
        "--acceptance-id", required=True,
        help="the acceptance ID shown by `entity-graph-build failures`")
    add_command(commands, "retry-failures",
                "Retry transiently failed documents once: reset only those source documents "
                "and rerun the indexer (a Search write; repeats their model calls).",
                [spec]).add_argument(
        "--retry-id", required=True, help="the retry ID shown by `entity-graph-build failures`")
    # Same --chat-capacity as plan and apply, so a plan's flags can be reused verbatim.
    chat = argparse.ArgumentParser(add_help=False)
    chat.add_argument("--chat-capacity", type=int,
                      help="chat deployment capacity in thousands of TPM; accepted for parity "
                           "with plan and apply (the report uses measured rates)")
    add_command(commands, "attribution", "Report model usage attribution (read-only).",
                [spec, chat])
    add_command(commands, "trial-report", "Report a verified trial build: populated and "
                                          "zero-hit classes and relationships, the full-build "
                                          "extrapolation and go/no-go (read-only).",
                [spec, chat])
    add_command(commands, "inventory", "Inventory the source into a manifest (read-only).",
                [spec]).add_argument("--output", help="write the manifest to this new file")
    fetch_cmd = add_command(
        commands,
        "fetch-sample",
        "Download and verify the built-in public sample corpus (default: microsoft-earnings-calls).",
    )
    fetch_cmd.add_argument(
        "--output", required=True,
        help="destination folder for the verified sample documents (created if missing)",
    )
    fetch_cmd.add_argument(
        "--dataset", default="microsoft-earnings-calls",
        choices=("microsoft-earnings-calls",),
        help="packaged sample dataset to materialize (default: microsoft-earnings-calls)",
    )
    fetch_cmd.add_argument(
        "--limit", type=int, default=None,
        help="optional limit on the number of sample documents to materialize",
    )
    apply = add_command(commands, "apply", "Apply the approved build plan.", [spec, capacity])
    _gate(apply, "build")
    apply.add_argument("--wait", action="store_true",
                       help="poll managed synchronization for up to five minutes and verify")
    publish_cmd = add_command(commands, "publish", "Publish the verified build's descriptor.", [spec])
    publish_cmd.add_argument(
        "--output", help="write the descriptor to this file and update the current pointer; "
                         "omit to write <Entity Graph home>/descriptors/<name>.json")
    publish_cmd.add_argument(
        "--keep-current", action="store_true",
        help="leave the current pointer on the previously published descriptor, for example "
             "to publish a second graph side by side")
    _gate(add_command(commands, "update", "Apply the approved in-place update plan.", [spec]),
          "update")
    add_command(commands, "plan-attach-ontology",
                "Review attaching an ontology to a published deferred-ontology build "
                "(read-only).", [spec]).add_argument(
        "--trial-report",
        help="a GO `entity-graph-build trial-report --json` result for this ontology and corpus; "
             "its measured time and cost replace the card's plan-time estimate")
    _gate(add_command(commands, "attach-ontology",
                      "Apply the approved attach-ontology plan.", [spec]), "attach")
    status = add_command(commands, "status", "Read one run from the build journal.")
    status.add_argument("--build-journal", required=True)
    status.add_argument("--run-id", required=True)
    telemetry = add_command(commands, "telemetry", "Summarize build and consume timings.")
    telemetry.add_argument("--build-journal")
    telemetry.add_argument("--run-id")
    telemetry.add_argument("--consume-log", help="Consume JSONL log to summarize (read-only)")
    add_command(commands, "generations", "List Entity Graph generations and what protects them.",
                [generation])
    add_command(commands, "plan-retire", "Review retiring generations (read-only).",
                [generation]).add_argument(
        "--generation", action="append", required=True,
        help="16-hex generation to delete (repeatable)")
    retire = add_command(commands, "retire", "Apply the approved retire plan.", [generation])
    retire.add_argument("--generation", action="append", required=True,
                        help="16-hex generation to delete (repeatable)")
    _gate(retire, "retire")
    return parser


def _staged_storage(args):
    if not args.storage_endpoint or not args.storage_resource_id:
        return None
    from . import generations as gen
    from .blob_sources import AzureBlobReader
    return gen.StagedStorage(AzureBlobReader(tenant_id=args.tenant_id),
                             args.storage_endpoint.rstrip("/"), args.storage_resource_id)


def _index_grants(args, adapter):
    if not args.search_resource_id or not args.tenant_id:
        return None
    from . import generations as gen
    return gen.IndexGrants(adapter, args.search_resource_id, args.tenant_id)


def _check_tenant(adapter, tenant_id: str) -> None:
    from ekg_core import az_identity
    token = adapter.credential.get_token("https://search.azure.com/.default").token
    if not az_identity.token_in_tenant(token, tenant_id):
        raise Blocked("TENANT_MISMATCH", "the signed-in Search credential is not in --tenant-id")


def _telemetry_summary(report: dict) -> dict:
    from ekg_core.telemetry import summary_text
    return {"summary": summary_text(report)}


def _handle_telemetry(args) -> dict:
    if not args.build_journal and not args.consume_log:
        raise Blocked("USAGE", "telemetry requires --build-journal and/or --consume-log")
    from .telemetry import build_telemetry
    try:
        return build_telemetry(args.build_journal, args.run_id, consume_log=args.consume_log)
    except ValueError as error:
        raise Blocked("INVALID_INPUT", str(error)) from error


def _handle_generations(args) -> dict:
    from ekg_core import az_identity
    from . import generations as gen
    adapter = AzureDataPlane(search_endpoint=args.search_endpoint,
                             credential=az_identity.cli_credential(args.tenant_id),
                             search_api_version=SEARCH_API_VERSION)
    _check_tenant(adapter, args.tenant_id)
    scope = {"descriptors": tuple(args.descriptor), "search_endpoint": args.search_endpoint}
    storage = _staged_storage(args)
    grants = _index_grants(args, adapter)
    if args.command == "generations":
        return gen.list_generations(adapter, scope["descriptors"])
    if args.command == "plan-retire":
        review = gen.retire_plan(adapter, tuple(args.generation), **scope, storage=storage,
                                 grants=grants)
        if not review["blockers"]:
            review["approval_card"] = _retire_card(args, review)
        return review
    result = gen.retire(adapter, tuple(args.generation), **scope, storage=storage,
                        grants=grants, approved_plan_id=args.plan_id or "",
                        confirmed=args.confirm_writes)
    if result.get("status") == "stopped":
        raise Blocked("RETIRE_STOPPED", result["error"], result=result)
    return result


def _card_context(args) -> dict:
    from ekg_core import approval
    return approval.azure_context(args.tenant_id, None,
                                  approval.search_service_name(args.search_endpoint))


_RESOURCE_NAMES = {"knowledgesources": "Knowledge Source", "knowledgebases": "knowledge base",
                   "indexes": "index", "indexers": "indexer", "skillsets": "skillset",
                   "datasources": "data source"}
_REMOVED_ORDER = ("indexer", "skillset", "data source", "content index", "graph index")


def _removed_label(op: dict) -> str:
    if op["kind"] == "indexes":
        return "graph index" if op["name"].endswith("graph-index") else "content index"
    return _RESOURCE_NAMES.get(op["kind"], op["kind"])


def _retire_card(args, review: dict) -> str:
    from ekg_core import approval
    changes = []
    for op in review["operations"]:
        if op["kind"] == "blobs" or op["action"] != "delete":
            continue
        if op["kind"] == "roleassignments":
            changes.append(f"Remove {op['role']} for {op['principal']} on index {op['index']}")
            continue
        text = f"Delete {_RESOURCE_NAMES.get(op['kind'], op['kind'])} {op['name']}"
        removed = [_removed_label(o) for o in review["operations"]
                   if o["action"] == "await_removal" and o["generation"] == op["generation"]]
        if op["kind"] == "knowledgesources" and removed:
            labels = sorted(set(removed), key=lambda label: (
                _REMOVED_ORDER.index(label) if label in _REMOVED_ORDER else 99, label))
            listed = (", ".join(labels[:-1]) + " and " + labels[-1]) if len(labels) > 1 \
                else labels[0]
            text += (f" (its generated {listed} are removed with it;"
                     " a scheduled Knowledge Source stops polling)")
        changes.append(text)
    for prefix in review["write"]["blob_prefixes"]:
        count = sum(1 for op in review["operations"] if op["kind"] == "blobs"
                    and f"{op['container']}/{op.get('prefix', op['generation'] + '/')}" == prefix)
        changes.append(f"Delete {count} staged blob(s) under {prefix}")
    names = _card_context(args)
    return approval.card(
        what=f"retire {len(dict.fromkeys(args.generation))} generation(s)",
        changes=changes, time=approval.time_text(1, 5),
        cost=approval.cost_text(0.0), tenant_id=args.tenant_id,
        tenant_name=names.get("tenant_name"), subscription=names.get("subscription"),
        resource_group=names.get("resource_group"))


def _update_card(args, spec, review: dict) -> str:
    from ekg_core import approval
    from ekg_core.pricing import SERVERLESS_USAGE_COST
    from .estimates import extraction_estimate
    write, stale = review["write"], review["stale"]
    changes = [text for text, count in (
        (f"Upload {write['stage']} new or changed document(s)", write["stage"]),
        (f"Stop serving {write['remove']} removed document(s)", write["remove"]),
        (f"Delete {len(stale['chunks'])} stale chunk(s) and {len(stale['triples'])} stale "
         "graph fact(s)", write["document_deletes"]),
        ("Run the Knowledge Source indexer once", write["indexer_runs"]),
    ) if count]
    changes.append("Rewrite the local descriptor with the new source mapping")
    estimate = extraction_estimate(spec, write["stage"])
    cost = estimate.get("extraction_cost_usd")
    serverless = spec.search_sku == "serverless"
    estimate_cost = approval.cost_text(
        (cost["low"], cost["high"]) if cost else None if serverless else 0.0,
        daily=None if serverless else 0.0,
    )
    wall = estimate.get("minimum_wall_seconds") or 0
    timing = approval.time_text(wall / 60 + 2, wall / 60 * 1.5 + 10)
    names = _card_context(args)
    return approval.card(
        what=f"update published generation {review['generation']}",
        changes=changes,
        time=timing,
        cost=(f"model extraction estimate only: {estimate_cost}; total usage: "
              f"{SERVERLESS_USAGE_COST}" if serverless else estimate_cost),
        tenant_id=args.tenant_id, tenant_name=names.get("tenant_name"),
        subscription=names.get("subscription"), resource_group=names.get("resource_group"))


def _handle_inventory(args, source) -> dict:
    if source is None:
        raise Blocked("USAGE", "inventory requires an explicit source")
    if source.kind in {SourceKind.LOCAL_PATH, SourceKind.ZIP_ARCHIVE}:
        from .local_sources import inventory_local_source
        manifest = inventory_local_source(source)
    elif source.kind is SourceKind.BLOB_PREFIX:
        if not args.tenant_id:
            raise Blocked("USAGE", "Blob inventory requires --tenant-id")
        from .blob_sources import AzureBlobReader, inventory_blob_prefix
        manifest = inventory_blob_prefix(
            source, AzureBlobReader(tenant_id=args.tenant_id),
            tenant_id=args.tenant_id,
        ).manifest
    else:
        raise Blocked("USAGE", "no inventory adapter exists for this source kind")
    body = {"manifest": asdict(manifest), "digest": manifest.digest}
    if args.output:
        try:
            with open(args.output, "x", encoding="utf-8") as handle:
                json.dump(body, handle, indent=2)
        except FileExistsError as error:
            raise Blocked("USAGE", "--output must be a new file") from error
    elif not args.json:
        raise Blocked("USAGE", "inventory needs --output <new-file> (or --json to print the "
                      "manifest)")
    return {"summary": f"Inventoried {len(manifest.items)} source item(s)"
                       + (f" into {args.output}." if args.output else "."),
            **body,
            "next_step": "Pass the manifest file as --source-manifest to `entity-graph-build plan`."}


_ATTACH_BLOCKS = {"waiting": "ATTACH_WAITING", "stopped": "ATTACH_STOPPED",
                  "inconsistent": "ATTACH_INCONSISTENT", "stale": "ATTACH_STALE",
                  "partial": "ATTACH_PARTIAL"}


def _attach_card(args, spec, review: dict) -> str:
    from ekg_core import approval
    write = review["write"]
    changes = [
        *(["Replace the Knowledge Source definition at its reviewed ETag, adding the inline "
           f"ontology {review['ontology']['schema_id']}"] if write["knowledge_source_replace"]
          else []),
        "Run the Knowledge Source indexer once to extract the graph from cached chunks",
        *([f"Create Knowledge Base {review['knowledge_base']}"] if write["knowledge_bases"]
          else []),
        "Rewrite the local descriptor with the graph index and ontology",
    ]
    measured = _attach_trial_estimate(args, spec)
    estimate = (approval.cost_text((measured["extraction_cost_usd"]["low"],
                                    measured["extraction_cost_usd"]["high"]))
                if measured and measured.get("extraction_cost_usd")
                else _extraction_cost(spec) if spec.source_manifest else None)
    wall = (measured or {}).get("wall_minutes")
    names = _card_context(args)
    return approval.card(
        what=(f"attach ontology {review['ontology']['schema_id']} to deferred generation "
              f"{review['generation']}"),
        changes=changes,
        time=(approval.time_text(wall["low"] + 3, wall["high"] + 10) if wall
              else approval.time_text(5, 120)),
        cost=(f"graph extraction over every cached chunk: {estimate}"
              + (", measured by the trial" if measured else
                 " (plan-time rate; pass the trial's --trial-report for a measured estimate)")
              if estimate else
              "graph extraction over every cached chunk (chat model tokens; pass the trial's "
              "--trial-report for a measured estimate)"),
        tenant_id=args.tenant_id, tenant_name=names.get("tenant_name"),
        subscription=names.get("subscription"), resource_group=names.get("resource_group"),
        notes=(f"An attached ontology can't be removed from generation {review['generation']}; "
               "a different ontology later needs a new build.",))


def _attach_trial_estimate(args, spec) -> dict | None:
    path = getattr(args, "trial_report", None)
    if not path:
        return None
    from .estimates import trial_estimate
    try:
        return trial_estimate(spec, json.loads(Path(path).read_text(encoding="utf-8")))
    except (OSError, ValueError) as error:
        raise Blocked("USAGE", str(error)) from error


def _extraction_cost(spec) -> str | None:
    from ekg_core import approval
    from .estimates import extraction_estimate
    try:
        cost = extraction_estimate(spec, len(spec.source_manifest.items)).get(
            "extraction_cost_usd")
    except (KeyError, TypeError, ValueError):
        return None
    return approval.cost_text((cost["low"], cost["high"])) if cost else None


def _attach_spec(args, spec):
    """Bind the spec to the deferred generation the descriptor serves."""
    from dataclasses import replace
    from .attach import AttachError, descriptor_generation
    if len(args.descriptor) != 1:
        raise Blocked("USAGE", f"{args.command} requires exactly one --descriptor: the "
                      "published descriptor of the deferred-ontology build")
    try:
        return replace(spec, ontology_attached_to=descriptor_generation(args.descriptor[0]))
    except AttachError as error:
        raise Blocked("ATTACH_BLOCKED", str(error)) from error


def _attached_verify_spec(args, spec):
    """verify --descriptor <attached build>: check the attached generation, not a new one."""
    from dataclasses import replace
    from .attach import attached_record
    from .generations import _generation_of
    if len(args.descriptor) != 1 or spec.ontology_mode is OntologyMode.DEFERRED:
        return spec
    try:
        published = json.loads(Path(args.descriptor[0]).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return spec
    found = _generation_of(str((published.get("endpoints") or {}).get("knowledge_source")
                               or "")) if isinstance(published, dict) else None
    if found is None:
        return spec
    attached = replace(spec, ontology_attached_to=found)
    return attached if attached_record(attached) is not None else spec


def _handle_attach(args, spec) -> dict:
    if not args.search_endpoint or not args.tenant_id:
        raise Blocked("USAGE", f"{args.command} requires --search-endpoint and --tenant-id")
    from ekg_core import az_identity
    from . import attach as attaching
    adapter = AzureDataPlane(search_endpoint=args.search_endpoint,
                             storage_endpoint=args.storage_endpoint,
                             credential=az_identity.cli_credential(args.tenant_id),
                             search_api_version=search_api_version(spec))
    _check_tenant(adapter, args.tenant_id)
    if args.command == "attach-ontology" and args.confirm_writes:
        from ekg_core.cli import announce
        announce("a while: Search finds entities in every document; the progress check "
                 "says how far it got")
    if args.command == "plan-attach-ontology":
        review = attaching.attach_plan(adapter, spec, args.descriptor[0])
        if not review["blockers"]:
            review["approval_card"] = _attach_card(args, spec, review)
        return review
    result = attaching.attach(adapter, spec, args.descriptor[0], plan_id=args.plan_id or "",
                              confirm_writes=args.confirm_writes)
    if result["status"] != "attached":
        raise Blocked(_ATTACH_BLOCKS.get(result["status"], "ATTACH_STOPPED"),
                      result["summary"], result=result)
    return result


_UPDATE_BLOCKS = {"waiting": "UPDATE_WAITING", "stopped": "UPDATE_STOPPED",
                  "inconsistent": "UPDATE_INCONSISTENT"}


def _handle_update(args, spec) -> dict:
    if len(args.descriptor) != 1 or not spec.source_manifest:
        raise Blocked("USAGE", f"{args.command} requires one --descriptor and --source-manifest")
    storage_ep = args.storage_endpoint or (
        spec.source.reference if uses_direct_blob_source(spec) and spec.source else None
    )
    if not args.search_endpoint or not storage_ep or not args.tenant_id:
        raise Blocked("USAGE", f"{args.command} requires --search-endpoint, --storage-endpoint "
                      "and --tenant-id")
    from ekg_core import az_identity
    from . import update as content
    adapter = AzureDataPlane(search_endpoint=args.search_endpoint,
                             storage_endpoint=storage_ep,
                             credential=az_identity.cli_credential(args.tenant_id),
                             search_api_version=search_api_version(spec))
    _check_tenant(adapter, args.tenant_id)
    if args.command == "plan-update":
        review = content.update_plan(adapter, spec, args.descriptor[0])
        if not review["blockers"]:
            review["approval_card"] = _update_card(args, spec, review)
        return review
    reader = None
    if spec.source.kind is SourceKind.BLOB_PREFIX:
        from .blob_sources import AzureBlobReader
        reader = AzureBlobReader(tenant_id=spec.tenant_id)
    result = content.update(adapter, spec, args.descriptor[0], reader=reader,
                            approved_plan_id=args.plan_id or "",
                            confirmed=args.confirm_writes)
    if result["status"] != "updated":
        raise Blocked(_UPDATE_BLOCKS.get(result["status"], "UPDATE_STOPPED"),
                      result["summary"], result=result)
    return result


def _propose_cleanup(args, spec, published: dict) -> dict | None:
    """Publish only proposes cleanup; it never deletes."""
    if len(args.descriptor) != 1 or not spec.tenant_id:
        raise Blocked("USAGE", "publish takes one --descriptor (the previous serving "
                      "descriptor) and --tenant-id to propose cleanup")
    from ekg_core import az_identity
    from . import generations as gen
    adapter = AzureDataPlane(search_endpoint=args.search_endpoint,
                             credential=az_identity.cli_credential(spec.tenant_id),
                             search_api_version=SEARCH_API_VERSION)
    try:
        return gen.cleanup_proposal(adapter, published, args.descriptor[0],
                                    search_endpoint=args.search_endpoint,
                                    storage=_staged_storage(args),
                                    grants=_index_grants(args, adapter))
    except (ValueError, RuntimeError) as error:
        return {"summary": f"Cleanup proposal unavailable: {error}.",
                "retire_plan_id": None,
                "next_step": "Run `entity-graph-build generations` to review."}


def _arm(args):
    from ekg_core import az_identity
    return AzureDataPlane(search_endpoint=args.search_endpoint or "https://unused",
                          credential=az_identity.cli_credential(args.tenant_id))


def _journaled_readers(args) -> tuple[str, ...] | None:
    try:
        record = json.loads(Path(args.build_journal).read_text(encoding="utf-8"))
    except (TypeError, OSError, ValueError):
        return None
    found = record.get("readers") if isinstance(record, dict) else None
    return tuple(found) if isinstance(found, list) else None


def _readers(args) -> tuple[str, ...]:
    """--reader plus the index-scoped readers of the published descriptor (read-only).
    Once a run is journaled its approved reader set is fixed: re-detecting would move the
    plan ID whenever a reader changes on the old indexes, or after publish."""
    from . import readers
    try:
        found = readers.parse(args.reader)
        journaled = _journaled_readers(args) if args.command != "plan" else None
        if journaled is not None:
            if args.reader and set(found) - set(journaled):
                raise ValueError("this run's reader set is fixed by its approved plan; "
                                 "plan a new build to change it")
            return journaled
        if (args.command in ("plan", "apply") and len(args.descriptor) == 1
                and args.search_resource_id and args.tenant_id):
            published = json.loads(Path(args.descriptor[0]).read_text(encoding="utf-8"))
            carried = readers.published(_arm(args), args.search_resource_id, published,
                                        args.tenant_id)
            print(f"Index-scoped readers on the published generation: "
                  f"{', '.join(carried) or 'none'}", file=sys.stderr)
            found = readers.parse(found + carried)
    except (OSError, ValueError, RuntimeError) as error:
        raise Blocked("INVALID_INPUT", f"readers: {error}") from error
    return found


def _check_grant_permission(args, spec, desired):
    """Block the plan up front rather than fail after an expensive apply."""
    if not spec.readers or not spec.target.search_resource_id or args.command not in (
            "plan", "apply"):
        return desired
    from dataclasses import replace
    from . import readers
    if readers.can_grant(_arm(args), spec.target.search_resource_id, spec.tenant_id):
        return desired
    return replace(desired, blocked_by=(*desired.blocked_by, (
        "READER_GRANT_DENIED: the signed-in identity cannot write role assignments on the "
        "Search service, so it cannot grant the readers. Next: build as an identity with "
        "Role Based Access Control Administrator (or Owner) on the service, or drop --reader "
        "and grant the reader role yourself after the build.")))


_LIVE = ("inspect", "apply", "verify", "reconcile", "publish", "progress", "attribution",
         "trial-report", "failures", "accept-failures", "retry-failures")
# With the attach flags and one deferred descriptor, these read the attached build in place.
_ATTACHED_READS = ("failures", "accept-failures", "retry-failures", "progress")


def _publish(args, spec, executor) -> dict:
    from .update import updated_in_place
    when = updated_in_place(spec)
    if when:
        return {"status": "current",
                "summary": f"Already published: this generation was updated in place on {when}, "
                           "so its descriptor is current. Nothing to do."}
    published = publish(spec, executor).to_dict()
    from . import grounding_report
    covered = (getattr(executor, "last_verified", None) or {}).get("grounding_coverage")
    from .browse import write_descriptor
    try:
        result = write_descriptor(published, args.output, args.descriptor, spec.tenant_id,
                                  set_current=not args.keep_current)
    except ValueError as error:
        raise Blocked("USAGE", str(error)) from error
    if args.descriptor:
        proposal = _propose_cleanup(args, spec, published)
        result["cleanup_proposal"] = proposal
        result["next_step"] = proposal["next_step"]
    return grounding_report.attach(result, covered)


def _build_changes(spec, desired) -> list[str]:
    documents = len(spec.source_manifest.items) if spec.source_manifest else None
    count = f"{documents} document(s)" if documents is not None else "the documents"
    direct_blob = uses_direct_blob_source(spec)
    source = (f"Read {count} in place from {spec.source.container}/{spec.source.prefix} "
              "(nothing is copied). " if direct_blob and spec.source else "")
    text = {
        "stage-corpus": f"Upload {count} to storage container {spec.storage_container}",
        "create-managed-knowledge-source": (
            f"{source}Make them searchable: Azure AI Search splits them into passages and "
            "adds embeddings now, and finds entities later, once there is an ontology"
            if spec.ontology_mode is OntologyMode.DEFERRED else
            f"{source}Build the knowledge graph: Azure AI Search splits the documents into "
            "passages, adds embeddings and finds entities and relationships with your chat model"),
        "create-managed-knowledge-base": (
            "Create the Knowledge Base agents use to ask questions over it"),
        "grant-readers": f"Let {len(spec.readers)} reader(s) search the index",
    }
    return [text.get(op.id, f"{op.action} {op.resource} {op.name}")
            for op in desired.operations if op.requires_approval]


def _resource_group(resource_id: str | None) -> str | None:
    parts = str(resource_id or "").split("/")
    lowered = [part.lower() for part in parts]
    return (parts[lowered.index("resourcegroups") + 1]
            if "resourcegroups" in lowered[:-1] else None)


def _build_time_and_cost(spec, desired) -> tuple[str, str]:
    """Plain time and cost: embeddings from the document sizes, plus extraction when planned."""
    from ekg_core import approval
    estimates = desired.estimates or {}
    extraction = estimates.get("extraction") or {}
    embedding = estimates.get("embedding") or {}
    deferred = spec.ontology_mode is OntologyMode.DEFERRED
    embed_wall = embedding.get("wall_minutes")
    embed_cost = embedding.get("embedding_cost_usd")
    measured = extraction.get("wall_minutes")
    wall = extraction.get("minimum_wall_seconds")
    if deferred:
        span = (embed_wall["low"], embed_wall["high"]) if embed_wall else None
    elif measured:
        span = (measured["low"] + 3, measured["high"] + 10)
    elif wall is not None:
        span = (wall / 60 + 3, wall / 60 * 1.5 + 10)
    else:
        span = None
    time = (approval.time_text(*span) if span else
            "unknown (no list of documents yet)" if spec.source_manifest is None else
            "unknown")
    if span and not deferred and (extraction.get("indexer_runs") or 1) > 1:
        time += f", across about {extraction['indexer_runs']} indexer runs"
    parts = [] if deferred else [extraction.get("extraction_cost_usd")]
    parts.append(embed_cost)
    known = [part for part in parts if part]
    one_time = ((sum(p["low"] for p in known), sum(p["high"] for p in known))
                if known and len(known) == len(parts) else None)
    what = "embeddings" if deferred else "embeddings and entity extraction"
    serverless = spec.search_sku == "serverless"
    cost = approval.cost_text(one_time, daily=None if serverless else 0.0,
                              unknown_reason="model price not listed")
    cost = cost.replace(" one-time", f" one-time ({what})", 1)
    if serverless:
        cost = cost.replace("ongoing: unknown", "Search Serverless also bills for what it uses")
    return time, cost


def _build_details(spec, desired) -> list[str]:
    """Everything the short build card leaves out; shown when the user asks."""
    from ekg_core.pricing import SERVERLESS_USAGE_COST
    details = []
    if spec.uses_system_identity:
        details.append("Identity: Search system-assigned identity for Storage and Azure "
                       "OpenAI/Foundry model access.")
    elif spec.search_identity_resource_id:
        details.append(f"Identity: Search user-assigned identity ({spec.search_identity_resource_id}).")
    storage_ref = ((spec.source.resource_id if uses_direct_blob_source(spec) and spec.source else None)
                   or spec.target.storage_resource_id or spec.target.storage_endpoint)
    openai_ref = (spec.target.openai_resource_id or spec.target.effective_chat_openai_resource_id
                  or spec.target.effective_chat_openai_endpoint)
    details.append(
        f"Resources: Search {spec.target.search_resource_id or spec.target.search_endpoint} "
        f"(region {spec.target.location or 'unknown'}, SKU {spec.search_sku or 'unknown'}); "
        f"Storage {storage_ref}; Foundry/OpenAI {openai_ref}.")
    if spec.embedding_deployment or spec.chat_deployment:
        line = (f"Deployments: embedding={spec.embedding_deployment} ({spec.embedding_model}), "
                f"chat={spec.chat_deployment} ({spec.chat_model})")
        if spec.kb_chat_deployment:
            line += f", kb={spec.kb_chat_deployment} ({spec.effective_kb_chat_model})"
        details.append(line + ".")
    details.append("Enrichment cache: stores a copy of the extracted content in Blob and "
                   "Table storage and adds storage cost.")
    embedding = (desired.estimates or {}).get("embedding") or {}
    if embedding.get("chunks"):
        chunks = embedding["chunks"]
        details.append(f"Estimate basis: about {chunks['low']}-{chunks['high']} passages, from "
                       f"{embedding['basis']}.")
    if spec.search_sku == "serverless":
        details.append(SERVERLESS_USAGE_COST)
    return details


def _build_card(spec, desired) -> str | None:
    from .executor import staging_prefix
    from ekg_core import approval
    changes = _build_changes(spec, desired)
    if desired.blocked_by or not changes:
        return None
    time, cost = _build_time_and_cost(spec, desired)
    direct_blob = uses_direct_blob_source(spec)
    search_group = _resource_group(spec.target.search_resource_id)
    groups = list(dict.fromkeys(group for group in (
        search_group,
        _resource_group(spec.source.resource_id if direct_blob and spec.source else
                        spec.target.storage_resource_id),
        _resource_group(spec.target.openai_resource_id
                        or spec.target.effective_chat_openai_resource_id)) if group))
    parts = str(spec.target.search_resource_id or "").split("/")
    subscription = parts[2] if len(parts) > 2 and parts[1].lower() == "subscriptions" else None
    names = approval.azure_context(
        spec.tenant_id, subscription,
        None if search_group else approval.search_service_name(spec.target.search_endpoint))
    what = (f"run a trial build on {spec.trial.size} of {spec.trial.corpus_documents} documents"
            if spec.trial is not None else "build the knowledge graph")
    notes = [grounding.plan_card_line(desired.grounding)] if desired.grounding else []
    if spec.source_description:
        notes.append(f"Description agents see: \"{spec.source_description}\"")
    if direct_blob and spec.source is not None:
        notes.append(f"Source: your documents stay in {spec.source.reference}/"
                     f"{spec.source.container}/{spec.source.prefix}; no documents will be copied.")
    elif spec.target.storage_endpoint:
        notes.append(f"Source: your documents will be copied to {spec.target.storage_endpoint}/"
                     f"{spec.storage_container}/{staging_prefix(spec)}/.")
    return approval.card(
        what=what, changes=changes, time=time, cost=cost, tenant_id=spec.tenant_id,
        tenant_name=names.get("tenant_name"),
        subscription=names.get("subscription") or subscription,
        resource_group=", ".join(groups) or names.get("resource_group"), notes=notes)


def _handle_result(args, spec, desired):
    if args.command in ("plan-update", "update"):
        return _handle_update(args, spec)
    if args.command in ("plan-attach-ontology", "attach-ontology"):
        return _handle_attach(args, spec)
    if args.command == "plan":
        result = desired.to_dict()
        card = _build_card(spec, desired)
        if card:
            result["approval_card"] = card
            result["details"] = _build_details(spec, desired)
        return result
    if args.command in ("descriptor", "preflight"):
        return (preflight(spec).to_dict() if args.command == "preflight" else
                descriptor(spec).to_dict())
    if desired.blocked_by and args.command in _LIVE:
        raise Blocked("BUILD_BLOCKED", desired.blocked_by[0],
                      result={"plan_id": desired.plan_id, "blocked_by": list(desired.blocked_by)})
    storage_ep = args.storage_endpoint or (
        spec.source.reference if uses_direct_blob_source(spec) and spec.source else None
    )
    if not args.search_endpoint or not storage_ep:
        raise Blocked("USAGE", "live commands require --search-endpoint and --storage-endpoint")
    adapter = AzureDataPlane(search_endpoint=args.search_endpoint,
                             storage_endpoint=storage_ep,
                             openai_endpoint=spec.target.effective_embedding_openai_endpoint or args.openai_endpoint,
                             embedding_deployment=args.embedding_deployment,
                             search_api_version=search_api_version(spec))
    from .target_reader import AzureTargetReader
    from .blob_sources import AzureBlobReader
    executor = BuildExecutor(
        adapter, target_reader=AzureTargetReader(tenant_id=spec.tenant_id),
        blob_reader=(AzureBlobReader(tenant_id=spec.tenant_id)
                     if spec.source.kind is SourceKind.BLOB_PREFIX else None),
    )
    executor.upload_concurrency = getattr(args, "upload_concurrency", 16)
    if args.command == "inspect":
        return executor.inspect(spec)
    if args.command == "verify":
        return executor.verify(spec)
    if args.command == "reconcile":
        return executor.reconcile(spec)
    if args.command == "progress":
        return executor.progress(spec)
    if args.command in ("failures", "accept-failures", "retry-failures"):
        from . import ingestion
        resume = ("`entity-graph-build attach-ontology` again with the same --plan-id"
                  if spec.ontology_attached_to else
                  "`entity-graph-build reconcile` with the same flags")
        if args.command == "failures":
            return ingestion.failures(executor, spec, resume=resume)
        if args.command == "retry-failures":
            return ingestion.retry_failures(executor, spec, args.retry_id, resume=resume)
        return ingestion.accept_failures(executor, spec, args.acceptance_id, resume=resume)
    if args.command == "attribution":
        from .attribution import collect
        from .executor import index_names as managed_names
        return collect(adapter, managed_names(spec)["knowledge_source"],
                       openai_resource_id=spec.target.openai_resource_id,
                       search_resource_id=spec.target.search_resource_id,
                       tenant_id=spec.tenant_id,
                       embedding_openai_resource_id=spec.target.effective_embedding_openai_resource_id,
                       chat_openai_resource_id=spec.target.effective_chat_openai_resource_id)
    if args.command == "publish":
        return _publish(args, spec, executor)
    if args.command == "trial-report":
        from . import trial
        return trial.collect(executor, spec)
    if args.confirm_writes and args.wait:
        from dataclasses import replace as _replace
        from ekg_core.cli import announce
        from .estimates import plan_estimates
        announce(_build_time_and_cost(spec, _replace(desired, estimates=plan_estimates(spec)))[0])
    applied = executor.apply(spec, approved_plan_id=args.plan_id or "",
                             approved=args.confirm_writes, wait_for_sync=args.wait)
    result = {"plan_id": desired.plan_id, "completed": applied.completed,
              "events": [asdict(e) for e in applied.events]}
    if not applied.completed:
        if any(event.status == "failed" and (
                event.message == "PARTIAL_INGESTION" or
                str(event.message).startswith("PartialIngestion:"))
               for event in applied.events):
            raise Blocked("INGESTION_PARTIAL", "some documents did not ingest; the build is "
                          "paused until the user investigates or accepts them", result=result)
        raise Blocked("APPLY_INCOMPLETE", "the build did not complete", result=result)
    from . import grounding_report
    return grounding_report.attach(result, grounding_report.for_build(adapter, spec))


def _source(args):
    if not args.source_kind or not args.source_reference:
        raise Blocked("USAGE", "--source-kind and --source-reference are required")
    try:
        return SourceLocator(
            kind=SourceKind(args.source_kind), reference=args.source_reference,
            resource_id=args.source_resource_id, container=args.source_container,
            prefix=args.source_prefix, library_id=args.source_library_id,
        )
    except ValueError as error:
        raise Blocked("USAGE", str(error)) from error


def _manifest(args, source):
    if not args.source_manifest:
        if args.sample is not None:
            raise Blocked("USAGE", "--sample needs --source-manifest (run `entity-graph-build "
                          "inventory` first)")
        return None, None
    try:
        raw = json.loads(Path(args.source_manifest).read_text(encoding="utf-8"))
        payload = raw.get("manifest", raw)
        manifest = SourceManifest(
            version=payload["version"], source=source,
            observed_at=payload["observed_at"],
            items=tuple(manifest_item_from_json(item) for item in payload["items"]),
            transform_config_id=payload.get("transform_config_id", "identity"),
        )
        if raw.get("digest", manifest.digest) != manifest.digest:
            raise ValueError("source manifest digest differs from its contents")
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        raise Blocked("INVALID_INPUT", f"invalid source manifest: {error}") from error
    if args.sample is None:
        return manifest, None
    from .trial import sample_manifest
    try:
        return sample_manifest(manifest, args.sample)
    except ValueError as error:
        raise Blocked("USAGE", str(error)) from error


def _spec(args, source, manifest, trial=None) -> BuildSpec:
    return BuildSpec(
        target=Target(subscription_id=args.subscription_id,
                      resource_group=args.resource_group,
                      location=args.location,
                      search_endpoint=args.search_endpoint,
                      storage_endpoint=args.storage_endpoint,
                      openai_endpoint=args.openai_endpoint,
                      content_understanding_endpoint=args.content_understanding_endpoint,
                      search_resource_id=args.search_resource_id,
                      storage_resource_id=args.storage_resource_id,
                      openai_resource_id=args.openai_resource_id,
                      cache_storage_resource_id=getattr(args, "cache_storage_resource_id", None),
                      embedding_openai_endpoint=getattr(args, "embedding_openai_endpoint", None),
                      embedding_openai_resource_id=getattr(args, "embedding_openai_resource_id", None),
                      chat_openai_endpoint=getattr(args, "chat_openai_endpoint", None),
                      chat_openai_resource_id=getattr(args, "chat_openai_resource_id", None),
                      kb_openai_endpoint=getattr(args, "kb_openai_endpoint", None),
                      kb_openai_resource_id=getattr(args, "kb_openai_resource_id", None)),
        ontology_mode=OntologyMode(args.ontology),
        ontology_path=args.ontology_path,
        embedding_deployment=args.embedding_deployment,
        embedding_model=args.embedding_model,
        embedding_dimensions=args.embedding_dimensions,
        chat_deployment=args.chat_deployment,
        chat_model=args.chat_model,
        search_identity_resource_id=(
            "system" if getattr(args, "use_system_identity", False)
            else args.search_identity_resource_id
        ),
        tenant_id=args.tenant_id,
        extraction_parallelism=args.extraction_parallelism,
        ingestion_interval=args.ingestion_interval,
        grounding_index=args.grounding_index,
        search_sku=args.search_sku,
        build_journal=args.build_journal,
        storage_container=args.storage_container,
        source=source,
        source_manifest=manifest,
        requested_outcome=(RequestedOutcome(args.requested_outcome)
                           if args.requested_outcome else None),
        knowledge_source_kind=(KnowledgeSourceKind(args.knowledge_source_kind)
                               if args.knowledge_source_kind else None),
        readers=_readers(args),
        trial=trial,
        kb_chat_deployment=getattr(args, "kb_chat_deployment", None),
        kb_chat_model=getattr(args, "kb_chat_model", None),
        source_description=(getattr(args, "source_description", None) or "").strip() or None,
    )


def _rebind_journal_defaults(spec: BuildSpec, journal_gen: str, *,
                             attach_capable: bool) -> BuildSpec:
    """Restore the defaults `plan` bound into the journaled build (for example
    extraction_parallelism) when the command line omits them.

    The journal records either the build itself or, for an ontology attach, the deferred
    build it completes; attach-capable commands match either view, others only the build.
    """
    from dataclasses import replace
    from .attach import deferred_spec
    from .executor import generation
    from .target_validation import new_build_spec
    views = [lambda value: value, *([deferred_spec] if attach_capable else [])]

    def matches(candidate: BuildSpec) -> bool:
        return any(generation(view(candidate)) == journal_gen for view in views)

    if matches(spec):
        return spec
    base = replace(spec, requested_outcome=None, knowledge_source_kind=None)
    for candidate in (new_build_spec(spec), base, new_build_spec(base)):
        if matches(candidate):
            return candidate
    return spec


def _run(args) -> dict:
    if args.command == "fetch-sample":
        from .sample_data import fetch_sample
        return fetch_sample(args.output, dataset=args.dataset, limit=args.limit)
    if args.command == "status":
        return read_build_status(args.build_journal, args.run_id)
    if args.command == "telemetry":
        return _handle_telemetry(args)
    if args.command in ("generations", "plan-retire", "retire"):
        return _handle_generations(args)
    source = _source(args)
    if args.command == "inventory":
        return _handle_inventory(args, source)
    spec = _spec(args, source, *_manifest(args, source))
    if (args.command in ("plan", "preflight", "inspect", "apply")
            and not (spec.build_journal and Path(spec.build_journal).exists())):
        from .target_validation import new_build_spec
        spec = new_build_spec(spec)
    elif spec.build_journal and Path(spec.build_journal).exists():
        try:
            record = json.loads(Path(spec.build_journal).read_text(encoding="utf-8"))
            journal_gen = record.get("generation")
            recorded = (record.get("scope") or {}).get("knowledge_source_description")
        except (OSError, ValueError, TypeError, AttributeError):
            journal_gen = recorded = None
        if spec.source_description is None and isinstance(recorded, str) and recorded:
            # Later commands reuse the description the build was approved and created with.
            from dataclasses import replace
            spec = replace(spec, source_description=recorded)
        if journal_gen:
            spec = _rebind_journal_defaults(
                spec, journal_gen,
                attach_capable=(args.command in ("plan-attach-ontology", "attach-ontology")
                                or (args.command in (*_ATTACHED_READS, "verify")
                                    and spec.ontology_mode is not OntologyMode.DEFERRED)))
    if spec.trial is not None and args.command in ("publish", "plan-update", "update",
                                                   "plan-attach-ontology", "attach-ontology"):
        raise Blocked("BUILD_BLOCKED", "TRIAL_NOT_PUBLISHABLE: a trial build is for measurement "
                      "only; run `entity-graph-build trial-report`, then plan the full build without "
                      "--sample")
    if args.command in ("plan-attach-ontology", "attach-ontology"):
        spec = _attach_spec(args, spec)
    elif (args.command in _ATTACHED_READS and len(args.descriptor) == 1
          and spec.ontology_mode is not OntologyMode.DEFERRED):
        spec = _attach_spec(args, spec)
    elif args.command == "verify":
        spec = _attached_verify_spec(args, spec)
    if spec.trial is None and args.command == "trial-report":
        raise Blocked("USAGE", "trial-report reads a trial build: pass the same flags as its "
                      "plan, including --sample")
    desired = _check_grant_permission(args, spec, plan(spec))
    if args.chat_capacity is not None:
        if args.chat_capacity < 1:
            raise Blocked("USAGE", "--chat-capacity is a positive estimate input")
        if desired.estimates:
            from dataclasses import replace
            from .estimates import plan_estimates
            desired = replace(desired, estimates=plan_estimates(
                spec, chat_capacity_k_tpm=args.chat_capacity))
    if getattr(args, "trial_report", None) and desired.estimates:
        from dataclasses import replace
        from .estimates import trial_estimate
        try:
            report = json.loads(Path(args.trial_report).read_text(encoding="utf-8"))
            measured = trial_estimate(spec, report)
        except (OSError, ValueError) as error:
            raise Blocked("USAGE", str(error)) from error
        desired = replace(desired, estimates={**desired.estimates, "extraction": measured})
    if (args.command == "plan"
            and spec.build_journal and Path(spec.build_journal).exists()):
        from dataclasses import replace
        desired = replace(desired, blocked_by=(*desired.blocked_by, (
            f"BUILD_JOURNAL_IN_USE: {spec.build_journal} already records a build attempt. "
            "Reconcile that attempt with the same flags, or pass a new --build-journal path "
            "for another build (for example, the full build after a trial).")))
    if (args.command == "plan" and spec.grounding_index and spec.target.search_endpoint
            and not desired.blocked_by):
        from dataclasses import replace
        from .managed_pipeline import grounding_live_blocker
        found = grounding_live_blocker(
            AzureDataPlane(search_endpoint=spec.target.search_endpoint,
                           search_api_version=search_api_version(spec)), spec)
        if found:
            desired = replace(desired, blocked_by=(*desired.blocked_by, found))
    return _handle_result(args, spec, desired)


def _classify(error: Exception, command: str) -> Blocked:
    from ekg_core.az_identity import IdentityError
    from ekg_core.execution import ApprovalRequired
    from .blob_sources import BlobSourceError
    from .sharepoint_sources import SharePointReadError, SharePointSourceError
    from .executor import BuildError
    from .generations import RetireError
    from .update import UpdateError
    from .attach import AttachError
    text = str(error)
    if isinstance(error, ApprovalRequired):
        return Blocked("APPROVAL_REQUIRED", text, plan_verb=_PLAN_VERB.get(command, "plan"))
    if isinstance(error, IdentityError):
        return Blocked("AZ_SIGNIN", text)
    if isinstance(error, RetireError):
        return Blocked("RETIRE_BLOCKED", text)
    if isinstance(error, UpdateError):
        return Blocked("UPDATE_BLOCKED", text)
    if isinstance(error, AttachError):
        return Blocked("ATTACH_BLOCKED", text)
    from .executor import PartialIngestion
    if isinstance(error, PartialIngestion):
        return Blocked("INGESTION_PARTIAL", text)
    if isinstance(error, BuildError):
        if text == "managed synchronization is incomplete":
            return Blocked("SYNC_IN_PROGRESS", text)
        return Blocked("BUILD_BLOCKED", text)
    if isinstance(error, (SharePointSourceError, SharePointReadError, BlobSourceError)):
        return Blocked("SOURCE_UNAVAILABLE", text)
    if isinstance(error, OSError):
        return Blocked("LOCAL_IO", text)
    if isinstance(error, ValueError):
        return Blocked("INVALID_INPUT", text)
    # An Azure failure part-way through a write leaves an unknown outcome: settle it first.
    return Blocked({"apply": "APPLY_INCOMPLETE", "update": "UPDATE_STOPPED",
                    "retire": "RETIRE_STOPPED", "attach-ontology": "ATTACH_STOPPED",
                    }.get(command, "AZURE_ERROR"), text)


def _say(result, args) -> None:
    if args.command == "telemetry" and not args.json:
        result = _telemetry_summary(result)
    say(result, args, prog=PROG)


def main(argv: list[str] | None = None) -> None:
    argv = list(sys.argv[1:] if argv is None else argv)
    args = parse(_parser(), argv, _DEFAULTS)
    if args.command == "doctor":
        from ekg_core import doctor
        doctor.run(PROG, args)
        return
    try:
        result = _run(args)
    except Blocked as blocked:
        report(blocked, prog=PROG, command=args.command)
    except (RuntimeError, ValueError, OSError) as error:
        report(_classify(error, args.command), prog=PROG, command=args.command, cause=error)
    _say(result, args)
