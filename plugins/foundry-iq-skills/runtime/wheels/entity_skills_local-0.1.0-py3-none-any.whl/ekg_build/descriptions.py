"""Wording the build sends to Search for every Knowledge Base.

Pending review by Mike Kim (Foundry IQ knowledge retrieval); edit it only here. Knowledge
Source descriptions are not generated: the skill agent drafts one per corpus
(`--source-description`).
"""

KNOWLEDGE_BASE_RETRIEVAL_INSTRUCTIONS = (
    "Use *_graph_search tools for structured questions about entities, their properties, and "
    "relationships, including finding entities that meet specific criteria or tracing "
    "connections. Use relevance-based search tools to find information by topic, meaning, or "
    "wording, including supporting passages and broader context. Combine both approaches when "
    "entity and relationship findings benefit from contextual evidence. Express graph requests "
    "as natural-language questions describing the entities, relationships, and criteria sought."
)

KNOWLEDGE_BASE_ANSWER_INSTRUCTIONS = (
    "Answer only from the retrieved graph rows and passages. Prefer graph rows for entities, "
    "properties, and relationships, and use passages for supporting context. Cite every claim "
    "with its [ref_id:N]. Do not add facts that the retrieved results do not state. If nothing "
    "relevant was retrieved, say that retrieval returned no matching results for the question; "
    "do not claim the information is absent from the corpus."
)
