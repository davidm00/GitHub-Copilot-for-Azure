from ekg_core.models import BuildSpec

from .executor import (BuildError, PARTIAL_NEXT_ACTION, PartialIngestion, _sync_checkpoint,
                       _sync_status, index_names)

def _indexer_failure(executor, name: str) -> str | None:
        """The generated indexer's last run, when it failed outright (e.g. identity errors)."""
        from .ingestion import _text
        from .managed_pipeline import generated
        adapter = executor.adapter
        if not callable(getattr(adapter, "indexer_status", None)):
            return None
        try:
            live = adapter.get_knowledge_source(name)
            indexer = generated(live, require_graph=False)["indexer"] if isinstance(live, dict) else None
        except (ValueError, KeyError, TypeError):
            return None
        if not indexer:
            return None
        run = (adapter.indexer_status(indexer) or {}).get("lastResult") or {}
        if str(run.get("status") or "").lower() not in ("error", "transientfailure"):
            return None
        message = _text(run.get("errorMessage")) or "the indexer run failed without a message"
        return f"Indexer {indexer} failed: {message}"


def progress(executor, spec: BuildSpec) -> dict:
        """Read live managed synchronization progress; performs no writes."""
        from .ingestion import accepted_failed
        name = index_names(spec)["knowledge_source"]
        status = executor.adapter.knowledge_source_status(name)
        current = status.get("currentSynchronizationState") or {}
        last = status.get("lastSynchronizationState") or {}
        error = None
        partial = False
        try:
            finished = _sync_status(status, accepted_failed(spec)) is not None
        except PartialIngestion as failure:
            finished, error, partial = False, str(failure), True
        except BuildError as failure:
            finished, error = False, str(failure)
        checkpoint = _sync_checkpoint(status)
        indexer_failed = None if (finished or error or checkpoint) else _indexer_failure(executor, name)
        error = error or indexer_failed
        state = current if current else last
        status_name = "partial" if partial else "failed" if error else "synchronized" if finished else (
            "continuing" if checkpoint else "synchronizing")
        return {
            "phase": "build.progress", "knowledge_source": name,
            "status": status_name,
            "items_processed": state.get("itemsUpdatesProcessed"),
            "items_failed": state.get("itemsUpdatesFailed"),
            "document_count": spec.source_manifest.document_count if spec.source_manifest else None,
            "started_at": state.get("startTime"), "finished_at": last.get("endTime"),
            "error": error, "evidence_origin": "live_knowledge_source_status",
            "next_action": (
                PARTIAL_NEXT_ACTION if partial else
                "Reconcile this exact attempt read-only before publish." if finished else
                ("The indexer could not start. For a managed-identity error, check the Search "
                 "identity and its roles (`entity-graph-provision connect`), then run the indexer "
                 "once; do not re-run plan or apply." if indexer_failed else
                 "Do not retry writes; run `entity-graph-build failures` and reconcile read-only.")
                if error else
                "Indexer reached the normal 120-minute checkpoint; the next scheduled run continues it." if checkpoint else
                "Synchronization is still running; check again later or reconcile when finished."
            ),
        }
