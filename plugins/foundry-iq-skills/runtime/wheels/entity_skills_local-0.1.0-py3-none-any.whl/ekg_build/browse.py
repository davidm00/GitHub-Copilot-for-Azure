"""Write a published descriptor and explain harness-independent consumption."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ekg_core.descriptors import (
    default_descriptor_path, descriptor_name, write_current,
)
from ekg_core.files import atomic_write_text

AUTH = "Microsoft Entra ID through the signed-in Azure CLI (az login); no keys"


def write_descriptor(descriptor: dict[str, Any], out: str | None, previous: list[str],
                     tenant_id: str | None, *, set_current: bool = True) -> dict[str, Any]:
    path = (Path(out).expanduser().resolve() if out
            else default_descriptor_path(descriptor_name(descriptor)))
    if any(path == Path(item).expanduser().resolve() for item in previous):
        raise ValueError("--output must be a new file, not the previous --descriptor, "
                         "which publish reads to propose cleanup")
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(path, json.dumps(descriptor, indent=2) + "\n")
    if set_current:
        write_current(path)
    prompt = ("Using the entity-graph-consume CLI or graph Apps, answer \"<your question>\" from the graph "
              "and cite the source file for every hop.")
    command = ('python -I "<package-root>\\runtime\\bootstrap.py" run entity entity-graph-consume '
               'capabilities --descriptor "<descriptor-path>"')
    browse = {"descriptor_path": str(path),
              "search_endpoint": descriptor.get("endpoints", {}).get("search"),
              "auth": AUTH, "tenant_id": tenant_id, "current": set_current,
              "commands": [command], "example_prompt": prompt}
    default_line = ("  then just ask; entity-graph-consume and the graph Apps use this descriptor by default."
                    if set_current else
                    f"  the current pointer is unchanged; name this descriptor in the prompt "
                    f"(descriptor_path {path}) or pass --descriptor to entity-graph-consume.")
    summary = "\n".join([
        f"Published descriptor: {path}",
        f"Search endpoint: {browse['search_endpoint']}",
        f"Auth: {AUTH}; tenant {tenant_id or '<the tenant you built in>'}",
        "Browse from your chosen harness or the explicit CLI; no harness registry query is required.",
        "Replace <package-root> with your installed/extracted package and <descriptor-path> with the path above:",
        *(f"  {line}" for line in browse["commands"]),
        default_line,
        f"  for example: {prompt}",
    ])
    return {**descriptor, "status": "published", "descriptor_path": str(path),
            "browse": browse, "summary": summary}
