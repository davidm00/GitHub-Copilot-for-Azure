"""Offline route decisions and read-only, exact-resource preflight."""

from __future__ import annotations

import re
from typing import Any, Protocol

from ekg_core.models import (
    CACHE_USES_SYSTEM_ASSIGNED_IDENTITY, BuildSpec, Event, KnowledgeSourceKind,
    PreflightResult, RequestedOutcome, RouteDecision, SourceKind,
)

from .managed_pipeline import (
    search_api_version, uses_content_understanding, uses_direct_blob_source,
)
from .target_validation import graph_input_error, search_resource_id
from .target_reader import canonical_resource_endpoint


class ResourceReader(Protocol):
    def inspect_search_service(self, resource_id: str, tenant_id: str) -> dict[str, Any]: ...
    def inspect_resource(self, resource_id: str, tenant_id: str) -> dict[str, Any]: ...


_ARM_ID = re.compile(
    r"/subscriptions/([0-9a-fA-F-]{36})/resourceGroups/([^/]+)/"
    r"providers/(Microsoft\.[^/]+)/([^/]+)/([^/]+)", re.IGNORECASE,
)
_GUID = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")
SOFT_DELETE_DOC = ("https://learn.microsoft.com/en-us/azure/storage/blobs/"
                   "soft-delete-blob-enable?tabs=azure-portal")
STORAGE_ARM_API_VERSION = "2024-01-01"


def blob_soft_delete(arm: Any, spec: BuildSpec) -> tuple[str, str | None] | None:
    """Read-only check of the Blob source's soft delete; None when it does not apply.

    The managed data source detects deleted blobs only through soft delete, so a blob
    removed from the source prefix outside `update` otherwise stays in the indexes.
    """
    source = spec.source
    if (arm is None or not hasattr(arm, "arm_read") or not uses_direct_blob_source(spec)
            or source is None or not spec.tenant_id):
        return None
    parsed = _identity(source.resource_id, "Microsoft.Storage", "storageAccounts")
    if parsed is None:
        return None
    subscription, group, account = parsed
    enable = (f"az storage account blob-service-properties update --account-name {account} "
              f"--resource-group {group} --subscription {subscription} "
              "--enable-delete-retention true --delete-retention-days 7")
    try:
        observed = arm.arm_read(f"{source.resource_id}/blobServices/default",
                                STORAGE_ARM_API_VERSION, tenant_id=spec.tenant_id)
        policy = observed["properties"].get("deleteRetentionPolicy") or {}
    except Exception:  # denied, missing or malformed: report unknown, never fail
        return ("unknown",
                f"BLOB_SOFT_DELETE_UNKNOWN: could not read blob soft delete on storage account "
                f"{account}. Documents deleted from the source prefix are removed from the index "
                f"only when soft delete is on; check it, or turn it on with: {enable} "
                f"(see {SOFT_DELETE_DOC}).")
    if policy.get("enabled") is True:
        return ("enabled", None)
    return ("disabled",
            f"BLOB_SOFT_DELETE_OFF: blob soft delete is off on storage account {account}, so "
            "documents deleted from the source prefix stay in the index. Turn it on before any "
            f"deletions occur: {enable} (see {SOFT_DELETE_DOC}).")


def _identity(resource_id: str | None, provider: str, resource_type: str) -> tuple[str, str, str] | None:
    match = _ARM_ID.fullmatch(resource_id or "")
    if not match or not _GUID.fullmatch(match[1]) or (
        match[3].casefold(), match[4].casefold()
    ) != (provider.casefold(), resource_type.casefold()):
        return None
    return match[1], match[2], match[5]


def route(spec: BuildSpec) -> RouteDecision:
    outcome = spec.requested_outcome or RequestedOutcome.GRAPH_BUILD
    sharepoint = spec.source is not None and spec.source.kind is SourceKind.SHAREPOINT_LIBRARY
    kind = spec.knowledge_source_kind or (
        KnowledgeSourceKind.SHAREPOINT if sharepoint else KnowledgeSourceKind.AZURE_BLOB
    )
    if kind is not KnowledgeSourceKind.AZURE_BLOB or sharepoint:
        return RouteDecision(outcome, kind, "unsupported",
                             blocked_by=("UNSUPPORTED_GRAPH_ROUTE: graphExtraction is verified only on Azure Blob KS; no automatic source copy",))
    if spec.source is None:
        return RouteDecision(outcome, kind, "unsupported",
                             blocked_by=("SOURCE_REQUIRED: pass --source-kind and --source-reference, "
                                         "then inventory the source",))
    if spec.source_manifest is None:
        return RouteDecision(outcome, kind, "unsupported",
                             blocked_by=("SOURCE_MANIFEST_REQUIRED: run `entity-graph-build inventory` "
                                         "and pass its manifest as --source-manifest",))
    return RouteDecision(
        outcome, kind, "verified_path",
        evidence=(f"Search {search_api_version(spec)} Azure Blob graphExtraction via approved staging",),
    )


def target_blockers(spec: BuildSpec) -> tuple[str, ...]:
    target = spec.target
    errors: list[str] = []
    if target.search_resource_id is not None:
        try:
            expected_search = search_resource_id(spec)
        except ValueError:
            expected_search = None
        if (not isinstance(target.search_resource_id, str) or not expected_search
                or target.search_resource_id.casefold() != expected_search.casefold()):
            errors.append("TARGET_ID_MISMATCH: Search ARM ID differs from exact subscription, RG or endpoint")
    for label, resource_id, provider, kind, endpoint, suffix in (
        ("Storage", target.storage_resource_id, "Microsoft.Storage", "storageAccounts",
         target.storage_endpoint, "blob.core.windows.net"),
        ("OpenAI", target.openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.openai_endpoint, None),
        ("Embedding OpenAI", target.embedding_openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.effective_embedding_openai_endpoint, None),
        ("Chat OpenAI", target.chat_openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.effective_chat_openai_endpoint, None),
        ("KB OpenAI", target.kb_openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.effective_kb_openai_endpoint, None),
    ):
        if resource_id is None:
            continue
        parsed = _identity(resource_id, provider, kind)
        if parsed is None:
            errors.append(f"TARGET_ID_MISMATCH: {label} ARM ID is invalid")
        elif label == "Storage" and endpoint != f"https://{parsed[2]}.{suffix}":
            errors.append("TARGET_ENDPOINT_MISMATCH: Storage endpoint differs from exact account ARM ID")
        elif label != "Storage" and (
            not isinstance(endpoint, str) or not endpoint.startswith("https://")
        ):
            errors.append(f"TARGET_ENDPOINT_MISMATCH: {label} endpoint is required with its ARM ID")
    if target.cache_storage_resource_id is not None:
        if _identity(target.cache_storage_resource_id, "Microsoft.Storage", "storageAccounts") is None:
            errors.append("TARGET_ID_MISMATCH: Cache Storage ARM ID is invalid")
    if spec.source and spec.source.kind is SourceKind.BLOB_PREFIX:
        parsed = _identity(spec.source.resource_id, "Microsoft.Storage", "storageAccounts")
        if parsed is None or spec.source.reference != f"https://{parsed[2]}.blob.core.windows.net":
            errors.append("SOURCE_ID_MISMATCH: Blob source endpoint differs from exact account ARM ID")
    return tuple(errors)


def scope(spec: BuildSpec, decision: RouteDecision | None) -> dict[str, Any]:
    from .executor import staging_prefix

    try:
        derived_search_id = search_resource_id(spec)
    except ValueError:
        derived_search_id = None
    direct_blob = uses_direct_blob_source(spec)
    storage_res_id = spec.target.storage_resource_id or (
        spec.source.resource_id if direct_blob and spec.source else None
    )
    storage_ep = spec.target.storage_endpoint or (
        spec.source.reference if direct_blob and spec.source else ""
    )
    storage_container = (
        spec.source.container if direct_blob and spec.source else spec.storage_container
    )
    prefix = (
        spec.source.prefix if direct_blob and spec.source else staging_prefix(spec)
    ) if (spec.source_manifest and spec.source) else None
    extra_openai: dict[str, Any] = {}
    for key in (
        "embedding_openai_resource_id", "embedding_openai_endpoint",
        "chat_openai_resource_id", "chat_openai_endpoint",
        "kb_openai_resource_id", "kb_openai_endpoint",
    ):
        val = getattr(spec.target, key, None)
        if val is not None:
            extra_openai[key] = val
    for spec_key in ("kb_chat_deployment", "kb_chat_model"):
        val = getattr(spec, spec_key, None)
        if val is not None:
            extra_openai[spec_key] = val
    return {
        "source_kind": spec.source.kind.value if spec.source else None,
        "source_id": spec.source.source_id if spec.source else None,
        "source_resource_id": spec.source.resource_id if spec.source else None,
        "manifest_digest": spec.source_manifest.digest if spec.source_manifest else None,
        "document_count": spec.source_manifest.document_count if spec.source_manifest else None,
        "requested_outcome": decision.outcome.value if decision else None,
        "knowledge_source_kind": decision.knowledge_source_kind.value if decision else None,
        "tenant_id": spec.tenant_id,
        "subscription_id": spec.target.subscription_id,
        "search_resource_id": spec.target.search_resource_id or derived_search_id,
        "storage_resource_id": storage_res_id,
        "openai_resource_id": spec.target.openai_resource_id,
        **({"cache_storage_resource_id": spec.target.cache_storage_resource_id}
           if spec.target.cache_storage_resource_id else {}),
        **extra_openai,
        **({
            "storage_container": storage_container,
            "staging_prefix": prefix,
            "search_endpoint": spec.target.search_endpoint,
            "storage_endpoint": storage_ep,
            "openai_endpoint": spec.target.openai_endpoint,
            **({"content_extraction": "content_understanding",
                "content_understanding_endpoint": spec.target.content_understanding_endpoint}
               if uses_content_understanding(spec) else {}),
        } if spec.source_manifest and spec.source else {}),
    }


def _observed_mismatch(blockers: list[str]) -> bool:
    return any(item.startswith((
        "TARGET_ID_MISMATCH:", "TARGET_ENDPOINT_MISMATCH:",
        "TARGET_SKU_MISMATCH:", "TARGET_REGION_MISMATCH:", "TARGET_NOT_READY:",
        "TENANT_MISMATCH:", "PERMISSION_DENIED:", "TARGET_INSPECTION_FAILED:",
    )) for item in blockers)


def preflight(spec: BuildSpec, reader: ResourceReader | None = None,
              arm: Any = None) -> PreflightResult:
    """`arm` (an adapter with tenant-checked `arm_read`) adds the advisory soft delete check."""
    from .planner import plan

    desired = plan(spec)
    decision = desired.route or route(spec)
    blockers = list(desired.blocked_by)
    unsupported = decision.capability == "unsupported"
    # A missing manifest is a readiness gap, not an unsupported route: still inspect targets read-only.
    awaiting_manifest = unsupported and bool(decision.blocked_by) and all(
        reason.startswith("SOURCE_MANIFEST_REQUIRED:") for reason in decision.blocked_by
    )
    route_closed = unsupported and not awaiting_manifest
    if unsupported:
        blockers.extend(reason for reason in (
            decision.blocked_by or ("UNSUPPORTED_ROUTE: no implemented route",)
        ) if reason not in blockers)
    evidence: dict[str, Any] = {
        "origin": "offline_contract",
        "capability": decision.capability,
    }
    uncertainties = list(decision.uncertainty)
    warnings: list[str] = []
    can_inspect = (
        reader is not None and not graph_input_error(spec) and not target_blockers(spec)
        and not route_closed
    )
    if can_inspect:
        expected = spec.target.search_resource_id or search_resource_id(spec)
        observed = reader.inspect_search_service(expected, spec.tenant_id)
        search_observed = observed
        evidence["origin"] = "injected_resource_observations"
        if not isinstance(observed, dict):
            blockers.append("TARGET_INSPECTION_FAILED: Search inspection did not return resource metadata")
        else:
            properties = observed.get("properties")
            sku = observed.get("sku")
            if (str(observed.get("id", "")).casefold() != expected.casefold()
                    or str(observed.get("name", "")).casefold() != expected.rsplit("/", 1)[-1].casefold()
                    or not isinstance(properties, dict)
                    or properties.get("endpoint") != spec.target.search_endpoint):
                blockers.append("TARGET_ID_MISMATCH: observed Search ARM identity or endpoint differs")
            elif not isinstance(sku, dict) or str(sku.get("name", "")).casefold() != str(spec.search_sku or "").casefold():
                blockers.append("TARGET_SKU_MISMATCH: observed Search SKU differs")
            elif str(observed.get("location", "")).replace(" ", "").casefold() != str(spec.target.location or "").casefold():
                blockers.append("TARGET_REGION_MISMATCH: observed Search region differs")
            elif str(properties.get("provisioningState", "")).casefold() != "succeeded":
                blockers.append("TARGET_NOT_READY: Search provisioning is not complete")
            if (observed.get("tenant_id") and
                    str(observed["tenant_id"]).casefold() != spec.tenant_id.casefold()
                    or spec.source_manifest and not observed.get("tenant_id")):
                blockers.append("TENANT_MISMATCH: observed tenant differs from requested tenant")
            if observed.get("permissions") == "denied":
                blockers.append("PERMISSION_DENIED: caller lacks required Search access")
            evidence["search_arm_observed"] = not _observed_mismatch(blockers)
            if not observed.get("tenant_id"):
                uncertainties.append("TENANT_UNVERIFIED: Search ARM resource does not attest tenant membership")
        direct_blob = uses_direct_blob_source(spec)
        storage_res_id = spec.target.storage_resource_id or (
            spec.source.resource_id if direct_blob and spec.source else None
        )
        storage_ep = spec.target.storage_endpoint or (
            spec.source.reference if direct_blob and spec.source else ""
        )
        resource_checks: list[tuple[str, str | None, str]] = [
            ("Storage", storage_res_id, storage_ep),
            ("OpenAI", spec.target.openai_resource_id, spec.target.openai_endpoint),
        ]
        for res_id, ep in (
            (spec.target.embedding_openai_resource_id, spec.target.effective_embedding_openai_endpoint),
            (spec.target.chat_openai_resource_id, spec.target.effective_chat_openai_endpoint),
            (spec.target.kb_openai_resource_id, spec.target.effective_kb_openai_endpoint),
        ):
            if res_id and ("OpenAI", res_id, ep) not in resource_checks:
                resource_checks.append(("OpenAI", res_id, ep))
        for label, resource_id, endpoint in resource_checks:
            if not resource_id or _observed_mismatch(blockers):
                continue
            if not hasattr(reader, "inspect_resource"):
                uncertainties.append(f"{label.upper()}_UNVERIFIED: no read-only resource reader is available")
                continue
            observed = reader.inspect_resource(resource_id, spec.tenant_id)
            if (not isinstance(observed, dict)
                    or str(observed.get("id", "")).casefold() != resource_id.casefold()
                    or not isinstance(observed.get("endpoint"), str)
                    or canonical_resource_endpoint(observed["endpoint"]) !=
                    canonical_resource_endpoint(endpoint)):
                blockers.append(f"TARGET_ID_MISMATCH: observed {label} ARM identity or endpoint differs")
            elif (observed.get("tenant_id") and
                  str(observed["tenant_id"]).casefold() != spec.tenant_id.casefold()
                  or spec.source_manifest and not observed.get("tenant_id")):
                blockers.append(f"TENANT_MISMATCH: observed {label} tenant differs")
            elif observed.get("permissions") == "denied":
                blockers.append(f"PERMISSION_DENIED: caller lacks required {label} access")
            elif label == "Storage" and not spec.target.cache_storage_resource_id and (
                observed.get("kind") and observed.get("kind") != "StorageV2"
            ):
                blockers.append("CACHE_STORAGE_KIND_INVALID: enrichment cache requires a StorageV2 (general-purpose v2) storage account")
            else:
                evidence[f"{label.lower()}_arm_observed"] = True
        cache_id = spec.target.cache_storage_resource_id or storage_res_id
        if (
            spec.target.cache_storage_resource_id
            and not _observed_mismatch(blockers)
            and hasattr(reader, "inspect_resource")
        ):
            cache_obs = reader.inspect_resource(
                spec.target.cache_storage_resource_id, spec.tenant_id
            )
            if (
                not isinstance(cache_obs, dict)
                or str(cache_obs.get("id", "")).casefold()
                != spec.target.cache_storage_resource_id.casefold()
            ):
                blockers.append("TARGET_ID_MISMATCH: observed Cache Storage ARM identity differs")
            elif cache_obs.get("kind") and cache_obs.get("kind") != "StorageV2":
                blockers.append(
                    "CACHE_STORAGE_KIND_INVALID: enrichment cache requires a StorageV2 "
                    "(general-purpose v2) storage account"
                )
            else:
                evidence["cache_storage_arm_observed"] = True
        if cache_id and not _observed_mismatch(blockers) and hasattr(reader, "inspect_cache_roles"):
            search_sys_pid = (
                ((search_observed.get("identity") or {}).get("principalId"))
                if isinstance(search_observed, dict) else None
            )
            cache_principal = (
                search_sys_pid if CACHE_USES_SYSTEM_ASSIGNED_IDENTITY
                else spec.search_identity_resource_id
            )
            who_label = (
                "Search system-assigned identity"
                if CACHE_USES_SYSTEM_ASSIGNED_IDENTITY
                else "Search identity"
            )
            if CACHE_USES_SYSTEM_ASSIGNED_IDENTITY and not cache_principal:
                blockers.append(
                    "CACHE_ROLES_MISSING: Search service has no system-assigned managed "
                    "identity for the enrichment cache; run entity-graph-provision connect"
                )
            else:
                missing_roles = reader.inspect_cache_roles(
                    cache_id, cache_principal, spec.tenant_id
                )
                if missing_roles:
                    blockers.append(
                        f"CACHE_ROLES_MISSING: {who_label} lacks {', '.join(missing_roles)} "
                        "on the cache storage account; run entity-graph-provision connect to grant them"
                    )
                else:
                    evidence["cache_roles_observed"] = True
        soft_delete = blob_soft_delete(arm, spec) if not _observed_mismatch(blockers) else None
        if soft_delete is not None:
            evidence["blob_soft_delete"] = soft_delete[0]
            if soft_delete[1]:
                warnings.append(soft_delete[1])
    elif not route_closed:
        uncertainties.append("TARGET_UNVERIFIED: no read-only resource observations were supplied")
    if not route_closed:
        uncertainties.append("PERMISSIONS_UNVERIFIED: ARM identity alone does not prove data-plane RBAC or network access")
    if spec.source is not None:
        uncertainties.append(
            "SOURCE_APPROVAL_RECHECK_REQUIRED: source bytes must be rechecked before staging"
            if spec.source_manifest else
            "SOURCE_NOT_INVENTORIED: provide an adapter-produced manifest for this route"
        )
    priority = next((item for item in blockers if item.startswith((
        "TARGET_ID_MISMATCH:", "TARGET_ENDPOINT_MISMATCH:",
        "TARGET_SKU_MISMATCH:", "TARGET_REGION_MISMATCH:", "TARGET_NOT_READY:",
        "TENANT_MISMATCH:", "PERMISSION_DENIED:", "SOURCE_ID_MISMATCH:",
    ))), None)
    if priority is None and unsupported:
        priority = decision.blocked_by[0] if decision.blocked_by else "UNSUPPORTED_ROUTE: no implemented route"
    if priority is None and blockers:
        priority = blockers[0]
    code = priority.split(":", 1)[0] if priority else "BUILD_PLAN_REQUIRES_APPROVAL"
    next_action = (
        "Inventory the source with its read-only adapter, attach its manifest, then request "
        "separate approval of the exact staged Azure Blob graph plan."
        if code == "SOURCE_MANIFEST_REQUIRED" else
        "Correct the exact source, target or route and rerun read-only preflight."
        if blockers else
        "Review the exact plan and remaining target/permission evidence; request separate approval before writes."
    )
    event = Event("preflight", "blocked" if blockers else "planned", code, {
        "plan_id": desired.plan_id, "blockers": blockers,
        "uncertainty": uncertainties, "evidence": evidence,
        **({"warnings": warnings} if warnings else {}),
    })
    return PreflightResult(desired.plan_id, "blocked" if blockers else "unverified", code, next_action,
                           decision, desired.scope or scope(spec, decision), (event,))
