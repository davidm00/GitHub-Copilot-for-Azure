"""Attach an ontology to a published deferred-ontology build, in place.

A deferred build's Knowledge Source already chunks, vectorizes and caches the corpus
with `graphExtraction.ontology = null`. Attaching replaces that definition, at the
reviewed ETag, with the same body plus the inline JSON-LD ontology; Search then
extracts triples from the cached chunks (no re-crawl, re-chunk or re-embed). The
generation, Knowledge Source, staging prefix and index names stay those of the
deferred build; the graph index and the Knowledge Base are new.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from ekg_core.descriptors import descriptor_file
from ekg_core.execution import ApprovalRequired
from ekg_core.models import BuildSpec, Ontology, OntologyMode, stable_id
from ekg_core.ontology import load_ontology
from ekg_core.telemetry import TelemetryRecorder
from ekg_core.validation import validate_deployment_descriptor
from .adapters import SearchRequestError
from .executor import (_indexer_time_quota_checkpoint, _source_record, failed_items, generation,
                       hash_json, index_names, staging_prefix)
from .generations import _generation_of
from .ingestion import accepted_failed
from .managed_pipeline import (generated, inline_ontology_matches, knowledge_base,
                               knowledge_source, search_api_version)
from .update import (INDEXER_DELAY_SECONDS, INDEXER_POLLS, _await_indexer, _bound,
                     _journal_path, _last_run, _save)

REPLAN = "run `entity-graph-build plan-attach-ontology` again"
ATTACH_PARTIAL = (
    "Run `entity-graph-build failures` with the same flags, show the user the failed documents "
    "and errors, then ask them to choose: (A) investigate and fix the failures (rerunning "
    "attach-ontology without accepting retries the indexer), or (B) accept exactly those "
    "documents with `entity-graph-build accept-failures --acceptance-id <id>`, then rerun "
    "attach-ontology with the same plan ID to continue. Never stop without offering both.")
_PLAN_ID = re.compile(r"attach-plan-[0-9a-f]{16}")
_FAILED = {"failed", "failure", "error", "partialsuccess", "transientfailure",
           "persistentfailure", "cancelled", "canceled"}


class AttachError(RuntimeError):
    pass


def _deferred_published(descriptor_path: str) -> tuple[dict[str, Any], str]:
    try:
        descriptor = json.loads(descriptor_file(descriptor_path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as error:
        raise AttachError(f"descriptor is not readable JSON: {descriptor_path}") from error
    endpoints = descriptor.get("endpoints") or {}
    found = _generation_of(str(endpoints.get("knowledge_source") or ""))
    if (found is None or (descriptor.get("ontology") or {}).get("mode") != "deferred"
            or not endpoints.get("content_index") or endpoints.get("graph_index")
            or endpoints.get("knowledge_base")):
        raise AttachError("the descriptor is not a published deferred-ontology build; "
                          "attach-ontology needs the descriptor `entity-graph-build publish` wrote "
                          "for an `--ontology deferred` build")
    return descriptor, found


def descriptor_generation(descriptor_path: str) -> str:
    """The generation a deferred descriptor serves, for binding the attach spec."""
    return _deferred_published(descriptor_path)[1]


def deferred_spec(spec: BuildSpec) -> BuildSpec:
    """The BuildSpec the deferred build was applied with."""
    return replace(spec, ontology_mode=OntologyMode.DEFERRED, ontology_path=None,
                   schema_org_profile=None, schema_org_version=None, resolve_imports=False,
                   ontology_attached_to=None)


def _ontology(spec: BuildSpec) -> Ontology | None:
    return load_ontology(spec.ontology_mode, path=spec.ontology_path,
                         schema_org_profile=spec.schema_org_profile,
                         schema_org_version=spec.schema_org_version,
                         resolve_imports=spec.resolve_imports)


def _request(spec: BuildSpec, ontology: Ontology) -> dict[str, Any]:
    name = index_names(spec)["knowledge_source"]
    return knowledge_source(spec, name=name, graph_name=name, prefix=staging_prefix(spec),
                            ontology=ontology)


def _without_ontology(definition: dict[str, Any]) -> dict[str, Any]:
    blob = definition.get("azureBlobParameters") or {}
    graph = blob.get("graphExtraction") or {}
    return {**definition, "azureBlobParameters": {
        **blob, "graphExtraction": {**graph, "ontology": None}}}


def _drift(live: dict[str, Any], expected: dict[str, Any]) -> list[str]:
    """Differences apart from the ontology; the connection string may read back redacted."""
    want, have = _bound(_without_ontology(expected)), _bound(_without_ontology(live))
    problems = [f"the Knowledge Source {part} changed since the deferred build"
                for part in want if have[part] != want[part]]
    blob, expected_blob = live.get("azureBlobParameters") or {}, expected["azureBlobParameters"]
    connection = blob.get("connectionString")
    if connection != expected_blob["connectionString"] and not (
            isinstance(connection, str) and connection.casefold() == "<redacted>"):
        problems.append("the Knowledge Source staging connection changed since the deferred build")
    cache = (blob.get("ingestionParameters") or {}).get("cache") or {}
    stored = cache.get("storageConnectionString")
    # Search leaves the cache connection string out of GET responses (it's a secret), so
    # enableReprocessing is the live evidence that the cache is configured.
    if cache.get("enableReprocessing") is not True or (
            isinstance(stored, str) and not stored.strip()):
        problems.append("the Knowledge Source has no reprocessing enrichment cache, so "
                        "attaching would require a full rerun to seed the cache; rebuild "
                        "with `entity-graph-build plan` and `entity-graph-build apply` instead")
    if ((blob.get("graphExtraction") or {}).get("graphName")
            != expected_blob["graphExtraction"]["graphName"]):
        problems.append("the Knowledge Source graph name changed since the deferred build")
    return problems


def _source_journal_blocker(spec: BuildSpec, deferred: BuildSpec) -> str | None:
    try:
        record = json.loads(Path(spec.build_journal or "").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "the deferred build's --build-journal is missing or unreadable"
    expected = _source_record(deferred, "verified")
    if not isinstance(record, dict) or record.get("state") != "verified" or any(
            record.get(key) != expected[key] for key in (
                "version", "run_id", "plan_id", "scope", "generation", "knowledge_source",
                "create_request_hash")):
        return ("the --build-journal does not record this verified deferred build; pass the "
                "same flags and journal as its apply")
    return None


def _end_time(status: dict[str, Any]) -> str | None:
    return ((status or {}).get("lastSynchronizationState") or {}).get("endTime")


def _parsed(value: str | None) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")) if value else None
    except ValueError:
        return None


def _advanced(end: str | None, prior: str | None) -> bool:
    if not end:
        return False
    if not prior:
        return True
    new, old = _parsed(end), _parsed(prior)
    return new > old if new and old else end != prior


def _triples(status: dict[str, Any]) -> int:
    # Read where the November preview reports it; older shapes nest it per run.
    last = status.get("lastSynchronizationState") or {}
    stats = status.get("graphStatistics") or last.get("graphStatistics") or {}
    value = stats.get("triplesWritten") if isinstance(stats, dict) else None
    return value if isinstance(value, int) else 0


def attach_plan(dp: Any, spec: BuildSpec, descriptor_path: str) -> dict[str, Any]:
    """Read-only: what attaching this ontology to the deferred build would write."""
    descriptor, gen = _deferred_published(descriptor_path)
    endpoints = descriptor["endpoints"]
    name = endpoints["knowledge_source"]
    blockers: list[str] = []
    ontology = None
    if spec.ontology_mode is OntologyMode.DEFERRED:
        blockers.append("attach-ontology needs an ontology: pass --ontology owl_file "
                        "--ontology-path <file>, or --ontology schema_org")
    else:
        try:
            ontology = _ontology(spec)
        except (OSError, ValueError) as error:
            blockers.append(f"the ontology is not usable: {error}")
        if ontology is not None and ontology.inline_jsonld is None:
            blockers.append("the ontology has no inline JSON-LD form")
            ontology = None
    deferred = deferred_spec(spec)
    if spec.ontology_attached_to != gen:
        blockers.append(f"the spec is not bound to the descriptor's generation {gen}")
    elif spec.source_manifest is None or not spec.build_journal:
        blockers.append("attach-ontology needs the deferred build's --source-manifest and "
                        "--build-journal")
    elif generation(deferred) != gen:
        blockers.append("the build flags differ from the deferred build (its generation is "
                        f"{gen}); pass exactly the flags of its apply, with only --ontology "
                        "and --ontology-path changed")
    elif blocker := _source_journal_blocker(spec, deferred):
        blockers.append(blocker)
    if ((spec.target.search_endpoint or "").rstrip("/").lower()
            != str(endpoints.get("search") or "").rstrip("/").lower()):
        blockers.append("the Search endpoint differs from the deferred build's descriptor")
    if endpoints.get("search_api_version") != search_api_version(spec):
        blockers.append(f"the deferred build was published for Search "
                        f"{endpoints.get('search_api_version')}, not {search_api_version(spec)}")
    live = None if blockers else dp.get_knowledge_source(name)
    already = False
    request: dict[str, Any] = {}
    etag = None
    if not blockers and live is None:
        blockers.append(f"the deferred Knowledge Source {name} no longer exists; rebuild")
    elif not blockers:
        request = _request(spec, ontology)
        blockers.extend(_drift(live, request))
        current = ((live.get("azureBlobParameters") or {}).get("graphExtraction") or {}).get(
            "ontology")
        if current is not None:
            if inline_ontology_matches(current, ontology):
                already = True
            else:
                blockers.append("the Knowledge Source already has a different ontology; the "
                                "service cannot remove or swap it in place, so build a new "
                                "generation instead")
        etag = live.get("@odata.etag")
        if not isinstance(etag, str) or not etag.strip():
            blockers.append("the Knowledge Source read back no ETag, so a safe replace is "
                            "impossible")
        try:
            generated(live, require_graph=False)
        except ValueError as error:
            blockers.append(f"the deferred Knowledge Source is incomplete: {error}")
        if not blockers and not already:
            status = dp.knowledge_source_status(name) or {}
            if status.get("currentSynchronizationState"):
                blockers.append("the Knowledge Source is synchronizing now; " + REPLAN
                                + " after it finishes")
    names = index_names(spec)
    kb = names.get("knowledge_base")
    indexer = f"{name}-indexer"
    operations = [
        {"id": "put-knowledge-source", "action": "replace", "resource": "knowledge_source",
         "name": name, "if_match": etag,
         "change": "graphExtraction.ontology: null -> inline JSON-LD",
         **({"skipped": "the ontology is already attached"} if already else {})},
        {"id": "run-indexer", "action": "run", "resource": "indexer", "name": indexer},
        {"id": "await-extraction", "action": "poll", "resource": "knowledge_source_status",
         "name": name},
        {"id": "verify-graph", "action": "verify", "resource": "graph_index",
         "name": f"{name}-graph-index"},
        *([{"id": "create-knowledge-base", "action": "create", "resource": "knowledge_base",
            "name": kb}] if kb else []),
        {"id": "rewrite-descriptor", "action": "write", "resource": "descriptor",
         "name": str(descriptor_file(descriptor_path))},
    ]
    warnings = [
        f"Triple extraction runs over every chunk with the chat deployment "
        f"{spec.chat_deployment}; the enrichment cache only avoids re-cracking, re-chunking "
        "and re-embedding.",
        "Once attached, the ontology cannot be removed (Search returns HTTP 400); a "
        "different ontology needs a new build.",
    ]
    if spec.readers:
        warnings.append("Readers granted on the deferred build cover only its content index; "
                        f"grant Search Index Data Reader on {name}-graph-index after attach.")
    identity = {
        "search_endpoint": str(endpoints.get("search") or "").rstrip("/").lower(),
        "generation": gen, "descriptor": hash_json(descriptor),
        "ontology_schema_id": ontology.schema_id if ontology else None,
        "ontology_jsonld": hash_json(ontology.inline_jsonld) if ontology else None,
        "request": hash_json(request) if request else None,
        "etag": etag, "knowledge_base": kb,
    }
    plan_id = stable_id("attach-plan", identity)
    edge_types = len(ontology.edge_types) if ontology else 0
    return {
        "plan_id": plan_id,
        "summary": (f"Attach ontology {ontology.schema_id} ({edge_types} relationship "
                    f"type(s)) to deferred generation {gen}, extract its graph from the "
                    f"cached chunks{', and create Knowledge Base ' + kb if kb else ''}."
                    if not blockers else f"Blocked: {blockers[0]}"),
        "next_step": (f"Resolve the blocker, then {REPLAN}." if blockers else
                      "After approval, run `entity-graph-build attach-ontology` with the same flags "
                      f"plus --plan-id {plan_id} --confirm-writes."),
        "generation": gen, "knowledge_source": name, "knowledge_base": kb,
        "ontology": ({"mode": ontology.source_kind, "schema_id": ontology.schema_id,
                      "edge_type_count": edge_types} if ontology else None),
        "edge_type_count": edge_types,
        "already_attached": already,
        "operations": operations, "blockers": blockers, "blocked_by": list(blockers),
        "warnings": warnings,
        "request_hash": identity["request"], "etag": etag,
        "write": {"requires_approval": True, "knowledge_source_replace": 0 if already else 1,
                  "indexer_runs": 1, "knowledge_bases": 1 if kb else 0,
                  "local": "the descriptor is rewritten with the graph index and ontology"},
        "undo": "an attached ontology cannot be removed; retire the generation and rebuild",
    }


def _resume(dp: Any, spec: BuildSpec, descriptor_path: str, path: Path,
            plan_id: str) -> dict[str, Any]:
    if path.is_file():
        return json.loads(path.read_text(encoding="utf-8"))
    review = attach_plan(dp, spec, descriptor_path)
    if plan_id != review["plan_id"]:
        raise ApprovalRequired(
            f"explicit approval of attach plan {review['plan_id']} is required; the "
            "ontology, the build flags or the live Knowledge Source changed since review")
    if review["blockers"]:
        raise AttachError(review["blockers"][0])
    name = review["knowledge_source"]
    record = {"plan": review, "state": "requested", "telemetry": [],
              "attach_request_hash": review["request_hash"],
              "pre_attach_end_time": _end_time(dp.knowledge_source_status(name) or {}),
              "prior_start": _last_run(dp, f"{name}-indexer").get("startTime")}
    _save(path, record)
    return record


def attach(dp: Any, spec: BuildSpec, descriptor_path: str, *, plan_id: str,
           confirm_writes: bool,
           sleep: Callable[[float], None] = time.sleep) -> dict[str, Any]:
    """Apply an approved attach plan; every step is journaled so a rerun resumes."""
    if not confirm_writes:
        raise ApprovalRequired("attach-ontology writes require explicit confirmation "
                               "(--confirm-writes)")
    if not isinstance(plan_id, str) or not _PLAN_ID.fullmatch(plan_id):
        raise ApprovalRequired("attach-ontology needs the approved --plan-id from "
                               "`entity-graph-build plan-attach-ontology`")
    if not spec.build_journal:
        raise AttachError("attach-ontology needs --build-journal; its folder holds the "
                          "attach journal")
    path = _journal_path(spec, plan_id)
    record = _resume(dp, spec, descriptor_path, path, plan_id)
    review = record["plan"]
    if review.get("generation") != spec.ontology_attached_to:
        raise AttachError("this attach journal belongs to another generation")
    name, kb = review["knowledge_source"], review.get("knowledge_base")
    indexer = f"{name}-indexer"
    recorder = TelemetryRecorder("build")

    def advance(state: str, **extra: Any) -> None:
        record.update(state=state, **extra)
        record["telemetry"] = record["telemetry"] + recorder.events
        recorder.events.clear()
        _save(path, record)

    def result(status: str, message: str, next_step: str) -> dict[str, Any]:
        return {"status": status, "summary": message, "next_step": next_step,
                "plan_id": plan_id, "journal": str(path), "state": record["state"],
                "generation": review["generation"], "knowledge_source": name,
                "knowledge_base": kb, "telemetry": record["telemetry"]}

    if record["state"] == "stale":
        return result("stale", "The Knowledge Source changed after review (HTTP 412), so "
                               "nothing was written.", f"Re-read it: {REPLAN}.")
    ontology = None
    if record["state"] not in ("published", "inconsistent"):
        ontology = _ontology(spec)
        if (ontology is None or ontology.schema_id != (review.get("ontology") or {}).get(
                "schema_id")):
            raise AttachError(f"the ontology differs from the approved plan; {REPLAN}")
    if record["state"] == "requested":
        live = dp.get_knowledge_source(name) or {}
        current = ((live.get("azureBlobParameters") or {}).get("graphExtraction") or {}).get(
            "ontology")
        if current is not None and inline_ontology_matches(current, ontology):
            advance("put", put_receipt={"name": name, "kind": live.get("kind"),
                                        "etag": live.get("@odata.etag")}, put_skipped=True)
        else:
            body = _request(spec, ontology)
            if hash_json(body) != record["attach_request_hash"]:
                raise AttachError(f"the Knowledge Source request differs from the approved "
                                  f"plan; {REPLAN}")
            pre = _end_time(dp.knowledge_source_status(name) or {})
            prior = _last_run(dp, indexer).get("startTime")
            try:
                with recorder.span("attach-put-knowledge-source", resource="knowledge_source"):
                    receipt = dp.put_knowledge_source(body, if_match=review["etag"])
            except SearchRequestError as error:
                info = {"service_error": error.service_error} if error.service_error else {}
                if error.status == 412:
                    advance("stale")
                    return {**result("stale", "The Knowledge Source changed after review "
                                              "(HTTP 412 stale ETag), so nothing was written.",
                                     f"Re-read it: {REPLAN} and approve the new plan."), **info}
                if error.status == 409:
                    return {**result("waiting", "A rebuild is already pending on this Knowledge "
                                                "Source (HTTP 409).",
                                     "Rerun attach-ontology with the same plan ID in a few "
                                     "minutes."), **info}
                raise
            advance("put", put_receipt=receipt, pre_attach_end_time=pre, prior_start=prior)
    if record["state"] == "put":
        partial = record.get("partial")
        if isinstance(partial, dict) and 0 < partial.get("failed", 0) <= accepted_failed(spec):
            # The user accepted exactly these failed documents; resume without a rerun.
            if partial.get("state") == "indexing":
                advance("indexing", prior_start=partial.get("prior_start"), partial=None)
            else:
                advance("extracting", partial=None)
    if record["state"] == "put":
        if hasattr(dp, "set_skillset_reasoning_effort"):
            dp.set_skillset_reasoning_effort(f"{name}-skillset")
        try:
            with recorder.span("attach-indexer-run", resource="indexer"):
                dp.run_indexer(indexer)
        except SearchRequestError as error:
            # The replace itself may have started the run already.
            if error.status != 409:
                raise
        advance("indexing")
    if record["state"] == "indexing":
        with recorder.span("attach-indexer-wait", resource="indexer") as span:
            run = _await_indexer(dp, indexer, record.get("prior_start"), sleep)
            span["counts"]["documents"] = (run or {}).get("itemsProcessed") or 0
        if run is None:
            advance("indexing")
            return result("waiting", "The indexer is still extracting the graph.",
                          "Rerun attach-ontology with the same plan ID to continue.")
        if _indexer_time_quota_checkpoint(run):
            advance("indexing")
            return result("waiting", "The indexer reached the normal 120-minute checkpoint.",
                          "Wait for the next scheduled continuation, then rerun "
                          "attach-ontology with the same plan ID.")
        failed = run.get("itemsFailed") or len(run.get("errors") or ())
        if failed and failed > accepted_failed(spec):
            advance("put", prior_start=run.get("startTime"),
                    partial={"state": "indexing", "prior_start": record.get("prior_start"),
                             "failed": failed})
            return result("partial", f"{failed} document(s) failed while extracting the graph, "
                                     "so attach is paused, not finished.", ATTACH_PARTIAL)
        if run.get("status") == "transientFailure" and not failed:
            # Search asks for a retry ("Graph synchronization has pending cached documents and
            # must be retried"); rerunning attach runs the indexer again from the journal.
            advance("put", prior_start=run.get("startTime"))
            message = str(run.get("errorMessage") or "").strip()
            return result("waiting", "The indexer stopped with a transient failure"
                                     + (f" ({message})" if message else "") + ".",
                          "Rerun attach-ontology with the same plan ID to run the indexer "
                          "again; it resumes from the journal.")
        if run.get("status") != "success" and not failed:
            advance("put", prior_start=run.get("startTime"))
            return result("stopped", "The indexer reported a failure while extracting the graph.",
                          "Fix the cause, then rerun attach-ontology with the same plan ID.")
        advance("extracting")
    if record["state"] == "extracting":
        status: dict[str, Any] = {}
        done = False
        with recorder.span("attach-extraction-wait", resource="knowledge_source"):
            for attempt in range(INDEXER_POLLS):
                status = dp.knowledge_source_status(name) or {}
                last = status.get("lastSynchronizationState") or {}
                if (not status.get("currentSynchronizationState")
                        and _advanced(last.get("endTime"), record.get("pre_attach_end_time"))
                        and not _indexer_time_quota_checkpoint(last)):
                    done = True
                    break
                if attempt + 1 < INDEXER_POLLS:
                    sleep(INDEXER_DELAY_SECONDS)
        if not done:
            advance("extracting")
            return result("waiting", "The Knowledge Source is still synchronizing.",
                          "Rerun attach-ontology with the same plan ID to continue.")
        last = status.get("lastSynchronizationState") or {}
        failed = failed_items(last)
        terminal = str(last.get("status") or last.get("synchronizationStatus") or "").lower()
        if failed and failed > accepted_failed(spec):
            advance("put", partial={"state": "extracting", "failed": failed})
            return result("partial", f"Synchronization reported {failed} failed document(s) "
                                     "while extracting the graph, so attach is paused, not "
                                     "finished.", ATTACH_PARTIAL)
        if not failed and terminal in _FAILED:
            advance("put")
            return result("stopped", "Synchronization failed while extracting the graph.",
                          "Fix the cause, then rerun attach-ontology with the same plan ID.")
        triples = _triples(status)
        if triples <= 0:
            advance("put")
            return result("stopped", "Synchronization finished but wrote no graph triples.",
                          "Check that the ontology's classes and relationships occur in the "
                          "corpus, then rerun attach-ontology with the same plan ID.")
        advance("extracted", triples_written=triples)
    if record["state"] == "extracted":
        with recorder.span("attach-verify-graph", resource="search_index"):
            problems: list[str] = []
            live = dp.get_knowledge_source(name) or {}
            current = ((live.get("azureBlobParameters") or {}).get("graphExtraction") or {}).get(
                "ontology")
            if not inline_ontology_matches(current, ontology):
                problems.append("the live Knowledge Source ontology differs from the plan")
            try:
                resources = generated(live, require_graph=True)
            except ValueError as error:
                resources = {}
                problems.append(f"the service reported no graph index: {error}")
            count = 0
            if resources:
                graph = dp.get_index(resources["graphIndex"]) or {}
                if (graph.get("graphProfile") or {}).get("kind") != "edgeList":
                    problems.append("the graph index lacks an edge-list graph profile")
                count = dp.count(resources["graphIndex"]) if graph else 0
                if count <= 0:
                    problems.append("the graph index is empty")
            etag = live.get("@odata.etag")
            if not isinstance(etag, str) or not etag.strip():
                problems.append("the Knowledge Source read back no ETag")
        if problems:
            advance("inconsistent", problems=problems)
        else:
            advance("verified", created_resources=resources, graph_count=count,
                    verified_receipt={"name": name, "kind": live.get("kind"), "etag": etag})
    if record["state"] == "verified":
        if kb:
            existing = dp.get_knowledge_base(kb)
            expected = knowledge_base(spec, name=kb, knowledge_source_name=name)
            if existing is None:
                with recorder.span("attach-create-knowledge-base", resource="knowledge_base"):
                    dp.create_knowledge_base(expected)
            elif (
                [{k: v for k, v in item.items() if v is not None} if isinstance(item, dict) else item
                 for item in existing.get("knowledgeSources")]
                if isinstance(existing.get("knowledgeSources"), list) else None
            ) != expected["knowledgeSources"]:
                advance("inconsistent", problems=[
                    f"Knowledge Base {kb} already exists with a different Knowledge Source"])
        if record["state"] == "verified":
            advance("kb_created")
    if record["state"] == "inconsistent":
        return result("inconsistent", "The attached graph did not verify ("
                      + "; ".join(record.get("problems") or ()) + ").",
                      "Investigate with `entity-graph-build progress`, or retire the generation and "
                      "rebuild with `entity-graph-build plan` and `entity-graph-build apply`.")
    if record["state"] == "kb_created":
        _publish(descriptor_path, spec, ontology, record)
        advance("published",
                published_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
    return result("attached", f"Attached ontology {review['ontology']['schema_id']} to "
                              f"generation {review['generation']}; the graph index "
                              f"{record['created_resources']['graphIndex']} holds "
                              f"{record.get('graph_count')} graph fact(s)"
                              + (f" and Knowledge Base {kb} is ready." if kb else "."),
                  "The descriptor now serves the graph; run `entity-graph-build verify` with the same "
                  "flags and --descriptor to re-check it read-only.")


def _publish(descriptor_path: str, spec: BuildSpec, ontology: Ontology,
             record: dict[str, Any]) -> None:
    target = descriptor_file(descriptor_path)
    current = json.loads(target.read_text(encoding="utf-8"))
    if (current.get("ontology") or {}).get("mode") != "deferred":
        raise AttachError("the descriptor changed during attach; it no longer describes the "
                          "deferred build")
    kb = record["plan"].get("knowledge_base")
    endpoints = {**current["endpoints"],
                 "graph_index": record["created_resources"]["graphIndex"],
                 "search_api_version": search_api_version(spec),
                 **({"knowledge_base": kb} if kb else {})}
    updated = {
        **current,
        "ontology": {"mode": ontology.source_kind, "schema_id": ontology.schema_id,
                     "source_reference": ontology.source_reference,
                     "edge_types": [list(edge) for edge in ontology.edge_types]},
        "capabilities": {**current.get("capabilities", {}),
                         "graph_retrieval": bool(ontology.edge_types),
                         "agentic_retrieval": bool(kb)},
        "endpoints": endpoints,
    }
    errors = validate_deployment_descriptor(updated)
    if errors:
        raise AttachError("the attached descriptor is invalid: " + "; ".join(errors))
    _save(target, updated)


def attached_record(spec: BuildSpec) -> dict[str, Any] | None:
    """The published attach journal for this attached spec's generation, if any."""
    if spec.ontology_attached_to is None or not spec.build_journal:
        return None
    found = []
    for path in sorted(Path(spec.build_journal).parent.glob("attach-plan-*.json")):
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if (isinstance(record, dict) and record.get("state") == "published"
                and (record.get("plan") or {}).get("generation") == spec.ontology_attached_to):
            found.append(record)
    return found[0] if len(found) == 1 else None
