from __future__ import annotations

import json
from urllib.parse import urlparse

from ekg_core import grounding
from ekg_core.models import (
    CACHE_USES_SYSTEM_ASSIGNED_IDENTITY, BuildSpec, Ontology, OntologyMode, SourceKind,
)
from ekg_core.ontology import load_ontology

from .descriptions import KNOWLEDGE_BASE_ANSWER_INSTRUCTIONS, KNOWLEDGE_BASE_RETRIEVAL_INSTRUCTIONS
from .document_types import needs_content_understanding
# The Ignite API: graph extraction lives on azureBlobParameters, the ontology is inline
# JSON-LD only, and the enrichment cache lets an ontology attach without re-crawling.
SEARCH_API_VERSION = "2026-11-01-preview"


def search_api_version(spec: BuildSpec) -> str:
    return SEARCH_API_VERSION


def uses_inline_jsonld(spec: BuildSpec) -> bool:
    """Every ontology the build sends to Search is an inline JSON-LD document."""
    return spec.ontology_mode is not OntologyMode.DEFERRED


def ontology_deferred(spec: BuildSpec) -> bool:
    """Graph extraction is configured and cached, but waits for `attach-ontology`."""
    return spec.ontology_mode is OntologyMode.DEFERRED


def uses_content_understanding(spec: BuildSpec) -> bool:
    """Text-only corpora stay on minimal extraction; any other document type needs CU."""
    return spec.source_manifest is not None and needs_content_understanding(
        item.media_type for item in spec.source_manifest.items)


def content_understanding_error(spec: BuildSpec) -> str | None:
    if not uses_content_understanding(spec):
        return None
    endpoint = spec.target.content_understanding_endpoint
    host = (urlparse(endpoint).hostname or "") if endpoint else ""
    if not endpoint or not endpoint.startswith("https://") or not host.endswith(
            ".services.ai.azure.com"):
        return ("CONTENT_UNDERSTANDING_REQUIRED: PDFs, Office files or images need Content "
                "Understanding; pass --content-understanding-endpoint "
                "https://<name>.services.ai.azure.com (provision it with "
                "--content-understanding-name)")
    return None


# Requested page parallelism; generated settings determine effective packing/concurrency.
DEFAULT_EXTRACTION_PARALLELISM = 64


def extraction_settings(spec: BuildSpec) -> dict:
    """The one extraction knob 2026-11-01-preview keeps."""
    return {"pageDegreeOfParallelism":
            spec.extraction_parallelism or DEFAULT_EXTRACTION_PARALLELISM}


def graph_ontology(ontology: Ontology) -> dict:
    if ontology.inline_jsonld is None:
        raise ValueError("graph extraction requires an inline JSON-LD ontology")
    return {"kind": "inline", "value": ontology.inline_jsonld}


def inline_ontology_matches(observed, ontology: Ontology | None) -> bool:
    """Compare a live graphExtraction.ontology with the approved one; None means deferred."""
    if ontology is None:
        return observed is None
    if not isinstance(observed, dict) or observed.get("kind") != "inline":
        return False
    value = observed.get("value")
    if value == ontology.inline_jsonld:
        return True
    try:
        return json.loads(value) == json.loads(ontology.inline_jsonld or "")
    except (TypeError, ValueError):
        return False


def uses_direct_blob_source(spec: BuildSpec) -> bool:
    """Customer blob_prefix sources are referenced directly without staging copies."""
    return spec.source is not None and spec.source.kind is SourceKind.BLOB_PREFIX


def _search_identity_payload(spec: BuildSpec, *, context: str) -> dict | None:
    if not spec.search_identity_resource_id:
        raise ValueError(f"{context} requires a Search user-assigned identity or system-assigned identity")
    if spec.uses_system_identity:
        return None
    return {
        "@odata.type": "#Microsoft.Azure.Search.DataUserAssignedIdentity",
        "userAssignedIdentity": spec.search_identity_resource_id,
    }


def knowledge_source(spec: BuildSpec, *, name: str, graph_name: str, prefix: str,
                     ontology: Ontology | None = None) -> dict:
    target = spec.target
    direct_blob = uses_direct_blob_source(spec)
    if not (target.subscription_id and target.resource_group) and not target.search_resource_id:
        raise ValueError("managed Blob ingestion needs explicit subscription and resource group")
    storage_endpoint = (
        spec.source.reference
        if direct_blob and spec.source is not None and spec.source.reference
        else target.storage_endpoint
    )
    if not storage_endpoint or not storage_endpoint.startswith("https://"):
        raise ValueError("managed Blob ingestion needs an HTTPS Storage endpoint")
    host = urlparse(storage_endpoint).hostname or ""
    if not host.endswith(".blob.core.windows.net"):
        raise ValueError("managed Blob ingestion requires an Azure Storage account endpoint")
    emb_endpoint = target.effective_embedding_openai_endpoint
    chat_endpoint = target.effective_chat_openai_endpoint
    if (not emb_endpoint or not emb_endpoint.startswith("https://")
            or not chat_endpoint or not chat_endpoint.startswith("https://")):
        raise ValueError("managed graph ingestion needs an HTTPS Azure OpenAI endpoint")
    if not all((spec.embedding_deployment, spec.embedding_model, spec.chat_deployment,
                spec.chat_model, spec.embedding_dimensions)):
        raise ValueError("managed graph ingestion needs explicit model names, deployments and dimensions")
    identity = _search_identity_payload(spec, context="managed graph ingestion")
    content_understanding = uses_content_understanding(spec)
    if content_understanding and content_understanding_error(spec):
        raise ValueError(content_understanding_error(spec))

    def model(deployment: str, model_name: str, endpoint: str) -> dict:
        return {"kind": "azureOpenAI",
                "azureOpenAIParameters": {
                    "resourceUri": endpoint.rstrip("/"),
                    "deploymentId": deployment, "modelName": model_name,
                    **({"authIdentity": identity} if identity is not None else {}),
                }}

    storage_name = host.split(".", 1)[0]
    if direct_blob and spec.source is not None:
        storage_id = spec.source.resource_id
        container_name = spec.source.container
        folder_path = spec.source.prefix
        cache_storage_id = target.cache_storage_resource_id or target.storage_resource_id or storage_id
    else:
        storage_id = (
            target.storage_resource_id if spec.source_manifest is not None else
            f"/subscriptions/{target.subscription_id}/resourceGroups/"
            f"{target.resource_group}/providers/Microsoft.Storage/storageAccounts/{storage_name}"
        )
        container_name = spec.storage_container
        folder_path = prefix
        cache_storage_id = target.cache_storage_resource_id or storage_id
    if not storage_id or storage_id.rsplit("/", 1)[-1].casefold() != storage_name.casefold():
        raise ValueError("managed Blob ingestion needs the exact destination Storage ARM ID")
    if ontology_deferred(spec):
        ontology_binding = None
    elif uses_inline_jsonld(spec):
        ontology = ontology or load_ontology(
            spec.ontology_mode, path=spec.ontology_path,
            schema_org_profile=spec.schema_org_profile,
            schema_org_version=spec.schema_org_version,
            resolve_imports=spec.resolve_imports,
        )
        if ontology is None:
            raise ValueError("graph extraction requires its validated local ontology")
        ontology_binding = graph_ontology(ontology)
    else:
        raise ValueError("managed graph ingestion requires an ontology or --ontology deferred")
    connection = f"ResourceId={storage_id}"
    if not cache_storage_id or "/providers/microsoft.storage/storageaccounts/" not in cache_storage_id.casefold():
        raise ValueError("enrichment cache requires an Azure Storage account ARM resource ID")
    cache_connection = f"ResourceId={cache_storage_id}"
    return {
        "name": name, "kind": "azureBlob",
        **({"description": spec.source_description} if spec.source_description else {}),
        "azureBlobParameters": {
            "connectionString": connection,
            "containerName": container_name, "folderPath": folder_path,
            "ingestionParameters": {
                **({"identity": identity} if identity is not None else {}),
                "embeddingModel": model(spec.embedding_deployment, spec.embedding_model, emb_endpoint),
                "chatCompletionModel": model(spec.chat_deployment, spec.chat_model, chat_endpoint),
                "disableImageVerbalization": True,
                "contentExtractionMode": "standard" if content_understanding else "minimal",
                **({"aiServices": {"uri": target.content_understanding_endpoint.rstrip("/")}}
                   if content_understanding else {}),
                # Lets a later ontology (attach or replace) re-extract from cached
                # chunks instead of re-crawling and re-embedding the corpus.
                # Note: 2026-11-01-preview RestRemoteIndexerValidationExecutor fails to
                # deserialize abstract DataIdentity on indexer.cache.identity (HTTP 400);
                # when CACHE_USES_SYSTEM_ASSIGNED_IDENTITY is True, omit cache.identity so
                # ResourceId= uses the Search service's system-assigned managed identity.
                "cache": {
                    "storageConnectionString": cache_connection,
                    "enableReprocessing": True,
                    **({} if (CACHE_USES_SYSTEM_ASSIGNED_IDENTITY or identity is None)
                       else {"identity": identity}),
                },
                **({"ingestionSchedule": {"interval": spec.ingestion_interval}}
                   if spec.ingestion_interval else {}),
            },
            "graphExtraction": {
                "graphName": graph_name, "ontology": ontology_binding,
                **({"grounding": {"kind": "searchIndex",
                                  "index": {"indexName": spec.grounding_index}}}
                   if spec.grounding_index else {}),
                **extraction_settings(spec),
            },
        },
    }


def knowledge_base(spec: BuildSpec, *, name: str, knowledge_source_name: str) -> dict:
    target = spec.target
    kb_endpoint = target.effective_kb_openai_endpoint
    kb_deployment = spec.effective_kb_chat_deployment
    kb_model = spec.effective_kb_chat_model
    if not kb_endpoint or not kb_endpoint.startswith("https://"):
        raise ValueError("managed Knowledge Base needs an HTTPS Azure OpenAI endpoint")
    if not all((kb_deployment, kb_model)):
        raise ValueError("managed Knowledge Base needs explicit chat deployment and model")
    identity = _search_identity_payload(spec, context="managed Knowledge Base")
    return {
        "name": name,
        "knowledgeSources": [{"name": knowledge_source_name}],
        "models": [{
            "kind": "azureOpenAI",
            "azureOpenAIParameters": {
                "resourceUri": kb_endpoint.rstrip("/"),
                "deploymentId": kb_deployment,
                "modelName": kb_model,
                **({"authIdentity": identity} if identity is not None else {}),
            },
        }],
        "outputMode": "answerSynthesis",
        "answerInstructions": KNOWLEDGE_BASE_ANSWER_INSTRUCTIONS,
        "retrievalReasoningEffort": {"kind": "low"},
        "retrievalInstructions": KNOWLEDGE_BASE_RETRIEVAL_INSTRUCTIONS,
    }


def grounding_live_blocker(adapter, spec: BuildSpec) -> str | None:
    """One read-only GET of the grounding index definition; None when it is usable."""
    from .adapters import SearchRequestError
    if not spec.grounding_index:
        return None
    try:
        definition = adapter.get_index(spec.grounding_index)
    except SearchRequestError as error:
        return grounding.classify(spec.grounding_index, None, status=error.status,
                                  service_error=error.service_error)
    return grounding.classify(
        spec.grounding_index, definition,
        profile_returned=getattr(adapter, "search_api_version", SEARCH_API_VERSION)
        == SEARCH_API_VERSION)


def generated(live: dict, *, require_graph: bool = True) -> dict[str, str]:
    """Generated resource names; a deferred-ontology source may not report a graph index yet."""
    blob = live.get("azureBlobParameters") or {}
    resources = blob.get("createdResources") or live.get("createdResources") or {}
    expected = {"datasource", "skillset", "indexer", "index"}
    if require_graph or (isinstance(resources, dict) and "graphIndex" in resources):
        expected.add("graphIndex")
    if not isinstance(resources, dict) or not expected.issubset(resources):
        raise ValueError("managed Knowledge Source did not report all generated resources")
    if any(not isinstance(resources[key], str) or not resources[key] for key in expected):
        raise ValueError("managed Knowledge Source reported invalid generated resource names")
    name = live.get("name")
    if not isinstance(name, str) or resources["index"] != f"{name}-index":
        raise ValueError("managed generated index names differ from the versioned source")
    if "graphIndex" in expected and (resources["index"] == resources["graphIndex"] or
                                     resources["graphIndex"] != f"{name}-graph-index"):
        raise ValueError("managed generated index names differ from the versioned source")
    return {key: resources[key] for key in expected}
