"""Document types a Build accepts, and which ones need Content Understanding."""
from __future__ import annotations

from pathlib import PurePosixPath

TEXT_TYPES = {".md": "text/markdown", ".txt": "text/plain"}
OFFICE = "application/vnd.openxmlformats-officedocument"
CU_TYPES = {
    ".pdf": "application/pdf",
    ".docx": f"{OFFICE}.wordprocessingml.document",
    ".xlsx": f"{OFFICE}.spreadsheetml.sheet",
    ".pptx": f"{OFFICE}.presentationml.presentation",
    ".html": "text/html", ".htm": "text/html",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".jpe": "image/jpeg",
    ".bmp": "image/bmp", ".tif": "image/tiff", ".tiff": "image/tiff",
    ".heif": "image/heif", ".heic": "image/heic",
}
EXTENSION_TYPES = {**TEXT_TYPES, **CU_TYPES}
# Canonical staged suffix per media type: the first extension listed for it.
_SUFFIXES: dict[str, str] = {}
for _extension, _type in EXTENSION_TYPES.items():
    _SUFFIXES.setdefault(_type, _extension)
SUPPORTED_MEDIA_TYPES = frozenset(_SUFFIXES)
SUPPORTED_EXTENSIONS = ", ".join(sorted(EXTENSION_TYPES))


def extension(name: str) -> str:
    return PurePosixPath(name.replace("\\", "/")).suffix.casefold()


def media_type_for(name: str) -> str | None:
    """Media type for a file name, or None when the type is not supported."""
    return EXTENSION_TYPES.get(extension(name))


def base_type(media_type: str) -> str:
    return media_type.split(";", 1)[0].strip().lower()


def staged_suffix(media_type: str) -> str:
    """Blob suffix a document is staged under, so the indexer picks the right parser."""
    return _SUFFIXES.get(base_type(media_type), ".txt")


def needs_content_understanding(media_types) -> bool:
    return any(base_type(value) not in {"text/markdown", "text/plain"} for value in media_types)


def resolve_media_type(name: str, reported: object) -> str | None:
    """Media type to record for a stored file, or None when it is unsupported.

    Storage services often report application/octet-stream for binary files, so the
    file extension decides; a reported type that contradicts the extension is rejected.
    """
    expected = media_type_for(name)
    if expected is None or not isinstance(reported, str):
        return None
    reported_type = base_type(reported)
    text = {"text/markdown", "text/plain"}
    if reported_type == "application/octet-stream":
        return expected
    if reported_type == expected or reported_type in text and expected in text:
        return reported
    return None
