"""Ontology-aware Entity Graph build planning."""

from .planner import plan

__all__ = ["plan"]
