from __future__ import annotations

from ekg_core.models import BuildSpec, DeploymentDescriptor, OntologyMode, stable_id
from ekg_core.ontology import load_ontology
from .executor import (BuildError, BuildExecutor, generation,
                       hash_json, index_names, source_provenance)
from .managed_pipeline import search_api_version, uses_direct_blob_source
from .planner import plan
from .status import build_status
from .target_validation import graph_input_error


def descriptor(spec: BuildSpec, *, endpoints: dict[str, str] | None = None,
               verified: dict | None = None) -> DeploymentDescriptor:
    blockers = plan(spec).blocked_by
    if blockers:
        raise BuildError("; ".join(blockers))
    if verified is not None:
        reason = graph_input_error(spec)
        if reason:
            raise BuildError(reason)
    direct_blob = uses_direct_blob_source(spec)
    provenance = None
    if spec.source_manifest is not None:
        if build_status(spec)["code"] != "JOURNAL_VERIFIED":
            raise BuildError("SOURCE_MAPPING_UNVERIFIED: approved source run is not journaled as verified")
        prov_ok = (
            isinstance(verified.get("source_provenance"), dict)
            and bool(verified["source_provenance"])
            if (direct_blob and verified)
            else (verified and verified.get("source_provenance") == source_provenance(spec))
        )
        if not verified or verified.get("status") != "verified" or (
            verified.get("manifest_digest") != spec.source_manifest.digest
        ) or not prov_ok:
            raise BuildError("SOURCE_MAPPING_UNVERIFIED: publish needs exact verified provenance")
        provenance = {
            "manifest_digest": spec.source_manifest.digest,
            "staged": verified["source_provenance"],
        }
        provenance["mapping_digest"] = hash_json(provenance)
    ontology = load_ontology(
        spec.ontology_mode,
        path=spec.ontology_path,
        schema_org_profile=spec.schema_org_profile,
        schema_org_version=spec.schema_org_version,
        resolve_imports=spec.resolve_imports,
    )
    ontology_data = None
    deferred = spec.ontology_mode is OntologyMode.DEFERRED
    if ontology:
        ontology_data = {
            "mode": ontology.source_kind,
            "schema_id": ontology.schema_id,
            "source_reference": ontology.source_reference,
            "edge_types": [list(edge) for edge in ontology.edge_types],
        }
        if spec.ontology_path:
            import json as _json
            from pathlib import Path as _Path
            sidecar_path = _Path(str(spec.ontology_path) + ".aliases.json")
            if sidecar_path.is_file():
                try:
                    sidecar_raw = _json.loads(sidecar_path.read_text(encoding="utf-8"))
                    if isinstance(sidecar_raw, dict):
                        ontology_data["aliases"] = {
                            "classes": sidecar_raw.get("classes") or {},
                            "properties": sidecar_raw.get("properties") or {},
                        }
                except Exception:
                    pass
    elif deferred:
        # The chunk index is ready for Topic Graph; `attach-ontology` adds the graph later.
        ontology_data = {"mode": "deferred", "schema_id": None, "source_reference": None,
                         "edge_types": []}
    resolved = dict(endpoints or {})
    if spec.target.search_endpoint:
        resolved["search"] = spec.target.search_endpoint
    if spec.source_manifest is not None:
        storage_ep = (
            spec.source.reference
            if direct_blob and spec.source and spec.source.reference
            else spec.target.storage_endpoint
        )
        if not storage_ep:
            raise BuildError("SOURCE_MAPPING_UNVERIFIED: destination endpoint is missing")
        resolved["storage"] = storage_ep
        resolved["source_manifest_digest"] = spec.source_manifest.digest
    if spec.target.openai_endpoint:
        resolved["openai"] = spec.target.openai_endpoint
    for ep_key, ep_val in (
        ("embedding_openai", spec.target.embedding_openai_endpoint),
        ("chat_openai", spec.target.chat_openai_endpoint),
        ("kb_openai", spec.target.kb_openai_endpoint),
    ):
        if ep_val:
            resolved[ep_key] = ep_val
    if spec.target.content_understanding_endpoint:
        resolved["content_understanding"] = spec.target.content_understanding_endpoint
    if spec.target.cache_storage_resource_id:
        resolved["cache_storage_resource_id"] = spec.target.cache_storage_resource_id
    if spec.embedding_deployment:
        resolved["embedding_deployment"] = spec.embedding_deployment
    if spec.chat_deployment:
        resolved["chat_deployment"] = spec.chat_deployment
    if spec.chat_model:
        resolved["chat_model"] = spec.chat_model
    if spec.kb_chat_deployment:
        resolved["kb_chat_deployment"] = spec.kb_chat_deployment
    if spec.kb_chat_model:
        resolved["kb_chat_model"] = spec.kb_chat_model
    if spec.grounding_index:
        resolved["grounding_index"] = spec.grounding_index
    if (ontology or deferred) and verified:
        resources = verified["created_resources"]
        resolved["content_index"] = resources["index"]
        if resources.get("graphIndex") and not deferred:
            resolved["graph_index"] = resources["graphIndex"]
        resolved["knowledge_source"] = verified["knowledge_source"]
        if verified.get("knowledge_base"):
            resolved["knowledge_base"] = verified["knowledge_base"]
        resolved["search_api_version"] = search_api_version(spec)
    elif not ontology and not deferred:
        try:
            resolved["content_index"] = index_names(spec)["content"]
        except ValueError:
            pass
    return DeploymentDescriptor(
        deployment_id=stable_id("deployment", spec),
        build_id=(f"build-{generation(spec)}" if "content_index" in resolved
                  else stable_id("build", spec)),
        ontology=ontology_data,
        capabilities={
            "document_retrieval": spec.vector_retrieval and
                                  (not ontology or verified is not None),
            "graph_retrieval": bool(
                ontology and ontology.edge_types and verified
            ),
            "agentic_retrieval": bool(
                ontology and verified and verified.get("knowledge_base")
            ),
        },
        endpoints=resolved,
        source_provenance=provenance,
    )


def publish(spec: BuildSpec, executor: BuildExecutor) -> DeploymentDescriptor:
    """Only publish a serving descriptor after read-only remote verification."""
    verified = executor.verify(spec)
    executor.last_verified = verified
    published = descriptor(spec, verified=verified)
    if spec.readers:
        from . import readers
        created = verified["created_resources"]
        missing = readers.missing(executor.adapter, spec.target.search_resource_id,
                                  [created[key] for key in ("index", "graphIndex")
                                   if created.get(key)], spec.readers,
                                  spec.tenant_id)
        if missing:
            raise BuildError(
                f"READERS_MISSING: {len(missing)} reader grant(s) are missing on the new "
                "generation, so those consumers would get HTTP 403. Run these, then publish "
                "again: " + "; ".join(missing))
    return published
