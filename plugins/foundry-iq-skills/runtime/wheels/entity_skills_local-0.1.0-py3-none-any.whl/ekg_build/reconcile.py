from ekg_core.models import BuildSpec
from ekg_core.telemetry import TelemetryRecorder, adapter_http_stats

from .managed_pipeline import search_api_version
from .executor import (
    BuildError, _advance_source_journal, _merge_telemetry, _read_attempt_journal,
    _source_record, _synchronization_event, index_names, plan,
)


def reconcile(executor, spec: BuildSpec) -> dict:
    desired = plan(spec)
    if desired.blocked_by:
        raise BuildError("; ".join(desired.blocked_by))
    if spec.source_manifest is None:
        raise BuildError("SOURCE_MANIFEST_REQUIRED: reconciliation needs the build's --source-manifest")
    record, original = _read_attempt_journal(spec)
    expected = _source_record(spec, "attempt_requested")
    same_run = all(record.get(key) == expected[key] for key in (
        "version", "run_id", "plan_id", "scope", "generation",
        "knowledge_source", "create_request_hash",
    ))
    if same_run and record.get("state") == "verified":
        verified = executor.verify(spec)
        return {**verified, "plan_id": desired.plan_id, "journal_state": "verified",
                "already_verified": True}
    if not same_run or record.get("state") not in {
        "attempt_requested", "staging", "indexing", "synchronizing", "failed",
    }:
        raise BuildError("source journal differs from exact run or cannot be reconciled")
    recorder = TelemetryRecorder("build", adapter_http_stats(executor.adapter))
    with recorder.span("reconcile_targets"):
        executor._source_targets(spec)
    if getattr(executor.adapter, "search_api_version", search_api_version(spec)) != search_api_version(spec):
        raise BuildError(f"managed graph requires exact Search {search_api_version(spec)} API version")
    try:
        status = executor.adapter.knowledge_source_status(index_names(spec)["knowledge_source"])
    except Exception:  # telemetry is best-effort; verification below is authoritative
        status = {}
    if isinstance(status, dict):
        recorder.add(_synchronization_event(status.get("lastSynchronizationState") or {}))
    with recorder.span("verify"):
        verified = executor.verify(spec)
    prior = record.get("telemetry") if isinstance(record.get("telemetry"), list) else []
    _advance_source_journal(spec, original, state="verified", counts=verified["counts"],
                            telemetry=_merge_telemetry(prior, recorder.events))
    return {**verified, "plan_id": desired.plan_id, "journal_state": "verified"}
