import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from pathlib import Path
from typing import Any
from ekg_core import service_errors
from ekg_core.execution import ApplyResult
from ekg_core.models import BuildSpec, Event
from ekg_core.ontology import load_ontology
from ekg_core.telemetry import TelemetryRecorder, adapter_http_stats
from .managed_pipeline import (generated, knowledge_base, knowledge_source, ontology_deferred,
                               search_api_version, uses_direct_blob_source)
from .executor import (
    PARTIAL_NEXT_ACTION, BuildError, PartialIngestion, _create_source_journal, _failure_detail,
    _source_bytes, _advance_source_journal, _sync_status, _synchronization_event,
    index_names, plan, source_provenance, staging_prefix,
)


def _service_error(error: BaseException) -> dict[str, Any]:
    info = service_errors.find(error)
    return {"service_error": info} if info else {}


def _source_inputs(executor, spec):
        if plan(spec).blocked_by:
            raise BuildError("; ".join(plan(spec).blocked_by))
        if not callable(getattr(executor.adapter, "search_page", None)):
            raise BuildError("SOURCE_PAGINATION_REQUIRED: exhaustive generated content readback is unavailable")
        service = executor._source_targets(spec)
        if getattr(executor.adapter, "search_api_version", search_api_version(spec)) != search_api_version(spec):
            raise BuildError(f"managed graph requires exact Search {search_api_version(spec)} API version")
        names = index_names(spec)
        prefix = staging_prefix(spec)
        mapping = source_provenance(spec)
        ontology = load_ontology(
            spec.ontology_mode, path=spec.ontology_path,
            schema_org_profile=spec.schema_org_profile,
            schema_org_version=spec.schema_org_version,
            resolve_imports=spec.resolve_imports,
        )
        if ontology is None and not ontology_deferred(spec):
            raise BuildError("managed graph requires an ontology")
        rows: list[dict] = []
        definition = knowledge_source(
            spec, name=names["knowledge_source"],
            graph_name=names["knowledge_source"], prefix=prefix, ontology=ontology,
        )
        if Path(spec.build_journal or "").exists():
            raise BuildError("managed build journal exists; reconcile the recorded attempt, or "
                             "plan another build with a new --build-journal path")
        statistics = executor.adapter.service_statistics()
        capacity = (statistics.get("counters") or {}).get("indexesCount") or {}
        required_index_headroom = 2
        if not isinstance(capacity.get("usage"), int) or not isinstance(
            capacity.get("quota"), int
        ) or capacity["quota"] - capacity["usage"] < required_index_headroom:
            raise BuildError(
                f"Search index headroom is unknown or less than {required_index_headroom} indexes")
        expected_indexes = [f"{names['knowledge_source']}-index",
                            f"{names['knowledge_source']}-graph-index"]
        if any(executor.adapter.get_index(name) is not None for name in expected_indexes) \
                or executor.adapter.get_knowledge_source(names["knowledge_source"]) is not None \
                or ("knowledge_base" in names and
                    executor.adapter.get_knowledge_base(names["knowledge_base"]) is not None):
            raise BuildError("managed generation already exists; refusing to overwrite")
        if uses_direct_blob_source(spec):
            contents = ()
        else:
            # The final complete in-memory snapshot is checked immediately before the first write.
            contents = _source_bytes(spec, executor.blob_reader)
            if len(contents) != len(mapping):
                raise BuildError("SOURCE_DRIFT: source byte count differs from approved manifest")
        original = _create_source_journal(spec)
        if uses_direct_blob_source(spec) and hasattr(executor.adapter, "journal_before_write"):
            executor.adapter.journal_before_write = Path(spec.build_journal or "").exists()
        return service, names, prefix, mapping, ontology, rows, definition, contents, original
def stage_all(adapter, container: str, items, *, concurrency: int = 16) -> int:
    """Stage (blob name, bytes) pairs with bounded concurrency; return the count staged.

    On the first failure no new uploads start; in-flight ones finish, and the error says
    how many were staged. A rerun re-stages the same bytes idempotently.
    """
    items = list(items)
    if concurrency < 1:
        raise BuildError("upload concurrency must be at least 1")
    staged, failure = 0, None
    with ThreadPoolExecutor(max_workers=min(concurrency, max(1, len(items)))) as pool:
        pending = iter(items)
        running = set()

        def submit() -> bool:
            item = next(pending, None)
            if item is None:
                return False
            running.add(pool.submit(adapter.stage, container, item[0], item[1]))
            return True

        for _ in range(concurrency):
            if not submit():
                break
        while running:
            done, _ = wait(running, return_when=FIRST_COMPLETED)
            for future in done:
                running.discard(future)
                error = future.exception()
                if error is None:
                    staged += 1
                elif failure is None:
                    failure = error
                if failure is None:
                    submit()
    if failure is not None:
        status = getattr(failure, "status", None)
        info = service_errors.find(failure)
        cause = type(failure).__name__ + (
            f": {service_errors.summary(info)}" if info
            else f" HTTP {status}" if isinstance(status, int) else "")
        # Name the cause's type and parsed, redacted service error, never raw request details.
        raise service_errors.attach(BuildError(
            f"STAGING_PARTIAL: {staged} of {len(items)} document(s) staged before "
            f"an upload failed ({cause}); plan another build with a new "
            "--build-journal path"), info) from failure
    return staged


def _stage_source(executor, spec, mapping, contents, original, timings, events, recorder):
            started = time.perf_counter()
            with recorder.span("stage") as span:
                executor.adapter.ensure_container(spec.storage_container)
                names = []
                for (url, _), data in zip(mapping.items(), contents):
                    name = url.removeprefix(f"{spec.target.storage_endpoint}/{spec.storage_container}/")
                    if name == url:
                        raise BuildError("SOURCE_MAPPING_AMBIGUOUS: staged destination is not exact")
                    names.append((name, data))
                stage_all(executor.adapter, spec.storage_container, names,
                          concurrency=executor.upload_concurrency)
                span["counts"]["documents"] = len(contents)
                span["counts"]["upload_concurrency"] = executor.upload_concurrency
                span["bytes"] = sum(len(data) for data in contents)
            timings["stage_ms"] = round((time.perf_counter() - started) * 1000, 3)
            original = _advance_source_journal(
                spec, original, state="indexing",
                counts={"source": len(contents), "staged": len(contents)}, timings_ms=timings,
                telemetry=recorder.events,
            )
            events.append(Event("stage-corpus", "verified", "approved source bytes staged", {
                "source_count": len(contents), "uploaded_count": len(contents),
                "latency_ms": timings["stage_ms"], "evidence_origin": "approved_source_snapshot",
            }))
            return original
def _index_source_ontology(executor, spec, names, ontology, rows, contents, original, timings, events, recorder):
            # The ontology travels inline on the Knowledge Source; there is no index to load.
            return _advance_source_journal(
                spec, original, state="synchronizing",
                counts={"source": len(contents), "staged": len(contents)},
                timings_ms=timings, telemetry=recorder.events,
            )
def _grant_readers(executor, spec, resources, original, recorder):
    """Grant carried-forward readers once the generated indexes exist. A failure is
    journaled rather than raised: the build is still good, and publish names the fix."""
    from . import readers
    indexes = [resources[key] for key in ("index", "graphIndex") if key in resources]
    with recorder.span("grant_readers", resource="role_assignment") as span:
        try:
            grants = readers.grant(executor.adapter, spec.target.search_resource_id, indexes,
                                   spec.readers, spec.tenant_id)
        except RuntimeError as error:
            grants = {"readers": len(spec.readers), "indexes": indexes, "granted": 0,
                      "error": str(error)[:200]}
        span["counts"]["granted"] = grants["granted"]
    return _advance_source_journal(spec, original, reader_grants=grants)


def _create_source_knowledge_source(executor, spec, names, prefix, definition, original, timings, events, recorder):
            started = time.perf_counter()
            with recorder.span("create_knowledge_source"):
                receipt = executor.adapter.create_knowledge_source(definition)
                if (not isinstance(receipt, dict)
                        or receipt.get("name") != names["knowledge_source"]
                        or receipt.get("kind") != "azureBlob"
                        or not isinstance(receipt.get("etag"), str)
                        or not receipt["etag"].strip()):
                    raise BuildError("SOURCE_MAPPING_UNVERIFIED: Knowledge Source create receipt is missing")
                original = _advance_source_journal(
                    spec, original, create_receipt={
                        "name": receipt["name"], "kind": receipt["kind"], "etag": receipt["etag"],
                    },
                )
                live = executor.adapter.get_knowledge_source(names["knowledge_source"])
                if not live or live.get("kind") != "azureBlob" or live.get("name") != names["knowledge_source"]:
                    raise BuildError("managed Knowledge Source could not be verified")
                resources = generated(live, require_graph=not ontology_deferred(spec))
                if not ontology_deferred(spec) and hasattr(executor.adapter, "set_skillset_reasoning_effort"):
                    executor.adapter.set_skillset_reasoning_effort(resources["skillset"])
                if uses_direct_blob_source(spec) and spec.trial is not None and hasattr(executor.adapter, "set_indexer_max_items"):
                    executor.adapter.set_indexer_max_items(
                        resources["indexer"], spec.trial.size
                    )
                if "knowledge_base" in names:
                    executor.adapter.create_knowledge_base(knowledge_base(
                        spec, name=names["knowledge_base"],
                        knowledge_source_name=names["knowledge_source"],
                    ))
            create_ms = round((time.perf_counter() - started) * 1000, 3)
            if spec.readers:
                original = _grant_readers(executor, spec, resources, original, recorder)
            original = _advance_source_journal(spec, original, telemetry=recorder.events)
            events.append(Event("create-managed-knowledge-source", "verified",
                                "managed Knowledge Source accepted; service-side synchronization started", {
                                    "knowledge_source_id": names["knowledge_source"],
                                    "created_resources": resources, "latency_ms": create_ms,
                                    "evidence_origin": "knowledge_source_create_receipt",
                                }))
            if "knowledge_base" in names:
                events.append(Event("create-managed-knowledge-base", "verified",
                                    "linked Knowledge Base created", {
                                        "knowledge_base_id": names["knowledge_base"],
                                        "knowledge_source_id": names["knowledge_source"],
                                    }))
            submitted = Event("build", "submitted", "SYNCHRONIZATION_STARTED", {
                "run_id": f"build-{prefix}", "plan_id": plan(spec).plan_id,
                "phase": "synchronizing", "timings_ms": {**timings, "create_ms": create_ms},
                "evidence_origin": "knowledge_source_create_receipt",
                "uncertainty": ["Generated indexes and graph are unverified until reconcile succeeds."],
                "next_action": ("Optionally watch with `entity-graph-build progress`; run `entity-graph-build reconcile` "
                                "read-only after synchronization finishes. Do not rerun apply."),
            })
            return original, submitted, started
def _finish_source_apply(executor, spec, names, prefix, service, contents, original, submitted, timings, events, recorder, started_total, started):
            with recorder.span("wait_for_synchronization") as span:
                for polls in range(1, 61):
                    last = _sync_status(executor.adapter.knowledge_source_status(names["knowledge_source"]))
                    if last:
                        break
                    time.sleep(5)
                span["counts"]["polls"] = polls
            if not last:
                original = _advance_source_journal(spec, original, telemetry=recorder.events)
                return original, ApplyResult(tuple(events + [submitted]), True)
            recorder.add(_synchronization_event(last))
            timings["synchronization_ms"] = round((time.perf_counter() - started) * 1000, 3)
            started = time.perf_counter()
            with recorder.span("verify"):
                verified = executor.verify(spec)
            timings["verify_ms"] = round((time.perf_counter() - started) * 1000, 3)
            timings["time_to_build_ms"] = round((time.perf_counter() - started_total) * 1000, 3)
            direct_blob = uses_direct_blob_source(spec)
            source_count = spec.source_manifest.document_count if spec.source_manifest else len(contents)
            staged_count = 0 if direct_blob else len(contents)
            original = _advance_source_journal(
                spec, original, state="verified",
                counts={"source": source_count, "staged": staged_count, **verified["counts"]},
                timings_ms=timings, telemetry=recorder.events,
            )
            events.append(Event("verify-managed-synchronization", "verified",
                                "generated indexes, graph and original provenance verified", {
                                    "document_count": verified["counts"]["content"],
                                    "graph_document_count": verified["counts"].get("graph"),
                                    "serving_state": "verified", "latency_ms": timings["verify_ms"],
                                }))
            events.append(Event("build", "completed", "approved source generation verified", {
                "run_id": f"build-{prefix}", "plan_id": plan(spec).plan_id,
                "counts": {"source": source_count, "staged": staged_count, **verified["counts"]},
                "phase_latency_ms": timings, "evidence_origin": "read_only_generated_index_checks",
                "next_action": "Publish after fresh read-only verification of the exact generation.",
                "target_verification": service,
            }))
            return original, ApplyResult(tuple(events), True)
def _apply_source(executor, spec: BuildSpec, *, wait_for_sync: bool = True) -> ApplyResult:
        service, names, prefix, mapping, ontology, rows, definition, contents, original = _source_inputs(executor, spec)
        events: list[Event] = []
        timings: dict[str, float] = {}
        recorder = TelemetryRecorder("build", adapter_http_stats(executor.adapter))
        started_total = time.perf_counter()
        phase = "staging"
        try:
            if uses_direct_blob_source(spec):
                source_count = spec.source_manifest.document_count if spec.source_manifest else 0
                original = _advance_source_journal(
                    spec, original, state="synchronizing",
                    counts={"source": source_count, "staged": 0},
                    timings_ms=timings, telemetry=recorder.events,
                )
            else:
                original = _stage_source(executor, spec, mapping, contents, original, timings, events, recorder)
                phase = "indexing"
                original = _index_source_ontology(executor, spec, names, ontology, rows, contents, original, timings, events, recorder)
            phase = "synchronizing"
            original, submitted, started = _create_source_knowledge_source(executor, spec, names, prefix, definition, original, timings, events, recorder)
            if not wait_for_sync:
                return ApplyResult(tuple(events + [submitted]), True)
            original, result = _finish_source_apply(executor, spec, names, prefix, service, contents, original, submitted, timings, events, recorder, started_total, started)
            return result
        except Exception as error:
            partial = isinstance(error, PartialIngestion)
            code = ("PARTIAL_INGESTION" if partial else
                    "SOURCE_DRIFT" if "SOURCE_DRIFT" in str(error) else
                    "REMOTE_OUTCOME_UNVERIFIED" if phase == "synchronizing" else
                    "BUILD_ATTEMPT_FAILED")
            timings["time_to_build_ms"] = round((time.perf_counter() - started_total) * 1000, 3)
            failure = _failure_detail(error)
            _advance_source_journal(spec, original, state="failed", error_code=code,
                                    timings_ms=timings, telemetry=recorder.events,
                                    **({"service_error": failure["service_error"]}
                                       if "service_error" in failure else {}))
            events.append(Event("build", "failed", code, {
                "run_id": f"build-{prefix}", "phase": phase, "timings_ms": timings,
                **failure,
                "evidence_origin": "local_build_journal",
                "uncertainty": ["Remote mutation may have completed; no automatic retry is safe."],
                **({"items_failed": error.failed, "next_action": PARTIAL_NEXT_ACTION} if partial else
                   {"next_action": "Reconcile this exact attempt read-only; never retry its writes automatically."}),
            }))
            return ApplyResult(tuple(events), False)
