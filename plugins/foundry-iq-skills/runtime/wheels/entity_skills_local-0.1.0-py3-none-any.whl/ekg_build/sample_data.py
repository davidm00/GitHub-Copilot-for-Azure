"""Fetch or stage packaged public sample datasets (default: microsoft-earnings-calls)."""

from __future__ import annotations

import hashlib
from importlib.resources import files
import json
from pathlib import Path
import time
import urllib.error
import urllib.request

from ekg_core import service_errors
from ekg_core.cli import Blocked

SUPPORTED_DATASETS = ("microsoft-earnings-calls",)
USER_AGENT = "foundry-iq-entity-skills-sample-fetch/1.0"


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_earnings_manifest() -> dict:
    root = files("ekg_build").joinpath("examples", "microsoft_earnings_calls")
    manifest = json.loads(root.joinpath("manifest.json").read_text(encoding="utf-8"))
    items = manifest.get("transcripts")
    if not isinstance(items, list) or len(items) != manifest.get("count"):
        raise ValueError("sample manifest transcript list does not match its count")
    if len({item.get("id") for item in items}) != len(items):
        raise ValueError("sample manifest transcript IDs must be unique")
    if len({item.get("sha256") for item in items}) != len(items):
        raise ValueError("sample manifest transcript SHA-256 digests must be unique")
    return manifest


def load_earnings_questions() -> dict:
    root = files("ekg_build").joinpath("examples", "microsoft_earnings_calls")
    return json.loads(root.joinpath("questions.json").read_text(encoding="utf-8"))


def _fetch_bytes(url: str, *, retries: int = 4) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    for attempt in range(retries + 1):
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                return response.read()
        except urllib.error.HTTPError as error:
            if error.code not in (429, 500, 502, 503, 504) or attempt == retries:
                service_errors.attach(error, service_errors.from_exception(error))
                raise
            time.sleep(float(error.headers.get("Retry-After") or 2 ** (attempt + 1)))
        except urllib.error.URLError as error:
            if attempt == retries:
                raise
            time.sleep(2 ** (attempt + 1))
    raise AssertionError("unreachable")


def fetch_sample(
    output: str | Path,
    *,
    dataset: str = "microsoft-earnings-calls",
    limit: int | None = None,
    delay: float = 0.02,
) -> dict:
    if dataset not in SUPPORTED_DATASETS:
        raise Blocked(
            "USAGE",
            f"Unsupported sample dataset {dataset!r}; choose from {', '.join(SUPPORTED_DATASETS)}.",
        )
    target_dir = Path(output).expanduser().resolve()
    target_dir.mkdir(parents=True, exist_ok=True)
    questions_target = target_dir.parent / f"{target_dir.name}-questions.json"

    manifest = load_earnings_manifest()
    questions_data = load_earnings_questions()
    questions_target.write_text(json.dumps(questions_data, indent=2) + "\n", encoding="utf-8")

    items = manifest["transcripts"]
    if limit is not None:
        if limit < 1:
            raise Blocked("USAGE", "--limit must be a positive integer")
        items = items[:limit]

    base_url = manifest["source"]["raw_base_url"].rstrip("/")
    license_info = manifest["license"]
    license_target = target_dir / license_info["file"]
    if not (license_target.exists() and _sha256(license_target.read_bytes()) == license_info["sha256"]):
        lic_bytes = _fetch_bytes(f"{base_url}/{license_info['file']}")
        if _sha256(lic_bytes) != license_info["sha256"]:
            raise ValueError("Downloaded LICENSE SHA-256 does not match pinned manifest")
        license_target.write_bytes(lic_bytes)

    written = skipped = 0
    for item in items:
        dest = target_dir / item["file"]
        if dest.exists() and _sha256(dest.read_bytes()) == item["sha256"]:
            skipped += 1
            continue
        raw = _fetch_bytes(f"{base_url}/corpus/{item['file']}")
        if _sha256(raw) != item["sha256"]:
            raise ValueError(f"{item['file']}: SHA-256 mismatch against pinned manifest")
        dest.write_bytes(raw)
        written += 1
        if delay > 0:
            time.sleep(delay)

    return {
        "status": "ok",
        "dataset": manifest["name"],
        "license": manifest["license"]["id"],
        "expected": len(items),
        "written": written,
        "already_present": skipped,
        "output": str(target_dir),
        "questions_file": str(questions_target),
        "questions": [
            q["question"]
            for q in questions_data.get("questions", [])
            if isinstance(q, dict) and "question" in q
        ],
    }
