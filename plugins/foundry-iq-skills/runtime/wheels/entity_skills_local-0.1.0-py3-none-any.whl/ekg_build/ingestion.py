"""Documents that failed ingestion: read-only diagnosis and explicit local acceptance.

``failures`` reads live Knowledge Source status, the generated indexer's last run and the
content index; it never writes. ``accept_failures`` writes one local record, next to the
build journal, naming exactly the reviewed failed set. Gates continue past failed documents
only when that record covers them; anything beyond it still blocks.

When every failure looks transient (a dropped connection, a timeout, throttling, or the
service's own "must be retried"), or documents came through with chunks missing their
embeddings, ``failures`` also offers one bounded retry. ``retry_failures`` resets only those
source documents and reruns the generated indexer once; a local record stops a second retry.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import unquote

from ekg_core.models import BuildSpec

from .executor import BuildError, _sync_running, failed_items, hash_json, index_names, \
    source_provenance
from .managed_pipeline import generated
from ekg_core.files import atomic_write_text

VERSION = 1
_ERROR_LIMIT = 50
_MISSING_LIMIT = 100
_WARNING_SAMPLE = 5
GUIDE = ("the errors above: each message, details and documentation link (see the "
         "entity-graph-build status-and-telemetry reference, Failed documents)")


_TRANSIENT = re.compile(
    r"connection (?:was )?(?:aborted|reset|closed)|timed? ?out|timeout|too many requests"
    r"|\b(?:429|502|503|504)\b|service unavailable|temporar|must be retried"
    r"|pending cached documents", re.IGNORECASE)
_MISSING_VECTOR = re.compile(r"Missing or empty value '/document/pages/\d+/text_vector'")


def _knowledge_source(spec: BuildSpec) -> str:
    return index_names(spec)["knowledge_source"]


def acceptance_path(spec: BuildSpec) -> Path:
    if not spec.build_journal:
        raise BuildError("failed-document acceptance needs --build-journal; its folder holds "
                         "the acceptance record")
    return Path(spec.build_journal).with_name(
        f"{_knowledge_source(spec)}.accepted-failures.json")


def load_acceptance(spec: BuildSpec) -> dict[str, Any] | None:
    """The user's accepted failed set for this Knowledge Source, or None."""
    if not spec.build_journal:
        return None
    path = acceptance_path(spec)
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError):
        return None
    missing = record.get("missing_sources") if isinstance(record, dict) else None
    count = record.get("failed_count") if isinstance(record, dict) else None
    if (not isinstance(record, dict) or record.get("version") != VERSION
            or record.get("knowledge_source") != _knowledge_source(spec)
            or not isinstance(record.get("acceptance_id"), str)
            or not isinstance(count, int) or isinstance(count, bool) or count < 0
            or not isinstance(missing, list) or not all(isinstance(u, str) for u in missing)):
        return None
    return record


def retry_path(spec: BuildSpec) -> Path | None:
    if not spec.build_journal:
        return None
    return Path(spec.build_journal).with_name(f"{_knowledge_source(spec)}.retry-failures.json")


def _retried(spec: BuildSpec) -> dict[str, Any] | None:
    path = retry_path(spec)
    try:
        record = json.loads(path.read_text(encoding="utf-8")) if path else None
    except (OSError, UnicodeError, ValueError):
        return None
    return record if isinstance(record, dict) and isinstance(record.get("documents"), list) else None


def accepted_failed(spec: BuildSpec) -> int:
    record = load_acceptance(spec)
    return record["failed_count"] if record else 0


def accepted_missing(spec: BuildSpec) -> set[str]:
    record = load_acceptance(spec)
    return set(record["missing_sources"]) if record else set()


def _text(value: Any, limit: int = 600) -> str | None:
    if value is None:
        return None
    text = " ".join(str(value).split())
    return text if len(text) <= limit else text[:limit - 1] + "…"


def _error(entry: dict[str, Any]) -> dict[str, Any]:
    found = {
        "key": _text(entry.get("key")), "name": _text(entry.get("name")),
        "error_message": _text(entry.get("errorMessage") or entry.get("message")),
        "details": _text(entry.get("details")), "status_code": entry.get("statusCode"),
        "documentation_link": entry.get("documentationLink"),
    }
    return {key: value for key, value in found.items() if value is not None}


def _decoded_key(key: Any) -> str | None:
    """Blob indexer keys are often URL-safe base64 of the blob path, with a padding digit."""
    if not isinstance(key, str) or not key:
        return None
    for candidate in (key, key[:-1] if key[-1:].isdigit() else None):
        if not candidate:
            continue
        try:
            raw = base64.urlsafe_b64decode(candidate + "=" * (-len(candidate) % 4))
            return raw.decode("utf-8")
        except (binascii.Error, ValueError, UnicodeDecodeError):
            continue
    return None


def _mentions(entry: dict[str, Any], url: str, blob_name: str) -> bool:
    text = " ".join(str(entry.get(name) or "") for name in
                    ("key", "name", "errorMessage", "message", "details"))
    haystacks = [text, unquote(text), _decoded_key(entry.get("key")) or ""]
    needles = [url, unquote(url), blob_name]
    return any(needle and needle in haystack for haystack in haystacks for needle in needles)


def _entry_url(entry: dict[str, Any]) -> str | None:
    """The source document URL an indexer error or warning names, if any."""
    key = entry.get("key")
    if not isinstance(key, str) or not key:
        return None
    for part in key.split("&"):
        name, _, value = part.partition("=")
        if name == "documentKey" and value:
            return unquote(value)
    decoded = _decoded_key(key)
    return decoded if decoded and decoded.startswith(("http://", "https://")) else None


def _transient(entry: dict[str, Any]) -> bool:
    text = " ".join(str(entry.get(name) or "") for name in ("errorMessage", "message", "details"))
    return bool(_TRANSIENT.search(text))


def _incomplete(warnings: list[dict[str, Any]]) -> dict[str, int]:
    """Source documents with chunks the service indexed without an embedding."""
    counts: dict[str, int] = {}
    for entry in warnings:
        url = _entry_url(entry) if _MISSING_VECTOR.search(str(entry.get("details") or "")) else None
        if url:
            counts[url] = counts.get(url, 0) + 1
    return counts


def _seen_urls(adapter: Any, index: str) -> set[str]:
    """Every staged blob URL that produced at least one chunk in the content index."""
    total = adapter.count(index)
    seen: set[str] = set()
    offset = 0
    while offset < total:
        page = adapter.search_page(index, skip=offset, top=min(1000, total - offset))
        if not isinstance(page, list) or not page:
            break
        seen.update(row["blob_url"] for row in page
                    if isinstance(row, dict) and isinstance(row.get("blob_url"), str))
        offset += len(page)
    return seen


def _two_choice(knowledge_source: str, count: int, acceptance_id: str, resume: str,
                retry: dict[str, Any] | None = None) -> str:
    text = (
        f"{count} document(s) in {knowledge_source} did not ingest, so the build is paused, not "
        "finished. Ask the user to choose: (A) investigate: work from "
        f"{GUIDE}; a corrected source document needs a new plan; or (B) continue without them: "
        f"run `entity-graph-build accept-failures --acceptance-id {acceptance_id}` with the "
        f"same flags, then {resume}.")
    if retry:
        return text + " " + _retry_choice(retry) + " Never stop without offering all three choices."
    return text + " Never stop without offering both choices."


def _retry_choice(retry: dict[str, Any]) -> str:
    count = len(retry["documents"])
    return (f"(C) retry once: the errors look transient, so run `entity-graph-build "
            f"retry-failures --retry-id {retry['retry_id']}` with the same flags. It resets only "
            f"those {count} source document(s) and reruns the indexer, repeating their embedding "
            "and extraction model calls (a small charge); it is a Search write, so ask first. "
            "It is offered once; afterwards only (A) and (B) remain.")


def failures(executor: Any, spec: BuildSpec, *,
             resume: str = "`entity-graph-build reconcile` with the same flags") -> dict[str, Any]:
    """Read-only list of failed documents, their indexer errors and an acceptance ID."""
    return _review(executor, spec, resume)[0]


def _review(executor: Any, spec: BuildSpec, resume: str) -> tuple[dict[str, Any], list[str]]:
    name = _knowledge_source(spec)
    adapter = executor.adapter
    status = adapter.knowledge_source_status(name) or {}
    last = status.get("lastSynchronizationState") or {}
    current = status.get("currentSynchronizationState") or {}
    live = adapter.get_knowledge_source(name)
    if not isinstance(live, dict):
        raise BuildError(f"Knowledge Source {name} was not found; check the flags match the "
                         "build that was applied")
    try:
        resources = generated(live, require_graph=False)
    except ValueError as error:
        raise BuildError(str(error)) from error
    indexer = resources["indexer"]
    run: dict[str, Any] = {}
    if callable(getattr(adapter, "indexer_status", None)):
        run = (adapter.indexer_status(indexer) or {}).get("lastResult") or {}
    raw_errors = [entry for entry in run.get("errors") or [] if isinstance(entry, dict)]
    raw_warnings = [entry for entry in run.get("warnings") or [] if isinstance(entry, dict)]
    base: dict[str, Any] = {
        "phase": "build.failures", "knowledge_source": name, "indexer": indexer,
        "indexer_run": {key: value for key, value in {
            "status": run.get("status"), "start_time": run.get("startTime"),
            "end_time": run.get("endTime"), "items_processed": run.get("itemsProcessed"),
            "items_failed": run.get("itemsFailed"),
            "error_message": _text(run.get("errorMessage")),
        }.items() if value is not None},
        "errors": [_error(entry) for entry in raw_errors[:_ERROR_LIMIT]],
        "errors_truncated": len(raw_errors) > _ERROR_LIMIT,
        "warnings": {"count": len(raw_warnings),
                     "sample": [_error(entry) for entry in raw_warnings[:_WARNING_SAMPLE]]},
        "evidence_origin": "live_knowledge_source_and_indexer_status",
        "troubleshooting": GUIDE,
    }
    if _sync_running(current) or _sync_running(last) or run.get("status") == "inProgress":
        return {**base, "status": "synchronizing",
                "next_step": "Synchronization is still running; failed documents are known only "
                             "when it finishes. Check `entity-graph-build progress`, then run "
                             "`entity-graph-build failures` again."}, []
    failed = max(failed_items(last), failed_items(current), failed_items(run))
    missing: list[dict[str, Any]] = []
    if spec.source_manifest is not None:
        mapping = source_provenance(spec)
        seen = _seen_urls(adapter, resources["index"])
        container = f"/{spec.storage_container}/"
        for url in sorted(set(mapping) - seen):
            blob_name = unquote(url.split(container, 1)[-1])
            missing.append({
                "source_id": mapping[url]["source_id"],
                "original_uri": mapping[url]["original_uri"], "staged_uri": url,
                "errors": [_error(entry) for entry in raw_errors
                           if _mentions(entry, url, blob_name)][:5],
            })
    count = max(failed, len(missing))
    urls = [item["staged_uri"] for item in missing]
    incomplete = _incomplete(raw_warnings)
    base["incomplete_sources"] = [{"staged_uri": url, "chunks_without_embedding": n}
                                  for url, n in sorted(incomplete.items())][:_MISSING_LIMIT]
    retry = _retry_offer(spec, name, run, raw_errors, urls, incomplete)
    if retry:
        base["retry"] = retry
    if not count:
        if incomplete:
            return {**base, "status": "clean", "failed_count": 0, "missing_sources": [],
                    "next_step": (
                        f"No failed documents, but {len(incomplete)} document(s) have chunks "
                        "indexed without embeddings, so vector search misses them. Ask the user "
                        f"to choose: continue with {resume}"
                        + (f", or {_retry_choice(retry)}" if retry else
                           "; a retry was already used, so investigate from " + GUIDE)
                        + ".")}, []
        return {**base, "status": "clean", "failed_count": 0, "missing_sources": [],
                "next_step": f"No failed documents; continue with {resume}."}, []
    acceptance_id = hash_json({"knowledge_source": name, "failed_count": failed,
                               "missing_sources": urls})
    accepted = load_acceptance(spec)
    done = bool(accepted and accepted["acceptance_id"] == acceptance_id)
    return {
        **base, "status": "partial", "failed_count": failed,
        "documents": spec.source_manifest.document_count if spec.source_manifest else None,
        "missing_count": len(missing), "missing_sources": missing[:_MISSING_LIMIT],
        "missing_truncated": len(missing) > _MISSING_LIMIT,
        "acceptance_id": acceptance_id, "accepted": done,
        "next_step": (f"These failed documents are already accepted; continue with {resume}."
                      if done else _two_choice(name, count, acceptance_id, resume, retry)),
    }, urls


def _retry_offer(spec: BuildSpec, name: str, run: dict[str, Any], errors: list[dict[str, Any]],
                 missing: list[str], incomplete: dict[str, int]) -> dict[str, Any] | None:
    """One bounded retry, only when every failure looks transient and none was tried yet."""
    if retry_path(spec) is None or not all(_transient(entry) for entry in errors):
        return None
    run_transient = bool(_TRANSIENT.search(str(run.get("errorMessage") or "")))
    if not (errors or incomplete or (missing and run_transient)):
        return None
    documents = sorted({url for url in (_entry_url(entry) for entry in errors) if url}
                       | set(missing) | set(incomplete))
    if not documents or _retried(spec) is not None:
        return None
    return {"retry_id": hash_json({"knowledge_source": name, "documents": documents}),
            "documents": documents}


def accept_failures(executor: Any, spec: BuildSpec, acceptance_id: str, *,
                    resume: str = "`entity-graph-build reconcile` with the same flags"
                    ) -> dict[str, Any]:
    """Record the user's acceptance of exactly the reviewed failed set (local write only)."""
    if not isinstance(acceptance_id, str) or not acceptance_id.startswith("sha256:"):
        raise BuildError("accept-failures needs the --acceptance-id shown by "
                         "`entity-graph-build failures`")
    report, missing = _review(executor, spec, resume)
    if report["status"] == "synchronizing":
        raise BuildError("synchronization is still running; review `entity-graph-build "
                         "failures` after it finishes")
    if report["status"] == "clean":
        raise BuildError("no failed documents to accept; continue with " + resume)
    if report["acceptance_id"] != acceptance_id:
        raise BuildError("ACCEPTANCE_STALE: the failed documents changed since review; run "
                         "`entity-graph-build failures` again and review the new acceptance ID")
    record = {
        "version": VERSION, "knowledge_source": report["knowledge_source"],
        "acceptance_id": acceptance_id, "failed_count": report["failed_count"],
        "missing_sources": missing,
        "accepted_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    path = acceptance_path(spec)
    atomic_write_text(path, json.dumps(record, sort_keys=True, indent=1))
    return {
        "status": "accepted", "knowledge_source": record["knowledge_source"],
        "acceptance_id": acceptance_id, "failed_count": record["failed_count"],
        "missing_count": len(record["missing_sources"]), "record": str(path),
        "summary": (f"Accepted {max(record['failed_count'], len(record['missing_sources']))} "
                    "failed document(s); the graph will be built without them. Only this exact "
                    "set is accepted; any new failure still stops the build."),
        "next_step": f"Continue with {resume}.",
    }


def retry_failures(executor: Any, spec: BuildSpec, retry_id: str, *,
                   resume: str = "`entity-graph-build reconcile` with the same flags"
                   ) -> dict[str, Any]:
    """Reset exactly the reviewed documents and rerun the generated indexer, once."""
    if not isinstance(retry_id, str) or not retry_id.startswith("sha256:"):
        raise BuildError("retry-failures needs the --retry-id shown by `entity-graph-build failures`")
    if _retried(spec) is not None:
        raise BuildError("RETRY_ALREADY_USED: these documents were already retried once; choose "
                         "(A) investigate or (B) accept-failures from `entity-graph-build failures`")
    report, _ = _review(executor, spec, resume)
    if report["status"] == "synchronizing":
        raise BuildError("synchronization is still running; review `entity-graph-build "
                         "failures` after it finishes")
    offer = report.get("retry")
    if not offer:
        raise BuildError("RETRY_UNAVAILABLE: no transient failure is waiting for a retry; see "
                         "`entity-graph-build failures` for the remaining choices")
    if offer["retry_id"] != retry_id:
        raise BuildError("RETRY_STALE: the failed documents changed since review; run "
                         "`entity-graph-build failures` again and review the new retry ID")
    path = retry_path(spec)
    record = {"version": VERSION, "knowledge_source": report["knowledge_source"],
              "retry_id": retry_id, "documents": offer["documents"],
              "started_at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    # Recorded before the writes: an interrupted retry's outcome is unknown, so it is never repeated.
    atomic_write_text(path, json.dumps(record, sort_keys=True, indent=1))
    adapter = executor.adapter
    adapter.reset_documents(report["indexer"], offer["documents"])
    adapter.run_indexer(report["indexer"])
    return {
        "status": "retrying", "knowledge_source": report["knowledge_source"],
        "indexer": report["indexer"], "retry_id": retry_id,
        "documents": offer["documents"], "record": str(path),
        "summary": (f"Reset {len(offer['documents'])} source document(s) and started the indexer; "
                    "only those documents are reprocessed."),
        "next_step": ("Check `entity-graph-build progress` with the same flags until "
                      "synchronization finishes, then run `entity-graph-build failures` again. "
                      f"If it is clean, continue with {resume}; otherwise offer (A) investigate "
                      "or (B) accept-failures. The retry is not offered twice."),
    }
