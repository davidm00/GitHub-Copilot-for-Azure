"""One bounded ARM throttling layer; never replays a provisioning operation."""
from __future__ import annotations

import json
import math
import random
import re
import sys
import time
from datetime import timezone
from email.utils import parsedate_to_datetime
from typing import Any, Callable
from urllib.parse import parse_qsl, urlsplit

from . import service_errors

POLICY_ID = "arm-429-v1"
POLICY_TEXT = (
    "Selected ARM requests may retry HTTP 429 at most five times within 120 seconds "
    "per request sequence, honoring Azure's minimum delay. No automatic workflow "
    "replay or cleanup; uncertain writes require authoritative reconciliation."
)
_TRANSIENT = frozenset({
    "toomanyrequests", "throttled", "throttling", "ratelimitexceeded",
    "requestratetoolarge", "tenantthrottled", "resourceproviderthrottled", "429",
})


class RetryExhausted(RuntimeError):
    status_code = 429


class RetryCancelled(RuntimeError):
    pass


def _number(value: str | None) -> float | None:
    try:
        result = float(value) if value is not None else -1
    except (ValueError, TypeError):
        return None
    if math.isinf(result) and isinstance(value, str) and re.fullmatch(r"\d+(?:\.\d+)?", value):
        return math.inf
    return result if math.isfinite(result) and result >= 0 else None


def retry_after(headers: Any, now: float) -> float | None:
    headers = {str(key).lower(): str(value) for key, value in headers.items()}
    delays = []
    value = headers.get("retry-after")
    seconds = _number(value)
    if seconds is None and value:
        try:
            date = parsedate_to_datetime(value)
            if date.tzinfo is not None:
                seconds = max(0.0, date.astimezone(timezone.utc).timestamp() - now)
                if headers.get("date"):
                    issued = parsedate_to_datetime(headers["date"])
                    if issued.tzinfo is not None:
                        seconds = max(seconds, (date - issued).total_seconds())
        except (ValueError, TypeError, OverflowError):
            pass
    if seconds is not None:
        delays.append(seconds)
    for key in ("x-ms-retry-after-ms", "retry-after-ms"):
        milliseconds = _number(headers.get(key))
        if milliseconds is not None:
            delays.append(milliseconds / 1000)
    return max(delays) if delays else None


def _error_code(response: Any) -> str | None:
    """Most specific ARM error code, or None when the body cannot be read or parsed.

    The SDK policy sees streamed responses whose body may still be unread
    (azure-core raises ResponseNotReadError, not ValueError). A 429 without a
    readable code is still definite throttling, so None never blocks a retry;
    only a parsed non-transient code does.
    """
    try:
        read = getattr(response, "read", None)
        if callable(read):
            read()
        body = response.json() if hasattr(response, "json") else json.loads(
            response.text())
    except Exception:
        return None
    error = body.get("error") if isinstance(body, dict) else None
    code = None
    for _ in range(5):
        if not isinstance(error, dict):
            break
        current = error.get("code")
        if current:
            code = str(current).casefold()
            if code not in _TRANSIENT:
                return code
        error = error.get("innererror") or error.get("innerError")
    return code


def _safe_method(request: Any) -> bool:
    method = request.method.upper()
    headers = {str(key).casefold(): value for key, value in request.headers.items()}
    if method in ("GET", "HEAD"):
        return True
    path = urlsplit(request.url).path.casefold()
    if method == "POST":
        return path == "/providers/microsoft.search/fetchofferings"
    if method == "PUT":
        return (headers.get("if-none-match") == "*"
                or re.search(r"/providers/microsoft\.authorization/roleassignments/"
                             r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$", path) is not None)
    return method == "PATCH" and bool(headers.get("if-match"))


def _identity(request: Any, response: Any) -> dict[str, Any]:
    result: dict[str, Any] = {
        "method": request.method.upper(), "resource": urlsplit(request.url).path,
    }
    headers = {str(key).lower(): str(value) for key, value in response.headers.items()}
    client_id = request.headers.get("x-ms-client-request-id")
    if client_id:
        headers.setdefault("x-ms-client-request-id", str(client_id))
    for key in ("x-ms-request-id", "x-ms-correlation-request-id", "x-ms-client-request-id"):
        value = headers.get(key)
        if value and re.fullmatch(r"[0-9a-fA-F-]{36}", value):
            result[key] = value
    if request.method.upper() == "PUT" and response.status_code in (200, 201, 202):
        subscription = re.match(r"/subscriptions/[^/]+/", urlsplit(request.url).path, re.I)
        for key in ("azure-asyncoperation", "operation-location", "location"):
            value = headers.get(key)
            parsed = urlsplit(value or "")
            if (value and subscription and parsed.scheme == "https"
                    and parsed.netloc == "management.azure.com" and not parsed.fragment
                    and parsed.path.casefold().startswith(subscription[0].casefold())
                    and all(name == "api-version" and re.fullmatch(r"[\w.-]+", version)
                            for name, version in parse_qsl(parsed.query))):
                result["operation_url"] = value
                break
    return result


def report(event: dict[str, Any]) -> None:
    if event["event"] == "retry_wait":
        print(
            f"Azure throttled {event['method']} {event['resource']}; "
            f"retrying in {event['delay_seconds']:.3f}s "
            f"(attempt {event['next_attempt']}/6; HTTP 429).",
            file=sys.stderr, flush=True,
        )
    elif event["event"] == "retry_exhausted":
        print("Azure HTTP 429 request retries exhausted; preserve partial progress and "
              "use plan-resume for a separately approved continuation. No workflow "
              "replay or cleanup.", file=sys.stderr, flush=True)


def request_sequence(
    send: Callable[[], Any], request: Any, *,
    observe: Callable[[dict[str, Any]], None] = report,
    monotonic: Callable[[], float] = time.monotonic,
    wall_time: Callable[[], float] = time.time,
    sleep: Callable[[float], None] = time.sleep,
    jitter: Callable[[], float] = random.random,
    cancelled: Callable[[], bool] = lambda: False,
    before_send: Callable[[float], None] = lambda remaining: None,
) -> Any:
    """Retry only definite throttling responses; transport exceptions propagate once."""
    started = monotonic()
    last_identity: dict[str, Any] = {}
    last_info: dict[str, Any] | None = None
    for attempt in range(1, 7):
        if cancelled():
            raise RetryCancelled("ARM request cancelled; reconcile any uncertain write before recovery.")
        remaining = 120 - (monotonic() - started)
        if remaining <= 0:
            observe({"event": "retry_exhausted", "attempt": attempt - 1, "status": 429,
                     "reason": "elapsed_deadline", **last_identity})
            message = "HTTP 429 request deadline exhausted; use plan-resume, not apply replay."
            if last_info:
                message += f" Last service error: {service_errors.summary(last_info)}"
            raise service_errors.attach(RetryExhausted(message), last_info)
        before_send(remaining)
        result = send()
        response = getattr(result, "http_response", result)
        identity = _identity(request, response)
        last_identity = identity
        status = response.status_code
        if request.method.upper() == "PUT" and status in (200, 201, 202):
            observe({"event": "write_accepted", "attempt": attempt, "status": status, **identity})
        if status != 429:
            return result
        code = _error_code(response)
        if not _safe_method(request) or (code is not None and code not in _TRANSIENT):
            observe({"event": "not_retryable", "attempt": attempt, "status": 429,
                     "reason": "unsafe_request_or_nontransient_error", **identity})
            return result
        last_info = service_errors.from_response(response)
        server_delay = retry_after(response.headers, wall_time())
        minimum = server_delay if server_delay is not None else min(2 ** (attempt - 1), 30)
        delay = minimum + min(1.0, max(0.0, jitter())) * 0.25
        remaining = 120 - (monotonic() - started)
        if attempt == 6 or delay >= remaining:
            observe({"event": "retry_exhausted", "attempt": attempt, "status": 429,
                     "reason": "retry_limit" if attempt == 6 else "server_delay_exceeds_deadline",
                     "minimum_delay_seconds": minimum if math.isfinite(minimum) else None,
                     **identity})
            response.close()
            message = ("HTTP 429 request retry budget exhausted; server delay was not shortened. "
                       "Preserve partial progress and use plan-resume for separately approved "
                       "recovery.")
            if last_info:
                message += f" Last service error: {service_errors.summary(last_info)}"
            raise service_errors.attach(RetryExhausted(message), last_info)
        observe({"event": "retry_wait", "attempt": attempt, "next_attempt": attempt + 1,
                 "delay_seconds": delay, "status": 429,
                 "reason": "server_delay" if server_delay is not None else "exponential_backoff",
                 **identity})
        # Release throttled responses before waiting; do not retain sockets over backoff.
        response.close()
        until = monotonic() + delay
        while monotonic() < until:
            if cancelled():
                raise RetryCancelled("ARM request cancelled during throttling backoff.")
            sleep(min(1.0, until - monotonic()))
    raise AssertionError("unreachable retry state")


def sdk_retry_policy(observe: Callable[[dict[str, Any]], None] = report, **clock: Any) -> Any:
    """Replace, rather than wrap, Azure SDK's general-purpose RetryPolicy."""
    from azure.core.pipeline.policies import HTTPPolicy

    class Arm429Policy(HTTPPolicy):
        def send(self, request: Any) -> Any:
            def timeout(remaining: float) -> None:
                for key in ("connection_timeout", "read_timeout"):
                    configured = request.context.options.get(key)
                    request.context.options[key] = min(
                        remaining, float(configured) if configured is not None else remaining)

            return request_sequence(
                lambda: self.next.send(request), request.http_request,
                observe=observe, before_send=timeout, **clock,
            )

    return Arm429Policy()
