"""Model facts that come from service contracts, with their sources.

Nothing here decides which deployment a user should pick. These are the constraints
the target services publish; discovery reports them next to each candidate.
"""
from __future__ import annotations

# Azure AI Search `AzureOpenAIParameters.modelName` (vectorizer, embedding skill and
# graph extraction) is the `AzureOpenAIModelName` enum. Source, public REST spec:
# https://github.com/Azure/azure-rest-api-specs/blob/main/specification/search/data-plane/Search/preview/2026-08-01-preview/search.json
# (definitions.AzureOpenAIModelName, the latest public preview as of 2026-10).
SEARCH_SPEC_URL = ("https://github.com/Azure/azure-rest-api-specs/blob/main/specification/"
                   "search/data-plane/Search/preview/2026-08-01-preview/search.json")
_PUBLIC_2026_08_EMBEDDING = frozenset({
    "text-embedding-ada-002", "text-embedding-3-large", "text-embedding-3-small",
})
_PUBLIC_2026_08_CHAT = frozenset({
    "gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
    "gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-5.1", "gpt-5.2",
    "gpt-5.4", "gpt-5.4-mini", "gpt-5.4-nano", "gpt-5.5",
    "gpt-5.6-sol", "gpt-5.6-terra", "gpt-5.6-luna",
})
# 2026-11-01-preview adds these values. That version is not in the public spec repo yet;
# the delta is pinned from the service preview and labeled as such wherever it is reported.
_PREVIEW_2026_11_DELTA = frozenset({"gpt-6-astra", "gpt-6-sol", "gpt-6-luna", "gpt-6.1-sol"})

SEARCH_MODEL_NAMES: dict[str, dict[str, frozenset[str]]] = {
    "2026-08-01-preview": {"chat": _PUBLIC_2026_08_CHAT, "embedding": _PUBLIC_2026_08_EMBEDDING},
    "2026-11-01-preview": {"chat": _PUBLIC_2026_08_CHAT | _PREVIEW_2026_11_DELTA,
                           "embedding": _PUBLIC_2026_08_EMBEDDING},
}
SEARCH_MODEL_SOURCES = {
    "2026-08-01-preview": f"AzureOpenAIModelName enum, {SEARCH_SPEC_URL}",
    "2026-11-01-preview": (f"AzureOpenAIModelName enum, {SEARCH_SPEC_URL}, plus "
                           f"{', '.join(sorted(_PREVIEW_2026_11_DELTA))} pinned from the "
                           "2026-11-01-preview service (not yet in the public spec)"),
}


def search_admits(api_version: str, role: str, model: str | None) -> bool | None:
    """True/False when the Search API publishes a modelName list; None when it doesn't."""
    names = SEARCH_MODEL_NAMES.get(api_version)
    if names is None or not model:
        return None
    return model in names["chat" if role in ("chat", "kb") else "embedding"]


# Native output dimensions, used only to fill in a value the user didn't pass. This is a
# lookup, not an admission list: any other embedding model gets an explicit
# --embedding-dimensions or an opt-in probe. Source:
# https://learn.microsoft.com/azure/ai-foundry/openai/concepts/models#embeddings
NATIVE_EMBEDDING_DIMENSIONS = {
    "text-embedding-3-large": 3072, "text-embedding-3-small": 1536,
    "text-embedding-ada-002": 1536,
}


def embedding_dimensions_error(model: str | None, dimensions: int) -> str | None:
    """Reject only what the Search contract rejects for `dimensions`."""
    native = NATIVE_EMBEDDING_DIMENSIONS.get(str(model or ""))
    # AzureOpenAIEmbeddingSkill.dimensions: "Only supported in text-embedding-3 and later
    # models" (same spec). ada-002 therefore always produces its native size.
    if model == "text-embedding-ada-002" and dimensions != native:
        return (f"{model} has a fixed {native}-dimension output; Search does not admit a "
                f"`dimensions` override for it ({SEARCH_SPEC_URL})")
    if native is not None and str(model).startswith("text-embedding-3") and dimensions > native:
        return f"{model} outputs at most {native} dimensions"
    return None
