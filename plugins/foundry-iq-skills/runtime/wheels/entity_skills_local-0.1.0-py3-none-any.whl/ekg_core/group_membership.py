"""Transitive group membership for Azure role checks.

Azure RBAC applies a role assigned to a group to every member of that group, including
members of nested groups:
https://learn.microsoft.com/azure/role-based-access-control/overview#security-principal
`az role assignment list --assignee-object-id` returns only assignments made to that exact
object, so a check that filters on the principal misses every group grant. Role checks list
the assignments at a scope (inherited ones included) and match the principal or any group
it belongs to. Group IDs come from Microsoft Graph getMemberObjects, which is transitive:
https://learn.microsoft.com/graph/api/directoryobject-getmemberobjects
Display names for reporting come from directoryObjects/getByIds:
https://learn.microsoft.com/graph/api/directoryobject-getbyids
"""

from __future__ import annotations

import json
import threading
from typing import Any, Callable, Iterable

from .az_identity import IdentityError, az_json

GRAPH = "https://graph.microsoft.com/v1.0"
GRAPH_RESOURCE = "https://graph.microsoft.com"
UNREADABLE = "group membership could not be read"
_GET_BY_IDS_LIMIT = 1000
_CACHE: dict[tuple[int, str, bool], tuple[Any, "Membership"]] = {}
_CACHE_LOCK = threading.Lock()


def _post(url: str, body: dict[str, Any], runner: Callable[..., Any]) -> Any:
    return az_json(["rest", "--method", "post", "--url", url,
                    "--body", json.dumps(body, separators=(",", ":")),
                    "--headers", "Content-Type=application/json",
                    "--resource", GRAPH_RESOURCE], runner=runner)


class Membership:
    """One principal's transitive groups, read from Graph at most once per run."""

    def __init__(self, principal: str, principal_type: str, runner: Callable[..., Any],
                 *, signed_in: bool = False) -> None:
        self.principal = principal.casefold()
        self.principal_type = principal_type
        self.signed_in = signed_in
        self.runner = runner
        self._lock = threading.Lock()
        self._resolved = False
        self._groups: frozenset[str] | None = None
        self._names: dict[str, str | None] = {}

    def _url(self) -> str:
        if self.signed_in and self.principal_type == "User":
            return f"{GRAPH}/me/getMemberObjects"
        if self.principal_type == "ServicePrincipal":
            return f"{GRAPH}/servicePrincipals/{self.principal}/getMemberObjects"
        return f"{GRAPH}/directoryObjects/{self.principal}/getMemberObjects"

    def _read(self) -> frozenset[str] | None:
        url: str | None = self._url()
        seen: set[str] = set()
        found: set[str] = set()
        try:
            while url:
                if not url.startswith(GRAPH + "/") or url in seen:
                    raise ValueError("unsafe or repeated nextLink")
                seen.add(url)
                page = _post(url, {"securityEnabledOnly": False}, self.runner)
                values = page.get("value") if isinstance(page, dict) else None
                if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
                    raise ValueError("getMemberObjects returned no value array")
                found.update(value.casefold() for value in values)
                url = page.get("@odata.nextLink")
                if url is not None and not isinstance(url, str):
                    raise ValueError("nextLink is malformed")
        except (IdentityError, ValueError):
            return None
        return frozenset(found)

    @property
    def groups(self) -> frozenset[str] | None:
        """Every group the principal is in, nested included; None if Graph can't be read."""
        with self._lock:
            if not self._resolved:
                self._groups = self._read()
                self._resolved = True
            return self._groups

    @property
    def readable(self) -> bool:
        return self.groups is not None

    def prefetch(self) -> None:
        threading.Thread(target=lambda: self.groups, daemon=True).start()

    def principals(self) -> list[str]:
        """The principal first, then its groups in sorted order."""
        return [self.principal, *sorted(self.groups or ())]

    def holder(self, principal_id: Any) -> str | None:
        """'direct' for the principal itself, the group ID for a group it's in, else None."""
        value = str(principal_id or "").casefold()
        if not value:
            return None
        if value == self.principal:
            return "direct"
        return value if value in (self.groups or ()) else None

    def names(self, ids: Iterable[str]) -> dict[str, str | None]:
        wanted = sorted({i.casefold() for i in ids} - set(self._names))
        for start in range(0, len(wanted), _GET_BY_IDS_LIMIT):
            chunk = wanted[start:start + _GET_BY_IDS_LIMIT]
            try:
                page = _post(f"{GRAPH}/directoryObjects/getByIds",
                             {"ids": chunk, "types": ["group"]}, self.runner)
                values = page.get("value") if isinstance(page, dict) else None
            except IdentityError:
                values = None
            for item in values if isinstance(values, list) else ():
                if isinstance(item, dict) and isinstance(item.get("id"), str):
                    self._names[item["id"].casefold()] = item.get("displayName")
            for gid in chunk:
                self._names.setdefault(gid, None)
        return {i.casefold(): self._names.get(i.casefold()) for i in ids}

    def via_group(self, group_id: str) -> dict[str, Any]:
        return {"id": group_id, "display_name": self.names([group_id])[group_id.casefold()]}


def member_groups(principal: str, principal_type: str, runner: Callable[..., Any],
                  *, signed_in: bool = False) -> Membership:
    """The shared, per-run Membership for one principal and one Azure CLI runner."""
    key = (id(runner), principal.casefold(), signed_in)
    with _CACHE_LOCK:
        hit = _CACHE.get(key)
        # The cache holds the runner, so its id can't be reused while the entry exists.
        if hit is not None and hit[0] is runner:
            return hit[1]
        membership = Membership(principal, principal_type, runner, signed_in=signed_in)
        _CACHE[key] = (runner, membership)
        return membership
