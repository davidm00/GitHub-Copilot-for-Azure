"""Parse Azure and OpenAI error responses into a bounded, redacted service_error.

A service_error is a plain dict: ``status`` (int or None) plus, only when known,
``code``, ``message``, ``details`` (list of ``{code, message[, target]}``) and
``request_id``. It never carries the raw body, request body, headers or tokens.
"""
from __future__ import annotations

import html
import json
import re
from http import HTTPStatus
from typing import Any, Mapping

MESSAGE_LIMIT = 2000
DETAIL_LIMIT = 500
MAX_DETAILS = 10
_FIELD_LIMIT = 200
_BODY_LIMIT = 1_000_000
_REQUEST_ID_HEADERS = ("x-ms-request-id", "request-id", "apim-request-id",
                       "x-request-id", "x-ms-client-request-id")
_REDACTIONS = (
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+"), "Bearer [redacted]"),
    (re.compile(r"\beyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*"), "[redacted]"),
    (re.compile(r"(?i)\b(sig=)[^&\s\"'<>]+"), r"\1[redacted]"),
    (re.compile(r"(?i)\b(AccountKey=|SharedAccessKey=)[^;\s\"'<>]+"), r"\1[redacted]"),
    (re.compile(r"(?i)([\"'](?:api[-_]?key|key)[\"']\s*:\s*[\"'])[^\"']*([\"'])"),
     r"\1[redacted]\2"),
    (re.compile(r"(?i)\b(api[-_]?key\s*[=:]\s*|key=)[^\s,;&\"'<>]+"), r"\1[redacted]"),
)
_PHRASES = {status.phrase.casefold(): int(status) for status in HTTPStatus}


def redact(text: str) -> str:
    for pattern, replacement in _REDACTIONS:
        text = pattern.sub(replacement, text)
    return text


def _clean(value: Any, limit: int) -> str | None:
    if value is None or isinstance(value, (dict, list)):
        return None
    text = redact(" ".join(str(value).split()))
    if not text:
        return None
    return text if len(text) <= limit else text[:limit - 3] + "..."


def _text(body: Any) -> str:
    if isinstance(body, (bytes, bytearray)):
        return bytes(body[:_BODY_LIMIT]).decode("utf-8", errors="replace")
    return str(body)[:_BODY_LIMIT]


def _detail(item: Any) -> dict[str, str] | None:
    if not isinstance(item, dict):
        return None
    detail = {key: value for key, value in (
        ("code", _clean(item.get("code") or item.get("Code"), _FIELD_LIMIT)),
        ("message", _clean(item.get("message") or item.get("Message")
                           or item.get("errorMessage"), DETAIL_LIMIT)),
        ("target", _clean(item.get("target") or item.get("key"), _FIELD_LIMIT)),
    ) if value}
    return detail if detail.get("code") or detail.get("message") else None


def _from_json(data: Any) -> tuple[Any, Any, list[Any]] | None:
    if not isinstance(data, dict):
        return None
    error = data.get("error")
    if isinstance(error, dict):
        details = list(error.get("details") or []) if isinstance(error.get("details"), list) else []
        inner = error.get("innererror") or error.get("innerError")
        for _ in range(5):
            if not isinstance(inner, dict):
                break
            details.append(inner)
            inner = inner.get("innererror") or inner.get("innerError")
        return error.get("code") or error.get("type"), error.get("message"), details
    if isinstance(error, str):
        return error, data.get("error_description") or data.get("message"), []
    odata = data.get("odata.error")
    if isinstance(odata, dict):
        message = odata.get("message")
        if isinstance(message, dict):
            message = message.get("value")
        return odata.get("code"), message, []
    code = data.get("code") or data.get("Code")
    message = data.get("message") or data.get("Message")
    if code or message:
        details = data.get("details") if isinstance(data.get("details"), list) else []
        return code, message, list(details)
    return None


def _from_xml(text: str) -> tuple[Any, Any, list[Any]] | None:
    def tag(name: str) -> str | None:
        found = re.search(rf"<{name}>(.*?)</{name}>", text, re.S)
        return html.unescape(found.group(1)) if found else None

    code, message = tag("Code"), tag("Message")
    if not (code or message):
        return None
    detail = tag("AuthenticationErrorDetail")
    return code, message, ([{"code": "AuthenticationErrorDetail", "message": detail}]
                           if detail else [])


def _plain(text: str) -> str:
    if re.search(r"<[A-Za-z!/][^>]*>", text):
        text = re.sub(r"(?is)<(script|style)\b.*?</\1\s*>", " ", text)
        text = html.unescape(re.sub(r"<[^>]+>", " ", text))
    return text


def _header(headers: Any, name: str) -> str | None:
    if not headers:
        return None
    try:
        items = headers.items()
    except AttributeError:
        return None
    for key, value in items:
        if str(key).casefold() == name and value:
            return str(value)
    return None


def describe(status: int | None, body: Any, headers: Mapping[str, Any] | None = None) -> dict:
    """Return a redacted service_error for an HTTP status, response body and headers."""
    parsed = None
    if isinstance(body, (dict, list)):
        parsed = _from_json(body)
        text = ""
    else:
        text = _text(body) if body is not None else ""
        stripped = text.strip()
        if stripped[:1] in "{[" and stripped:
            try:
                parsed = _from_json(json.loads(stripped))
            except ValueError:
                parsed = None
        if parsed is None and stripped.startswith("<"):
            parsed = _from_xml(stripped)
    if parsed is None:
        code, message, details = None, _plain(text) if text else None, []
    else:
        code, message, details = parsed
    info: dict[str, Any] = {"status": int(status) if isinstance(status, int) else None}
    code = _clean(code, _FIELD_LIMIT) or _clean(_header(headers, "x-ms-error-code"), _FIELD_LIMIT)
    if code:
        info["code"] = code
    message = _clean(message, MESSAGE_LIMIT)
    if message:
        info["message"] = message
    cleaned = [detail for detail in map(_detail, details) if detail][:MAX_DETAILS]
    if cleaned:
        info["details"] = cleaned
    for name in _REQUEST_ID_HEADERS:
        request_id = _clean(_header(headers, name), _FIELD_LIMIT)
        if request_id:
            info["request_id"] = request_id
            break
    return info


def summary(info: Mapping[str, Any] | None) -> str:
    """Render ``HTTP 400 Code: message (request id x)``, omitting absent parts."""
    info = info or {}
    head = " ".join(part for part in (
        f"HTTP {info['status']}" if info.get("status") is not None else "",
        str(info.get("code") or ""),
    ) if part)
    message = info.get("message")
    if not (info.get("code") or message):
        message = "no service error body"
    text = f"{head}: {message}" if head and message else (head or str(message))
    if info.get("request_id"):
        text += f" (request id {info['request_id']})"
    return text


def with_summary(message: str, info: Mapping[str, Any] | None) -> str:
    """Append the service summary to an existing message, keeping its prefix."""
    return f"{message}: {summary(info)}" if info else message


def _body(response: Any) -> Any:
    for name in ("content", "body", "text"):
        try:
            value = getattr(response, name, None)
            if callable(value):
                value = value()
        except Exception:
            continue
        if isinstance(value, (bytes, bytearray, str)):
            return value
    return None


def from_response(response: Any) -> dict | None:
    """Describe an httpx/requests/azure-core/urllib response object."""
    if response is None:
        return None
    status = getattr(response, "status_code", None)
    if not isinstance(status, int):
        status = getattr(response, "status", None)
    if not isinstance(status, int):
        return None
    return describe(status, _body(response), getattr(response, "headers", None))


def from_cli_stderr(stderr: Any) -> dict | None:
    """Describe Azure CLI stderr such as ``ERROR: Forbidden({"error": {...}})``."""
    text = _text(stderr or "").strip()
    if not text:
        return None
    text = re.sub(r"(?im)^\s*(ERROR|WARNING):\s*", "", text).strip()
    coded = re.match(r"\((\w+)\)\s*([^\r\n]*)", text)
    if coded:
        return describe(None, {"code": coded.group(1), "message": coded.group(2)})
    status = None
    phrase = re.match(r"([A-Za-z][A-Za-z -]{2,40}?)\s*\(", text)
    if phrase:
        status = _PHRASES.get(phrase.group(1).strip().casefold())
    start, end = text.find("{"), text.rfind("}")
    if 0 <= start < end:
        try:
            parsed = json.loads(text[start:end + 1])
        except ValueError:
            parsed = None
        if _from_json(parsed) is not None:
            return describe(status, parsed)
    return describe(status, text)


def from_exception(exc: BaseException | None) -> dict | None:
    """Return a service_error for azure-core, openai, httpx, urllib or duck-typed errors."""
    if exc is None:
        return None
    attached = getattr(exc, "service_error", None)
    if isinstance(attached, dict):
        return attached
    response = getattr(exc, "response", None)
    info = from_response(response)
    if info is not None:
        if not (info.get("code") or info.get("message")):
            fallback = _exception_error(exc)
            info.update({key: value for key, value in fallback.items() if value})
        return info
    status = getattr(exc, "status_code", None)
    if not isinstance(status, int):
        status = getattr(exc, "code", None) if hasattr(exc, "read") else None
    body = getattr(exc, "body", None)
    if not isinstance(status, int) or not (
            body is not None or hasattr(exc, "read") or getattr(exc, "error", None) is not None):
        return None
    headers = getattr(exc, "headers", None) or getattr(exc, "hdrs", None)
    if body is None and hasattr(exc, "read"):
        try:
            body = exc.read(_BODY_LIMIT)
        except Exception:
            body = None
    info = describe(status, body, headers)
    if not (info.get("code") or info.get("message")):
        info.update({key: value for key, value in _exception_error(exc).items() if value})
    return info


def _exception_error(exc: BaseException) -> dict[str, Any]:
    error = getattr(exc, "error", None)
    code = getattr(error, "code", None) or getattr(exc, "error_code", None)
    message = getattr(error, "message", None) or getattr(exc, "message", None)
    return {"code": _clean(code, _FIELD_LIMIT), "message": _clean(message, MESSAGE_LIMIT)}


def find(exc: BaseException | None) -> dict | None:
    """Find the first service_error on an exception or its cause/context chain."""
    seen: set[int] = set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        info = from_exception(exc)
        if info is not None:
            return info
        exc = exc.__cause__ or exc.__context__
    return None


def attach(exc: BaseException, info: Mapping[str, Any] | None) -> BaseException:
    """Set ``exc.service_error`` when info is known and return the exception."""
    if info:
        exc.service_error = dict(info)  # type: ignore[attr-defined]
    return exc
