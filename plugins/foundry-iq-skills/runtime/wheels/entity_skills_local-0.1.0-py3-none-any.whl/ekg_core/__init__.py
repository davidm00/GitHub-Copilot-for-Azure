"""Shared, harness-neutral Entity Graph contracts."""

from .models import (
    BuildSpec,
    Capability,
    DeploymentDescriptor,
    Event,
    Ontology,
    OntologyMode,
    Operation,
    Plan,
    ProvisioningSpec,
    Target,
)



def package_version() -> str:
    """The installed distribution's version, or "checkout" when run from source."""
    from importlib.metadata import PackageNotFoundError, version
    for dist_name in ("entity-skills-local",):
        try:
            return version(dist_name)
        except PackageNotFoundError:
            continue
    return "checkout"


def skill_user_agent() -> str:
    """HTTP User-Agent attribution token per http-contract.md."""
    return f"foundry-iq-skill-v{package_version()}"


__all__ = [
    "BuildSpec", "Capability", "DeploymentDescriptor", "Event", "Ontology",
    "OntologyMode", "Operation", "Plan",
    "ProvisioningSpec", "Target", "package_version", "skill_user_agent",
]
