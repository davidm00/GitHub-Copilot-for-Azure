"""Harness adapters over the local Entity Graph contracts."""
