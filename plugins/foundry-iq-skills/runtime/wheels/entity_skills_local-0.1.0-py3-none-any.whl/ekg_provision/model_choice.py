"""Default models, versions and capacity for new deployments, read from the region's catalog.

The chat default names a model, not a version: the version is the region catalog's default
(``isDefaultVersion``). ``latest`` picks the newest generally available chat model the
region offers, that the pinned Search API admits and that has free quota. Capacity, when
not given, is the free quota up to the role's default.
"""
from __future__ import annotations

from typing import Any

from ekg_core.models import MODEL_DEPLOYMENT_CAPACITY_DEFAULTS, TPM_CAPACITY_SKUS
from ekg_core.search_models import search_admits

# Search API version the Entity Graph build pins; "latest" only picks models it admits.
ENTITY_SEARCH_API = "2026-11-01-preview"
LATEST = "latest"
DEFAULT_SKU = "GlobalStandard"
# (model, version): None means the region catalog's default version.
MODEL_DEFAULTS: dict[str, tuple[str, str | None]] = {
    "embedding": ("text-embedding-3-small", "1"),
    "chat": ("gpt-5.6-luna", None),
}
# Below this many thousand tokens per minute a build crawls; ask for quota instead.
MIN_CAPACITY_K_TPM = 50
_GA = ("generallyavailable", "stable")


def _models(catalog: list[Any]) -> list[dict[str, Any]]:
    return [item["model"] for item in catalog
            if isinstance(item, dict) and isinstance(item.get("model"), dict)
            and item["model"].get("format", "OpenAI") == "OpenAI"]


def offered_versions(catalog: list[Any], model: str) -> list[dict[str, Any]]:
    return [m for m in _models(catalog) if m.get("name") == model]


def catalog_version(catalog: list[Any], model: str) -> str | None:
    """The region's default version of ``model``, else its newest listed version."""
    versions = offered_versions(catalog, model)
    chosen = next((m for m in versions if m.get("isDefaultVersion")), None) or max(
        versions, key=lambda m: str(m.get("version")), default=None)
    return str(chosen["version"]) if chosen and chosen.get("version") else None


def free_k_tpm(usages: list[Any], sku: str, model: str) -> int | None:
    """Free quota in thousands of TPM; None when this SKU doesn't count TPM."""
    if sku not in TPM_CAPACITY_SKUS:
        return None
    name = f"OpenAI.{sku}.{model}"
    for usage in usages:
        if isinstance(usage, dict) and (usage.get("name") or {}).get("value") == name:
            return max(0, int(usage.get("limit") or 0) - int(usage.get("currentValue") or 0))
    return 0


def newest_chat_model(catalog: list[Any], usages: list[Any], sku: str = DEFAULT_SKU) -> str | None:
    """The newest GA chat model the region offers in ``sku``, Search admits and has quota."""
    candidates = []
    for model in _models(catalog):
        name = str(model.get("name") or "")
        chat = str((model.get("capabilities") or {}).get("chatCompletion", "")).lower() == "true"
        skus = {s.get("name") for s in model.get("skus") or [] if isinstance(s, dict)}
        if (chat and str(model.get("lifecycleStatus", "")).casefold() in _GA and sku in skus
                and search_admits(ENTITY_SEARCH_API, "chat", name)
                and (free_k_tpm(usages, sku, name) or 0) >= MIN_CAPACITY_K_TPM):
            candidates.append((str(model.get("version")), name))
    return max(candidates)[1] if candidates else None


def capacity(role: str, free: int | None) -> int | None:
    """Capacity to request when none was given: the default, or less when less is free."""
    default = MODEL_DEPLOYMENT_CAPACITY_DEFAULTS[role]
    if free is None or free >= default:
        return None
    return free if free >= MIN_CAPACITY_K_TPM else None
