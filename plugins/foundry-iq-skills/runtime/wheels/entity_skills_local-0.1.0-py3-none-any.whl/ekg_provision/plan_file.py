"""The approved provisioning plan, saved by `plan` so `apply` never reconstructs its flags.

`plan` writes `<state>/provision-plans/<plan-id>.json` with the exact plan arguments and
the effective spec. `apply --plan-file <file> --plan-id <id> --confirm-writes` replays
those arguments unchanged; apply still recomputes the plan ID from live state and runs
every quota, permission, policy and drift check, so a saved plan never authorizes stale
operations. The file holds names, IDs and settings only; never credentials or tokens.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any
from ekg_core.files import atomic_write_text

VERSION = 1
# Flags apply may add to a saved plan; everything else must come from the file.
_APPLY_ONLY = {"--plan-file": True, "--plan-id": True, "--confirm-writes": False,
               "--json": False, "--state-dir": True}


class PlanFileError(ValueError):
    """The saved plan is missing, altered, or combined with conflicting flags."""


def root(state_dir: str | None) -> Path:
    base = Path(state_dir).parent if state_dir else Path.cwd() / ".entity"
    return base / "provision-plans"


def plan_args(raw: list[str]) -> list[str]:
    """Resource arguments of a plan or apply invocation, without command and run flags."""
    kept: list[str] = []
    tokens = iter(raw)
    for token in tokens:
        name = token.split("=", 1)[0]
        if token in ("plan", "apply"):
            continue
        if name in _APPLY_ONLY:
            if _APPLY_ONLY[name] and "=" not in token:
                next(tokens, None)
            continue
        kept.append(token)
    return kept


def _digest(body: dict[str, Any]) -> str:
    raw = json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def write(state_dir: str | None, plan_id: str, args: list[str], spec: dict[str, Any],
          runtime_version: str) -> Path:
    body = {"version": VERSION, "plan_id": plan_id, "args": args, "spec": spec,
            "runtime_version": runtime_version}
    path = root(state_dir) / f"{plan_id}.json"
    atomic_write_text(path, json.dumps({**body, "sha256": _digest(body)}, indent=2,
                                       sort_keys=True) + "\n")
    return path


def read(path: str | Path) -> dict[str, Any]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise PlanFileError(f"saved plan {path} can't be read: {error}") from error
    if not isinstance(data, dict) or data.get("version") != VERSION:
        raise PlanFileError(f"saved plan {path} has an unsupported format; run plan again")
    digest = data.pop("sha256", None)
    if digest != _digest(data):
        raise PlanFileError(f"saved plan {path} was modified after planning; run plan again")
    if (not isinstance(data.get("args"), list)
            or not all(isinstance(item, str) for item in data["args"])):
        raise PlanFileError(f"saved plan {path} has no plan arguments; run plan again")
    return data


def find(state_dir: str | None, plan_id: str) -> dict[str, Any] | None:
    path = root(state_dir) / f"{plan_id}.json"
    if not path.is_file():
        return None
    try:
        return read(path)
    except PlanFileError:
        return None


def apply_argv(raw: list[str]) -> list[str]:
    """Rewrite `apply --plan-file F --plan-id X ...` into apply with the saved arguments."""
    extra = plan_args(raw)
    if extra:
        raise PlanFileError(
            "--plan-file can't be combined with resource flags (" + " ".join(extra[:4])
            + "); a changed setting needs a new plan and approval")
    path = plan_id = None
    tokens = list(raw)
    for index, token in enumerate(tokens):
        if token == "--plan-file" and index + 1 < len(tokens):
            path = tokens[index + 1]
        elif token.startswith("--plan-file="):
            path = token.split("=", 1)[1]
        elif token == "--plan-id" and index + 1 < len(tokens):
            plan_id = tokens[index + 1]
        elif token.startswith("--plan-id="):
            plan_id = token.split("=", 1)[1]
    if not path:
        raise PlanFileError("--plan-file needs a path")
    saved = read(path)
    if plan_id != saved["plan_id"]:
        raise PlanFileError(f"--plan-id {plan_id} isn't the saved plan {saved['plan_id']}")
    passthrough = [token for index, token in enumerate(tokens)
                   if token in ("--json", "--confirm-writes")
                   or token == "--state-dir" or (index and tokens[index - 1] == "--state-dir")
                   or token.startswith("--state-dir=")]
    return ["apply", *saved["args"], "--plan-id", plan_id, *passthrough]


def differences(approved: dict[str, Any], requested: dict[str, Any]) -> list[dict[str, Any]]:
    """Fields whose approved and requested values differ, as dotted paths."""
    rows: list[dict[str, Any]] = []

    def walk(path: str, left: Any, right: Any) -> None:
        if isinstance(left, dict) and isinstance(right, dict):
            for key in sorted(set(left) | set(right)):
                walk(f"{path}.{key}" if path else key, left.get(key), right.get(key))
        elif left != right:
            rows.append({"field": path, "approved": left, "requested": right})

    walk("", approved, json.loads(json.dumps(requested)))
    return rows
