from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from ekg_core import package_version
from ekg_core.cli import Blocked, add_command, new_parser, parse, report, say
from ekg_core.execution import ApprovalRequired, serialize_events
from ekg_core.models import (
    MODEL_DEPLOYMENT_CAPACITY_DEFAULTS, BuildAccessSpec,
    ModelDeploymentSpec, NetworkSpec, ProvisioningSpec, PublicTestSpec,
    PublicDataSpec, Target,
)
from .backends import AzureSdkBackend, ProvisioningError
from .capacity import CapacityError, capacity_plan, capacity_update, quota_check
from .journal import ProvisioningJournal
# Recommended defaults for a new deployment, shown as such on the approval card. Any model,
# version and SKU the account's region lists (`discover --models-for`) is accepted.
from .model_choice import (DEFAULT_SKU, LATEST, MIN_CAPACITY_K_TPM, MODEL_DEFAULTS,
                           catalog_version, free_k_tpm, newest_chat_model, offered_versions)
from .planner import plan
from .renderers import write_artifacts
from .rbac import RbacError, RbacSpec, rbac_check, rbac_grant, rbac_review
from .smoke import AzureTransport, SmokeError, SmokeSpec, run_smoke, smoke_plan
from .search import (DEFAULT_SEARCH_LOCATION, SEARCH_SKUS, SERVERLESS_WARNING,
                     graph_api_problem, region_name)
from ekg_core.files import atomic_write_text

PROG = "entity-graph-provision"
_DEFAULTS = {
    "plan_id": None, "confirm_writes": False, "run_id": None, "output": None, "state_dir": None,
    "smoke_id": None, "smoke_container": None, "smoke_vpn_egress_ip": None,
    "smoke_embedding_deployment": None, "rbac_principal_object_id": None,
    "rbac_principal_type": None, "rbac_container": None, "capacity_deployment": None,
    "capacity": None, "search_identity_name": None, "storage_container": None,
    "operator_object_id": None, "operator_principal_type": "User",
    "cache_storage_name": None, "cache_storage_resource_id": None, "cache_same_as_source": False,
    "search_location": None, "openai_location": None,
    "search_subscription_id": None, "search_resource_group": None,
    "embedding_openai_resource_id": None, "chat_openai_resource_id": None,
    "kb_openai_resource_id": None,
    "kb_chat_deployment": None, "use_system_identity": False,
}
# Gated verb -> the review verb whose plan ID it takes.
_GATED = {"apply": "plan", "resume-apply": "plan-resume", "smoke-run": "plan-smoke",
          "rbac-grant": "plan-rbac", "capacity-update": "plan-capacity",
          "connect-apply": "connect",
          "cleanup-approve": "plan-cleanup"}
_LIVE = ("inspect", "apply", "verify", "plan-resume", "resume-apply", "smoke-run",
         "rbac-check", "rbac-grant", "quota", "plan-capacity", "capacity-update")
_LIVE_TENANT = ("inspect", "verify", "quota", "plan-capacity", "capacity-update")
# Commands whose plan ID covers the operator grants; each reads the held roles live.
_HELD_ROLE_COMMANDS = ("plan", "render", "inspect", "apply", "verify", "plan-resume",
                       "resume-apply", "plan-smoke", "smoke-run", "plan-rbac", "rbac-check",
                       "rbac-grant")


def _account() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--subscription-id", help="required for live Azure commands")
    parser.add_argument("--tenant-id", help="required for default/private live inspect and verify")
    parser.add_argument("--resource-group")
    parser.add_argument("--state-dir", help="local provisioning journal folder "
                                            "(default ./.entity/provision-runs)")
    return parser


def _resources() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False, parents=[_account()])
    parser.add_argument("--location", default="westus3",
                        help="Azure region for the resource group, storage and models "
                             "(default westus3)")
    parser.add_argument("--search-location",
                        help="Azure region for the Search service (default --location; "
                             f"{DEFAULT_SEARCH_LOCATION}, where Search has the graph API, "
                             "for --public-data-entra)")
    parser.add_argument("--openai-location",
                        help="Azure region for the Azure OpenAI account when split from --location")
    parser.add_argument("--search-subscription-id",
                        help="subscription for the Search service when it must live apart from "
                             "storage and models (default --subscription-id)")
    parser.add_argument("--search-resource-group",
                        help="resource group for the Search service when it must live apart "
                             "(default --resource-group)")
    parser.add_argument("--search-name")
    parser.add_argument("--storage-name")
    parser.add_argument("--cache-storage-name",
                        help="dedicated StorageV2 account for the Knowledge Source enrichment cache "
                             "(3..24 lowercase alphanumeric chars, e.g. <alias><short>cache)")
    parser.add_argument("--cache-same-as-source", action="store_true",
                        help="explicitly share the source documents storage account as the "
                             "enrichment cache (grants Search identity write access on source)")
    parser.add_argument("--openai-name")
    parser.add_argument("--content-understanding-name")
    parser.add_argument("--search-sku", default="serverless", choices=SEARCH_SKUS,
                        help="new service tier (default serverless); Dedicated tiers require explicit opt-in")
    parser.add_argument("--create-resource-group", action="store_true")
    parser.add_argument("--network-vnet-name")
    parser.add_argument("--network-subnet-name")
    parser.add_argument("--network-vnet-cidr")
    parser.add_argument("--network-subnet-cidr")
    parser.add_argument("--public-test", action="store_true",
                        help="opt in to a time-limited synthetic-only public test")
    parser.add_argument("--public-test-mode", choices=("ip_allowlist", "entra_only"),
                        help="explicit public network posture; never inferred from missing IPs")
    parser.add_argument("--public-test-tenant-id")
    parser.add_argument("--public-test-egress-ip", action="append")
    parser.add_argument("--public-test-expires-at")
    parser.add_argument("--synthetic-data-only", action="store_true")
    parser.add_argument("--public-data-entra", action="store_true",
                        help="bounded public-corpus-only Entra setup; not synthetic public-test")
    parser.add_argument("--public-data-only", action="store_true",
                        help="acknowledge genuinely public corpus only, no non-public data")
    parser.add_argument("--search-identity-name",
                        help="opt-in: create and attach this user-assigned identity for Search "
                             "(build access); default is Search's system-assigned identity")
    parser.add_argument("--storage-container", help="private Blob container to create "
                                                    "(build access)")
    parser.add_argument("--operator-object-id",
                        help="your Entra object ID; gets the 4 Build roles (build access)")
    parser.add_argument("--operator-principal-type", choices=("User", "ServicePrincipal"),
                        default="User")
    for role, (model, version) in MODEL_DEFAULTS.items():
        parser.add_argument(f"--{role}-deployment",
                            help=f"create the {role} model deployment with this name")
        parser.add_argument(f"--{role}-model",
                            help=f"{role} model name (recommended default {model}"
                                 + ("; `latest` picks the newest chat model the region offers"
                                    if role == "chat" else "")
                                 + "; `discover --models-for` lists what the region offers)")
        parser.add_argument(f"--{role}-model-version",
                            help=f"{role} model version (default {version or 'the region catalog default'})")
        parser.add_argument(f"--{role}-sku",
                            help="ARM deployment SKU, any the region's catalog offers "
                                 "(recommended default GlobalStandard)")
        parser.add_argument(f"--{role}-capacity", type=int,
                            help="capacity (default: free quota up to "
                                 f"{MODEL_DEPLOYMENT_CAPACITY_DEFAULTS[role]}): "
                                 "thousands of tokens per minute for Standard, "
                                 "GlobalStandard and DataZoneStandard; SKU units otherwise "
                                 f"(default {MODEL_DEPLOYMENT_CAPACITY_DEFAULTS[role]})")
    return parser


def _smoke() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--smoke-id", required=True,
                        help="twelve unique lowercase hexadecimal characters")
    parser.add_argument("--smoke-container", required=True,
                        help="existing approved synthetic-only Blob container")
    parser.add_argument("--smoke-vpn-egress-ip", help="exact single IP bound to the public plan")
    parser.add_argument("--smoke-embedding-deployment",
                        help="existing separately approved embedding deployment, if available")
    return parser


def _rbac() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--rbac-principal-object-id", required=True)
    parser.add_argument("--rbac-principal-type", choices=("User", "ServicePrincipal"),
                        required=True)
    parser.add_argument("--rbac-container", required=True)
    return parser


def _capacity() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--capacity-deployment", required=True,
                        help="existing deployment name")
    parser.add_argument("--capacity", type=int, required=True,
                        help="desired thousands of tokens per minute")
    return parser


def _connect_arguments() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(add_help=False, parents=[_account()])
    parser.add_argument("--search-subscription-id",
                        help="subscription of the Search service when it lives apart from "
                             "storage and models (default --subscription-id)")
    parser.add_argument("--search-resource-group",
                        help="resource group of the Search service when it lives apart "
                             "(default --resource-group)")
    for kind in ("search", "storage", "cache-storage"):
        parser.add_argument(f"--{kind}-name")
    for kind in ("search", "storage", "cache-storage", "search-identity"):
        parser.add_argument(f"--{kind}-resource-id",
                            help=f"exact ARM ID of the existing {kind} resource")
    for kind in ("openai", "embedding-openai", "chat-openai", "kb-openai"):
        parser.add_argument(f"--{kind}-resource-id",
                            help="exact Foundry/OpenAI account ID from `discover --row`")
    parser.add_argument("--openai-name",
                        help="Foundry/OpenAI account name in --resource-group (instead of "
                             "--openai-resource-id)")
    parser.add_argument("--use-system-identity", action="store_true",
                        help="authenticate Search to Storage and OpenAI using its system-assigned managed identity")
    parser.add_argument("--cache-same-as-source", action="store_true",
                        help="explicitly share the source storage account for the enrichment cache")
    parser.add_argument("--storage-container", help="existing private Blob container")
    parser.add_argument("--embedding-deployment")
    parser.add_argument("--chat-deployment")
    parser.add_argument("--kb-chat-deployment")
    parser.add_argument("--embedding-dimensions", type=int,
                        help="embedding dimensions (text-embedding-3 models accept fewer "
                             "than native)")
    parser.add_argument("--probe-embedding-dimensions", action="store_true",
                        help="when the model's native size isn't documented, make one "
                             "embeddings call to measure it")
    for role in ("embedding", "chat"):
        parser.add_argument(f"--{role}-model",
                            help=f"model for a missing {role} deployment (recommended "
                                 "default shown on the card; `discover --models-for` lists "
                                 "the region's models)")
        parser.add_argument(f"--{role}-model-version")
        parser.add_argument(f"--{role}-sku", help="any SKU the region lists for the model")
        parser.add_argument(f"--{role}-capacity", type=int,
                            help="capacity for a missing deployment: thousands of tokens per "
                                 "minute for Standard, GlobalStandard and DataZoneStandard "
                                 f"(recommended default {MODEL_DEPLOYMENT_CAPACITY_DEFAULTS[role]});"
                                 " required in SKU units for any other SKU")
    parser.add_argument("--documents", type=int,
                        help="corpus document count for the extraction estimate")
    return parser


def _discover_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--tenant-id", required=True)
    parser.add_argument("--subscription-id", action="append",
                        dest="discover_subscriptions", metavar="GUID",
                        help="list the resources and deployments in this subscription "
                             "(repeatable); without it, discover lists your subscriptions")
    parser.add_argument("--sub-row", type=int, metavar="N",
                        help="the subscription row the user chose from the subscription "
                             "table; needs that table's --discovery-id")
    parser.add_argument("--all", action="store_true", dest="show_all",
                        help="resource table only: list every resource and deployment, not "
                             "just usable chat and embedding deployments")
    parser.add_argument("--count-roles", action="store_true",
                        help="subscription table only: list every deployment to count "
                             "usable ones per role (slower)")
    parser.add_argument("--resource-group", dest="discover_resource_group",
                        help="only search this resource group of the chosen subscription")
    parser.add_argument("--select", metavar="RESOURCE_ID::DEPLOYMENT",
                        help="validate the user's chosen row (its exact `select` value) and "
                             "print the runtime flags for it")
    parser.add_argument("--row", type=int, metavar="N",
                        help="the deployment row the user chose from the resource table; "
                             "needs that table's --discovery-id and --subscription-id")
    parser.add_argument("--discovery-id", metavar="ID",
                        help="the discovery ID printed with the table the user chose from")
    parser.add_argument("--models-for", metavar="ACCOUNT_RESOURCE_ID",
                        help="list the models, versions and SKUs this account's region "
                             "offers for a new deployment")
    parser.add_argument("--role", choices=("chat", "embedding", "kb"),
                        help="the role to select or list models for")


def _discover(args, runner=None) -> dict:
    import subprocess
    from ekg_core.az_identity import IdentityError, active_az_identity
    from ekg_core.group_membership import member_groups
    from . import discovery

    runner = runner or subprocess.run
    row = getattr(args, "row", None)
    sub_row = getattr(args, "sub_row", None)
    subs = args.discover_subscriptions
    if sum(bool(x) for x in (args.select, args.models_for, row is not None,
                             sub_row is not None)) > 1:
        raise _usage("pass only one of --select, --row, --sub-row or --models-for")
    if (args.select or args.models_for or row is not None) and not args.role:
        raise _usage("--select, --row and --models-for need --role")
    if (row is not None or sub_row is not None) and not getattr(args, "discovery_id", None):
        raise _usage("--row and --sub-row need the --discovery-id printed with the table "
                     "the user chose from")
    if sub_row is not None and subs:
        raise _usage("pass either --sub-row or --subscription-id, not both")
    if row is not None and not subs:
        raise _usage("--row picks from a resource table; pass the --subscription-id that "
                     "table's next_command shows")
    tier1 = not (subs or sub_row is not None or args.select or args.models_for)
    if args.discover_resource_group and tier1:
        raise _usage("--resource-group narrows one subscription; pick the subscription "
                     "first (--sub-row or --subscription-id)")
    if args.count_roles and not tier1:
        raise _usage("--count-roles applies only to the subscription table")
    if getattr(args, "show_all", False) and (tier1 or args.select or args.models_for):
        raise _usage("--all applies only to the resource table")
    client = discovery.client_for(runner, args.tenant_id)
    token = getattr(client, "claims", None) or {}
    caller = token.get("oid")
    caller_type = "ServicePrincipal" if token.get("idtyp") == "app" else "User"
    fallback = []
    if caller is None or not (args.select or args.models_for):
        try:
            identity = active_az_identity(args.tenant_id, runner=runner)
            if caller is None:
                caller, caller_type = (identity["principal_object_id"],
                                       identity["principal_type"])
            fallback = [identity["subscription_id"]] if identity["subscription_id"] else []
        except IdentityError:
            pass
    groups = None
    if caller and not args.models_for:
        groups = member_groups(caller, caller_type, runner, signed_in=True)
        groups.prefetch()
    try:
        if args.models_for:
            return discovery.model_catalog(client, account_id=args.models_for, role=args.role)
        if args.select:
            return discovery.select(client, tenant_id=args.tenant_id, selection=args.select,
                                    role=args.role, caller_object_id=caller,
                                    caller_groups=groups)
        if tier1 or sub_row is not None:
            summary = discovery.subscription_summary(
                client, tenant_id=args.tenant_id, caller_object_id=caller,
                fallback_subscriptions=fallback, count_roles=args.count_roles and tier1,
                caller_groups=groups)
            if tier1:
                return summary
            subs = [discovery.pick_subscription(summary, sub_row=sub_row,
                                                discovery_id=args.discovery_id)]
        listing = discovery.discover(client, tenant_id=args.tenant_id, caller_object_id=caller,
                                     subscriptions=subs,
                                     resource_group=args.discover_resource_group,
                                     fallback_subscriptions=fallback, caller_groups=groups,
                                     show_all=getattr(args, "show_all", False))
        if row is None:
            return listing
        return discovery.select_row(client, listing, row=row, discovery_id=args.discovery_id,
                                    role=args.role, tenant_id=args.tenant_id,
                                    caller_object_id=caller, caller_groups=groups)
    except discovery.DiscoveryError as error:
        raise Blocked("DISCOVERY_BLOCKED", str(error)) from error


def _discover_text(result: dict) -> str:
    if result.get("status") == "selected":
        sel = result["selection"]
        lines = [f"Selected for {result['role']}: {sel['deployment']} ({sel['model']} "
                 f"{sel['version']}, {sel['sku']}) on {sel['resource_id']}"]
        lines += [f"{runtime}: {' '.join(flags)}" for runtime, flags in result["args"].items()]
        return "\n".join(lines + [result["note"]])
    if result.get("status") == "options":
        return "\n".join([f"Models offered in {result['account']['region']} for "
                          f"{result['role']}:", result["table"], result["note"]])
    scope = result["scope"]
    if result.get("status") == "subscriptions":
        lines = [f"You can see {scope['subscription_count']} subscription(s) (via "
                 f"{scope['method']}). Discovery ID: {result['discovery_id']}",
                 result["table"]]
        lines += [f"Note: {u}" for u in result["uncertainty"]]
    else:
        names = sorted({c.get("subscription_name") or c["subscription_id"]
                        for c in result["candidates"]})
        where = ", ".join(names) if isinstance(scope["subscriptions"], list) and names else (
            ", ".join(scope["subscriptions"]) if isinstance(scope["subscriptions"], list)
            else "all subscriptions you can see")
        found = (f"Found {result['candidate_count']} Foundry/OpenAI resource(s) with "
                 f"{result['deployment_count']} deployment(s)" if result["view"] == "all" else
                 f"Found {result['usable_count']} usable chat and embedding deployment(s)")
        lines = [found + f" in {where}"
                 + (f", resource group {scope['resource_group']}" if scope["resource_group"]
                    else "")
                 + f" (via {scope['method']}). Discovery ID: {result['discovery_id']}",
                 result["table"]]
        if result["hidden_count"]:
            lines.append(f"{result['hidden_count']} other row(s) hidden: empty accounts, "
                         "Foundry projects and unusable deployments. Add --all to list them.")
        if result["excluded_kinds"]:
            lines.append("Not listed (these account kinds can't host model deployments): "
                         + ", ".join(f"{k} x{v}" for k, v in result["excluded_kinds"].items()))
    lines += [f"Warning: {w}" for w in result["warnings"]]
    lines.append("Next: " + result["selection"]["how"])
    lines.append("Command: " + result["selection"]["next_command"])
    return "\n".join(lines)


def _gate(parser: argparse.ArgumentParser, what: str, *, writes: bool = True) -> None:
    parser.add_argument("--plan-id", help=f"the exact {what} plan ID the user approved")
    if writes:
        parser.add_argument("--confirm-writes", action="store_true",
                            help="confirm the Azure writes of the approved plan")


def _run_id(parser: argparse.ArgumentParser, text: str) -> None:
    parser.add_argument("--run-id", required=True, help=text)


def _build_parser():
    parser, commands = new_parser(PROG, "Plan, provision and connect Entity Graph Azure resources.",
                                  package_version())
    resources, smoke, rbac, capacity = _resources(), _smoke(), _rbac(), _capacity()
    connect = _connect_arguments()
    from ekg_core import doctor
    doctor.add_arguments(add_command(
        commands, "doctor", "Check this operator environment (read-only, no Azure writes)."),
        provision=True)
    for name, text in (("plan", "Review the provisioning plan and its plan ID (offline)."),
                       ("render", "Write Bicep parameters and Portal guidance (offline).")):
        add_command(commands, name, text, [resources]).add_argument(
            "--output", help="folder for Bicep parameters and Portal guidance")
    add_command(commands, "inspect", "Inspect the live resources (read-only).", [resources])
    add_command(commands, "verify", "Verify the provisioned resources (read-only).", [resources])
    _gate(add_command(commands, "apply", "Apply the approved bounded public plan.", [resources]),
          "provisioning")
    commands.choices["apply"].add_argument(
        "--plan-file", help="the plan file `plan` saved (its plan_file); replays the approved "
                            "flags unchanged and rejects resource flags")
    _run_id(add_command(commands, "plan-resume", "Review resuming an interrupted run.",
                        [resources]), "the run to resume")
    resume = add_command(commands, "resume-apply", "Apply the approved resume plan.", [resources])
    _run_id(resume, "the run to resume")
    _gate(resume, "resume")
    for name, text in (("plan-cleanup", "Review cleanup of a run's resources (offline)."),
                       ("cleanup-approve", "Record approval of a cleanup plan (offline).")):
        sub = add_command(commands, name, text)
        sub.add_argument("--state-dir", help="local provisioning journal folder")
        _run_id(sub, "the run to clean up")
    _gate(commands.choices["cleanup-approve"], "cleanup", writes=False)
    add_command(commands, "plan-smoke", "Review the synthetic smoke test.", [resources, smoke])
    _gate(add_command(commands, "smoke-run", "Run the approved smoke test.",
                      [resources, smoke]), "smoke")
    add_command(commands, "plan-rbac", "Review the role assignments.", [resources, rbac])
    add_command(commands, "rbac-check", "Check the role assignments (read-only).",
                [resources, rbac])
    _gate(add_command(commands, "rbac-grant", "Grant the approved role assignments.",
                      [resources, rbac]), "RBAC")
    add_command(commands, "quota", "Check model quota (read-only).", [resources])
    add_command(commands, "plan-capacity", "Review a model capacity change.",
                [resources, capacity])
    _gate(add_command(commands, "capacity-update", "Apply the approved capacity change.",
                      [resources, capacity]), "capacity")
    telemetry = add_command(commands, "telemetry", "Summarize a run's timings (offline).")
    telemetry.add_argument("--state-dir", help="local provisioning journal folder")
    _run_id(telemetry, "the run to summarize")
    _discover_arguments(add_command(
        commands, "discover",
        "List every Foundry/OpenAI account, project and model deployment you can see, "
        "for you to choose from (read-only)."))
    add_command(commands, "connect", "Discover and validate existing resources (read-only).",
                [connect])
    _gate(add_command(commands, "connect-apply",
                      "Apply the approved connect setup plan (container, models, roles).",
                      [connect]), "connect setup")
    return parser


def _journal(args) -> ProvisioningJournal:
    return ProvisioningJournal(args.state_dir or Path.cwd() / ".entity" / "provision-runs")


def _telemetry(args) -> dict:
    from ekg_core.telemetry import summarize_phases, valid_event
    try:
        record = _journal(args).read(args.run_id)
    except json.JSONDecodeError as error:
        raise Blocked("INVALID_INPUT", str(error)) from error
    events = [event for event in record.get("telemetry") or [] if valid_event(event)]
    return {
        "phase": "provision.telemetry", "run_id": args.run_id,
        "plan_id": record.get("plan_id"), "completed": record.get("completed"),
        "evidence": {"origin": "local_provisioning_journal"},
        "phases": summarize_phases(events),
        "uncertainty": [] if events else ["Run recorded no telemetry events."],
    }


def _usage(message: str) -> Blocked:
    return Blocked("USAGE", message)


def _validate_command_args(args) -> tuple[tuple[str | None, ...], list[ModelDeploymentSpec]]:
    for flag in ("resource_group", "location", "search_name", "storage_name", "openai_name"):
        if getattr(args, flag) is None:
            raise _usage(f"--{flag.replace('_', '-')} is required")
    network_args = (
        args.network_vnet_name, args.network_subnet_name,
        args.network_vnet_cidr, args.network_subnet_cidr,
    )
    if any(value is not None for value in network_args) and not all(
        value is not None for value in network_args
    ):
        raise _usage("network configuration requires --network-vnet-name, "
                     "--network-subnet-name, --network-vnet-cidr and --network-subnet-cidr "
                     "together")
    if args.public_data_entra:
        if (args.public_test or args.public_test_mode or args.public_test_tenant_id
                or args.public_test_egress_ip or args.public_test_expires_at
                or args.synthetic_data_only):
            raise _usage("--public-data-entra rejects all public-test/synthetic settings")
        if not args.tenant_id:
            raise _usage("--public-data-entra requires --tenant-id")
        if any(value is not None for value in network_args):
            raise _usage("--public-data-entra cannot use private networking")
    elif args.public_data_only:
        raise _usage("public-data settings require --public-data-entra")
    if args.public_test:
        if not (args.public_test_mode and args.public_test_tenant_id
                and args.public_test_expires_at and args.synthetic_data_only):
            raise _usage("--public-test requires --public-test-mode, --public-test-tenant-id, "
                         "--public-test-expires-at and --synthetic-data-only")
        if args.public_test_mode == "ip_allowlist" and not args.public_test_egress_ip:
            raise _usage("ip_allowlist requires --public-test-egress-ip")
        if args.public_test_mode == "entra_only" and args.public_test_egress_ip:
            raise _usage("entra_only rejects --public-test-egress-ip")
        if any(value is not None for value in network_args):
            raise _usage("--public-test cannot be combined with private networking")
        if args.tenant_id and args.tenant_id != args.public_test_tenant_id:
            raise _usage("--tenant-id must match --public-test-tenant-id")
    elif (args.public_test_mode or args.public_test_tenant_id or args.public_test_egress_ip
          or args.public_test_expires_at or args.synthetic_data_only):
        raise _usage("public-test settings require --public-test")
    if args.command in ("plan-resume", "resume-apply") and not (
        args.public_test or args.public_data_entra
    ):
        raise _usage("resume requires --public-test or --public-data-entra")
    if args.command in ("plan-smoke", "smoke-run"):
        if not args.public_test:
            raise _usage("smoke requires --public-test")
        if args.public_test_mode == "ip_allowlist" and not args.smoke_vpn_egress_ip:
            raise _usage("ip_allowlist smoke requires --smoke-vpn-egress-ip")
        if args.public_test_mode == "entra_only" and args.smoke_vpn_egress_ip:
            raise _usage("entra_only smoke rejects --smoke-vpn-egress-ip")
    if args.command in ("plan-rbac", "rbac-check", "rbac-grant") and not args.public_test:
        raise _usage("RBAC requires --public-test")
    if getattr(args, "chat_model", None) == LATEST:
        raise _usage("--chat-model latest is resolved by plan from the region's model "
                     "catalog; pass the model name plan chose, or name a model")
    unversioned = [f"--{role}-model-version" for role, (model, version) in MODEL_DEFAULTS.items()
                   if getattr(args, f"{role}_deployment") is not None
                   and not getattr(args, f"{role}_model_version")
                   and (getattr(args, f"{role}_model") not in (None, model) or version is None)]
    if unversioned:
        raise _usage(f"pass {' and '.join(unversioned)}, or --subscription-id so the region's "
                     "default version can be read: the versions of the chosen models in "
                     f"{args.openai_location or args.location} couldn't be read")
    deployments = []
    for role, (model, version) in MODEL_DEFAULTS.items():
        name = getattr(args, f"{role}_deployment")
        options = [getattr(args, f"{role}_{key}") for key in ("model", "model_version", "sku",
                                                               "capacity")]
        if name is None:
            if any(value is not None for value in options):
                raise _usage(f"--{role}-* settings require --{role}-deployment")
            continue
        try:
            deployments.append(ModelDeploymentSpec(
                role=role, name=name, model=options[0] or model,
                version=options[1] or (version or "" if options[0] in (None, model) else ""),
                sku=options[2] or "GlobalStandard",
                capacity=options[3],
            ))
        except ValueError as error:
            raise _usage(f"{role} deployment: {error}") from error
    if args.command == "quota" and not deployments:
        raise _usage("quota requires --embedding-deployment and/or --chat-deployment")
    access_args = (args.storage_container, args.operator_object_id)
    if any(access_args) or args.search_identity_name:
        if not all(access_args):
            raise _usage("build access needs --storage-container and --operator-object-id "
                         "together (--search-identity-name is an optional user-assigned opt-in)")
        if not (args.public_test or args.public_data_entra):
            raise _usage("build access requires --public-test or --public-data-entra")
        if {deployment.role for deployment in deployments} != {"embedding", "chat"}:
            raise _usage("build access needs --embedding-deployment and --chat-deployment, "
                         "so one plan finishes setup")
    return network_args, deployments


def _spec(args, network_args, deployments) -> ProvisioningSpec:
    if getattr(args, "cache_storage_name", None) and getattr(args, "cache_same_as_source", False):
        raise _usage("pass --cache-storage-name or --cache-same-as-source, not both")
    cache_name = (
        args.storage_name if getattr(args, "cache_same_as_source", False)
        else getattr(args, "cache_storage_name", None)
    )
    return ProvisioningSpec(
        target=Target(
            subscription_id=args.subscription_id,
            resource_group=args.resource_group,
            location=args.location,
        ),
        search_name=args.search_name,
        storage_name=args.storage_name,
        openai_name=args.openai_name,
        content_understanding_name=args.content_understanding_name,
        search_sku=args.search_sku,
        # A public-data plan always owns its resource group; one an earlier plan made is kept.
        create_resource_group=args.create_resource_group or bool(args.public_data_entra),
        cache_storage_name=cache_name,
        search_location=(getattr(args, "search_location", None)
                         or (DEFAULT_SEARCH_LOCATION if args.public_data_entra else None)),
        openai_location=getattr(args, "openai_location", None),
        search_subscription_id=getattr(args, "search_subscription_id", None),
        search_resource_group=getattr(args, "search_resource_group", None),
        network=(NetworkSpec(*network_args) if all(
            value is not None for value in network_args
        ) else None),
        public_test=(PublicTestSpec(
            tenant_id=args.public_test_tenant_id,
            egress_ips=tuple(args.public_test_egress_ip or ()),
            expires_at=args.public_test_expires_at,
            synthetic_data_only=args.synthetic_data_only,
            mode=args.public_test_mode,
        ) if args.public_test else None),
        public_data=(PublicDataSpec(tenant_id=args.tenant_id, public_data_only=True)
                     if args.public_data_entra else None),
        model_deployments=tuple(deployments),
        build_access=(BuildAccessSpec(
            search_identity_name=args.search_identity_name or None,
            storage_container=args.storage_container,
            operator_object_id=args.operator_object_id,
            operator_principal_type=args.operator_principal_type or "User",
        ) if args.storage_container else None),
    )


def _run(args) -> dict:
    if args.command in _GATED and not (
        args.plan_id and (args.confirm_writes or args.command == "cleanup-approve")
    ):
        needs = "--plan-id" if args.command == "cleanup-approve" else "--plan-id and " \
                                                                     "--confirm-writes"
        raise Blocked("APPROVAL_REQUIRED", f"{args.command} requires {needs}",
                      plan_verb=_GATED[args.command])
    if args.command in ("connect", "connect-apply"):
        return _connect(args)
    if args.command == "discover":
        return _discover(args)
    if args.command == "telemetry":
        return _telemetry(args)
    if args.command == "plan-cleanup":
        return _journal(args).cleanup_plan(args.run_id)
    if args.command == "cleanup-approve":
        return _journal(args).approve_cleanup(args.run_id, args.plan_id)
    _resolve_models(args, versions_only=args.command != "plan")
    spec = _spec(args, *_validate_command_args(args))
    if spec.public_data is not None:
        plan(spec, require_active=args.command not in ("inspect", "verify"))
    if args.command in _LIVE and not args.subscription_id:
        raise _usage("--subscription-id is required for live Azure commands")
    tenant = args.tenant_id or args.public_test_tenant_id
    if args.command in _LIVE_TENANT and not tenant:
        raise _usage("--tenant-id is required for live Azure commands")
    if spec.build_access is not None and args.command in _HELD_ROLE_COMMANDS:
        from dataclasses import replace
        from . import held_roles
        held, read = held_roles.operator_held(
            spec, spec.public_endpoint.tenant_id if spec.public_endpoint else tenant)
        spec = replace(spec, build_access=replace(spec.build_access, operator_held=held))
        args.operator_roles_read = read
    if args.command in ("quota", "plan-capacity", "capacity-update"):
        return _cmd_capacity(args, spec, tenant)
    if args.command in ("plan-rbac", "rbac-check", "rbac-grant"):
        return _cmd_rbac(args, spec)
    if args.command in ("plan-smoke", "smoke-run"):
        return _cmd_smoke(args, spec)
    if args.command in ("plan", "render"):
        return _cmd_plan(args, spec)
    return _cmd_backend(args, spec)


def _cmd_capacity(args, spec: ProvisioningSpec, tenant: str | None) -> dict:
    if args.command == "quota":
        return quota_check(spec, tenant_id=tenant)
    if args.command == "plan-capacity":
        review = capacity_plan(spec, args.capacity_deployment, args.capacity, tenant_id=tenant)
        if review["change"] != "none" and not review["blockers"]:
            current = review["current"]
            review["approval_card"] = _simple_card(
                spec, tenant, "change a model deployment's capacity",
                [f"Change deployment {review['deployment']} ({current['sku']}) from "
                 f"{current['capacity_k_tpm']}K to {review['desired_capacity_k_tpm']}K "
                 "tokens per minute"])
        return review
    return capacity_update(spec, args.capacity_deployment, args.capacity, tenant_id=tenant,
                           approved_plan_id=args.plan_id, confirmed=args.confirm_writes)


def _cmd_rbac(args, spec: ProvisioningSpec) -> dict:
    rbac = RbacSpec(args.rbac_principal_object_id, args.rbac_principal_type, args.rbac_container)
    if args.command == "rbac-check":
        return rbac_check(spec, rbac)
    if args.command == "rbac-grant":
        return rbac_grant(spec, rbac, approved_plan_id=args.plan_id,
                          confirmed=args.confirm_writes)
    review = rbac_review(spec, rbac)
    notes = tuple(
        f"Already held, so not granted: {item['role']} on {item['scope'].rsplit('/', 1)[-1]}"
        + (f" (unverified: {item['unverified']})." if "unverified" in item else ".")
        for item in review.get("held_detail", ()))
    notes += tuple(f"Already assigned directly on this scope, so the grant is a no-op: {role}."
                   for role in review.get("already_assigned", ()))
    if not review["roles_read"]:
        notes += ("Role assignments couldn't be checked, so every role is planned; "
                  "rbac-grant checks again and skips any role already held.",)
    review["approval_card"] = _simple_card(
        spec, spec.public_test.tenant_id if spec.public_test else args.tenant_id,
        "grant Entity Graph's roles",
        [f"Grant {item['principal_type']} {item['principal_object_id']} "
         f"{item['role']} on {item['scope'].rsplit('/', 1)[-1]}"
         for item in review["operations"]], notes=notes)
    return review


def _cmd_smoke(args, spec: ProvisioningSpec) -> dict:
    smoke = SmokeSpec(args.smoke_id, args.smoke_container, args.smoke_vpn_egress_ip,
                      args.smoke_embedding_deployment)
    review = smoke_plan(spec, smoke)
    if args.command == "plan-smoke":
        return review
    if args.plan_id != review["plan_id"]:
        raise ApprovalRequired(f"explicit approval of smoke plan {review['plan_id']} is required")
    backend = AzureSdkBackend(journal_root=args.state_dir,
                              expected_tenant_id=args.tenant_id or args.public_test_tenant_id)
    inspection = backend.inspect(spec)
    return run_smoke(spec, smoke, approved_smoke_plan_id=args.plan_id,
                     confirmed=args.confirm_writes,
                     transport=AzureTransport(backend._sdk_credential), inspection=inspection,
                     journal_dir=args.state_dir or Path.cwd() / ".entity" / "provision-runs")


def _simple_card(spec: ProvisioningSpec, tenant: str | None, what: str,
                 changes: list[str], notes: tuple[str, ...] = ()) -> str:
    """Card for a small change to existing resources: minutes, and no charge of its own."""
    from ekg_core import approval
    names = approval.azure_context(tenant, spec.target.subscription_id)
    return approval.card(
        what=what, changes=changes, time=approval.time_text(1, 2),
        cost=approval.cost_text(0.0), tenant_id=tenant, tenant_name=names.get("tenant_name"),
        subscription=names.get("subscription") or spec.target.subscription_id,
        resource_group=spec.target.resource_group, notes=notes)


def _model_choice_notes(spec: ProvisioningSpec) -> tuple[str, ...]:
    notes = []
    for deployment in spec.model_deployments:
        model, version = MODEL_DEFAULTS.get(deployment.role, (None, None))
        if (deployment.model, deployment.sku) == (model, DEFAULT_SKU) and version in (
                None, deployment.version):
            notes.append(f"{deployment.role.capitalize()} deployment {deployment.name} uses the "
                         f"recommended default ({model} {deployment.version}, "
                         f"{DEFAULT_SKU}, {deployment.capacity}K tokens per minute). "
                         "Other models, versions and SKUs the region offers are also fine "
                         "and are listed by `entity-graph-provision discover --models-for`.")
    return tuple(notes)


def _provision_details(spec: ProvisioningSpec, *, resume: bool = False,
                       roles_read: bool | None = None,
                       extra_notes: tuple[str, ...] = ()) -> list[str]:
    """Everything the short card leaves out; shown when the user asks for details."""
    from ekg_core.arm_retry import POLICY_TEXT
    return [
        *((f"Identity: {'Search system-assigned identity' if spec.build_access.uses_system_identity else 'Search user-assigned identity ' + str(spec.build_access.search_identity_name)}.",)
          if spec.build_access else ()),
        *(("Entra-authenticated public endpoints (local auth disabled, no trusted-service "
           "bypass). Upload, Build and publish each require separate approval.",)
          if spec.public_data else ()),
        *((SERVERLESS_WARNING,) if spec.search_sku == "serverless" else ()),
        *_model_choice_notes(spec),
        *(("Enrichment cache: stores a copy of extracted content in Blob and Table "
           "storage and adds storage cost."
           + (" WARNING: sharing the source storage account for the enrichment cache "
              "grants the Search identity write access to the source account."
              if not spec.cache_storage_name or spec.cache_storage_name == spec.storage_name
              else ""),) if spec.build_access else ()),
        *(("Keep the existing resource group and verified resources unchanged; "
           "the original journal stays immutable.",) if resume else ()),
        *extra_notes, *_held_notes(spec, roles_read), POLICY_TEXT,
    ]


def _provision_card(spec: ProvisioningSpec, writes: list[str], *,
                    kept: frozenset[str] = frozenset(), quota: str | None = None,
                    unchecked: int = 0, resume: bool = False,
                    model_notes: tuple[str, ...] = ()) -> str:
    """The short card: what gets made, what it costs, how to clean up. No IDs."""
    from ekg_core import approval
    from ekg_core.models import effective_cache_storage_name
    from ekg_core.pricing import dollars, search_usd_per_day
    tenant = spec.public_endpoint.tenant_id if spec.public_endpoint else None
    names = approval.azure_context(tenant, spec.target.subscription_id)
    group = spec.target.resource_group
    there = " (already there, kept)"
    group_state = ("already there, kept" if "create-resource-group" in kept
                   else "new" if spec.create_resource_group and not resume else "existing")
    sku = "Serverless" if spec.search_sku == "serverless" else spec.search_sku
    lines = [
        f"APPROVAL: {'Finish setting up' if resume else 'Set up'} Entity Graph's Azure "
        f"resources in resource group {group} ({group_state}), subscription "
        f"{names.get('subscription') or spec.target.subscription_id}",
        f"- Search: {spec.search_name} in {region_name(spec.effective_search_location)} "
        f"({sku})" + (there if "create-search_service" in kept else "")
        + (f", in resource group {spec.effective_search_resource_group}, subscription "
           f"{approval.azure_context(tenant, spec.effective_search_subscription_id).get('subscription') or spec.effective_search_subscription_id}"
           if spec.search_is_split else ""),
    ]
    cache = (effective_cache_storage_name(spec)
             if spec.build_access is not None or spec.cache_storage_name else None)
    lines.append(f"- Storage: {spec.storage_name} for your documents"
                 + (f", and {cache} for the build cache" if cache and cache != spec.storage_name
                    else "")
                 + (there if "create-storage_account" in kept else ""))
    models = {d.role: d.model for d in spec.model_deployments}
    roles_kept = all(f"create-{role}-deployment" in kept for role in models)
    lines.append(
        "- Models: " + (" and ".join(f"{model} for {'chat' if role == 'chat' else 'embeddings'}"
                                      for role, model in sorted(models.items()))
                        if models else "an account for your models")
        + f", in {spec.openai_name} ({region_name(spec.effective_openai_location)})"
        + (there if models and roles_kept else ""))
    lines += list(model_notes)
    if quota:
        lines.append(quota)
    if unchecked:
        lines.append(f"{unchecked} check(s) couldn't run yet; apply runs them again before "
                     "changing anything.")
    daily = None if spec.search_sku == "serverless" else search_usd_per_day(spec.search_sku)
    lines += [
        "Cost: " + ("Search and storage bill for what you use, with no fixed daily charge; "
                    "the models bill per call, and each later step shows its cost first."
                    if daily is None else
                    f"about {dollars(daily)}/day for Search while it exists, plus storage "
                    "and model use."),
        "Time: " + (approval.time_text(3, 6) if spec.search_sku == "serverless"
                    else approval.time_text(10, 20)),
        f"When you're done: delete resource group {group}"
        + (f" and {spec.effective_search_resource_group}" if spec.search_is_split else "")
        + "; I'll remind you.",
        f"Details: {len(writes)} change(s), including "
        f"{sum(line.startswith('Grant ') for line in writes)} role grant(s). Ask to see them.",
        approval.APPROVE_LINE,
    ]
    return "\n".join(lines)


# Read-only live checks before approval and before apply's first write. Tests replace
# this with an offline reader; None means live ARM.
LIVE_READER: Any = None


def _reader() -> Any:
    from .arm import read_json
    return LIVE_READER or read_json


def _resolve_models(args, *, versions_only: bool = False) -> None:
    """Fill in what a new deployment leaves out, from the region's catalog and free quota.

    A missing version becomes the catalog's default. Only `plan` (not ``versions_only``)
    also turns `latest` into the newest chat model there and a missing capacity into the
    free quota up to the default; the saved plan replays those flags, so apply matches.
    """
    from types import SimpleNamespace
    from .capacity import API_VERSION as MODELS_API
    args.model_notes = []
    roles = [role for role in MODEL_DEFAULTS
             if getattr(args, f"{role}_deployment", None) is not None]
    if not roles or not args.subscription_id:
        return
    region = args.openai_location or args.location
    reading = SimpleNamespace(public_endpoint=(SimpleNamespace(tenant_id=args.tenant_id)
                                               if args.tenant_id else None),
                              effective_search_location=args.search_location)
    base = (f"https://management.azure.com/subscriptions/{args.subscription_id}/providers/"
            f"Microsoft.CognitiveServices/locations/{region}")
    try:
        catalog = (_reader()(reading, "get", f"{base}/models?api-version={MODELS_API}")
                   or {}).get("value") or []
    except Exception:  # noqa: BLE001 - validation names any flag still missing
        return
    usages = None
    if not versions_only:
        try:
            usages = (_reader()(reading, "get", f"{base}/usages?api-version={MODELS_API}")
                      or {}).get("value")
        except Exception:  # noqa: BLE001 - plan's quota check reports it
            usages = None
    where = region_name(region)

    def fill(role: str, key: str, value: Any) -> None:
        setattr(args, f"{role}_{key}", value)
        args.raw_argv = [*getattr(args, "raw_argv", []), f"--{role}-{key.replace('_', '-')}",
                         str(value)]

    def unavailable(role: str, why: str) -> Blocked:
        newest = newest_chat_model(catalog, usages or []) if role == "chat" else None
        offer = (f"the newest chat model there, {newest} (--chat-model latest)" if newest
                 else "another region for the models (--location) or more quota")
        return Blocked("MODEL_UNAVAILABLE", why, offer=offer, region=where)

    chosen = {role: getattr(args, f"{role}_model") or MODEL_DEFAULTS[role][0] for role in roles}
    missing = [role for role, model in chosen.items()
               if model != LATEST and not offered_versions(catalog, model)]
    if missing and not versions_only:
        names = " and ".join(chosen[role] for role in missing)
        raise unavailable("chat" if "chat" in missing else missing[0],
                          f"{names} {'is' if len(missing) == 1 else 'are'}n't offered in {where}.")

    for role in roles:
        default_model, default_version = MODEL_DEFAULTS[role]
        model = getattr(args, f"{role}_model") or default_model
        sku = getattr(args, f"{role}_sku") or DEFAULT_SKU
        if model == LATEST and versions_only:
            continue
        if model == LATEST:
            newest = newest_chat_model(catalog, usages or [], sku) if role == "chat" else None
            if newest is None:
                raise Blocked("MODEL_UNAVAILABLE", f"{where} has no chat model with free quota "
                              "that Search can use.", region=where,
                              offer="another region for the models (--location) or more quota")
            fill(role, "model", newest)
            model = newest
            args.model_notes.append(f"{newest} is the newest chat model in {where}.")
        if not offered_versions(catalog, model):
            continue
        if not getattr(args, f"{role}_model_version") and (model != default_model
                                                             or default_version is None):
            version = catalog_version(catalog, model)
            if version:
                fill(role, "model_version", version)
        if usages is None or getattr(args, f"{role}_capacity") is not None:
            continue
        free = free_k_tpm(usages, sku, model)
        if free is None:
            continue
        if free < MIN_CAPACITY_K_TPM:
            raise unavailable(role, f"{where} has only {free}K tokens per minute free for "
                                    f"{model}; a build needs at least {MIN_CAPACITY_K_TPM}K.")
        usual = MODEL_DEPLOYMENT_CAPACITY_DEFAULTS[role]
        if free < usual:
            fill(role, "capacity", free)
            args.model_notes.append(f"{where} has {free}K tokens per minute free for {model}, "
                                    f"so I'll use that (the usual is {usual}K).")


def _live_gates(spec: ProvisioningSpec) -> dict[str, Any]:
    """Read-only checks that `plan` and `apply` both run before any write.

    Stops when Azure would refuse the plan. Returns the operations to keep (resources an
    earlier Entity Graph plan made), a plain quota line, and notes for checks that
    couldn't run.
    """
    from . import policy
    from .backends import ProvisioningError, existing_resources
    from .capacity import _location_url, quota_preflight
    from .search import read_serverless_availability, serverless_preflight
    reader = _reader()
    notes: list[str] = []
    kept: frozenset[str] = frozenset()
    if spec.public_data is not None:
        group = spec.target.resource_group
        try:
            kept = existing_resources(spec, reader)
        except ProvisioningError as error:
            raise Blocked("EXISTING_RESOURCE_CONFLICT", f"{error}. Nothing was created.",
                          suggested_group=f"{group}-2") from error
        except Exception as error:  # noqa: BLE001 - reported, and apply checks again
            notes.append(f"What already exists couldn't be checked before approval ({error}); "
                         "apply checks it again before any write.")
    if spec.search_sku == "serverless" and "create-search_service" not in kept:
        try:
            observed = read_serverless_availability(spec, reader=reader)
        except Exception as error:  # noqa: BLE001 - reported, and apply checks again
            notes.append(f"Serverless availability couldn't be checked before approval "
                         f"({error}); apply checks it again before any write.")
        else:
            try:
                serverless_preflight(spec, observed)
            except ValueError as error:
                raise Blocked("SEARCH_REGION_UNAVAILABLE", str(error),
                              search_location=spec.effective_search_location) from error
    problem = graph_api_problem(spec)
    if problem and spec.public_data is not None:
        raise Blocked("SEARCH_GRAPH_API_UNAVAILABLE", problem,
                      search_location=spec.effective_search_location,
                      graph_region=DEFAULT_SEARCH_LOCATION)
    denials, unchecked = policy.check(spec, reader=reader)
    if denials:
        raise Blocked("POLICY_DENIED", policy.summary(denials),
                      result={"policy_denials": denials},
                      advice=policy.advice(spec, denials))
    if unchecked:
        notes.append("Azure Policy couldn't be checked before approval for "
                     + "; ".join(unchecked) + ". Apply can still be denied by policy.")
    quota_line = None
    new = tuple(d for d in spec.model_deployments
                if f"create-{d.role}-deployment" not in kept)
    if new:
        try:
            listed = {key: reader(spec, "get", _location_url(spec, key))
                      for key in ("usages", "models")}
            quota = {key: value["value"] for key, value in listed.items()}
            if not all(isinstance(value, list) for value in quota.values()):
                raise ValueError("Azure returned no usages or models")
        except Exception:  # noqa: BLE001 - reported, and apply checks again
            notes.append("Model quota couldn't be checked before approval; apply checks it "
                         "again before creating any model.")
        else:
            report = quota_preflight(spec, quota, deployments=new)
            if report["blocked"]:
                raise Blocked("MODEL_QUOTA_SHORT", "; ".join(
                    blocker for row in report["deployments"] for blocker in row["blockers"]),
                    region=region_name(spec.effective_openai_location))
            what = ("both models" if len(new) == 2 else new[0].model)
            quota_line = (f"{region_name(spec.effective_openai_location)} has room for {what}."
                          if all(row["quota_status"] == "checked" for row in report["deployments"])
                          else f"{region_name(spec.effective_openai_location)} offers {what}; "
                               "its quota is checked again when the models are created.")
    return {"notes": tuple(notes), "kept": kept, "quota": quota_line}


def _held_notes(spec: ProvisioningSpec, roles_read: bool | None) -> tuple[str, ...]:
    if spec.build_access is None:
        return ()
    from .held_roles import UNREAD
    notes = tuple(f"Already held, so not granted: {role} ({evidence})."
                  for role, evidence in spec.build_access.operator_held)
    return notes + ((UNREAD,) if roles_read is False else ())


def _cmd_plan(args, spec: ProvisioningSpec) -> dict:
    from .access import plain_writes
    gates = (_live_gates(spec) if args.command == "plan" and spec.public_endpoint
             else {"notes": (), "kept": frozenset(), "quota": None})
    kept = gates["kept"]
    reviewed = plan(spec, kept=kept)
    payload = reviewed.to_dict()
    if gates["notes"]:
        payload["warnings"] = [*payload["warnings"], *gates["notes"]]
    problem = graph_api_problem(spec)
    if problem and spec.public_data is None:
        payload["warnings"] = [*payload["warnings"], problem]
    new_ops = tuple(op for op in reviewed.operations if op.id not in kept)
    writes = plain_writes(spec, new_ops)
    payload["writes"] = writes
    payload["kept"] = [line.replace("Create ", "Keep ", 1).replace("Deploy ", "Keep ", 1)
                       .replace("Grant ", "Keep grant ", 1) + " (already there)"
                       for line in plain_writes(spec, tuple(op for op in reviewed.operations
                                                              if op.id in kept))]
    if spec.public_data is not None:
        from .journal import journal_spec
        payload["spec"] = journal_spec(spec)
    if args.command == "plan":
        payload["summary"] = (
            (f"Here's what I'll create in resource group {spec.target.resource_group}"
             if spec.public_endpoint else
             f"Planned resources in resource group {spec.target.resource_group}")
            + f" ({len(writes)} changes):\n" + "\n".join(f"- {line}" for line in writes[:3])
            + (f"\n- ...and {len(writes) - 3} more (--json lists every change)"
               if len(writes) > 3 else ""))
        payload["next_step"] = (
            "Show the approval card to the user and ask them to approve it. When they do, "
            "run apply_command exactly, through the same launcher, in this conversation and "
            "wait for it to finish. Never ask the user to type the plan ID."
            if spec.public_endpoint else
            "Deploy with the rendered Bicep (`entity-graph-provision render`) or use --public-test.")
        if spec.public_endpoint:
            from . import plan_file
            from .journal import journal_spec
            saved = plan_file.write(
                args.state_dir, reviewed.plan_id,
                plan_file.plan_args(list(getattr(args, "raw_argv", None) or [])),
                json.loads(json.dumps(journal_spec(spec))), package_version())
            payload["plan_file"] = str(saved)
            payload["apply_command"] = _apply_command(saved, reviewed.plan_id)
        if spec.public_endpoint and not reviewed.blocked_by:
            payload["approval_card"] = _provision_card(
                spec, writes, kept=kept, quota=gates["quota"], unchecked=len(gates["notes"]),
                model_notes=tuple(getattr(args, "model_notes", ())))
            payload["details"] = [*writes, *payload["kept"], *_provision_details(
                spec, roles_read=getattr(args, "operator_roles_read", None),
                extra_notes=gates["notes"])]
    if spec.build_access is not None:
        payload["operator_roles_held"] = [
            {"role": role, "evidence": evidence}
            for role, evidence in spec.build_access.operator_held]
    if args.output:
        parameters, portal = write_artifacts(spec, args.output)
        payload["artifacts"] = {"bicep_parameters": str(parameters), "portal_guide": str(portal)}
    return payload


def _apply_command(saved: Path, plan_id: str) -> str:
    """The approved plan's apply command: the saved plan file plus its plan ID."""
    import subprocess
    return subprocess.list2cmdline([PROG, "apply", "--plan-file", str(saved), "--plan-id",
                                    plan_id, "--confirm-writes"])


def _cmd_backend(args, spec: ProvisioningSpec) -> dict:
    backend = AzureSdkBackend(journal_root=args.state_dir,
                              expected_tenant_id=args.tenant_id or args.public_test_tenant_id)
    if args.command == "inspect":
        return backend.inspect(spec)
    if args.command == "verify":
        return backend.verify(spec)
    if args.command == "plan-resume":
        review = backend.resume_plan(spec, args.run_id)
        if spec.public_data:
            review["approval_card"] = _provision_card(spec, review["writes"], resume=True)
            review["details"] = [*review["writes"], *_provision_details(
                spec, resume=True, roles_read=getattr(args, "operator_roles_read", None))]
        return review
    if args.command == "apply" and spec.public_endpoint:
        # Read-only, the same checks plan ran: stop before the first write if Azure would
        # refuse, and keep what an earlier plan made.
        gates = _live_gates(spec)
        expected = plan(spec, kept=gates["kept"]).plan_id
        if args.plan_id != expected:
            from . import plan_file
            from .journal import journal_spec
            saved = plan_file.find(args.state_dir, args.plan_id)
            diffs = (plan_file.differences(saved["spec"], journal_spec(spec))
                     if saved else [])
            roles_only = bool(diffs) and all(
                row["field"].startswith("build_access.operator_held") for row in diffs)
            if roles_only:
                why = ("Only the roles you already hold changed since planning, so the "
                       "approved card is stale. Run plan again and ask the user to approve "
                       "the new card.")
            elif diffs:
                why = ("The apply flags differ from the approved plan in "
                       + ", ".join(row["field"] for row in diffs)
                       + ". That's an execution error, not a new plan: run the approved "
                       "plan's apply_command (apply --plan-file) unchanged.")
            else:
                why = ("The apply flags differ from the approved plan's, or a role you hold "
                       "changed since planning. Run the approved plan's apply_command "
                       "unchanged; re-plan only if it still doesn't match.")
            raise Blocked(
                "APPROVAL_REQUIRED",
                f"these flags produce plan {expected}, not the approved {args.plan_id}, so "
                f"nothing was created. {why}",
                result={"differences": diffs} if diffs else None, plan_verb="plan")
    from ekg_core import approval
    from ekg_core.cli import announce
    announce(approval.time_text(3, 6) if spec.search_sku == "serverless"
             else approval.time_text(10, 20))
    result = (backend.resume_apply(spec, args.run_id, approved_plan_id=args.plan_id,
                                   confirmed_public_test=args.confirm_writes if spec.public_test else False,
                                   confirmed_public_data=args.confirm_writes if spec.public_data else False)
              if args.command == "resume-apply" else
              backend.apply(spec, approved_plan_id=args.plan_id,
                            confirmed_public_test=args.confirm_writes if spec.public_test else False,
                            confirmed_public_data=args.confirm_writes if spec.public_data else False))
    payload = {"plan_id": args.plan_id, "completed": result.completed,
               "events": serialize_events(result.events), "run_id": backend.last_run_id,
               "journal_path": (str(backend.journal.path(backend.last_run_id))
                                if backend.last_run_id else None)}
    if not result.completed:
        raise Blocked("PUBLIC_DATA_STOPPED" if spec.public_data else "PROVISION_INCOMPLETE",
                      "provisioning did not complete", result=payload)
    payload["summary"] = (f"Done: the resources in resource group {spec.target.resource_group} "
                          "are ready.")
    connect_args = _connect_args(args, spec)
    if connect_args:
        payload["connect_args"] = connect_args
        saved = _save_connect_args(args, connect_args, backend.last_run_id, args.plan_id)
        payload["connect_args_file"] = str(saved)
        # Apply checks the new resources itself, so no separate read-only step is needed.
        payload["connect"] = _connect_after_apply(connect_args, args.state_dir)
        if payload["connect"].get("build_args"):
            payload["build_args"] = payload["connect"]["build_args"]
            payload["build_args_file"] = payload["connect"]["build_args_file"]
            payload["next_step"] = (
                f"The new resources are ready. Pass `--build-args {payload['build_args_file']}` "
                "to `entity-graph-build plan` and the later steps; never retype the flags.")
        else:
            payload["summary"] += (" The check of the new resources isn't ready yet: "
                                   + payload["connect"]["summary"])
            import subprocess
            payload["next_step"] = (
                "New role grants can take up to 15 minutes. Wait a few minutes, then run: "
                + subprocess.list2cmdline([PROG, "connect", *connect_args]))
    return payload


def _connect_after_apply(connect_args: list[str], state_dir: str | None) -> dict:
    """Run the read-only connect check on what apply just made; never raises."""
    try:
        parsed = parse(_build_parser(), ["connect", *connect_args,
                                         *(["--state-dir", state_dir] if state_dir else [])],
                       _DEFAULTS)
        parsed.raw_argv = ["connect", *connect_args]
        payload = _connect(parsed)
    except Blocked as blocked:
        return {"status": "blocked", "summary": blocked.error}
    except Exception as error:  # noqa: BLE001 - apply succeeded; the check is reported
        return {"status": "error", "summary": f"{type(error).__name__}: {error}"}
    binding = payload.get("build_binding") or {}
    return {"status": payload["status"], "summary": _connect_summary(payload)["summary"],
            **({"build_args": binding["build_args"], "build_args_file": payload["build_args_file"]}
               if payload["status"] == "ready" and binding.get("build_args") else {})}


def _save_connect_args(args, connect_args: list[str], run_id: str | None,
                       plan_id: str | None) -> Path:
    """Keep apply's connect arguments, so a later session can re-run connect unchanged."""
    from . import plan_file
    path = plan_file.root(args.state_dir).parent / "connect-args.json"
    atomic_write_text(path, json.dumps({
        "version": 1, "run_id": run_id, "plan_id": plan_id, "connect_args": connect_args,
    }, indent=2) + "\n")
    return path


def _connect_args(args, spec: ProvisioningSpec) -> list[str]:
    from ekg_core.models import effective_cache_storage_name
    from ekg_provision.access import scope
    if spec.build_access is None and spec.cache_storage_name is None:
        return []
    tenant = getattr(args, "tenant_id", None) or getattr(args, "public_test_tenant_id", None)
    cache = effective_cache_storage_name(spec)
    out = [*(["--tenant-id", tenant] if tenant else []),
           "--subscription-id", spec.target.subscription_id,
           "--resource-group", spec.target.resource_group,
           *(["--search-resource-id", scope(spec, "search")] if spec.search_is_split
             else ["--search-name", spec.search_name]),
           "--storage-name", spec.storage_name,
           *(["--cache-same-as-source"] if cache == spec.storage_name
             else ["--cache-storage-name", cache]),
           "--openai-name", spec.openai_name]
    if spec.build_access is not None:
        out += ["--storage-container", spec.build_access.storage_container]
        if spec.build_access.uses_system_identity:
            out.append("--use-system-identity")
    for deployment in spec.model_deployments:
        out += [f"--{deployment.role}-deployment", deployment.name]
    return out


CACHE_CHOICE_STEP = (
    "Ask the user which StorageV2 account holds the enrichment cache, then run "
    "`entity-graph-provision connect` again with the same flags plus `--cache-storage-name <name>` "
    "(or `--cache-storage-resource-id <id>`). candidates.cache_storage lists StorageV2 accounts "
    "other than the source; if `entity-graph-provision apply` created the resources, use the cache "
    "account it created (matches_provisioned_cache_name). Never choose for the user. Use "
    "`--cache-same-as-source` only if the user explicitly accepts giving the Search identity "
    "write access to the source storage account."
)


def _connect_summary(payload: dict) -> dict:
    checks = payload.get("checks") or []
    passed = sum(check.get("status") == "ok" for check in checks)
    lines = [f"Connect: {payload['status']}; {passed}/{len(checks)} check(s) passed."]
    resources = payload.get("resources") or {}
    chosen_openai = [
        f"{k}={v}" for k in ("openai", "embedding_openai", "chat_openai", "kb_openai")
        if (v := resources.get(k))
    ]
    if chosen_openai:
        lines.append("Selected Foundry/OpenAI resource(s): " + ", ".join(chosen_openai))
    setup = payload.get("setup_plan")
    if payload.get("candidates"):
        lines.append("Missing inputs: " + ", ".join(sorted(payload["candidates"])))
    if payload.get("grant"):
        lines.append(f"Setup: {payload['grant']['status']}")
    if payload["status"] == "ready" and payload.get("build_binding"):
        saved = payload.get("build_args_file")
        if saved:
            lines.append(f"Saved the build flags to {saved}.")
            step = (f"Pass `--build-args {saved}` to the later steps (entity-graph-build, "
                    "topic-graph-build, grounding); never retype the flags.")
        else:
            lines.append("Build flags: " + " ".join(payload["build_binding"]["build_args"]))
            step = "Pass these build flags unchanged to `entity-graph-build plan`."
    elif "cache_storage" in (payload.get("candidates") or {}) and payload["status"] != "blocked":
        step = (CACHE_CHOICE_STEP
                + (" Also ask the user to choose the Foundry/OpenAI resource from "
                   "candidates.openai; never auto-select one."
                   if "openai" in payload["candidates"] else ""))
    elif setup and payload["status"] != "blocked":
        writes = setup["writes"]
        lines.append(f"Here's what I'll set up ({len(writes)} change(s)): "
                     + "; ".join(writes[:3])
                     + (f"; ...and {len(writes) - 3} more (--json lists every change)"
                        if len(writes) > 3 else ""))
        step = ("Show the approval card to the user and get explicit approval, then run "
                "`entity-graph-provision connect-apply` with the same flags plus --plan-id "
                f"{setup['plan_id']} --confirm-writes.")
        if payload.get("approval_card"):
            import subprocess
            command = ({"apply_command": subprocess.list2cmdline(
                [PROG, "connect-apply", *payload["connect_args"], "--plan-id",
                 setup["plan_id"], "--confirm-writes"])}
                if payload.get("connect_args") else {"plan_id": setup["plan_id"]})
            return {"summary": "\n".join(lines), "next_step": step,
                    "approval_card": payload["approval_card"], **command}
    elif payload["status"] == "unverified" and any(
        row.get("permission_coverage") is not None and row["status"] != "assigned"
        for row in payload.get("roles", [])
    ):
        step = ("Ask the account owner to verify OpenAI access for you and the Search identity "
                "(role-definition permissions, active PIM, conditions and denies), "
                "then run `entity-graph-provision connect` again. No missing role or grant is inferred.")
    elif payload["status"] == "unverified" and any(
        row.get("grant_recommended") is False and row["status"] != "assigned"
        for row in payload.get("roles", [])
    ):
        step = ("Some roles may be held through a conditional assignment, or through a group "
                "whose membership couldn't be read (see checks). Ask the account owner to "
                "confirm them, then run `entity-graph-provision connect` again. No grant is "
                "proposed for these roles.")
    elif "openai" in (payload.get("candidates") or {}):
        step = ("Ask whether to use the signed-in subscription (`az account show`), by name. "
                "Run `entity-graph-provision discover --tenant-id <tenant> --subscription-id "
                "<sub>` for it, or run discover without --subscription-id only if the user "
                "wants another and doesn't know its name. Show the resource table and ask "
                "which model to use for each role, by name. Run `discover --subscription-id "
                "<sub> --row <N> --discovery-id <id> --role <role>` for each choice, then run "
                "`entity-graph-provision connect` again with the `args.entity` flags it prints.")
    else:
        step = "Supply the missing inputs, then run `entity-graph-provision connect` again."
    return {"summary": "\n".join(lines), "next_step": step}


def _connect(args) -> dict:
    from .connect import ConnectSpec, connect, connect_apply, connection_spec, public_payload

    if not args.tenant_id:
        raise _usage("connect requires --tenant-id")
    for kind in ("search", "storage", "cache_storage"):
        if getattr(args, f"{kind}_name", None) and getattr(args, f"{kind}_resource_id", None):
            flag = kind.replace("_", "-")
            raise _usage(f"pass --{flag}-name or --{flag}-resource-id, not both")
    if (args.cache_storage_name or args.cache_storage_resource_id) and args.cache_same_as_source:
        raise _usage("pass --cache-storage-name/--cache-storage-resource-id or --cache-same-as-source, not both")
    openai = args.openai_resource_id
    if getattr(args, "openai_name", None):
        if openai or not (args.subscription_id and args.resource_group):
            raise _usage("--openai-name needs --subscription-id and --resource-group, and "
                         "replaces --openai-resource-id")
        openai = (f"/subscriptions/{args.subscription_id}/resourceGroups/{args.resource_group}"
                  f"/providers/Microsoft.CognitiveServices/accounts/{args.openai_name}")
    try:
        spec = ConnectSpec(
            tenant_id=args.tenant_id, subscription_id=args.subscription_id,
            resource_group=args.resource_group,
            search=args.search_resource_id or args.search_name,
            storage=args.storage_resource_id or args.storage_name,
            openai=openai,
            storage_container=args.storage_container,
            embedding_deployment=args.embedding_deployment,
            chat_deployment=args.chat_deployment,
            search_identity_resource_id=(
                "system" if getattr(args, "use_system_identity", False)
                else args.search_identity_resource_id
            ),
            embedding_dimensions=args.embedding_dimensions, documents=args.documents,
            cache_storage=args.cache_storage_resource_id or args.cache_storage_name,
            cache_same_as_source=bool(args.cache_same_as_source),
            embedding_openai=args.embedding_openai_resource_id,
            chat_openai=args.chat_openai_resource_id,
            kb_openai=args.kb_openai_resource_id,
            kb_chat_deployment=args.kb_chat_deployment,
            use_system_identity=bool(args.use_system_identity),
            **{f"{role}_{key}": getattr(args, f"{role}_{key}", None)
               for role in ("embedding", "chat")
               for key in ("model", "model_version", "sku", "capacity")},
            probe_embedding_dimensions=bool(getattr(args, "probe_embedding_dimensions", False)),
            search_subscription_id=args.search_subscription_id,
            search_resource_group=args.search_resource_group,
        )
    except ValueError as error:
        if "subscription GUIDs" in str(error):
            raise _usage("connect requires --tenant-id and --subscription-id (or full ARM resource IDs)") from error
        raise
    if args.command == "connect-apply":
        payload = connect_apply(spec, approved_plan_id=args.plan_id,
                                confirmed=args.confirm_writes)
    else:
        raw = connect(spec)
        payload = public_payload(raw)
        provision_spec = connection_spec(raw)
        if provision_spec is not None:
            from ekg_core.models import stable_id
            journal = _journal(args)
            run_id = journal.record_connection(
                provision_spec, plan(provision_spec, existing_resources=True),
                stable_id("connect-binding", payload["build_binding"]), payload)
            payload.update(run_id=run_id, journal_path=str(journal.path(run_id)))
    if payload["status"] == "blocked":
        raise Blocked("CONNECT_BLOCKED", f"failed checks: {', '.join(payload['blocked_by'])}",
                      result=payload)
    if args.command == "connect" and payload["status"] == "ready" and payload.get("build_binding"):
        # Later steps read this file (--build-args), so nobody retypes endpoints or IDs.
        from . import plan_file
        path = plan_file.root(args.state_dir).parent / "build-args.json"
        atomic_write_text(path, json.dumps({"version": 1, **payload["build_binding"]},
                                           indent=2) + "\n")
        payload["build_args_file"] = str(path)
    if args.command == "connect" and getattr(args, "raw_argv", None):
        # The exact read-only invocation, so a saved connect.json can be re-checked as is.
        payload["connect_args"] = [
            token for token in args.raw_argv if token not in ("connect", "--json")]
    setup = payload.get("setup_plan")
    if "cache_storage" in (payload.get("candidates") or {}):
        payload["next_step"] = CACHE_CHOICE_STEP
    elif (args.command == "connect" and setup and setup.get("writes")
            and payload["status"] != "ready"):
        payload["approval_card"] = _connect_card(payload, setup, args.resource_group)
    return payload


def _connect_card(payload: dict, setup: dict, resource_group: str | None) -> str:
    from ekg_core import approval
    resources = payload.get("resources") or {}
    if not resource_group:
        for value in resources.values():
            parts = str(value or "").split("/")
            lowered = [part.lower() for part in parts]
            if "resourcegroups" in lowered and lowered.index("resourcegroups") + 1 < len(parts):
                resource_group = parts[lowered.index("resourcegroups") + 1]
                break
    chosen_openai = [
        f"{k}={v}" for k in ("openai", "embedding_openai", "chat_openai", "kb_openai")
        if (v := resources.get(k))
    ]
    picked = [f"{role}: {row['deployment']} on {row['resource_id']}"
              for role, row in (setup.get("selection") or {}).items()]
    names = approval.azure_context(payload.get("tenant_id"), payload.get("subscription_id"))
    return approval.card(
        what="finish setup of your existing Entity Graph resources",         changes=setup["writes"], time=approval.time_text(1, 5), cost=approval.cost_text(0.0),
        tenant_id=payload.get("tenant_id"), tenant_name=names.get("tenant_name"),
        subscription=names.get("subscription") or payload.get("subscription_id"),
        resource_group=resource_group,
        notes=((f"Selected Foundry/OpenAI resource(s): {', '.join(chosen_openai)}",)
               if chosen_openai else ())
        + ((f"Selected deployments: {'; '.join(picked)}",) if picked else ()))


def _classify(error: Exception, command: str) -> Blocked:
    from ekg_core.az_identity import IdentityError
    from .connect import ConnectError
    text = str(error)
    if isinstance(error, ApprovalRequired):
        return Blocked("APPROVAL_REQUIRED", text, plan_verb=_GATED.get(command, "plan"))
    if isinstance(error, IdentityError):
        return Blocked("AZ_SIGNIN", text)
    for kind, code in ((ConnectError, "CONNECT_BLOCKED"), (SmokeError, "SMOKE_FAILED"),
                       (CapacityError, "CAPACITY_BLOCKED"), (RbacError, "RBAC_BLOCKED"),
                       (ProvisioningError, "PROVISION_FAILED")):
        if isinstance(error, kind):
            return Blocked(code, text)
    if isinstance(error, OSError):
        return Blocked("LOCAL_IO", text)
    if isinstance(error, (ValueError, KeyError)):
        return Blocked("INVALID_INPUT", text)
    return Blocked("PROVISION_INCOMPLETE" if command in _GATED else "AZURE_ERROR", text)


def main(argv: list[str] | None = None) -> None:
    args = parse(_build_parser(), argv, _DEFAULTS)
    args.raw_argv = list(sys.argv[1:] if argv is None else argv)
    if args.command == "apply" and getattr(args, "plan_file", None):
        from . import plan_file
        try:
            replay = plan_file.apply_argv(args.raw_argv)
        except plan_file.PlanFileError as error:
            report(Blocked("INVALID_INPUT", str(error)), prog=PROG, command=args.command)
        args = parse(_build_parser(), replay, _DEFAULTS)
        args.raw_argv = replay
    if args.command == "doctor":
        from ekg_core import doctor
        doctor.run(PROG, args)
        return
    try:
        result = _run(args)
    except Blocked as blocked:
        report(blocked, prog=PROG, command=args.command)
    except (RuntimeError, ValueError, OSError, KeyError) as error:
        if getattr(args, "public_data_entra", False) and isinstance(error, ProvisioningError):
            report(Blocked("PUBLIC_DATA_STOPPED", str(error)), prog=PROG, command=args.command,
                   cause=error)
        report(_classify(error, args.command), prog=PROG, command=args.command, cause=error)
    if not args.json:
        from ekg_core.telemetry import summary_text
        if args.command == "telemetry":
            result = {"summary": summary_text(result)}
        elif args.command in ("connect", "connect-apply"):
            result = _connect_summary(result)
        elif args.command == "discover":
            # The table is printed whole; the user picks from exactly what the runtime found.
            print(_discover_text(result))
            return
    say(result, args, prog=PROG)
