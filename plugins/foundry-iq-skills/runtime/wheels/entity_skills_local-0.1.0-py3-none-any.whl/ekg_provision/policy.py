"""Read-only Azure Policy preflight: would a deny policy reject a planned resource?

Each planned top-level resource is sent, exactly as apply would PUT it, to
Microsoft.PolicyInsights/checkPolicyRestrictions in the subscription that will hold it.
That call evaluates policy and creates nothing, so a deny surfaces before approval instead
of halfway through apply.
"""
from __future__ import annotations

import re
from typing import Any, Callable

from ekg_core.models import ProvisioningSpec

from .arm import read_json

API = "2024-10-01"
_TYPES = {
    "search_service": "Microsoft.Search/searchServices",
    "storage_account": "Microsoft.Storage/storageAccounts",
    "openai_resource": "Microsoft.CognitiveServices/accounts",
    "content_understanding": "Microsoft.CognitiveServices/accounts",
}
_LABELS = {
    "search_service": "Search service", "storage_account": "storage account",
    "openai_resource": "Azure OpenAI account",
    "content_understanding": "Content Understanding account",
}

Reader = Callable[..., Any]


def _denials(result: Any) -> list[dict[str, str]]:
    found: list[dict[str, str]] = []
    if not isinstance(result, dict):
        return found
    evaluations = (result.get("contentEvaluationResult") or {}).get("policyEvaluations") or []
    for row in evaluations:
        if not isinstance(row, dict) or str(row.get("evaluationResult")).lower() != "noncompliant":
            continue
        effect = str((row.get("effectDetails") or {}).get("policyEffect") or "deny").lower()
        if effect not in ("deny", "denyaction"):
            continue
        info = row.get("policyInfo") or {}
        found.append({
            "policy_assignment": str(info.get("policyAssignmentDisplayName")
                                     or info.get("policyAssignmentName") or "unnamed"),
            "policy_assignment_id": str(info.get("policyAssignmentId") or ""),
            "policy_definition": str(info.get("policyDefinitionDisplayName")
                                     or info.get("policyDefinitionName") or ""),
        })
    for field in result.get("fieldRestrictions") or []:
        for item in (field or {}).get("restrictions") or []:
            if str((item or {}).get("result")).lower() != "deny":
                continue
            info = item.get("policy") or {}
            found.append({
                "policy_assignment": str(info.get("policyAssignmentDisplayName")
                                         or info.get("policyAssignmentName") or "unnamed"),
                "policy_assignment_id": str(info.get("policyAssignmentId") or ""),
                "policy_definition": str(info.get("policyDefinitionDisplayName")
                                         or info.get("policyDefinitionName")
                                         or f"field {field.get('field')}"),
            })
    unique = {(row["policy_assignment_id"] or row["policy_assignment"]): row for row in found}
    return list(unique.values())


def check(spec: ProvisioningSpec, *, reader: Reader | None = None
          ) -> tuple[list[dict[str, str]], list[str]]:
    """(denials, unchecked): resources a deny policy would reject, and ones not checked."""
    from .backends import _API_VERSIONS, _desired
    from .planner import plan
    from .search import management_api

    reader = reader or read_json
    denials: list[dict[str, str]] = []
    unchecked: list[str] = []
    for operation in plan(spec).operations:
        if operation.resource not in _TYPES:
            continue
        search = operation.resource == "search_service"
        subscription = (spec.effective_search_subscription_id if search
                        else spec.target.subscription_id)
        content = {"type": _TYPES[operation.resource], "name": operation.name,
                   **_desired(spec, operation)}
        body = {
            "resourceDetails": {
                "resourceContent": content,
                "apiVersion": (management_api(spec) if search
                               else _API_VERSIONS[operation.resource]),
            },
            "includeAuditEffect": False,
        }
        url = (f"https://management.azure.com/subscriptions/{subscription}/providers/"
               f"Microsoft.PolicyInsights/checkPolicyRestrictions?api-version={API}")
        label = f"{_LABELS[operation.resource]} {operation.name}"
        try:
            result = reader(spec, "post", url, body=body)
        except Exception as error:  # noqa: BLE001 - reported as unchecked, never as allowed
            unchecked.append(f"{label}: {error}")
            continue
        for row in _denials(result):
            denials.append({"operation": operation.id, "resource": operation.resource,
                            "name": operation.name, "label": label,
                            "subscription_id": subscription, **row})
    return denials, unchecked


def summary(denials: list[dict[str, str]]) -> str:
    guid = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")

    def named(row: dict[str, str]) -> str:
        definition = row["policy_definition"]
        return row["policy_assignment"] + (
            f": {definition}" if definition and not guid.fullmatch(definition) else "")

    by_resource: dict[tuple[str, str], list[str]] = {}
    for row in denials:
        by_resource.setdefault((row["label"], row["subscription_id"]), []).append(named(row))
    return "Azure Policy would deny " + "; ".join(
        f"{label} in subscription {subscription} ({', '.join(policies)})"
        for (label, subscription), policies in by_resource.items())


def advice(spec: ProvisioningSpec, denials: list[dict[str, str]]) -> str:
    search_denied = any(row["resource"] == "search_service" for row in denials)
    data_denied = any(row["resource"] != "search_service" for row in denials)
    parts = []
    if data_denied:
        parts.append(
            "Ask the user for a different subscription where this policy doesn't apply for "
            "the storage and model resources, and a new resource group name; pass them as "
            "--subscription-id and --resource-group."
            + ("" if search_denied else
               f" To keep Search where it was planned, add --search-subscription-id "
               f"{spec.effective_search_subscription_id} --search-resource-group "
               f"{spec.effective_search_resource_group}."))
    if search_denied:
        parts.append(
            "Ask the user for a different subscription for Search and a new resource group "
            "name; pass them as --search-subscription-id and --search-resource-group.")
    return " ".join(parts)
