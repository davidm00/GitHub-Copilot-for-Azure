from dataclasses import asdict
from typing import Any
from ekg_core.models import ProvisioningSpec, Target
from .spec import ConnectSpec, _parts, _subscription
from ekg_core.pricing import model_prices
def _binding(spec: ConnectSpec, ids: dict[str, str | None], search: dict, storage: dict, openai: dict,
             uai: dict[str, Any], dimensions: int,
             *, openais: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    rows = openai["deployments"]
    search_id = str(ids["search"])
    search_sub = _subscription(search_id, spec.subscription_id)
    group = _parts(search_id)[0]
    cache_id = ids.get("cache_storage")
    emb_entry = (openais or {}).get("embedding")
    chat_entry = (openais or {}).get("chat")
    kb_entry = (openais or {}).get("kb")
    primary_openai_id = str(ids.get("openai") or (chat_entry or emb_entry or {}) .get("resource_id") or "")
    primary_openai_ep = str(openai.get("endpoint") or "")
    emb_ep = (emb_entry["account"]["endpoint"] if emb_entry and emb_entry["resource_id"].lower() != primary_openai_id.lower() else None)
    emb_id = (emb_entry["resource_id"] if emb_entry and emb_entry["resource_id"].lower() != primary_openai_id.lower() else None)
    chat_ep = (chat_entry["account"]["endpoint"] if chat_entry and chat_entry["resource_id"].lower() != primary_openai_id.lower() else None)
    chat_id = (chat_entry["resource_id"] if chat_entry and chat_entry["resource_id"].lower() != primary_openai_id.lower() else None)
    kb_ep = (kb_entry["account"]["endpoint"] if kb_entry and kb_entry["resource_id"].lower() not in {primary_openai_id.lower(), (chat_id or "").lower()} else None)
    kb_id = (kb_entry["resource_id"] if kb_entry and kb_entry["resource_id"].lower() not in {primary_openai_id.lower(), (chat_id or "").lower()} else None)
    optional_target_keys = {
        "cache_storage_resource_id", "embedding_openai_endpoint", "embedding_openai_resource_id",
        "chat_openai_endpoint", "chat_openai_resource_id", "kb_openai_endpoint", "kb_openai_resource_id",
    }
    target = Target(
        subscription_id=search_sub, resource_group=group,
        location=search["location"], search_endpoint=search["endpoint"],
        storage_endpoint=storage["endpoint"], openai_endpoint=primary_openai_ep,
        search_resource_id=search_id, storage_resource_id=str(ids["storage"]),
        openai_resource_id=primary_openai_id,
        cache_storage_resource_id=cache_id,
        embedding_openai_endpoint=emb_ep, embedding_openai_resource_id=emb_id,
        chat_openai_endpoint=chat_ep, chat_openai_resource_id=chat_id,
        kb_openai_endpoint=kb_ep, kb_openai_resource_id=kb_id,
    )
    kb_dep = rows.get("kb", {}).get("name") if spec.kb_chat_deployment else None
    kb_mod = rows.get("kb", {}).get("model") if spec.kb_chat_deployment else None
    binding = {
        "target": {k: v for k, v in asdict(target).items()
                   if k not in optional_target_keys or v is not None},
        "tenant_id": spec.tenant_id, "search_sku": search["sku"],
        "search_identity_resource_id": uai["resource_id"],
        "storage_container": spec.storage_container,
        "embedding_deployment": rows["embedding"]["name"],
        "embedding_model": rows["embedding"]["model"], "embedding_dimensions": dimensions,
        "chat_deployment": rows["chat"]["name"], "chat_model": rows["chat"]["model"],
        **({"kb_chat_deployment": kb_dep, "kb_chat_model": kb_mod} if kb_dep and kb_mod else {}),
        **({"cache_storage_resource_id": cache_id} if cache_id else {}),
    }
    # List prices for later cost estimates (ontology spend); None when the model is unknown.
    prices = model_prices(rows["chat"]["model"])
    binding["chat_model_usd_per_1m"] = list(prices) if prices else None
    flags = {
        "--tenant-id": spec.tenant_id, "--subscription-id": search_sub,
        "--resource-group": group, "--location": target.location,
        "--search-sku": search["sku"], "--search-endpoint": target.search_endpoint,
        "--storage-endpoint": target.storage_endpoint,
        "--openai-endpoint": target.openai_endpoint,
        "--search-resource-id": search_id, "--storage-resource-id": str(ids["storage"]),
        "--openai-resource-id": primary_openai_id,
        **({"--cache-storage-resource-id": cache_id} if cache_id else {}),
        **({"--embedding-openai-endpoint": emb_ep, "--embedding-openai-resource-id": emb_id} if emb_ep and emb_id else {}),
        **({"--chat-openai-endpoint": chat_ep, "--chat-openai-resource-id": chat_id} if chat_ep and chat_id else {}),
        **({"--kb-openai-endpoint": kb_ep, "--kb-openai-resource-id": kb_id} if kb_ep and kb_id else {}),
        "--search-identity-resource-id": uai["resource_id"],
        "--storage-container": spec.storage_container,
        "--embedding-deployment": binding["embedding_deployment"],
        "--embedding-model": binding["embedding_model"],
        "--embedding-dimensions": str(dimensions),
        "--chat-deployment": binding["chat_deployment"], "--chat-model": binding["chat_model"],
        **({"--kb-chat-deployment": kb_dep, "--kb-chat-model": kb_mod} if kb_dep and kb_mod else {}),
    }
    binding["build_args"] = [part for pair in flags.items() for part in pair]
    binding["args"] = binding["build_args"]
    return binding
def connection_spec(payload: dict[str, Any]) -> ProvisioningSpec | None:
    """The Provision-shaped spec for a complete binding, for the local journal record."""
    binding = payload.get("build_binding")
    if not binding:
        return None
    target = Target(**binding["target"])
    names = {kind: _parts(payload["resources"][kind])[1] for kind in ("search", "storage", "openai")}
    return ProvisioningSpec(
        target=target, search_name=names["search"], storage_name=names["storage"],
        openai_name=names["openai"], search_sku=binding["search_sku"],
        model_deployments=tuple(payload.get("_model_deployments") or ()),
    )
def public_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if not key.startswith("_")}
