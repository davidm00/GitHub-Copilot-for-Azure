from typing import Any, Callable
from ekg_core.models import (
    CACHE_USES_SYSTEM_ASSIGNED_IDENTITY, TPM_CAPACITY_SKUS, BuildSpec,
    ModelDeploymentSpec, ProvisioningSpec, Target,
)
from ..capacity import API_VERSION as OPENAI_API_VERSION, quota_preflight, read_regional_quota
from ekg_core.az_identity import IdentityError, az_json
from ekg_core.resource_endpoints import cognitive_account_endpoint
from ..discovery import MODEL_HOSTING_KINDS
from .spec import ARM, SEARCH_DATA_API_VERSION, ConnectSpec, _TYPES, _canonical, _check, _get, _network, _parts, _props, _region, _show, _subscription
def _search_state_checks(checks: list, props: dict[str, Any], sku: str) -> None:
    state_ok = (str(props.get("provisioningState", "")).lower() == "succeeded"
                and str(props.get("status", "running")).lower() == "running")
    _check(checks, "search.state", "ok" if state_ok else "fail",
           f"provisioningState {props.get('provisioningState')}, status {props.get('status')}")
    _check(checks, "search.sku", "fail" if sku.lower() == "free" else "ok",
           "The free tier has no managed identity; graph Build needs one." if sku.lower() == "free"
           else f"SKU {sku}", sku=sku)
    if sku.lower() == "serverless":
        _check(checks, "search.serverless_preview", "warn",
               "Serverless preview: no SLA or index aliases. Resource readiness is not "
               "managed Azure Blob graphExtraction proof; Build requires independent "
               "exact-service preflight, approval and extraction/retrieval evidence.")
    auth = props.get("authOptions") or {}
    if props.get("disableLocalAuth") is True:
        _check(checks, "search.local_auth", "ok", "API keys are disabled; Entra only.")
    elif "apiKeyOnly" in auth:
        _check(checks, "search.local_auth", "fail",
               "authOptions is apiKeyOnly; Entity Graph authenticates with Entra ID. Enable aadOrApiKey.")
    else:
        _check(checks, "search.local_auth", "warn",
               "API keys are enabled alongside Entra ID; Entity Graph uses Entra only.")
def _select_search_identity(spec: ConnectSpec, observed: dict[str, Any], checks: list,
                            selected: dict[str, Any], candidates: dict[str, Any]) -> None:
    identity = observed.get("identity") or {}
    attached = {key.lower(): (_canonical(key), value or {})
                for key, value in (identity.get("userAssignedIdentities") or {}).items()}
    id_type = str(identity.get("type") or "").replace(" ", "").lower()
    sys_pid = identity.get("principalId")
    has_sys = "systemassigned" in id_type and isinstance(sys_pid, str) and bool(sys_pid)
    wanted = spec.search_identity_resource_id
    wants_system = bool(spec.use_system_identity) or (
        isinstance(wanted, str)
        and wanted.strip().lower() in ("system", "systemassigned", "system-assigned", "system_assigned")
    )
    if wants_system:
        if has_sys:
            selected["search_identity"] = {
                "resource_id": "system", "principal_id": sys_pid, "kind": "system_assigned",
            }
            _check(checks, "search.identity", "ok",
                   "Using Search system-assigned identity.", principal_id=sys_pid)
        else:
            selected["missing_search_system_identity"] = True
            _check(checks, "search.identity", "fail",
                   "Search service has no system-assigned identity; approve the setup plan to enable it.")
    elif wanted:
        if wanted.lower() not in attached:
            _check(checks, "search.identity", "fail",
                   "The requested user-assigned identity is not attached to Search.")
        else:
            key, value = attached[wanted.lower()]
            selected["search_identity"] = {
                "resource_id": key, "principal_id": value.get("principalId"), "kind": "user_assigned",
            }
            _check(checks, "search.identity", "ok", "User-assigned identity is attached.")
    elif has_sys:
        selected["search_identity"] = {
            "resource_id": "system", "principal_id": sys_pid, "kind": "system_assigned",
        }
        _check(checks, "search.identity", "ok",
               "Using Search system-assigned identity (the default)."
               + (" User-assigned identities are attached; pass --search-identity-resource-id "
                  "only if the user opts in to one." if attached else ""),
               principal_id=sys_pid,
               **({"attached_user_assigned": [key for key, _ in attached.values()]}
                  if attached else {}))
    else:
        selected["missing_search_system_identity"] = True
        _check(checks, "search.identity", "fail",
               "Search service has no system-assigned identity; approve the setup plan to enable "
               "it (the default)"
               + (", or opt in to an attached user-assigned identity with "
                  "--search-identity-resource-id." if attached else "."),
               **({"attached_user_assigned": [key for key, _ in attached.values()]}
                  if attached else {}))
    if CACHE_USES_SYSTEM_ASSIGNED_IDENTITY:
        if has_sys:
            selected["search_system_identity"] = {"principal_id": sys_pid}
            _check(checks, "search.system_identity", "ok",
                   "System-assigned identity is enabled for enrichment-cache access.",
                   principal_id=sys_pid)
        else:
            selected["missing_search_system_identity"] = True
            _check(checks, "search.system_identity", "fail",
                   "Search service has no system-assigned identity; the 2026-11-01-preview "
                   "enrichment cache requires SystemAssigned identity on the Search service. "
                   "Approve the setup plan to enable it.")
def _probe_search_data_plane(endpoint: str, checks: list, runner: Callable[..., Any]) -> None:
    try:
        listed = _get(f"{endpoint}/indexes?api-version={SEARCH_DATA_API_VERSION}&$select=name",
                      runner, "https://search.azure.com")
        _check(checks, "search.data_plane", "ok", "Listed indexes with Entra ID from this host.",
               indexes=len((listed or {}).get("value") or []))
    except IdentityError:
        _check(checks, "search.data_plane", "fail",
               "Could not list indexes from this host: network, role or auth mode.")
        return
    from ..search import GRAPH_API_REGIONS, GRAPH_DATA_API, region_name
    try:
        _get(f"{endpoint}/indexes?api-version={GRAPH_DATA_API}&$select=name", runner,
             "https://search.azure.com")
    except IdentityError as error:
        if "api-version" not in str(error).casefold():
            _check(checks, "search.graph_api", "warn",
                   f"Couldn't check the graph API ({GRAPH_DATA_API}) from this host.")
            return
        _check(checks, "search.graph_api", "fail",
               f"This Search service doesn't have the graph API ({GRAPH_DATA_API}) in its "
               "region yet, so the graph steps would fail. Use a Search service in "
               f"{', '.join(region_name(r) for r in GRAPH_API_REGIONS)}; the models can "
               "stay where they are.")
    else:
        _check(checks, "search.graph_api", "ok", f"Serves the graph API ({GRAPH_DATA_API}).")
def _search(spec: ConnectSpec, search_id: str, checks: list, runner: Callable[..., Any],
            selected: dict[str, Any], candidates: dict[str, Any]) -> dict[str, Any] | None:
    observed = _show(search_id, "search", runner)
    if observed is None:
        _check(checks, "search.exists", "fail", "Search service is missing or unreadable.")
        return None
    props, sku = _props(observed), str((observed.get("sku") or {}).get("name") or "")
    _search_state_checks(checks, props, sku)
    _network(checks, "search", props, "The Build and Consume host")
    _select_search_identity(spec, observed, checks, selected, candidates)
    name = _parts(search_id)[1]
    endpoint = str(props.get("endpoint") or f"https://{name}.search.windows.net").rstrip("/")
    _probe_search_data_plane(endpoint, checks, runner)
    return {"observed": observed, "endpoint": endpoint, "sku": sku.lower(),
            "location": _region(observed.get("location")),
            "missing_system_identity": bool(selected.get("missing_search_system_identity"))}
def _storage(spec: ConnectSpec, storage_id: str, checks: list, runner: Callable[..., Any],
             candidates: dict[str, Any], *, is_cache: bool = True) -> dict[str, Any] | None:
    observed = _show(storage_id, "storage", runner)
    if observed is None:
        _check(checks, "storage.exists", "fail", "Storage account is missing or unreadable.")
        return None
    props = _props(observed)
    kind = observed.get("kind")
    kind_ok = (kind == "StorageV2") if is_cache else True
    state_ok = str(props.get("provisioningState", "")).lower() == "succeeded" and kind_ok
    detail = f"provisioningState {props.get('provisioningState')}, kind {kind}"
    if is_cache and not kind_ok:
        detail += "; the enrichment cache requires a StorageV2 (general-purpose v2) account"
    _check(checks, "storage.state", "ok" if state_ok else "fail", detail)
    if spec.cache_same_as_source:
        _check(checks, "storage.cache_same_as_source", "warn",
               "Using the source documents storage account for the enrichment cache grants "
               "the Search identity Blob and Table Data Contributor write access to source data.")
    if props.get("allowBlobPublicAccess") is True:
        _check(checks, "storage.public_blob_access", "warn",
               "Anonymous blob access is allowed on the account.")
    _check(checks, "storage.local_auth",
           "ok" if props.get("allowSharedKeyAccess") is False else "warn",
           "Shared key access is disabled." if props.get("allowSharedKeyAccess") is False
           else "Shared key access is enabled; Entity Graph uses Entra only.")
    _network(checks, "storage", props, "The Search indexer and the Build host")
    name = _parts(storage_id)[1]
    endpoint = str(((props.get("primaryEndpoints") or {}).get("blob"))
                   or f"https://{name}.blob.core.windows.net/").rstrip("/")
    container = spec.storage_container
    if container is None:
        try:
            listed = _get(f"{ARM}{storage_id}/blobServices/default/containers"
                          f"?api-version={_TYPES['storage'][1]}", runner)
            candidates["storage_container"] = [
                item.get("name") for item in (listed or {}).get("value") or []
                if isinstance(item, dict)]
        except IdentityError:
            candidates["storage_container"] = []
        return {"observed": observed, "endpoint": endpoint}
    try:
        found = _get(f"{ARM}{storage_id}/blobServices/default/containers/{container}"
                     f"?api-version={_TYPES['storage'][1]}", runner)
    except IdentityError:
        found = None
    if not isinstance(found, dict):
        _check(checks, "storage.container", "missing",
               "Container is missing or unreadable; the setup plan creates it (private).")
        return {"observed": observed, "endpoint": endpoint, "missing_container": True}
    else:
        access = str((found.get("properties") or {}).get("publicAccess") or "None")
        _check(checks, "storage.container", "ok" if access == "None" else "fail",
               "Container is private." if access == "None"
               else f"Container publicAccess is {access}; Entity Graph needs a private container.")
    try:
        az_json(["storage", "blob", "list", "--account-name", name, "--container-name",
                 container, "--auth-mode", "login", "--num-results", "1"], runner=runner)
        _check(checks, "storage.data_plane", "ok", "Listed blobs with Entra ID from this host.")
    except IdentityError:
        _check(checks, "storage.data_plane", "fail",
               "Could not list blobs from this host: network, role or auth mode.")
    return {"observed": observed, "endpoint": endpoint}
def _cache_storage(spec: ConnectSpec, cache_id: str, checks: list,
                   runner: Callable[..., Any]) -> dict[str, Any] | None:
    observed = _show(cache_id, "storage", runner)
    if observed is None:
        _check(checks, "cache_storage.exists", "fail",
               "Enrichment-cache storage account is missing or unreadable.")
        return None
    props = _props(observed)
    kind = observed.get("kind")
    state_ok = str(props.get("provisioningState", "")).lower() == "succeeded" and kind == "StorageV2"
    detail = f"provisioningState {props.get('provisioningState')}, kind {kind}"
    if kind != "StorageV2":
        detail += "; the enrichment cache requires a StorageV2 (general-purpose v2) account"
    _check(checks, "cache_storage.state", "ok" if state_ok else "fail", detail)
    _check(checks, "cache_storage.local_auth",
           "ok" if props.get("allowSharedKeyAccess") is False else "warn",
           "Shared key access is disabled." if props.get("allowSharedKeyAccess") is False
           else "Shared key access is enabled; Entity Graph uses Entra only.")
    _network(checks, "cache_storage", props, "The Search indexer")
    name = _parts(cache_id)[1]
    endpoint = str(((props.get("primaryEndpoints") or {}).get("blob"))
                   or f"https://{name}.blob.core.windows.net/").rstrip("/")
    return {"observed": observed, "endpoint": endpoint}
def _deployment_row(role: str, item: dict[str, Any]) -> dict[str, Any]:
    from ..discovery import deployment_row
    found = deployment_row(item)
    sku = item.get("sku") or {}
    model = _props(item).get("model") or {}
    return {"role": role, "name": item.get("name"), "model": model.get("name"),
            "version": model.get("version"), "sku": sku.get("name"),
            "capacity_k_tpm": sku.get("capacity"),
            "provisioning_state": _props(item).get("provisioningState"),
            "capabilities": found["capabilities"], "roles": found["roles"],
            "role_basis": found["role_basis"]}
def _openai_account_checks(checks: list, observed: dict[str, Any],
                           props: dict[str, Any], *, prefix: str = "openai") -> str:
    # Same cited kinds as discovery.MODEL_HOSTING_KINDS (Azure OpenAI deployments host only here).
    kind_ok = observed.get("kind") in MODEL_HOSTING_KINDS
    _check(checks, f"{prefix}.state",
           "ok" if kind_ok and str(props.get("provisioningState", "")).lower() == "succeeded"
           else "fail", f"kind {observed.get('kind')}, provisioningState "
           f"{props.get('provisioningState')}")
    subdomain = props.get("customSubDomainName")
    _check(checks, f"{prefix}.subdomain", "ok" if subdomain else "fail",
           "Custom subdomain is set." if subdomain else
           "Entra ID auth needs a custom subdomain on the account.")
    _check(checks, f"{prefix}.local_auth", "ok" if props.get("disableLocalAuth") is True else "warn",
           "API keys are disabled; Entra only." if props.get("disableLocalAuth") is True
           else "API keys are enabled; Entity Graph uses Entra only.")
    _network(checks, prefix, props, "The Search service (as caller) and the Build host")
    try:
        endpoint = cognitive_account_endpoint(props)
    except ValueError as error:
        _check(checks, f"{prefix}.endpoint", "fail", str(error))
        return ""
    origin = ("properties.endpoint" if props.get("endpoint") is not None else
              "properties.endpoints advertised OpenAI API (account endpoint absent)")
    _check(checks, f"{prefix}.endpoint", "ok", f"Using ARM {origin}: {endpoint}.")
    return endpoint
def _probe_openai_data_plane(endpoint: str, checks: list, runner: Callable[..., Any],
                             *, prefix: str = "openai") -> None:
    if not endpoint:
        return
    try:
        _get(f"{endpoint}/openai/v1/models", runner, "https://ai.azure.com")
        _check(checks, f"{prefix}.data_plane", "ok", "Listed models with Entra ID from this host; "
               "this does not verify inference operations or the Search identity's access.")
    except IdentityError:
        _check(checks, f"{prefix}.data_plane", "fail",
               "Could not list models from this host: network, role or auth mode.")
def _openai_deployments(openai_id: str, checks: list,
                        runner: Callable[..., Any], *, prefix: str = "openai") -> dict[str, Any]:
    try:
        listed = _get(f"{ARM}{openai_id}/deployments?api-version={OPENAI_API_VERSION}", runner)
        return {item["name"]: item for item in (listed or {}).get("value") or []
                if isinstance(item, dict) and isinstance(item.get("name"), str)}
    except IdentityError:
        _check(checks, f"{prefix}.deployments", "fail", "Could not list model deployments.")
        return {}
def _check_requested_deployment(role: str, name: str, deployed: dict[str, Any],
                                checks: list, *, prefix: str = "openai") -> dict[str, Any] | None:
    if name not in deployed:
        _check(checks, f"{prefix}.{role}_deployment", "missing",
               f"Deployment {name} not found; the setup plan deploys it after a quota check.")
        return None
    row = _deployment_row(role, deployed[name])
    want = "embedding" if role == "embedding" else "chat"
    failing: list[str] = []
    warning: list[str] = []
    if str(row["provisioning_state"]).lower() != "succeeded":
        failing.append(f"state {row['provisioning_state']}")
    elif row["role_basis"] == "capabilities_unreported":
        # ARM didn't report capabilities; the first call proves the role.
        warning.append(f"ARM reports no capabilities for {row['model']}; its {role} use "
                       "is checked when the deployment is first called")
    elif want not in row["roles"]:
        failing.append(f"ARM capabilities for {row['model']} "
                       f"({', '.join(row['capabilities']) or 'none'}) don't include "
                       f"{'embeddings' if want == 'embedding' else 'chatCompletion'}")
    unit = "K TPM" if row["sku"] in TPM_CAPACITY_SKUS else " capacity units"
    _check(checks, f"{prefix}.{role}_deployment",
           "fail" if failing else ("warn" if warning else "ok"),
           "; ".join(failing + warning) or f"{row['model']} {row['version']}, {row['sku']} "
           f"{row['capacity_k_tpm']}{unit}", **row)
    return row
def _deployment_rows(spec: ConnectSpec, deployed: dict[str, Any], checks: list,
                     candidates: dict[str, Any],
                     missing: dict[str, str],
                     *, prefix: str = "openai",
                     roles: tuple[str, ...] = ("embedding", "chat")) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    role_names = {
        "embedding": spec.embedding_deployment,
        "chat": spec.chat_deployment,
        "kb": spec.kb_chat_deployment or spec.chat_deployment,
    }
    for role in roles:
        name = role_names.get(role)
        if name is None:
            # Capability-based: a deployment is listed for every role ARM says it serves;
            # unreported capabilities are listed for both and marked.
            want = "embedding" if role == "embedding" else "chat"
            listed_rows = [_deployment_row(role, item) for item in deployed.values()]
            candidates[f"{role}_deployment"] = [
                row for row in listed_rows
                if want in row["roles"] or row["role_basis"] == "capabilities_unreported"]
            continue
        row = _check_requested_deployment(role, name, deployed, checks, prefix=prefix)
        if row is not None:
            rows[role] = row
        elif deployed is not None and name not in deployed:
            missing[role] = name
    return rows
def _openai(spec: ConnectSpec, openai_id: str, checks: list, runner: Callable[..., Any],
            candidates: dict[str, Any], *, prefix: str = "openai",
            roles: tuple[str, ...] = ("embedding", "chat")) -> dict[str, Any] | None:
    observed = _show(openai_id, "openai", runner)
    if observed is None:
        _check(checks, f"{prefix}.exists", "fail", "Azure OpenAI/Foundry account is missing or unreadable.")
        return None
    props = _props(observed)
    endpoint = _openai_account_checks(checks, observed, props, prefix=prefix)
    _probe_openai_data_plane(endpoint, checks, runner, prefix=prefix)
    deployed = _openai_deployments(openai_id, checks, runner, prefix=prefix)
    missing: dict[str, str] = {}
    listed = any(check["id"] == f"{prefix}.deployments" for check in checks)
    rows = _deployment_rows(spec, deployed, checks, candidates, {} if listed else missing,
                            prefix=prefix, roles=roles)
    return {"observed": observed, "endpoint": endpoint, "location": _region(observed.get("location")),
            "deployments": rows, "missing_deployments": missing}
def _capacity(spec: ConnectSpec, openai_id: str, openai: dict[str, Any], checks: list,
              runner: Callable[..., Any], *, openais: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    rows = openai["deployments"]
    token_rows = {role: row for role, row in rows.items()
                  if role in ("embedding", "chat")
                  and row["sku"] in TPM_CAPACITY_SKUS and isinstance(row["capacity_k_tpm"], int)
                  and row["capacity_k_tpm"] >= 1 and row["model"] and row["version"]}
    for role, row in rows.items():
        if role in ("embedding", "chat") and role not in token_rows:
            _check(checks, f"capacity.{role}", "warn",
                   f"{row['sku']} capacity is not counted in TPM (provisioned or batch "
                   "deployment types use other units), so TPM capacity is not estimated. "
                   "The deployment is accepted.")
    report: dict[str, Any] = {"deployments": [], "extraction": None, "model_deployments": ()}
    if token_rows:
        account_by_role = {}
        for role in token_rows:
            acct_id = (
                (openais or {}).get(role, {}).get("resource_id")
                or openai_id
            )
            acct_info = (openais or {}).get(role, {}).get("account") or openai
            account_by_role.setdefault(acct_id, (acct_info, {}))[1][role] = token_rows[role]
        all_mds: list[ModelDeploymentSpec] = []
        for acct_id, (acct_info, acct_rows) in account_by_role.items():
            group, name = _parts(acct_id)
            sub = _subscription(acct_id, spec.subscription_id)
            pspec = ProvisioningSpec(
                target=Target(subscription_id=sub, resource_group=group,
                              location=acct_info["location"]),
                search_name="unused", storage_name="unused", openai_name=name,
                model_deployments=tuple(
                    ModelDeploymentSpec(role, row["name"], row["model"], str(row["version"]),
                                        row["sku"], row["capacity_k_tpm"])
                    for role, row in acct_rows.items()),
            )
            all_mds.extend(pspec.model_deployments)
            try:
                quota = read_regional_quota(pspec, runner=runner)
            except (IdentityError, RuntimeError):
                quota = None
                _check(checks, "capacity.quota", "unverified", "Could not read regional quota.")
            if quota is not None:
                preflight = quota_preflight(
                    pspec, quota,
                    existing={row["name"]: row["capacity_k_tpm"] for row in acct_rows.values()})
                for row in preflight["deployments"]:
                    limit, current = row["quota_limit_k_tpm"], row["quota_current_k_tpm"]
                    report["deployments"].append({
                        key: row[key] for key in ("role", "deployment", "model", "sku",
                                                  "quota_name", "quota_current_k_tpm",
                                                  "quota_limit_k_tpm")
                    } | {"capacity_k_tpm": row["existing_capacity_k_tpm"],
                         "quota_headroom_k_tpm": None if limit is None else limit - current})
        report["model_deployments"] = tuple(all_mds)
    chat = token_rows.get("chat")
    if chat is not None:
        from ekg_build.estimates import extraction_estimate
        from ekg_build.managed_pipeline import DEFAULT_EXTRACTION_PARALLELISM

        estimate = extraction_estimate(
            BuildSpec(target=Target(),
                      extraction_parallelism=DEFAULT_EXTRACTION_PARALLELISM),
            spec.documents or 1,
            chat_capacity_k_tpm=chat["capacity_k_tpm"])
        if spec.documents is None:
            estimate = {key: estimate.get(key) for key in (
                "origin", "reasoning_effort", "page_parallelism", "chat_capacity_k_tpm",
                "serial_tokens_per_minute", "tpm_bound", "max_page_parallelism_for_capacity",
                "assumptions", "uncertainty")}
        report["extraction"] = estimate
        throttles = [item for item in estimate.get("uncertainty") or [] if "TPM" in item]
        _check(checks, "capacity.chat_throttle", "warn" if throttles else "ok",
               " ".join(throttles) or f"{chat['capacity_k_tpm']}K TPM covers default extraction "
               "at measured rates.")
    return report
