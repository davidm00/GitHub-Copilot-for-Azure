import re
from typing import Any, Callable
from ekg_core.models import CACHE_USES_SYSTEM_ASSIGNED_IDENTITY, stable_id
from ekg_core.az_identity import IdentityError, az_json
from ekg_core.group_membership import UNREADABLE, Membership, member_groups
from .spec import ACCEPTED_ROLES, UNVERIFIED_ROLE, ConnectSpec, _subscription
from .openai_roles import OpenAICoverage, _inherited


def membership_for(principal: str, principal_type: str, who: str,
                   runner: Callable[..., Any]) -> Membership:
    return member_groups(principal, principal_type, runner, signed_in=who == "operator")


_DELEGATION_ACTIONS = frozenset({"microsoft.authorization/roleassignments/write",
                                 "microsoft.authorization/roleassignments/delete"})


def limits_only_role_assignments(condition: Any) -> bool:
    """Whether an ABAC condition only constrains role-assignment writes and deletes.

    Delegation conditions on Owner or RBAC Administrator ("may assign any role except
    Owner, ...") gate `ActionMatches{'Microsoft.Authorization/roleAssignments/write'}`
    and `.../delete` and nothing else, so the role's other actions apply unconditionally.
    """
    if not isinstance(condition, str) or not condition.strip():
        return False
    groups = re.findall(r"ActionMatches\s*\{([^}]*)\}", condition, flags=re.IGNORECASE)
    actions = {action.strip().strip("'\"").casefold()
               for group in groups for action in group.split(",") if action.strip()}
    return bool(actions) and actions <= _DELEGATION_ACTIONS and not re.search(
        r"SubOperationMatches|@Principal|@Environment", condition, flags=re.IGNORECASE)


def _unconditional_for(item: dict[str, Any]) -> bool:
    condition = item.get("condition")
    if not condition and not item.get("conditionVersion"):
        return True
    return limits_only_role_assignments(condition)


def match_role(assignments: list[Any], membership: Membership, scope: str,
               accepted: tuple[str, ...] | frozenset[str] | set[str], role: str
               ) -> dict[str, Any]:
    """Status fields for one role from an unfiltered assignment list at `scope`."""
    applicable = [item for item in assignments if isinstance(item, dict)
                  and item.get("roleDefinitionName") in accepted
                  and _inherited(scope, item.get("scope"))]
    held = [(item, holder) for item in applicable
            if (holder := membership.holder(item.get("principalId")))]
    active = sorted(((item, holder) for item, holder in held if _unconditional_for(item)),
                    key=lambda pair: (pair[1] != "direct",
                                      bool(pair[0].get("condition")),
                                      str(pair[0].get("scope", "")).casefold() != scope.casefold(),
                                      str(pair[0].get("scope", "")).casefold()))
    if active:
        item, holder = active[0]
        return {"status": "assigned", "via_role": item["roleDefinitionName"],
                "inherited": str(item.get("scope", "")).casefold() != scope.casefold(),
                "assigned_scope": item.get("scope"),
                **({"condition": "limits only role assignments"} if item.get("condition")
                   else {}),
                **({} if holder == "direct" else {"via_group": membership.via_group(holder)})}
    if held:
        # A conditional assignment exists; its condition isn't evaluated, and a second,
        # unconditional grant would widen it, so none is proposed.
        return {"status": "unverified", "detail": UNVERIFIED_ROLE,
                "conditional_assignment": True, "grant_recommended": False}
    if membership.readable:
        return {"status": "unverified", "detail": UNVERIFIED_ROLE}
    if any(str(item.get("principalType", "")).casefold() == "group" for item in applicable):
        return {"status": "unverified", "group_membership": "unreadable",
                "grant_recommended": False,
                "detail": f"No direct assignment was found and {UNREADABLE}. A group holds "
                          f"{role} at this scope, so the principal may already have it; no "
                          "grant is proposed."}
    return {"status": "unverified", "group_membership": "unreadable",
            "detail": f"No direct assignment was found and {UNREADABLE}. No group holds "
                      f"{role} at this scope either."}


def _principal_roles(
    spec: ConnectSpec, principal: str, principal_type: str, scope: str, roles: tuple[str, ...],
    who: str, runner: Callable[..., Any],
    *, openai_coverage: OpenAICoverage | None = None,
) -> list[dict[str, Any]]:
    membership = membership_for(principal, principal_type, who, runner)
    if roles == ("Cognitive Services OpenAI User",):
        coverage = openai_coverage or OpenAICoverage(spec, runner)
        return [coverage.check(principal, principal_type, scope, who, membership)]
    scope_sub = _subscription(scope, spec.subscription_id)
    try:
        # No --assignee-object-id: it returns only assignments made to that exact object
        # and hides every grant to a group the principal belongs to.
        assignments = az_json([
            "role", "assignment", "list", "--scope", scope, "--include-inherited",
            "--fill-principal-name", "false", "--subscription", scope_sub,
        ], runner=runner)
    except IdentityError:
        assignments = None
    rows = []
    for role in roles:
        row = {"principal": who, "principal_object_id": principal,
               "principal_type": principal_type, "role": role, "scope": scope}
        if not isinstance(assignments, list):
            rows.append({**row, "status": "unverified",
                         "detail": "Role assignments are unreadable at this scope."})
            continue
        rows.append({**row, **match_role(assignments, membership, scope,
                                         ACCEPTED_ROLES[role], role)})
    return rows
def _grant_command(spec: ConnectSpec, row: dict[str, Any]) -> list[str]:
    scope_sub = _subscription(row["scope"], spec.subscription_id)
    return ["az", "role", "assignment", "create",
            "--assignee-object-id", row["principal_object_id"],
            "--assignee-principal-type", row["principal_type"],
            "--role", row["role"], "--scope", row["scope"],
            "--subscription", scope_sub]
def _openai_scopes(ids: dict[str, str | None]) -> list[str]:
    seen: set[str] = set()
    scopes: list[str] = []
    for key in ("openai", "embedding_openai", "chat_openai", "kb_openai"):
        val = ids.get(key)
        if val and val.lower() not in seen:
            seen.add(val.lower())
            scopes.append(val)
    return scopes
def _rbac(spec: ConnectSpec, operator: dict[str, str], ids: dict[str, str | None],
          uai: dict[str, Any] | None, runner: Callable[..., Any],
          *, sys_identity: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    container = (f"{ids['storage']}/blobServices/default/containers/{spec.storage_container}")
    oid, kind = operator["principal_object_id"], operator["principal_type"]
    cache_scope = ids.get("cache_storage") or (ids["storage"] if spec.cache_same_as_source else None)
    coverage = OpenAICoverage(spec, runner)
    openai_ids = _openai_scopes(ids)
    rows = _principal_roles(spec, oid, kind, str(ids["search"]),
                            ("Search Service Contributor", "Search Index Data Contributor"),
                            "operator", runner)
    rows += _principal_roles(spec, oid, kind, container, ("Storage Blob Data Contributor",),
                             "operator", runner)
    for openai_id in openai_ids:
        rows += _principal_roles(spec, oid, kind, openai_id, ("Cognitive Services OpenAI User",),
                                 "operator", runner, openai_coverage=coverage)
    if uai and uai.get("principal_id"):
        pid = uai["principal_id"]
        who = (
            "search_system_identity"
            if uai.get("kind") == "system_assigned" or uai.get("resource_id") == "system"
            else "search_identity"
        )
        rows += _principal_roles(spec, pid, "ServicePrincipal", container,
                                 ("Storage Blob Data Reader",), who, runner)
        if not CACHE_USES_SYSTEM_ASSIGNED_IDENTITY and cache_scope:
            rows += _principal_roles(spec, pid, "ServicePrincipal", str(cache_scope),
                                     ("Storage Blob Data Contributor", "Storage Table Data Contributor"),
                                     who, runner)
        for openai_id in openai_ids:
            rows += _principal_roles(spec, pid, "ServicePrincipal", openai_id,
                                     ("Cognitive Services OpenAI User",), who, runner,
                                     openai_coverage=coverage)
    if (CACHE_USES_SYSTEM_ASSIGNED_IDENTITY and cache_scope and sys_identity
            and sys_identity.get("principal_id")):
        rows += _principal_roles(
            spec, sys_identity["principal_id"], "ServicePrincipal", str(cache_scope),
            ("Storage Blob Data Contributor", "Storage Table Data Contributor"),
            "search_system_identity", runner,
        )
    return rows
def _role_plan(spec: ConnectSpec, rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    proposed = [row for row in rows if row["status"] != "assigned"
                and row.get("grant_recommended", True)]
    if not proposed:
        return None
    operations = [{
        "role": row["role"], "scope": row["scope"], "principal": row["principal"],
        "principal_object_id": row["principal_object_id"],
        "principal_type": row["principal_type"], "requires_approval": True,
        "command": _grant_command(spec, row),
    } for row in proposed]
    identity = {"tenant_id": spec.tenant_id.lower(), "subscription_id": spec.subscription_id.lower(),
                "operations": [{**{key: op[key] for key in ("role", "principal_object_id",
                                                           "principal_type")},
                                "scope": op["scope"].lower()} for op in operations]}
    return {
        "plan_id": stable_id("connect-rbac-plan", identity),
        "operations": operations,
        "warning": "No active assignment of these roles was found for the principal or any "
                   "group it belongs to, at each scope or above. A PIM-eligible role isn't "
                   "seen here; if you have one, activate it instead of approving a new grant. "
                   "Each assignment needs roleAssignments/write (Owner or Role Based Access "
                   "Control Administrator) at its scope.",
    }
