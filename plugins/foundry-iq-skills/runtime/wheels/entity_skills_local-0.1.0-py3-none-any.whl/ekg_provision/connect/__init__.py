import subprocess
from typing import Any, Callable
from ekg_core.execution import ApprovalRequired
from ekg_core.telemetry import TelemetryRecorder
from .output import _binding, connection_spec, public_payload
from .resources import _cache_storage, _capacity, _openai, _search, _storage
from .roles import _principal_roles, _rbac
from .setup import setup_plan
from ekg_core.search_models import NATIVE_EMBEDDING_DIMENSIONS, embedding_dimensions_error
from .spec import (DEFAULT_RUNNER, ConnectError, ConnectSpec, _candidates, _check, _resource_id,
                   _search_tenant, _subscription)
from ekg_core.az_identity import active_az_identity, az_command
from ekg_core.models import default_cache_storage_name
def cache_choice_pending(spec: ConnectSpec, ids: dict[str, str | None]) -> bool:
    """True until the user names a cache account or explicitly opts into the source account."""
    return not ids.get("cache_storage") and not spec.cache_same_as_source
def _cache_candidates(spec: ConnectSpec, storage_id: str,
                      runner: Callable[..., Any]) -> list[dict[str, Any]]:
    provisioned = default_cache_storage_name(storage_id.rsplit("/", 1)[-1])
    return [
        {**item, "matches_provisioned_cache_name": str(item.get("name") or "").lower() == provisioned}
        for item in _candidates(spec, "storage", runner)
        if item.get("kind") == "StorageV2"
        and str(item.get("resource_id") or "").lower() != storage_id.lower()
    ]
def _resource_ids(spec: ConnectSpec) -> dict[str, str | None]:
    ids = {kind: _resource_id(spec, kind, getattr(spec, kind))
           for kind in ("search", "storage", "openai")}
    for extra in ("embedding_openai", "chat_openai", "kb_openai"):
        val = getattr(spec, extra, None)
        if val is not None:
            ids[extra] = _resource_id(spec, "openai", val)
    if ids["openai"] is None and (ids.get("chat_openai") or ids.get("embedding_openai")):
        ids["openai"] = ids.get("chat_openai") or ids.get("embedding_openai")
    if spec.cache_storage is not None:
        ids["cache_storage"] = _resource_id(spec, "storage", spec.cache_storage)
    if spec.search_identity_resource_id:
        _resource_id(spec, "identity", spec.search_identity_resource_id)
    return ids
def _discover_resources(
    spec: ConnectSpec, ids: dict[str, str | None], checks: list[dict[str, Any]],
    candidates: dict[str, Any], runner: Callable[..., Any], recorder: TelemetryRecorder,
    operator: dict[str, str] | None = None, *, search_reachable: bool = True,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any] | None, dict[str, Any]]:
    selected: dict[str, Any] = {}
    search = storage = openai = None
    openais: dict[str, dict[str, Any]] = {}
    with recorder.span("discover", resource="arm_and_data_plane") as span:
        for kind in ("search", "storage", "openai"):
            if ids[kind] is None and (kind != "search" or search_reachable):
                candidates[f"{kind}"] = _candidates(spec, kind, runner)
        if ids["search"] and search_reachable:
            search = _search(spec, ids["search"], checks, runner, selected, candidates)
        same_cache = spec.cache_same_as_source or bool(
            ids.get("cache_storage") and ids["storage"]
            and ids["cache_storage"].lower() == ids["storage"].lower()
        )
        if ids["storage"] and cache_choice_pending(spec, ids):
            candidates["cache_storage"] = _cache_candidates(spec, str(ids["storage"]), runner)
        if ids["storage"]:
            storage = _storage(spec, ids["storage"], checks, runner, candidates,
                               is_cache=bool(same_cache))
        if ids.get("cache_storage") and not same_cache:
            _cache_storage(spec, ids["cache_storage"], checks, runner)
        if ids["openai"]:
            role_accounts = {
                "embedding": ids.get("embedding_openai") or ids["openai"],
                "chat": ids.get("chat_openai") or ids["openai"],
                **({"kb": ids.get("kb_openai") or ids.get("chat_openai") or ids["openai"]}
                   if spec.kb_openai or spec.kb_chat_deployment else {}),
            }
            unique_accounts: dict[str, tuple[str, list[str]]] = {}
            for role, acct_id in role_accounts.items():
                if not acct_id:
                    continue
                entry = unique_accounts.setdefault(acct_id.lower(), (acct_id, []))
                entry[1].append(role)
            if len(unique_accounts) == 1 and "kb" not in role_accounts:
                openai = _openai(spec, ids["openai"], checks, runner, candidates)
            else:
                merged_deployments: dict[str, dict[str, Any]] = {}
                merged_missing: dict[str, str] = {}
                primary_account = None
                for idx, (acct_key, (acct_id, acct_roles)) in enumerate(unique_accounts.items()):
                    prefix = "openai" if idx == 0 else f"{acct_roles[0]}_openai"
                    inspected = _openai(spec, acct_id, checks, runner, candidates,
                                        prefix=prefix, roles=tuple(acct_roles))
                    if inspected is not None:
                        if primary_account is None or acct_key == str(ids["openai"]).lower():
                            primary_account = inspected
                        merged_deployments.update(inspected["deployments"])
                        merged_missing.update(inspected["missing_deployments"])
                        for role in acct_roles:
                            openais[role] = {"resource_id": acct_id, "account": inspected}
                if primary_account is not None:
                    openai = {
                        **primary_account,
                        "deployments": merged_deployments,
                        "missing_deployments": merged_missing,
                    }
        span["counts"] = {"checks": len(checks)}
    selected["openais"] = openais
    return search, storage, openai, selected
def _capacity_report(
    spec: ConnectSpec, ids: dict[str, str | None], openai: dict[str, Any] | None,
    checks: list[dict[str, Any]], runner: Callable[..., Any], recorder: TelemetryRecorder,
    *, openais: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if not (openai and openai["deployments"]):
        return {}
    with recorder.span("capacity", resource="model_deployment"):
        return _capacity(spec, str(ids["openai"]), openai, checks, runner, openais=openais)
def _embedding_dimensions(spec: ConnectSpec, openai: dict[str, Any] | None,
                          candidates: dict[str, Any], checks: list[dict[str, Any]],
                          runner: Callable[..., Any]) -> int | None:
    """Explicit value, else the model's documented native size, else an opt-in probe."""
    dimensions = spec.embedding_dimensions
    embedding = (openai or {}).get("deployments", {}).get("embedding")
    if not embedding:
        return dimensions
    model = str(embedding["model"])
    if dimensions is not None:
        problem = embedding_dimensions_error(model, dimensions)
        if problem:
            _check(checks, "openai.embedding_dimensions", "fail", problem)
            return None
        return dimensions
    dimensions = NATIVE_EMBEDDING_DIMENSIONS.get(model)
    if dimensions is not None:
        _check(checks, "openai.embedding_dimensions", "ok",
               f"{model} returns {dimensions} dimensions natively (model docs).",
               dimensions=dimensions, basis="documented_native_size")
        return dimensions
    if spec.probe_embedding_dimensions and openai and openai.get("endpoint"):
        from .spec import probe_embedding_dimensions
        try:
            dimensions = probe_embedding_dimensions(openai["endpoint"], embedding["name"], runner)
        except Exception as error:  # noqa: BLE001 - reported, never guessed
            _check(checks, "openai.embedding_dimensions", "unverified",
                   f"Probe embedding failed ({error}); pass --embedding-dimensions.")
            return None
        _check(checks, "openai.embedding_dimensions", "ok",
               f"One probe embedding from {embedding['name']} returned {dimensions} dimensions.",
               dimensions=dimensions, basis="probe_embedding")
        return dimensions
    candidates["embedding_dimensions"] = (
        f"{model} has no documented native size here; pass --embedding-dimensions or "
        "--probe-embedding-dimensions (one embeddings call)")
    return None
def _role_review(
    spec: ConnectSpec, ids: dict[str, str | None], selected: dict[str, Any],
    operator: dict[str, str], recorder: TelemetryRecorder, runner: Callable[..., Any],
) -> list[dict[str, Any]]:
    required_ids = (ids.get("search"), ids.get("storage"), ids.get("openai"))
    if not (all(required_ids) and spec.storage_container):
        return []
    with recorder.span("rbac-check", resource="role_assignment") as span:
        roles = _rbac(
            spec, operator, ids, selected.get("search_identity"), runner,
            sys_identity=selected.get("search_system_identity"),
        )
        span["counts"] = {"roles": len(roles),
                          "unverified": sum(row["status"] != "assigned" for row in roles)}
    return roles
def _connect_status(
    ids: dict[str, str | None], spec: ConnectSpec, checks: list[dict[str, Any]],
    candidates: dict[str, Any], role_plan: dict[str, Any] | None, uai: dict[str, Any] | None,
    dimensions: int | None, search: dict[str, Any] | None, storage: dict[str, Any] | None,
    openai: dict[str, Any] | None,
) -> tuple[str, list[str], bool]:
    failed = [check["id"] for check in checks if check["status"] == "fail"]
    planned = set((openai or {}).get("missing_deployments") or ())
    required_ids = (ids.get("search"), ids.get("storage"), ids.get("openai"))
    expected_roles = {"embedding", "chat", *(["kb"] if spec.kb_openai or spec.kb_chat_deployment else [])}
    complete = (all(required_ids) and spec.storage_container and uai and dimensions
                and openai and expected_roles.issubset(set(openai["deployments"]))
                and search and storage and not (storage or {}).get("missing_container")
                and "cache_storage" not in candidates)
    covered = (all(required_ids) and spec.storage_container and uai and openai
               and expected_roles.issubset(set(openai["deployments"]) | planned)
               and search and storage)
    status = ("blocked" if failed else
              "needs_setup" if role_plan and not complete and covered and not candidates else
              "incomplete" if not complete or candidates else
              "unverified" if role_plan or any(c["status"] == "unverified" for c in checks)
              else "ready")
    return status, failed, bool(complete)
def connect(spec: ConnectSpec, *, runner: Callable[..., Any] | None = None) -> dict[str, Any]:
    """Discover and validate existing resources. Makes Azure reads only."""
    runner = runner or DEFAULT_RUNNER
    recorder = TelemetryRecorder("connect")
    checks: list[dict[str, Any]] = []
    candidates: dict[str, Any] = {}
    with recorder.span("identity"):
        operator = active_az_identity(spec.tenant_id, spec.subscription_id, runner=runner)
    ids = _resource_ids(spec)
    search_sub = _subscription(ids["search"], spec.search_subscription)
    search_reachable = (search_sub.casefold() == str(spec.subscription_id).casefold()
                        or _search_tenant(spec, search_sub, checks, runner))
    search, storage, openai, selected = _discover_resources(
        spec, ids, checks, candidates, runner, recorder, operator,
        search_reachable=search_reachable,
    )
    openais = selected.get("openais") or {}
    if search and search["sku"] == "serverless":
        openai_resources = (
            [entry["account"] for entry in openais.values() if entry.get("account")]
            if openais else ([openai] if openai else [])
        )
        for kind, resource in [("storage", storage), *(("openai", r) for r in openai_resources)]:
            if resource:
                props = resource["observed"].get("properties") or {}
                acl = props.get("networkAcls") or {}
                if props.get("publicNetworkAccess") != "Enabled" or acl.get("defaultAction") != "Allow":
                    _check(checks, f"search.serverless_{kind}_network", "fail",
                           "Serverless does not support private indexer networking or shared "
                           f"private links to {kind}. Host data-plane reads and an inbound "
                           "Search private endpoint do not prove outbound indexer access. "
                           "Do not widen ingress; select compatible resources explicitly.")
    capacity = _capacity_report(spec, ids, openai, checks, runner, recorder, openais=openais)
    dimensions = _embedding_dimensions(spec, openai, candidates, checks, runner)
    roles = _role_review(spec, ids, selected, operator, recorder, runner)
    for row in roles:
        if row.get("permission_coverage") is not None and row["status"] != "assigned":
            checks.append({"id": f"openai.roles.{row['principal']}",
                           "status": "fail" if row["effective_access"] == "denied" else "unverified",
                           "detail": row["detail"], "evidence": row})
        elif row["status"] != "assigned" and row.get("grant_recommended") is False:
            checks.append({"id": f"roles.{row['principal']}.{row['role']}",
                           "status": "unverified", "detail": row["detail"], "evidence": row})
    role_plan = setup_plan(spec, ids, storage, openai, roles, checks, runner,
                           search=search, openais=openais)
    status, failed, complete = _connect_status(
        ids, spec, checks, candidates, role_plan, selected.get("search_identity"),
        dimensions, search, storage, openai,
    )
    binding = (_binding(spec, ids, search, storage, openai, selected["search_identity"],
                        dimensions, openais=openais)
               if complete and not failed else None)
    payload = {
        "phase": "provision.connect", "status": status,
        "tenant_id": spec.tenant_id, "subscription_id": spec.subscription_id,
        "operator": operator, "resources": {kind: ids[kind] for kind in ids},
        "checks": checks, "blocked_by": failed, "candidates": candidates,
        "capacity": {key: value for key, value in capacity.items()
                     if key != "model_deployments"},
        "roles": roles, "setup_plan": role_plan, "build_binding": binding,
        **({"build_args": binding["build_args"], "args": binding["build_args"]} if binding else {}),
        "evidence": {"origin": "arm_and_data_plane_reads", "writes": 0},
        "uncertainty": [
            "Role checks match assignments at each scope or above to the principal and to "
            "every group it belongs to (Microsoft Graph getMemberObjects, nested groups "
            "included); PIM-eligible and conditional grants are reported as unverified.",
            "Data-plane probes run from this host; the Search service's own network path "
            "to Storage and Azure OpenAI is not exercised until Build.",
        ],
        "telemetry": recorder.events,
    }
    payload["_model_deployments"] = capacity.get("model_deployments", ())
    return payload
def _run_resource(operation: dict[str, Any], runner: Callable[..., Any]) -> None:
    command = az_command([*operation["command"][1:], "--output", "json"], runner)
    try:
        done = runner(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ConnectError(f"{operation['name']}: create outcome uncertain; re-run connect "
                           "before any retry") from error
    if getattr(done, "returncode", 0) != 0:
        detail = str(getattr(done, "stderr", "") or "").strip().splitlines()[-1:] or [""]
        raise ConnectError(f"{operation['name']}: create failed ({detail[0]}). Nothing was "
                           "retried or cleaned up; re-run connect before any retry.")


def _run_grant(spec: ConnectSpec, operation: dict[str, Any],
               runner: Callable[..., Any]) -> dict[str, Any]:
    command = az_command([*operation["command"][1:], "--output", "json"], runner)
    try:
        runner(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise ConnectError(f"{operation['role']}: assignment outcome uncertain; re-run "
                           "connect before any retry") from error
    reread = _principal_roles(spec, operation["principal_object_id"],
                              operation["principal_type"], operation["scope"],
                              (operation["role"],), operation["principal"], runner)[0]
    if reread["status"] != "assigned":
        raise ConnectError(
            f"{operation['role']}: assignment not visible after create; it may have "
            "failed (roleAssignments/write needed) or still be propagating. Re-run "
            "connect before any retry.")
    return {**{key: operation[key] for key in ("role", "scope", "principal")},
            "status": reread["status"]}


def connect_apply(spec: ConnectSpec, *, approved_plan_id: str, confirmed: bool,
                  runner: Callable[..., Any] | None = None) -> dict[str, Any]:
    """Run the reviewed setup plan: the only writes in this module."""
    if not confirmed:
        raise ApprovalRequired("connect setup writes require explicit confirmation")
    runner = runner or DEFAULT_RUNNER
    review = connect(spec, runner=runner)
    if review["status"] == "blocked":
        raise ConnectError("connect setup blocked: " + ", ".join(review["blocked_by"]))
    plan = review["setup_plan"]
    if plan is None:
        return {**public_payload(review), "grant": {"status": "nothing_to_do"}}
    if approved_plan_id != plan["plan_id"]:
        raise ApprovalRequired(
            f"explicit approval of connect setup plan {plan['plan_id']} is required; "
            "resources or assignments may have changed since review")
    recorder = TelemetryRecorder("connect")
    created, results = [], []
    with recorder.span("connect-apply", resource="setup") as span:
        for operation in plan["operations"]:
            if "kind" in operation:
                _run_resource(operation, runner)
                created.append({key: operation[key] for key in ("kind", "name")})
            else:
                results.append(_run_grant(spec, operation, runner))
        span["counts"] = {"resources": len(created), "assignments": len(results)}
    final = connect(spec, runner=runner)
    return {**public_payload(final), "grant": {"status": "applied", "plan_id": plan["plan_id"],
                                               "created": created, "assignments": results},
            "evidence": {**final["evidence"], "writes": len(created) + len(results)},
            "telemetry": final["telemetry"] + recorder.events}
