"""The one follow-up plan connect offers: missing container, model deployments and roles."""
from typing import Any, Callable
from ekg_core.az_identity import IdentityError
from ekg_core.models import TPM_CAPACITY_SKUS, ModelDeploymentSpec, ProvisioningSpec, Target, stable_id
from ..capacity import quota_preflight, read_regional_quota
from .. import model_choice
from ..model_choice import DEFAULT_SKU, LATEST, MIN_CAPACITY_K_TPM, MODEL_DEFAULTS
from .roles import _grant_command
from .spec import ConnectSpec, _check, _parts, _subscription

# The same defaults `entity-graph-provision plan` uses (model_choice). The user can pick any
# model, version and SKU the account's region lists (`entity-graph-provision discover
# --models-for`); the quota preflight checks the choice.


class Unavailable(ValueError):
    """The chosen model can't be deployed here; the message says why in plain words."""


def _choice(spec: ConnectSpec, role: str, catalog: list[Any], usages: list[Any],
            region: str) -> tuple[str, str, str, int | None, bool]:
    model = getattr(spec, f"{role}_model", None)
    version = getattr(spec, f"{role}_model_version", None)
    sku = getattr(spec, f"{role}_sku", None) or DEFAULT_SKU
    capacity = getattr(spec, f"{role}_capacity", None)
    default_model, default_version = MODEL_DEFAULTS[role]
    if model == LATEST:
        model = model_choice.newest_chat_model(catalog, usages, sku) if role == "chat" else None
        if model is None:
            raise Unavailable(f"{region} has no chat model with free quota that Search can use.")
    model = model or default_model
    if version is None:
        version = (default_version if model == default_model and default_version
                   else model_choice.catalog_version(catalog, model))
    if version is None:
        raise Unavailable(f"{model} isn't offered in {region}.")
    if capacity is None and sku not in TPM_CAPACITY_SKUS:
        raise ValueError(f"--{role}-sku {sku} does not count capacity in tokens per "
                         f"minute; pass --{role}-capacity from `entity-graph-provision "
                         "discover --models-for`")
    recommended = (model, sku) == (default_model, DEFAULT_SKU) and capacity is None
    if capacity is None:
        free = model_choice.free_k_tpm(usages, sku, model)
        if free is not None and free < MIN_CAPACITY_K_TPM:
            raise Unavailable(f"{region} has only {free}K tokens per minute free for {model}; "
                              f"a build needs at least {MIN_CAPACITY_K_TPM}K.")
        capacity = model_choice.capacity(role, free)
    return model, version, sku, capacity, recommended


def _container_operation(spec: ConnectSpec, storage_id: str) -> dict[str, Any]:
    return {"kind": "blob_container", "name": spec.storage_container, "scope": storage_id,
            "requires_approval": True,
            "command": ["az", "storage", "container-rm", "create", "--storage-account",
                        storage_id, "--name", spec.storage_container, "--public-access", "off"]}


def _search_system_identity_operation(
    spec: ConnectSpec, search_id: str, *, has_user_assigned: bool = True,
) -> dict[str, Any]:
    _, name = _parts(search_id)
    sub = _subscription(search_id, spec.subscription_id)
    id_type = "SystemAssigned, UserAssigned" if has_user_assigned else "SystemAssigned"
    return {
        "kind": "search_system_identity", "name": name, "scope": search_id,
        "requires_approval": True,
        "command": ["az", "resource", "update", "--ids", search_id,
                    "--api-version", "2025-05-01",
                    "--set", f"identity.type={id_type}",
                    "--subscription", sub],
    }


def _deployment_operations(
    spec: ConnectSpec, openai_id: str, openai: dict[str, Any], checks: list,
    runner: Callable[..., Any],
) -> list[dict[str, Any]]:
    missing = {k: v for k, v in (openai.get("missing_deployments") or {}).items()
               if k in MODEL_DEFAULTS}
    if not missing:
        return []
    group, account = _parts(openai_id)
    sub = _subscription(openai_id, spec.subscription_id)
    pspec = ProvisioningSpec(
        target=Target(subscription_id=sub, resource_group=group,
                      location=openai["location"]),
        search_name="unused", storage_name="unused", openai_name=account)
    try:
        quota = read_regional_quota(pspec, runner=runner)
    except (IdentityError, RuntimeError):
        _check(checks, "capacity.new_deployments", "fail",
               "Could not read regional quota, so the missing models can't be planned. "
               "Check Reader access on the subscription, then run connect again.")
        return []
    choices = {}
    for role in missing:
        try:
            choices[role] = _choice(spec, role, quota["models"], quota["usages"],
                                    openai["location"])
        except Unavailable as error:
            newest = (model_choice.newest_chat_model(quota["models"], quota["usages"])
                      if role == "chat" else None)
            _check(checks, f"capacity.new_{role}", "fail", f"{error} " + (
                f"Offer the newest chat model there, {newest} (--chat-model latest)."
                if newest else "Request more quota, or pick another region."))
    wanted = tuple(ModelDeploymentSpec(role, name, *choices[role][:4])
                   for role, name in missing.items() if role in choices)
    if not wanted:
        return []
    report = quota_preflight(pspec, quota, deployments=wanted)
    rows = {row["deployment"]: row for row in report["deployments"]}
    operations = []
    for deployment in wanted:
        row = rows.get(deployment.name) or {}
        if row.get("blockers"):
            _check(checks, f"capacity.new_{deployment.role}", "fail",
                   "; ".join(row["blockers"]) + ". Request more quota, or pick another region.")
            continue
        operations.append({
            "kind": "model_deployment", "role": deployment.role, "name": deployment.name,
            "model": deployment.model, "version": deployment.version, "sku": deployment.sku,
            "capacity_k_tpm": deployment.capacity, "scope": openai_id,
            "recommended_default": choices[deployment.role][4],
            "quota": {key: row.get(key) for key in ("quota_name", "quota_current_k_tpm",
                                                    "quota_limit_k_tpm")},
            "requires_approval": True,
            "command": ["az", "cognitiveservices", "account", "deployment", "create",
                        "--resource-group", group, "--name", account,
                        "--deployment-name", deployment.name,
                        "--model-name", deployment.model,
                        "--model-version", deployment.version, "--model-format", "OpenAI",
                        "--sku-name", deployment.sku,
                        "--sku-capacity", str(deployment.capacity),
                        "--subscription", sub],
        })
    return operations


def _role_operations(spec: ConnectSpec, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{
        "role": row["role"], "scope": row["scope"], "principal": row["principal"],
        "principal_object_id": row["principal_object_id"],
        "principal_type": row["principal_type"], "requires_approval": True,
        "command": _grant_command(spec, row),
    } for row in rows if row["status"] != "assigned" and row.get("grant_recommended", True)]


def plain(operation: dict[str, Any]) -> str:
    """One plain-language line per write, for the approval text."""
    if operation.get("kind") == "search_system_identity":
        return f"Enable system-assigned identity on Search service {operation['name']}"
    if operation.get("kind") == "blob_container":
        return f"Create private Blob container {operation['name']}"
    if operation.get("kind") == "model_deployment":
        unit = ("K tokens/min" if operation["sku"] in TPM_CAPACITY_SKUS
                else f" {operation['sku']} capacity units")
        return (f"Deploy {operation['model']} {operation['version']} as {operation['name']} "
                f"({operation['sku']}, {operation['capacity_k_tpm']}{unit}"
                + ("; recommended default" if operation.get("recommended_default") else "")
                + "), after a quota check")
    who = (
        "you" if operation["principal"] == "operator"
        else "the Search system identity" if operation["principal"] == "search_system_identity"
        else "the Search identity"
    )
    where = ("the container" if "/containers/" in operation["scope"] else
             "the Search service" if "/searchServices/" in operation["scope"] else
             "the cache storage account" if "/storageAccounts/" in operation["scope"] else
             "the OpenAI account")
    return f"Grant {operation['role']} for {who} on {where}"


def _selection(spec: ConnectSpec, ids: dict[str, str | None],
               openais: dict[str, dict[str, Any]] | None) -> dict[str, dict[str, str]]:
    names = {"embedding": spec.embedding_deployment, "chat": spec.chat_deployment,
             "kb": spec.kb_chat_deployment or (spec.chat_deployment
                                               if spec.kb_openai or spec.kb_chat_deployment
                                               else None)}
    picked = {}
    for role, name in names.items():
        account = ((openais or {}).get(role) or {}).get("resource_id") or ids.get("openai")
        if name and account:
            picked[role] = {"resource_id": str(account).lower(), "deployment": name}
    return picked


def setup_plan(
    spec: ConnectSpec, ids: dict[str, str | None], storage: dict[str, Any] | None,
    openai: dict[str, Any] | None, roles: list[dict[str, Any]], checks: list,
    runner: Callable[..., Any], *, search: dict[str, Any] | None = None,
    openais: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any] | None:
    resources = []
    if search and search.get("missing_system_identity") and ids["search"]:
        has_uai = bool(((search.get("observed") or {}).get("identity") or {}).get("userAssignedIdentities"))
        resources.append(_search_system_identity_operation(
            spec, ids["search"], has_user_assigned=has_uai,
        ))
    if storage and storage.get("missing_container") and ids["storage"]:
        resources.append(_container_operation(spec, ids["storage"]))
    if openais:
        seen_acct: set[str] = set()
        for entry in openais.values():
            acct_id = entry["resource_id"]
            acct_info = entry["account"]
            if acct_id.lower() not in seen_acct and acct_info:
                seen_acct.add(acct_id.lower())
                resources += _deployment_operations(spec, acct_id, acct_info, checks, runner)
    elif openai and ids["openai"]:
        resources += _deployment_operations(spec, ids["openai"], openai, checks, runner)
    grants = _role_operations(spec, roles)
    if not (resources or grants):
        return None
    identity: dict[str, Any] = {
        "tenant_id": spec.tenant_id.lower(), "subscription_id": spec.subscription_id.lower(),
        "operations": [{**{key: op[key] for key in ("role", "principal_object_id",
                                                   "principal_type")},
                        "scope": op["scope"].lower()} for op in grants]}
    if resources:
        identity["resources"] = [
            {key: op.get(key) for key in ("kind", "name", "model", "version", "sku",
                                          "capacity_k_tpm")} | {"scope": op["scope"].lower()}
            for op in resources]
    selection = _selection(spec, ids, openais)
    if resources and selection:
        # The user's exact resource + deployment picks are part of what was approved.
        identity["selection"] = selection
    operations = resources + grants
    return {
        # A roles-only plan keeps its original ID prefix and value.
        "plan_id": stable_id("connect-setup-plan" if resources else "connect-rbac-plan",
                             identity),
        "operations": operations,
        "selection": selection,
        "writes": [plain(op) for op in operations],
        "warning": "Missing roles were not found directly or inherited; a group or PIM grant "
                   "may already cover some. Role writes need Owner or Role Based Access "
                   "Control Administrator at their scope. Nothing is retried or cleaned up "
                   "automatically.",
    }
