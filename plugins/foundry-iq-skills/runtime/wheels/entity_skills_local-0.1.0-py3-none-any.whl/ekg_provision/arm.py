"""Header-visible ARM discovery with the bounded HTTP 429 request policy."""
from __future__ import annotations

import json
import re
import subprocess
from typing import Any, Callable
from urllib.parse import urlsplit

from ekg_core import service_errors
from ekg_core.arm_retry import report, sdk_retry_policy
from ekg_core.az_identity import IdentityError, az_json, claims
from ekg_core.models import ProvisioningSpec


class ArmReadError(IdentityError):
    def __init__(self, status: int, service_error: dict[str, Any] | None = None) -> None:
        message = f"ARM read returned HTTP {status}; no workflow replay or cleanup."
        if service_error:
            message += f" Service error: {service_errors.summary(service_error)}"
        super().__init__(message)
        self.status_code = status
        self.service_error = service_error


_READ_ONLY_POSTS = (
    re.compile(r"/providers/microsoft\.search/fetchofferings"),
    # Evaluates a proposed resource against Azure Policy; it creates nothing.
    re.compile(r"/subscriptions/[0-9a-f-]{36}/providers/microsoft\.policyinsights/"
               r"checkpolicyrestrictions"),
)


def read_json(
    spec: ProvisioningSpec, method: str, url: str, *,
    runner: Callable[..., Any] | None = None,
    observe: Callable[[dict[str, Any]], None] = report,
    body: dict[str, Any] | None = None,
) -> Any:
    """Read ARM JSON with bounded HTTP 429 retries that honor Azure's delay headers."""
    if runner is not None and runner is not subprocess.run:
        # Injected Azure CLI fakes replace the HTTP pipeline in tests.
        return az_json(["rest", "--method", method, "--url", url,
                        *(["--body", json.dumps(body)] if body is not None else [])],
                       runner=runner)
    # Public plans pin their approved tenant; others use the verified az CLI context.
    tenant = spec.public_endpoint.tenant_id if spec.public_endpoint else None
    parsed = urlsplit(url)
    if (parsed.scheme != "https" or parsed.netloc != "management.azure.com"
            or method.lower() not in ("get", "post")
            or (method.lower() == "post"
                and not any(pattern.fullmatch(parsed.path.casefold())
                            for pattern in _READ_ONLY_POSTS))
            or (body is not None and method.lower() != "post")):
        raise IdentityError("unsupported ARM discovery request")
    from azure.core.pipeline import Pipeline
    from azure.core.pipeline.policies import BearerTokenCredentialPolicy
    from azure.core.pipeline.transport import HttpRequest, RequestsTransport
    from azure.identity import AzureCliCredential

    class TenantCredential:
        def __init__(self) -> None:
            self.credential = AzureCliCredential(tenant_id=tenant)

        def get_token(self, *scopes: str, **kwargs: Any) -> Any:
            token = self.credential.get_token(*scopes, **kwargs)
            if tenant and str(claims(token.token).get("tid", "")).casefold() != tenant.casefold():
                raise IdentityError("ARM token tenant differs from the approved tenant")
            return token

    with Pipeline(transport=RequestsTransport(), policies=[
        sdk_retry_policy(observe), BearerTokenCredentialPolicy(
            TenantCredential(), "https://management.azure.com/.default"),
    ]) as pipeline:
        request = HttpRequest(method.upper(), url)
        if body is not None:
            request.set_json_body(body)
            request.headers["Content-Type"] = "application/json"
        response = pipeline.run(request).http_response
        if response.status_code != 200:
            raise ArmReadError(response.status_code, service_errors.from_response(response))
        return json.loads(response.text())
