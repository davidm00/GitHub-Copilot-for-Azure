from __future__ import annotations

from dataclasses import asdict, replace

from ekg_core.models import (
    Operation, Plan, ProvisioningSpec, effective_cache_storage_name, stable_id,
)
from .access import PERMISSIONS as ACCESS_PERMISSIONS, operations as access_operations
from .network import network_operations
from .public_test import validate_public_test
from .search import (
    SERVERLESS_API, SERVERLESS_WARNING, serverless_region_warnings, validate_search,
    validate_search_placement,
)
from ekg_core.arm_retry import POLICY_TEXT


def plan(spec: ProvisioningSpec, *, require_active: bool = True,
         existing_resources: bool = False, kept: frozenset[str] = frozenset()) -> Plan:
    """The provisioning plan. ``kept`` names operations whose resource already exists
    from an earlier Entity Graph plan: they stay as they are, and the plan ID covers them."""
    if existing_resources:
        if spec.public_endpoint or spec.network or spec.create_resource_group or spec.build_access:
            raise ValueError("existing-resource journal planning cannot include provisioning setup")
    else:
        validate_search(spec)
    validate_search_placement(spec)
    validate_public_test(spec, require_active=require_active)
    operations: list[Operation] = []
    network = network_operations(spec)
    if spec.build_access is not None and spec.public_endpoint is None:
        raise ValueError("build access (identity, container, roles) needs a public-test or public-data plan")
    before_search, after_models = access_operations(spec)
    if spec.create_resource_group:
        operations.append(Operation(
            id="create-resource-group", plane="provision", action="create",
            resource="resource_group", name=spec.target.resource_group or "",
            risk="billable_remote_change", reversible=False, requires_approval=True,
            evidence=("resource_id", "location"),
        ))
        if spec.search_is_split:
            operations.append(Operation(
                id="create-search-resource-group", plane="provision", action="create",
                resource="resource_group", name=spec.effective_search_resource_group or "",
                risk="billable_remote_change", reversible=False, requires_approval=True,
                evidence=("resource_id", "location"),
            ))
    operations.extend(before_search)
    cache_name = (
        effective_cache_storage_name(spec)
        if (spec.build_access is not None or spec.cache_storage_name is not None)
        else None
    )
    for resource, name in (
        ("search_service", spec.search_name),
        ("storage_account", spec.storage_name),
        *((("cache_storage_account", cache_name),)
          if cache_name and cache_name != spec.storage_name else ()),
        ("openai_resource", spec.openai_name),
    ):
        operations.append(Operation(
            id=f"create-{resource}", plane="provision", action="ensure",
            resource="storage_account" if resource == "cache_storage_account" else resource,
            name=name, risk="billable_remote_change",
            reversible=False, requires_approval=True,
            evidence=("resource_id", "endpoint", "provisioning_state", "public_network_access"),
            depends_on=(("create-search-identity",)
                        if resource == "search_service" and before_search else ()),
        ))
    if spec.content_understanding_name:
        operations.append(Operation(
            id="create-content-understanding", plane="provision", action="ensure",
            resource="content_understanding", name=spec.content_understanding_name,
            risk="billable_remote_change", reversible=False, requires_approval=True,
            evidence=("resource_id", "endpoint", "provisioning_state", "public_network_access"),
        ))
    for deployment in spec.model_deployments:
        operations.append(Operation(
            id=f"create-{deployment.role}-deployment", plane="provision", action="ensure",
            resource="model_deployment", name=deployment.name,
            risk="billable_remote_change", reversible=False, requires_approval=True,
            evidence=("resource_id", "sku", "capacity", "model", "provisioning_state",
                      "quota_preflight"),
            depends_on=("create-openai_resource",),
        ))
    operations.extend(after_models)
    operations.extend(network)
    unknown = set(kept) - {operation.id for operation in operations}
    if unknown:
        raise ValueError(f"kept operations aren't in the plan: {', '.join(sorted(unknown))}")
    operations = [replace(operation, action="keep") if operation.id in kept else operation
                  for operation in operations]
    identity = asdict(spec)
    if kept:
        identity["kept"] = sorted(kept)
    if spec.search_sku == "serverless":
        identity["search_management_api"] = SERVERLESS_API
    network_permissions = (
        "Microsoft.Network/virtualNetworks/read",
        "Microsoft.Network/virtualNetworks/write",
        "Microsoft.Network/virtualNetworks/subnets/read",
        "Microsoft.Network/virtualNetworks/subnets/write",
        "Microsoft.Network/privateDnsZones/read",
        "Microsoft.Network/privateDnsZones/write",
        "Microsoft.Network/privateDnsZones/virtualNetworkLinks/read",
        "Microsoft.Network/privateDnsZones/virtualNetworkLinks/write",
        "Microsoft.Network/privateEndpoints/read",
        "Microsoft.Network/privateEndpoints/write",
        "Microsoft.Network/privateEndpoints/privateDnsZoneGroups/read",
        "Microsoft.Network/privateEndpoints/privateDnsZoneGroups/write",
    ) if network else ()
    return Plan(
        plan_id=stable_id("provision-plan", identity),
        operations=tuple(operations),
        warnings=((
            "the resource group must already exist or be included in a separately "
            "approved plan before networking can be executed",
        ) if network and not spec.create_resource_group else ()) + ((
            ("TEMPORARY PUBLIC DATA: publicly available corpus only; no non-public data; "
             if spec.public_data else "TEMPORARY PUBLIC TEST: synthetic data only; ")
            + ("internet-reachable, Entra-authenticated endpoints (no IP firewall); "
               "user-delegation Blob SAS remains possible under Entra authority; "
               if spec.public_endpoint.mode == "entra_only" else
               "restrict access to the exact approved VPN egress IPs; ")
            + ("delete the resource group when you're done; nothing is removed "
               "automatically." if spec.public_data else
               "manually remove resources before the stated expiry. "
               "Expiry is an apply gate, not automatic shutdown or cleanup."),
            ("SETUP ONLY: this plan does not ingest documents or build a graph. "
             "Role assignments can take up to 15 minutes to take effect; Build "
             "is a separately approved step."
             if spec.build_access else
             "PROVISIONING ONLY: This plan does not create data-plane RBAC"
             + ("" if spec.model_deployments else ", deploy models")
             + ", ingest a graph or grant data-plane roles. It cannot prove end-to-end "
             "Entity Graph retrieval. A separately approved exact-service guarded Build "
             "and verified Consume are "
             "required; Search indexer service-to-service access remains untested. "
             "Synthetic client-side push/query smoke needs separate data-plane "
             "approval and Entra roles.")
            + (" Run the IP-mode smoke from a client on the allowlist."
               if spec.public_endpoint.mode == "ip_allowlist" else ""),
        ) if spec.public_endpoint else ()) + (
            (SERVERLESS_WARNING,) if spec.search_sku == "serverless" else ()
        ) + serverless_region_warnings(spec) + (POLICY_TEXT,),
        required_permissions=(
            "Microsoft.Resources/subscriptions/resourceGroups/read",
            *(
                ("Microsoft.Resources/subscriptions/resourceGroups/write",)
                if spec.create_resource_group else ()
            ),
            "Microsoft.Search/searchServices/read",
            "Microsoft.Search/searchServices/write",
            *(("Microsoft.Resources/subscriptions/providers/read",
               "Microsoft.Search/fetchOfferings/action")
              if spec.search_sku == "serverless" else ()),
            "Microsoft.Storage/storageAccounts/read",
            "Microsoft.Storage/storageAccounts/write",
            "Microsoft.CognitiveServices/accounts/read",
            "Microsoft.CognitiveServices/accounts/write",
            *((
                "Microsoft.CognitiveServices/accounts/deployments/read",
                "Microsoft.CognitiveServices/accounts/deployments/write",
                "Microsoft.CognitiveServices/locations/usages/read",
                "Microsoft.CognitiveServices/locations/models/read",
            ) if spec.model_deployments else ()),
            *(ACCESS_PERMISSIONS if spec.build_access else ()),
            *network_permissions,
        ),
    )
