"""Build access in the provision plan: the Search identity, the private container and
the eight role assignments Build needs. Every item is a planned, approved operation."""

from __future__ import annotations

import uuid
from fnmatch import fnmatch
from typing import Any

from ekg_core.models import (
    CACHE_USES_SYSTEM_ASSIGNED_IDENTITY, TPM_CAPACITY_SKUS, Operation, ProvisioningSpec,
    effective_cache_storage_name,
)

ROLE_API = "2022-04-01"
IDENTITY_API = "2023-01-31"
CONTAINER_API = "2023-05-01"
# Built-in role definition IDs; they are the same in every tenant.
ROLE_IDS = {
    "Search Service Contributor": "7ca78c08-252a-4471-8644-bb5ff32d4ba0",
    "Search Index Data Contributor": "8ebe5a00-799e-43f5-93ac-243d3dce84a7",
    "Storage Blob Data Contributor": "ba92f5b4-2d11-453d-a403-e96b0029c9fe",
    "Storage Blob Data Reader": "2a2b9908-6ea1-4ae2-8e65-a410df84e7d1",
    "Storage Table Data Contributor": "0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3",
    "Cognitive Services OpenAI User": "5e0bd9bd-7b93-4f28-af87-19fc36ad61bd",
}
CACHE_PRINCIPAL = (
    "search_system_identity" if CACHE_USES_SYSTEM_ASSIGNED_IDENTITY else "search_identity"
)
# (operation suffix, principal, role, scope kind)
GRANTS = (
    ("operator-search-service-contributor", "operator", "Search Service Contributor", "search"),
    ("operator-search-index-data-contributor", "operator", "Search Index Data Contributor",
     "search"),
    ("operator-storage-blob-data-contributor", "operator", "Storage Blob Data Contributor",
     "container"),
    ("operator-openai-user", "operator", "Cognitive Services OpenAI User", "openai"),
    ("search-identity-storage-blob-data-reader", "search_identity", "Storage Blob Data Reader",
     "container"),
    # The Knowledge Source enrichment cache writes blobs and tables in the dedicated cache account.
    ("search-identity-storage-blob-data-contributor", CACHE_PRINCIPAL,
     "Storage Blob Data Contributor", "cache_storage"),
    ("search-identity-storage-table-data-contributor", CACHE_PRINCIPAL,
     "Storage Table Data Contributor", "cache_storage"),
    ("search-identity-openai-user", "search_identity", "Cognitive Services OpenAI User",
     "openai"),
)
_GRANTS = {f"grant-{suffix}": (principal, role, kind) for suffix, principal, role, kind in GRANTS}
PERMISSIONS = (
    "Microsoft.ManagedIdentity/userAssignedIdentities/read",
    "Microsoft.ManagedIdentity/userAssignedIdentities/write",
    "Microsoft.ManagedIdentity/userAssignedIdentities/assign/action",
    "Microsoft.Storage/storageAccounts/blobServices/containers/read",
    "Microsoft.Storage/storageAccounts/blobServices/containers/write",
    "Microsoft.Authorization/roleAssignments/read",
    "Microsoft.Authorization/roleAssignments/write",
)


def _base(spec: ProvisioningSpec) -> str:
    return (f"/subscriptions/{spec.target.subscription_id}"
            f"/resourceGroups/{spec.target.resource_group}")


def search_base(spec: ProvisioningSpec) -> str:
    """Resource group that holds Search; differs from _base when Search is placed apart."""
    return (f"/subscriptions/{spec.effective_search_subscription_id}"
            f"/resourceGroups/{spec.effective_search_resource_group}")


def search_id(spec: ProvisioningSpec) -> str:
    return f"{search_base(spec)}/providers/Microsoft.Search/searchServices/{spec.search_name}"


def identity_id(spec: ProvisioningSpec) -> str:
    assert spec.build_access is not None
    return (f"{_base(spec)}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/"
            f"{spec.build_access.search_identity_name}")


def container_id(spec: ProvisioningSpec) -> str:
    assert spec.build_access is not None
    return (f"{_base(spec)}/providers/Microsoft.Storage/storageAccounts/{spec.storage_name}"
            f"/blobServices/default/containers/{spec.build_access.storage_container}")


def scope(spec: ProvisioningSpec, kind: str) -> str:
    if kind == "container":
        return container_id(spec)
    if kind == "search":
        return search_id(spec)
    if kind in ("storage", "cache_storage"):
        cache_name = effective_cache_storage_name(spec)
        return f"{_base(spec)}/providers/Microsoft.Storage/storageAccounts/{cache_name}"
    return f"{_base(spec)}/providers/Microsoft.CognitiveServices/accounts/{spec.openai_name}"


def grant(operation_id: str, spec: ProvisioningSpec | None = None) -> tuple[str, str, str]:
    """(principal, role, scope kind) of a planned role assignment."""
    principal, role, kind = _GRANTS[operation_id]
    if spec is not None and spec.build_access is not None and spec.build_access.uses_system_identity:
        if principal == "search_identity":
            principal = "search_system_identity"
    return principal, role, kind


def role_assignment_id(spec: ProvisioningSpec, operation_id: str) -> str:
    """Deterministic assignment name, so a rerun finds the one it made."""
    assert spec.build_access is not None
    principal, role, kind = grant(operation_id, spec)
    at = scope(spec, kind)
    who = (
        spec.build_access.operator_object_id.lower() if principal == "operator"
        else f"{search_id(spec)}|system".lower()
        if principal == "search_system_identity"
        else identity_id(spec).lower()
    )
    name = uuid.uuid5(uuid.NAMESPACE_URL, f"{at.lower()}|{who}|{ROLE_IDS[role]}")
    return f"{at}/providers/Microsoft.Authorization/roleAssignments/{name}"


def operations(spec: ProvisioningSpec) -> tuple[list[Operation], list[Operation]]:
    """(before Search, after the services and models) operations for build access."""
    access = spec.build_access
    if access is None:
        return [], []
    use_sys = access.uses_system_identity
    before = [] if use_sys else [Operation(
        id="create-search-identity", plane="provision", action="ensure",
        resource="search_identity", name=access.search_identity_name,
        risk="remote_change", reversible=False, requires_approval=True,
        evidence=("resource_id", "principal_id"),
    )]
    after = [Operation(
        id="create-blob-container", plane="provision", action="ensure",
        resource="blob_container", name=access.storage_container,
        risk="remote_change", reversible=False, requires_approval=True,
        evidence=("resource_id", "public_access"), depends_on=("create-storage_account",),
    )]
    cache_name = effective_cache_storage_name(spec)
    storage_dep = (
        "create-cache_storage_account"
        if cache_name != spec.storage_name
        else "create-storage_account"
    )
    held = {role for role, _ in access.operator_held}
    for suffix, raw_principal, role, kind in GRANTS:
        if raw_principal == "operator" and role in held:
            continue
        principal =  "search_system_identity" if (use_sys and raw_principal == "search_identity") else raw_principal
        principal_label = (
            "you" if principal == "operator"
            else "the Search system identity" if principal == "search_system_identity"
            else "the Search identity"
        )
        identity_deps = (
            ("create-search_service",) if principal == "search_system_identity"
            else ("create-search-identity",) if principal == "search_identity"
            else ()
        )
        after.append(Operation(
            id=f"grant-{suffix}", plane="provision", action="ensure",
            resource="role_assignment",
            name=f"{role} for {principal_label}",
            risk="access_change", reversible=False, requires_approval=True,
            evidence=("resource_id", "role", "principal_id", "scope"),
            depends_on=tuple(dict.fromkeys((
                "create-blob-container" if kind == "container" else
                "create-search_service" if kind == "search" else
                storage_dep if kind in ("storage", "cache_storage") else
                "create-openai_resource",
                *identity_deps,
            ))),
        ))
    return before, after


def desired(spec: ProvisioningSpec, operation: Operation, *, principal_id: str | None = None,
            tags: dict[str, str] | None = None) -> dict[str, Any]:
    assert spec.build_access is not None
    if operation.resource == "search_identity":
        payload: dict[str, Any] = {"location": spec.target.location}
        if tags:
            payload["tags"] = tags
        return payload
    if operation.resource == "blob_container":
        return {"properties": {"publicAccess": "None"}}
    who, role, kind = grant(operation.id, spec)
    # Role definitions are referenced in the subscription of the scope they are assigned at.
    subscription = scope(spec, kind).split("/")[2]
    return {"properties": {
        "roleDefinitionId": (f"/subscriptions/{subscription}/providers/"
                             f"Microsoft.Authorization/roleDefinitions/{ROLE_IDS[role]}"),
        "principalId": principal_id,
        "principalType": (spec.build_access.operator_principal_type if who == "operator"
                          else "ServicePrincipal"),
    }}


def principal_for(spec: ProvisioningSpec, operation_id: str,
                  identity_principal: str | None,
                  search_system_principal: str | None = None) -> str | None:
    assert spec.build_access is not None
    who, _, _ = grant(operation_id, spec)
    if who == "operator":
        return spec.build_access.operator_object_id
    if who == "search_system_identity":
        return search_system_principal if search_system_principal is not None else identity_principal
    return identity_principal


ROLE_WRITE = "Microsoft.Authorization/roleAssignments/write"


def missing_actions(permissions: Any, actions: tuple[str, ...]) -> list[str]:
    """Actions no permission row grants (Actions match, NotActions don't); unreadable denies all."""
    rows = permissions.get("value") if isinstance(permissions, dict) else None
    rows = [row for row in rows or () if isinstance(row, dict)]

    def allowed(action: str) -> bool:
        wanted = action.lower()
        return any(
            any(fnmatch(wanted, str(item).lower()) for item in row.get("actions") or ())
            and not any(fnmatch(wanted, str(item).lower()) for item in row.get("notActions") or ())
            for row in rows)

    return [action for action in dict.fromkeys(actions) if not allowed(action)]


def can_assign_roles(permissions: Any) -> bool:
    """Whether an ARM permissions listing allows roleAssignments/write."""
    return not missing_actions(permissions, (ROLE_WRITE,))


def scope_of(spec: ProvisioningSpec, operation: Operation) -> tuple[str, str | None]:
    """(subscription, resource group or None) that an operation writes into."""
    if operation.resource == "resource_group":
        return ((spec.effective_search_subscription_id, None)
                if operation.id == "create-search-resource-group"
                else (spec.target.subscription_id, None))
    if operation.resource == "search_service":
        return spec.effective_search_subscription_id, spec.effective_search_resource_group
    if operation.resource == "role_assignment":
        parts = scope(spec, grant(operation.id, spec)[2]).split("/")
        return parts[2], parts[4]
    return spec.target.subscription_id, spec.target.resource_group


def plain_writes(spec: ProvisioningSpec, operations_: tuple[Operation, ...]) -> list[str]:
    """One plain-language line per planned write, for the approval text."""
    lines = []
    for operation in operations_:
        if operation.resource == "resource_group":
            if operation.id == "create-search-resource-group":
                lines.append(f"Create resource group {operation.name} for Search")
            else:
                lines.append(f"Create resource group {operation.name}")
        elif operation.resource == "search_identity":
            lines.append(f"Create managed identity {operation.name} for Search to read "
                         "documents and call models")
        elif operation.resource == "search_service":
            loc_suffix = (f", in {spec.search_location}"
                          if spec.search_location and spec.search_location != spec.target.location
                          else "")
            has_uai = bool(spec.build_access and not spec.build_access.uses_system_identity)
            lines.append(f"Create Azure AI Search {operation.name} ({spec.search_sku}{loc_suffix})"
                         + (" with the managed identity attached" if has_uai else ""))
        elif operation.resource == "storage_account":
            if operation.id == "create-cache_storage_account":
                lines.append(f"Create StorageV2 enrichment-cache storage account {operation.name}")
            else:
                lines.append(f"Create storage account {operation.name}")
        elif operation.resource == "blob_container":
            lines.append(f"Create private Blob container {operation.name}")
        elif operation.resource == "content_understanding":
            lines.append(f"Create Content Understanding account {operation.name} so PDFs, "
                         "Office files and images can be read")
        elif operation.resource == "openai_resource":
            loc_suffix = (f" in {spec.openai_location}"
                          if spec.openai_location and spec.openai_location != spec.target.location
                          else "")
            lines.append(f"Create Azure OpenAI account {operation.name}{loc_suffix}")
        elif operation.resource == "model_deployment":
            model = next(item for item in spec.model_deployments if item.name == operation.name)
            unit = ("K tokens/min" if model.sku in TPM_CAPACITY_SKUS
                    else f" {model.sku} capacity units")
            lines.append(f"Deploy {model.model} {model.version} as {model.name} ({model.sku}, "
                         f"{model.capacity}{unit}), after a quota check")
        elif operation.resource == "role_assignment":
            _, role, kind = grant(operation.id)
            dedicated_cache = effective_cache_storage_name(spec) != spec.storage_name
            target = {"search": "the Search service", "container": "the container",
                      "storage": "the cache storage account" if dedicated_cache else "the storage account",
                      "cache_storage": "the cache storage account" if dedicated_cache else "the storage account",
                      "openai": "the OpenAI account"}[kind]
            lines.append(f"Grant {operation.name} on {target}")
        else:
            lines.append(f"{operation.action.capitalize()} {operation.resource} {operation.name}")
    if spec.search_is_split:
        # Two placements: say where every write lands.
        labelled = []
        for line, operation in zip(lines, operations_):
            subscription, group = scope_of(spec, operation)
            other = str(subscription).casefold() != str(spec.target.subscription_id).casefold()
            where = ([f"subscription {subscription}"] if other else []) + (
                [f"resource group {group}"] if group else [])
            labelled.append(f"{line} [{', '.join(where)}]" if where else line)
        lines = labelled
    return lines
