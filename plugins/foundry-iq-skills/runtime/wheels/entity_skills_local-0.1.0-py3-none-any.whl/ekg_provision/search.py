"""Search provisioning policy and read-only Serverless availability preflight."""
from __future__ import annotations

import re
from dataclasses import replace
from typing import Any

from ekg_core.models import ProvisioningSpec
from .arm import read_json

DEDICATED_API = "2025-05-01"
SERVERLESS_API = "2026-09-01-preview"
# The ARM SearchServices sku.name enum (Microsoft.Search 2025-05-01 plus the serverless
# preview), minus free, which has no managed identity:
# https://learn.microsoft.com/rest/api/searchmanagement/services/create-or-update#skuname
SEARCH_SKUS = (
    "serverless", "basic", "standard", "standard2", "standard3",
    "storage_optimized_l1", "storage_optimized_l2",
)
# STATIC FALLBACK ONLY, not an admission list. The live check is serverless_preflight
# (provider registration + POST fetchOfferings), which runs before any write and is the
# source of truth. This list is the published region table, used to warn at plan time
# when no live read has happened yet.
# https://learn.microsoft.com/azure/search/search-region-support (2026-10-09)
SERVERLESS_REGIONS = (
    "australiaeast", "centralindia", "centralus", "centraluseuap", "eastus2euap",
    "italynorth", "japaneast", "northcentralus", "norwayeast", "swedencentral",
    "switzerlandnorth", "uaenorth", "uksouth", "westcentralus", "westus", "westus2", "westus3",
)
# Entity Graph's build and query calls need this Search data-plane API version. Azure
# publishes no per-region list of data-plane versions, so new services are checked
# against the regions known to serve it; `connect` probes an existing service directly.
# Add regions here as the preview rolls out.
GRAPH_DATA_API = "2026-11-01-preview"
GRAPH_API_REGIONS = ("eastus2euap",)
DEFAULT_SEARCH_LOCATION = GRAPH_API_REGIONS[0]
_REGION_WORDS = {"us": "US", "eu": "EU", "uk": "UK", "uae": "UAE", "euap": "EUAP"}


def region_name(code: str | None) -> str:
    """'westus3' -> 'West US 3', 'eastus2euap' -> 'East US 2 EUAP', for plain-language text."""
    words = re.findall(r"north|south|east|west|central|euap|uae|us|uk|eu|\d+|[a-z]+",
                        str(code or "").casefold())
    return " ".join(_REGION_WORDS.get(word, word.capitalize()) for word in words) or "unknown"


def graph_api_problem(spec: ProvisioningSpec) -> str | None:
    """Why a new Search service in this region can't serve the graph API, or None."""
    location = (spec.effective_search_location or "").casefold()
    if location in GRAPH_API_REGIONS:
        return None
    return (f"Search in {region_name(location)} doesn't have the graph API "
            f"({GRAPH_DATA_API}) yet, so the graph steps would fail there. Put Search in "
            f"{', '.join(region_name(r) for r in GRAPH_API_REGIONS)} "
            f"({', '.join(GRAPH_API_REGIONS)}); the models can stay where they are.")


SERVERLESS_WARNING = (
    "Serverless preview: no SLA, index aliases, tier migration, private networking "
    "for indexers or shared private links. Inbound private endpoints do not provide "
    "outbound indexer connectivity. Compute Units and indexed storage are billable; "
    "usage cost is unknown, not zero. Provisioning readiness does not prove managed "
    "Azure Blob graphExtraction support; a separately approved exact-service Build "
    "and extraction/retrieval trial are still required."
)


def management_api(spec: ProvisioningSpec) -> str:
    return SERVERLESS_API if spec.search_sku == "serverless" else DEDICATED_API


def serverless_region_warnings(spec: ProvisioningSpec) -> tuple[str, ...]:
    """Plan-time note from the static fallback list; apply checks fetchOfferings live."""
    location = spec.effective_search_location
    if spec.search_sku != "serverless" or not location or location in SERVERLESS_REGIONS:
        return ()
    return (f"Serverless in {location}: not in the static fallback region list "
            "(search-region-support). Apply checks live Serverless offerings for "
            f"{location} before any write and stops if none is offered.",)


def validate_search(spec: ProvisioningSpec) -> None:
    if spec.search_sku not in SEARCH_SKUS:
        raise ValueError(f"Search SKU must be one of {', '.join(SEARCH_SKUS)}")
    if spec.search_sku != "serverless":
        return
    if spec.network is not None:
        raise ValueError(
            "Serverless cannot use this private-indexer configuration: inbound private "
            "endpoints do not enable outbound indexer networking. Explicitly opt in to "
            "a compatible Dedicated SKU and review its private-indexer requirements."
        )
    if spec.public_endpoint and spec.public_endpoint.mode != "entra_only":
        raise ValueError(
            "Serverless provisioning supports only explicit entra_only public mode; "
            "IP-allowlist provisioning requires an explicit Dedicated --search-sku."
        )


def validate_search_placement(spec: ProvisioningSpec) -> None:
    guid = r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"
    if spec.search_subscription_id is not None and not re.fullmatch(
            guid, str(spec.search_subscription_id)):
        raise ValueError("invalid search_subscription_id: must be a subscription GUID")
    if spec.search_resource_group is not None and (
            not re.fullmatch(r"[a-zA-Z0-9_.()\-]{1,90}", str(spec.search_resource_group))
            or str(spec.search_resource_group).endswith(".")):
        raise ValueError("invalid search_resource_group")
    if not spec.search_is_split:
        return
    if spec.public_endpoint is None:
        raise ValueError("a separate Search subscription or resource group needs a "
                         "public-test or public-data plan")
    if spec.network is not None:
        raise ValueError("a separate Search subscription or resource group can't be "
                         "combined with private networking")


def search_view(spec: ProvisioningSpec) -> ProvisioningSpec:
    """The spec as seen from Search's own subscription and resource group."""
    if not spec.search_is_split:
        return spec
    return replace(spec, target=replace(
        spec.target, subscription_id=spec.effective_search_subscription_id,
        resource_group=spec.effective_search_resource_group,
        location=spec.effective_search_location,
    ))


def read_serverless_availability(spec: ProvisioningSpec, **kwargs: Any) -> dict[str, Any]:
    """No writes: provider registration metadata and regional offering discovery."""
    root = "https://management.azure.com"
    reader = kwargs.pop("reader", None) or read_json

    def read(method: str, url: str) -> Any:
        return reader(spec, method, url, **kwargs)

    provider = read("get",
        f"{root}/subscriptions/{spec.effective_search_subscription_id}/providers/Microsoft.Search"
        "?api-version=2021-04-01",
        )
    # Fetch Offerings is a read-only action (POST with no request body).
    offerings = read("post",
        f"{root}/providers/Microsoft.Search/fetchOfferings?api-version={SERVERLESS_API}",
        )
    return {"provider": provider, "offerings": offerings}


def serverless_preflight(spec: ProvisioningSpec, observed: dict[str, Any]) -> dict[str, str]:
    provider = observed.get("provider")
    if not isinstance(provider, dict) or provider.get("registrationState") != "Registered":
        raise ValueError("Serverless preflight: Microsoft.Search must already be Registered")
    types = provider.get("resourceTypes")
    if not isinstance(types, list) or not any(
        isinstance(item, dict)
        and str(item.get("resourceType", "")).lower() == "searchservices"
        and isinstance(item.get("apiVersions"), list)
        and any(isinstance(version, str) and version.casefold() == SERVERLESS_API.casefold()
                for version in item["apiVersions"])
        for item in types
    ):
        raise ValueError(
            f"Serverless preflight: management API {SERVERLESS_API} is not advertised "
            "by the target subscription; no writes and no Dedicated fallback"
        )
    offerings = observed.get("offerings")
    regions = offerings.get("regions") if isinstance(offerings, dict) else None
    location = spec.effective_search_location or ""
    if not isinstance(regions, list) or not any(
        isinstance(region, dict)
        and str(region.get("regionName", "")).replace(" ", "").casefold() == location.casefold()
        and isinstance(region.get("skus"), list)
        and any(isinstance(item, dict) and item.get("name") == "serverless"
                for item in region["skus"])
        for region in regions
    ):
        raise ValueError(
            f"Serverless preflight: no current Serverless offering for {location}; "
            "no writes and no Dedicated fallback"
        )
    return {"origin": "arm_provider_and_fetch_offerings", "api_version": SERVERLESS_API,
            "location": location, "sku": "serverless"}
