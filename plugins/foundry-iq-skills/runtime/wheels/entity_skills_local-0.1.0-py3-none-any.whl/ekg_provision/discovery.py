"""Deterministic Foundry/Azure OpenAI model discovery shared by the graph runtimes.

The runtime enumerates and the user chooses. Nothing here selects, ranks, caps or hides
a candidate: every account, project and deployment the caller can see is returned in a
stable order, and anything that can't be used or verified is marked, not dropped.
"""
from __future__ import annotations

import json
import re
import subprocess
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Iterable
from urllib.parse import urlsplit

from ekg_core.az_identity import IdentityError, az_json, claims
from ekg_core.group_membership import UNREADABLE, Membership
from ekg_core.models import TPM_CAPACITY_SKUS, stable_id
from ekg_core.resource_endpoints import cognitive_account_endpoint
from ekg_core.search_models import SEARCH_MODEL_SOURCES, search_admits
from .model_choice import DEFAULT_SKU, ENTITY_SEARCH_API, MODEL_DEFAULTS

ARM = "https://management.azure.com"
# Resource Graph REST: https://learn.microsoft.com/rest/api/azureresourcegraph/resourcegraph/resources/resources
RESOURCE_GRAPH_URL = f"{ARM}/providers/Microsoft.ResourceGraph/resources?api-version=2022-10-01"
ACCOUNTS_API = "2024-10-01"
PROJECTS_API = "2025-06-01"
SUBSCRIPTIONS_API = "2022-12-01"
ROLE_API = "2022-04-01"
# Azure OpenAI deployments live on Cognitive Services accounts of kind OpenAI or AIServices
# (Foundry); a Foundry project uses its parent AIServices account's deployments. Other kinds
# (Speech, Vision, ...) can't host them. Sources:
# https://learn.microsoft.com/azure/ai-foundry/openai/how-to/create-resource
# https://learn.microsoft.com/azure/ai-foundry/concepts/resource-types
MODEL_HOSTING_KINDS = ("OpenAI", "AIServices")
# The defaults plan uses (model_choice), shown as "recommended default" when a new
# deployment is planned. A None version means the region catalog's default version. Other
# models the region lists are equally selectable; table order is alphabetical.
RECOMMENDED_NEW_DEPLOYMENTS = {
    role: {"model": model, "version": version, "sku": DEFAULT_SKU}
    for role, (model, version) in MODEL_DEFAULTS.items()
}
DATA_ACTIONS = {
    "chat": "Microsoft.CognitiveServices/accounts/OpenAI/deployments/chat/completions/action",
    "embedding": "Microsoft.CognitiveServices/accounts/OpenAI/deployments/embeddings/action",
}
ROLES = ("chat", "embedding", "kb")
_GUID = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")
_RG = re.compile(r"[-\w._()]{1,90}")
_ACCOUNT_ID = re.compile(
    r"/subscriptions/([^/]+)/resourceGroups/([^/]+)/providers/Microsoft\.CognitiveServices"
    r"/accounts/([^/]+)(?:/projects/([^/]+))?/?", re.IGNORECASE)


class DiscoveryError(RuntimeError):
    pass


class ArmError(RuntimeError):
    pass


def _safe(url: str) -> str:
    parts = urlsplit(url)
    if parts.scheme != "https" or parts.netloc.lower() != "management.azure.com" or parts.fragment:
        raise ArmError("refusing a non-ARM URL")
    return url


class AzRestClient:
    """One `az rest` call per request; used where a runner is injected (tests, connect)."""

    def __init__(self, runner: Callable[..., Any]) -> None:
        self.runner = runner

    def get(self, url: str) -> Any:
        try:
            return az_json(["rest", "--method", "get", "--url", _safe(url)], runner=self.runner)
        except IdentityError as error:
            raise ArmError(str(error)) from error

    def post(self, url: str, body: dict[str, Any]) -> Any:
        try:
            return az_json(["rest", "--method", "post", "--url", _safe(url), "--body",
                            json.dumps(body, separators=(",", ":"))], runner=self.runner)
        except IdentityError as error:
            raise ArmError(str(error)) from error


class TokenArmClient:
    """One ARM token from the Azure CLI, then direct HTTPS; fast enough for many accounts."""

    def __init__(self, tenant_id: str, runner: Callable[..., Any] = subprocess.run) -> None:
        issued = az_json(["account", "get-access-token", "--tenant", tenant_id,
                          "--resource", f"{ARM}/"], runner=runner)
        token = issued.get("accessToken") if isinstance(issued, dict) else None
        if not isinstance(token, str):
            raise IdentityError("Azure CLI did not return an ARM access token")
        self.claims = claims(token)
        if str(self.claims.get("tid", "")).casefold() != tenant_id.casefold():
            raise IdentityError("the ARM token is not for the requested tenant")
        self._token = token

    def _send(self, method: str, url: str, body: dict[str, Any] | None = None) -> Any:
        from ekg_core import skill_user_agent
        data = None if body is None else json.dumps(body).encode()
        for attempt in range(4):
            request = urllib.request.Request(_safe(url), data=data, method=method, headers={
                "Authorization": f"Bearer {self._token}", "Content-Type": "application/json",
                "User-Agent": skill_user_agent()})
            try:
                with urllib.request.urlopen(request, timeout=60) as response:
                    raw = response.read()
                return json.loads(raw) if raw else None
            except urllib.error.HTTPError as error:
                if error.code == 429 and attempt < 3:
                    try:
                        wait = float(error.headers.get("Retry-After") or 2)
                    except ValueError:
                        wait = 2.0
                    time.sleep(min(max(wait, 1.0), 10.0))
                    continue
                raise ArmError(f"ARM {method} returned HTTP {error.code}") from None
            except (urllib.error.URLError, OSError, ValueError) as error:
                raise ArmError(f"ARM {method} failed ({type(error).__name__})") from None
        raise ArmError(f"ARM {method} stayed throttled")

    def get(self, url: str) -> Any:
        return self._send("GET", url)

    def post(self, url: str, body: dict[str, Any]) -> Any:
        return self._send("POST", url, body)


def client_for(runner: Callable[..., Any], tenant_id: str) -> Any:
    return TokenArmClient(tenant_id) if runner is subprocess.run else AzRestClient(runner)


def _pages(client: Any, url: str) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    while url:
        if url in seen:
            raise ArmError("ARM returned a repeated nextLink")
        seen.add(url)
        page = client.get(url)
        if not isinstance(page, dict):
            raise ArmError("ARM returned a malformed page")
        rows += [row for row in page.get("value") or [] if isinstance(row, dict)]
        url = page.get("nextLink") or ""
    return rows


def _graph(client: Any, query: str, subscriptions: list[str] | None) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    token = None
    while True:
        options: dict[str, Any] = {"$top": 1000, "resultFormat": "objectArray"}
        if token:
            options["$skipToken"] = token
        body: dict[str, Any] = {"query": query, "options": options}
        if subscriptions:
            body["subscriptions"] = subscriptions
        page = client.post(RESOURCE_GRAPH_URL, body)
        if not isinstance(page, dict) or not isinstance(page.get("data"), list):
            raise ArmError("Resource Graph returned a malformed page")
        rows += [row for row in page["data"] if isinstance(row, dict)]
        token = page.get("$skipToken")
        if not token:
            return rows


def _canonical(resource_id: str) -> str:
    match = _ACCOUNT_ID.fullmatch(resource_id or "")
    if not match:
        return resource_id
    sub, group, account, project = match.groups()
    base = (f"/subscriptions/{sub.lower()}/resourceGroups/{group}/providers/"
            f"Microsoft.CognitiveServices/accounts/{account}")
    return f"{base}/projects/{project}" if project else base


def _sort_key(row: dict[str, Any]) -> tuple[str, str, str]:
    return (str(row.get("subscription_id") or "").casefold(),
            str(row.get("resource_group") or "").casefold(),
            str(row.get("name") or "").casefold())


def _endpoint(props: dict[str, Any], project: bool) -> str | None:
    endpoints = props.get("endpoints") if isinstance(props.get("endpoints"), dict) else {}
    if project:
        return endpoints.get("AI Foundry API") or props.get("endpoint")
    try:
        return cognitive_account_endpoint(props)
    except ValueError:
        return None


def _normalize(item: dict[str, Any], *, sub_names: dict[str, str]) -> dict[str, Any] | None:
    raw_id = str(item.get("id") or "")
    match = _ACCOUNT_ID.fullmatch(raw_id)
    if not match:
        return None
    sub, group, account, project = match.groups()
    props = item.get("properties") if isinstance(item.get("properties"), dict) else {
        key: item.get(key) for key in ("endpoint", "endpoints", "provisioningState",
                                       "publicNetworkAccess")}
    sku = item.get("sku")
    resource_id = _canonical(raw_id)
    return {
        "resource_id": resource_id,
        "name": f"{account}/{project}" if project else account,
        "type": "project" if project else "account",
        "kind": item.get("kind"),
        "subscription_id": sub.lower(),
        "subscription_name": item.get("subscriptionName") or sub_names.get(sub.lower()),
        "resource_group": item.get("resourceGroup") or group,
        "location": item.get("location"),
        "region": str(item.get("location") or "").replace(" ", "").lower() or None,
        "provisioning_state": props.get("provisioningState"),
        "public_network_access": props.get("publicNetworkAccess"),
        "endpoint": _endpoint(props, bool(project)),
        "sku": sku.get("name") if isinstance(sku, dict) else sku,
        "model_resource_id": _canonical(raw_id.split("/projects/")[0]) if project else resource_id,
    }


def _graph_query(resource_group: str | None) -> str:
    query = ("resources | where type in~ ('microsoft.cognitiveservices/accounts', "
             "'microsoft.cognitiveservices/accounts/projects')")
    if resource_group:
        query += f" | where resourceGroup =~ '{resource_group}'"
    return query + (
        " | join kind=leftouter (resourcecontainers | where type =~ "
        "'microsoft.resources/subscriptions' | project subscriptionId, subscriptionName=name)"
        " on subscriptionId"
        " | project id, name, type, kind, location, subscriptionId, subscriptionName,"
        " resourceGroup, sku=tostring(sku.name),"
        " provisioningState=tostring(properties.provisioningState),"
        " endpoint=tostring(properties.endpoint), endpoints=properties.endpoints,"
        " publicNetworkAccess=tostring(properties.publicNetworkAccess)"
        " | order by subscriptionId asc, resourceGroup asc, name asc")


def _arm_subscriptions(client: Any, tenant_id: str) -> dict[str, dict[str, Any]]:
    """Enabled subscriptions of the tenant from ARM, keyed by lower-case ID."""
    found = {}
    for item in _pages(client, f"{ARM}/subscriptions?api-version={SUBSCRIPTIONS_API}"):
        if (str(item.get("tenantId", tenant_id)).casefold() == tenant_id.casefold()
                and item.get("state") == "Enabled"
                and _GUID.fullmatch(str(item.get("subscriptionId") or ""))):
            found[item["subscriptionId"].lower()] = {
                "name": item.get("displayName"), "tenant_id": item.get("tenantId") or tenant_id,
                "state": item.get("state")}
    return found


def _enumerate(client: Any, tenant_id: str, subscriptions: list[str] | None,
               resource_group: str | None, fallback_subscriptions: list[str],
               warnings: list[str], *, use_graph: bool = True
               ) -> tuple[list[dict[str, Any]], str, int | None]:
    if use_graph:
        try:
            rows = _graph(client, _graph_query(resource_group), subscriptions)
            found = [row for row in (_normalize(item, sub_names={}) for item in rows) if row]
            return found, "resource-graph", len({row["subscription_id"] for row in found})
        except ArmError as error:
            warnings.append(f"Resource Graph was unavailable ({error}); listed accounts per "
                            "subscription instead.")
    subs = list(subscriptions or [])
    names: dict[str, str] = {}
    if not subs:
        try:
            for sub, info in _arm_subscriptions(client, tenant_id).items():
                subs.append(sub)
                names[sub] = info["name"]
        except ArmError as error:
            if not fallback_subscriptions:
                raise DiscoveryError("Could not list subscriptions or query Resource Graph; "
                                     "pass --subscription-id to search a known subscription."
                                     ) from error
            subs = list(fallback_subscriptions)
            warnings.append("Could not list subscriptions; searched only "
                            + ", ".join(subs) + ".")
    found: list[dict[str, Any]] = []
    for sub in sorted(set(subs)):
        scope = f"/subscriptions/{sub}" + (f"/resourceGroups/{resource_group}"
                                           if resource_group else "")
        try:
            accounts = _pages(client, f"{ARM}{scope}/providers/Microsoft.CognitiveServices/"
                                      f"accounts?api-version={ACCOUNTS_API}")
        except ArmError as error:
            warnings.append(f"Could not list accounts in subscription {sub} ({error}).")
            continue
        for item in accounts:
            row = _normalize(item, sub_names=names)
            if not row:
                continue
            found.append(row)
            if row["kind"] == "AIServices":
                try:
                    projects = _pages(client, f"{ARM}{row['resource_id']}/projects"
                                              f"?api-version={PROJECTS_API}")
                except ArmError:
                    warnings.append(f"Could not list projects of {row['resource_id']}.")
                    continue
                found += [p for p in (_normalize({**proj, "kind": proj.get("kind") or "AIServices"},
                                                 sub_names=names) for proj in projects) if p]
    return found, "per-subscription-fallback", len(set(subs))


def _truthy(capabilities: dict[str, Any]) -> list[str]:
    return sorted(key for key, value in capabilities.items() if str(value).lower() == "true")


def roles_from_capabilities(capabilities: dict[str, Any] | None) -> list[str] | None:
    """chatCompletion -> chat and kb; embeddings -> embedding. None when unreported.

    Capability names are the ARM `capabilities` map on deployments and on the regional
    model catalog: https://learn.microsoft.com/rest/api/aiservices/accountmanagement/deployments/get
    """
    if not isinstance(capabilities, dict) or not capabilities:
        return None
    truthy = set(_truthy(capabilities))
    return (["embedding"] if "embeddings" in truthy else []) + (
        ["chat", "kb"] if "chatCompletion" in truthy else [])


def deployment_row(item: dict[str, Any], catalog: dict[tuple, dict[str, Any]] | None = None
                   ) -> dict[str, Any]:
    props = item.get("properties") if isinstance(item.get("properties"), dict) else {}
    model = props.get("model") if isinstance(props.get("model"), dict) else {}
    sku = item.get("sku") if isinstance(item.get("sku"), dict) else {}
    capabilities = props.get("capabilities") if isinstance(props.get("capabilities"), dict) else None
    basis = "deployment_capabilities"
    roles = roles_from_capabilities(capabilities)
    if roles is None and catalog:
        listed = catalog.get((model.get("format"), model.get("name"), str(model.get("version"))))
        if listed is not None:
            capabilities, basis = listed, "region_model_catalog"
            roles = roles_from_capabilities(listed)
    if roles is None:
        basis = "capabilities_unreported"
    state = props.get("provisioningState")
    reason = None
    if str(state or "").lower() != "succeeded":
        reason = f"provisioningState is {state}"
    elif roles == []:
        reason = ("capabilities report neither chatCompletion nor embeddings ("
                  + (", ".join(_truthy(capabilities or {})) or "none") + ")")
    usable = False if reason else (None if roles is None else True)
    row = {
        "name": item.get("name"), "model": model.get("name"),
        "version": model.get("version"), "format": model.get("format"),
        "sku": sku.get("name"), "capacity": sku.get("capacity"),
        "capacity_unit": "k_tpm" if sku.get("name") in TPM_CAPACITY_SKUS else "sku_units",
        "capacity_k_tpm": sku.get("capacity") if sku.get("name") in TPM_CAPACITY_SKUS else None,
        "provisioning_state": state,
        "capabilities": _truthy(capabilities or {}), "role_basis": basis,
        "roles": [] if reason else (roles or []), "usable": usable,
        "search_model_name_admitted": {
            role: search_admits(ENTITY_SEARCH_API, role, model.get("name"))
            for role in ("chat", "embedding") if role in (roles or [])},
    }
    if reason:
        row["unusable_reason"] = reason
    if roles is None:
        row["note"] = "capabilities unreported; checked when the deployment is used"
    return row


def _catalog(client: Any, sub: str, region: str, cache: dict[tuple, Any]) -> dict[tuple, Any]:
    key = (sub, region)
    if key not in cache:
        try:
            items = _pages(client, f"{ARM}/subscriptions/{sub}/providers/Microsoft."
                                   f"CognitiveServices/locations/{region}/models"
                                   f"?api-version={ACCOUNTS_API}")
        except ArmError:
            items = []
        cache[key] = {
            (m.get("format"), m.get("name"), str(m.get("version"))): m.get("capabilities") or {}
            for m in ((item.get("model") or {}) for item in items) if isinstance(m, dict)}
    return cache[key]


def _deployments(client: Any, account: dict[str, Any], cache: dict[tuple, Any]
                 ) -> tuple[list[dict[str, Any]], str]:
    try:
        items = _pages(client, f"{ARM}{account['resource_id']}/deployments"
                               f"?api-version={ACCOUNTS_API}")
    except ArmError:
        return [], "unreadable"
    needs_catalog = any(not ((item.get("properties") or {}).get("capabilities")) for item in items)
    catalog = (_catalog(client, account["subscription_id"], account["region"] or "", cache)
               if needs_catalog and account.get("region") else None)
    rows = [deployment_row(item, catalog) for item in items
            if isinstance(item.get("name"), str)]
    return sorted(rows, key=lambda row: str(row["name"]).casefold()), "listed"


def _coverage(permissions: Any) -> set[str]:
    from .connect.openai_roles import _permission_coverage
    try:
        covered, conditional = _permission_coverage(permissions)
    except ValueError:
        return set()
    return set() if conditional else covered


_PRINCIPALS_PER_QUERY = 200


def _caller_access(client: Any, caller: str | None, accounts: list[dict[str, Any]],
                   warnings: list[str], *, per_account_fallback: bool = True,
                   caller_groups: Membership | None = None, name_groups: bool = True
                   ) -> dict[str, dict[str, Any]]:
    from .connect.openai_roles import _within
    unverified = {"chat": "unverified", "embedding": "unverified", "via_roles": [],
                  "via_groups": []}
    if not caller or not _GUID.fullmatch(caller) or not accounts:
        return {a["resource_id"].casefold(): {**unverified, "basis": "caller_unknown"}
                for a in accounts}
    groups = (caller_groups.groups if caller_groups is not None else None) or ()
    if caller_groups is not None and not caller_groups.readable:
        warnings.append(f"Access is matched to your direct assignments only: {UNREADABLE}. "
                        "Roles you hold through a group show as unverified.")
    principals = sorted({caller.casefold(), *(g for g in groups if _GUID.fullmatch(g))})
    mine = set(principals)
    basis = "resource_graph_assignments"
    try:
        assignments = []
        # Assignments to any group the caller belongs to count (nested groups included).
        for start in range(0, len(principals), _PRINCIPALS_PER_QUERY):
            chunk = ", ".join(f"'{p}'" for p in principals[start:start + _PRINCIPALS_PER_QUERY])
            assignments += _graph(client, (
                "authorizationresources | where type =~ 'microsoft.authorization/roleassignments'"
                f" | where tostring(properties.principalId) in~ ({chunk})"
                " | project scope=tostring(properties.scope),"
                " roleDefinitionId=tostring(properties.roleDefinitionId),"
                " principalId=tostring(properties.principalId),"
                " condition=tostring(properties.condition)"), None)
    except ArmError:
        if not per_account_fallback:
            warnings.append("Resource Graph couldn't list your role assignments; access "
                            "counts are unverified.")
            return {a["resource_id"].casefold(): {**unverified,
                                                  "basis": "resource_graph_unavailable"}
                    for a in accounts}
        basis = "arm_role_assignments_per_account"
        assignments = []

        def per_account(account: dict[str, Any]) -> list[dict[str, Any]]:
            # atScope() returns assignments at this scope and above, for every principal;
            # filter to the caller and their groups here.
            try:
                rows = _pages(client, f"{ARM}{account['resource_id']}/providers/Microsoft."
                                      f"Authorization/roleAssignments?api-version={ROLE_API}"
                                      f"&$filter=atScope()")
            except ArmError:
                return []
            return [{"scope": props.get("scope"),
                     "roleDefinitionId": props.get("roleDefinitionId"),
                     "principalId": props.get("principalId"),
                     "condition": props.get("condition")}
                    for r in rows if str((props := r.get("properties") or {})
                                         .get("principalId", "")).casefold() in mine]
        with ThreadPoolExecutor(max_workers=8) as pool:
            for rows in pool.map(per_account, accounts):
                assignments += rows
    definitions: dict[str, tuple[set[str], str | None]] = {}
    for assignment in assignments:
        definition_id = str(assignment.get("roleDefinitionId") or "")
        if not definition_id.startswith("/") or definition_id.casefold() in definitions:
            continue
        try:
            observed = client.get(f"{ARM}{definition_id}?api-version={ROLE_API}")
            props = observed.get("properties") or {}
            definitions[definition_id.casefold()] = (_coverage(props.get("permissions")),
                                                     props.get("roleName"))
        except (ArmError, AttributeError):
            definitions[definition_id.casefold()] = (set(), None)
    result = {}
    for account in accounts:
        covered: set[str] = set()
        via: set[str] = set()
        via_groups: set[str] = set()
        for assignment in assignments:
            if assignment.get("condition") or not _within(account["resource_id"],
                                                          assignment.get("scope")):
                continue
            actions, name = definitions.get(str(assignment.get("roleDefinitionId")).casefold(),
                                            (set(), None))
            if actions:
                covered |= actions
                via.add(name or str(assignment.get("roleDefinitionId")))
                holder = str(assignment.get("principalId") or "").casefold()
                if holder and holder != caller.casefold():
                    via_groups.add(holder)
        result[account["resource_id"].casefold()] = {
            role: "assigned" if DATA_ACTIONS[role] in covered else "unverified"
            for role in ("chat", "embedding")} | {"via_roles": sorted(via),
                                                  "via_groups": sorted(via_groups),
                                                  "basis": basis}
    held = sorted({g for row in result.values() for g in row["via_groups"]})
    names = (caller_groups.names(held)
             if caller_groups is not None and held and name_groups else {})
    for row in result.values():
        row["via_groups"] = [{"id": g, "display_name": names.get(g)} for g in row["via_groups"]]
    return result


PERMISSIONS_API = "2022-04-01"


def _effective_access(client: Any, accounts: list[dict[str, Any]],
                      access: dict[str, dict[str, Any]]) -> None:
    """Confirm access the assignment match missed, from the caller's effective permissions.

    The permissions API answers for the signed-in caller on that account, counting roles
    held through any group and roles inherited from the resource group, subscription or
    management group. Conditional grants still don't count.
    """
    todo = [a for a in accounts
            if any(access.get(a["resource_id"].casefold(), {}).get(role) != "assigned"
                   for role in ("chat", "embedding"))]

    def read(account: dict[str, Any]) -> tuple[dict[str, Any], list[Any] | None]:
        try:
            return account, _pages(client, f"{ARM}{account['resource_id']}/providers/Microsoft."
                                            f"Authorization/permissions?api-version={PERMISSIONS_API}")
        except ArmError:
            return account, None

    with ThreadPoolExecutor(max_workers=8) as pool:
        for account, permissions in pool.map(read, todo):
            covered = _coverage(permissions) if permissions else set()
            row = access.setdefault(account["resource_id"].casefold(), {
                "chat": "unverified", "embedding": "unverified", "via_roles": [],
                "via_groups": [], "basis": "effective_permissions"})
            for role in ("chat", "embedding"):
                if DATA_ACTIONS[role] in covered and row.get(role) != "assigned":
                    row[role] = "assigned"
                    row["basis"] = "effective_permissions"


def _table(candidates: list[dict[str, Any]]) -> tuple[str, list[dict[str, Any]]]:
    header = ("| # | Subscription | Resource group | Resource | Type | Region | Deployment | "
              "Model (version) | SKU | Roles | Usable | Your access (chat/embedding) |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|")
    lines, rows = [header], []

    def cell(value: Any) -> str:
        return str(value if value not in (None, "") else "-").replace("|", "/")

    for cand in candidates:
        access = cand.get("data_plane_access") or {}
        who = f"{access.get('chat', 'unverified')}/{access.get('embedding', 'unverified')}"
        if access.get("via_groups"):
            who += " via group " + ", ".join(g.get("display_name") or g["id"]
                                             for g in access["via_groups"])
        sub = cand.get("subscription_name") or cand["subscription_id"]
        resource_type = "Foundry project" if cand["type"] == "project" else f"{cand['kind']} account"
        prefix = [sub, cand["resource_group"], cand["name"], resource_type, cand["region"]]
        if cand["type"] == "project":
            entries = [(None, f"uses {cand['model_resource_id'].rsplit('/', 1)[-1]} deployments")]
        elif cand.get("deployments_status") == "unreadable":
            entries = [(None, "deployments unreadable")]
        elif not cand["deployments"]:
            entries = [(None, "no deployments")]
        else:
            entries = [(dep, None) for dep in cand["deployments"]]
        for dep, note in entries:
            number = len(rows) + 1
            if dep is None:
                values = [*prefix, note, "-", "-", "-", "-", who]
                select = None
            else:
                usable = {True: "yes", False: f"no: {dep.get('unusable_reason')}",
                          None: "unknown"}[dep["usable"]]
                values = [*prefix, dep["name"], f"{dep['model']} ({dep['version']})", dep["sku"],
                          ", ".join(dep["roles"]) or "-", usable, who]
                select = f"{cand['resource_id']}::{dep['name']}"
            lines.append(f"| {number} | " + " | ".join(cell(v) for v in values) + " |")
            rows.append({"row": number, "resource_id": cand["resource_id"],
                         "resource": cand["name"], "region": cand["region"],
                         "deployment": dep["name"] if dep else None,
                         "model": dep["model"] if dep else None,
                         "uses": [r for r in USES if dep and dep["usable"] and r in dep["roles"]],
                         "select": select})
    return "\n".join(lines), rows


USES = ("embedding", "chat")


def _usable_table(candidates: list[dict[str, Any]]) -> tuple[str, int]:
    """Usable chat and embedding deployments only, by model and region, yours first."""
    entries = []
    for cand in candidates:
        if cand["type"] != "account":
            continue
        access = cand.get("data_plane_access") or {}
        for dep in cand["deployments"]:
            uses = [r for r in USES if r in dep["roles"]]
            if dep["usable"] is not True or not uses:
                continue
            mine = any(access.get(u) == "assigned" for u in uses)
            entries.append(((not mine, USES.index(uses[0]), str(dep["model"]).casefold(),
                             str(cand["region"]), cand["name"].casefold(),
                             str(dep["name"]).casefold()), uses, dep, cand, mine, access))
    if not entries:
        return "No usable chat or embedding deployments found.", 0
    lines = ["| Use | Model | Version | Region | Deployment | Resource | Your access |",
             "|---|---|---|---|---|---|---|"]
    for _, uses, dep, cand, mine, access in sorted(entries, key=lambda e: e[0]):
        yours = "yes" if mine else ""
        if mine and access.get("via_groups"):
            yours += " (via group " + ", ".join(g.get("display_name") or g["id"]
                                                for g in access["via_groups"]) + ")"
        values = [", ".join(u.capitalize() for u in uses), dep["model"], dep["version"],
                  cand["region"], dep["name"], cand["name"], yours]
        lines.append("| " + " | ".join(str(v if v not in (None, "") else "-").replace("|", "/")
                                       for v in values) + " |")
    return "\n".join(lines), len(entries)


def discover(client: Any, *, tenant_id: str, caller_object_id: str | None = None,
             subscriptions: Iterable[str] | None = None, resource_group: str | None = None,
             fallback_subscriptions: Iterable[str] = (), max_workers: int = 16,
             caller_groups: Membership | None = None, show_all: bool = False
             ) -> dict[str, Any]:
    """List every model-hosting account, project and deployment the caller can see.

    `table` shows only usable chat and embedding deployments unless `show_all`; `rows`
    always numbers every entry, so a row number means the same thing in either view.
    """
    subs = sorted({s.lower() for s in subscriptions or () if s})
    for sub in subs:
        if not _GUID.fullmatch(sub):
            raise DiscoveryError(f"subscription filter {sub!r} is not a GUID")
    if resource_group and not _RG.fullmatch(resource_group):
        raise DiscoveryError("resource group filter has characters ARM doesn't allow")
    warnings: list[str] = []
    found, method, sub_count = _enumerate(client, tenant_id, subs or None, resource_group,
                                          [s.lower() for s in fallback_subscriptions], warnings)
    by_id = {row["resource_id"].casefold(): row for row in found}
    excluded: dict[str, int] = {}
    candidates = []
    for row in sorted(by_id.values(), key=_sort_key):
        if row["type"] == "account" and row["kind"] not in MODEL_HOSTING_KINDS:
            key = str(row["kind"] or "unknown")
            excluded[key] = excluded.get(key, 0) + 1
            continue
        candidates.append(row)
    accounts = [row for row in candidates if row["type"] == "account"]
    cache: dict[tuple, Any] = {}
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        listed = list(pool.map(lambda acct: _deployments(client, acct, cache), accounts))
    for account, (deployments, status) in zip(accounts, listed):
        account["deployments"], account["deployments_status"] = deployments, status
    model_accounts = {row["resource_id"].casefold(): row for row in accounts}
    access = _caller_access(client, caller_object_id, accounts, warnings,
                            caller_groups=caller_groups)
    _effective_access(client, accounts, access)
    for cand in candidates:
        parent = model_accounts.get(cand["model_resource_id"].casefold())
        if cand["type"] == "project":
            cand["deployments"] = []
            cand["deployments_status"] = "parent" if parent else "parent_not_visible"
            cand["model_endpoint"] = parent["endpoint"] if parent else None
            usable_from = parent["deployments"] if parent else []
        else:
            cand["model_endpoint"] = cand["endpoint"]
            usable_from = cand["deployments"]
        cand["eligible_roles"] = sorted({role for dep in usable_from
                                         if dep["usable"] is not False for role in dep["roles"]})
        cand["data_plane_access"] = access.get(cand["model_resource_id"].casefold(), {
            "chat": "unverified", "embedding": "unverified", "via_roles": [], "via_groups": [],
            "basis": "parent_not_visible"})
    table, rows = _table(candidates)
    usable_table, usable_count = _usable_table(candidates)
    hidden = 0 if show_all else len(rows) - usable_count
    identity = [(c["resource_id"].casefold(), [(d["name"], d["model"], d["version"], d["sku"],
                                                d["provisioning_state"], d["roles"])
                                               for d in c["deployments"]])
                for c in candidates]
    discovery_id = stable_id("model-discovery", {
        "tenant": tenant_id.casefold(), "subscriptions": subs, "resource_group":
        (resource_group or "").casefold(), "candidates": identity})
    scope_flags = " ".join([f"--subscription-id {s}" for s in subs]
                           + ([f"--resource-group {resource_group}"] if resource_group else []))
    next_command = (f"entity-graph-provision discover --tenant-id {tenant_id} "
                    + (scope_flags + " " if scope_flags else "")
                    + f"--row <N> --discovery-id {discovery_id} --role <role>")
    return {
        "phase": "provision.discover", "status": "candidates", "tier": "resource",
        "discovery_id": discovery_id,
        "scope": {"tenant_id": tenant_id, "subscriptions": subs or "all-visible",
                  "resource_group": resource_group, "method": method,
                  "subscription_count": sub_count, "account_kinds": list(MODEL_HOSTING_KINDS)},
        "candidate_count": len(candidates),
        "deployment_count": sum(len(c["deployments"]) for c in candidates),
        "candidates": candidates, "excluded_kinds": dict(sorted(excluded.items())),
        "table": table if show_all else usable_table, "view": "all" if show_all else "usable",
        "usable_count": usable_count, "hidden_count": hidden, "rows": rows,
        "selection": {
            "requires_explicit_selection": True,
            "how": "Show `table` to the user. Unless --all was passed, it lists only usable "
                   "chat and embedding deployments, the ones you hold a role on first; "
                   "`hidden_count` rows (empty accounts, Foundry projects that reuse an "
                   "account's deployments, unusable deployments) appear only with --all. "
                   "Ask which model to use for each role by its name, never by row number; "
                   "don't bring up access unless a later step fails with 403. If none "
                   "fits or the user wants new ones, plan new deployments instead. "
                   "Map the answer to its `rows` entry (same deployment and resource), then "
                   "run `next_command` with that entry's row and the role. For a role in "
                   "another subscription, discover that subscription. "
                   "Never pick, default or narrow the scope for the user.",
            "next_command": next_command,
        },
        "search_model_names": {"api_version": ENTITY_SEARCH_API,
                               "source": SEARCH_MODEL_SOURCES[ENTITY_SEARCH_API]},
        "warnings": warnings,
        "uncertainty": [
            "Access counts unconditional role assignments to you and to every group you "
            "belong to (nested included). PIM-eligible and conditional grants show as "
            "unverified, not as missing.",
            "Deployments are listed through ARM; a listed deployment can still be blocked "
            "by network rules from where it's called.",
        ],
    }


# Tier 1. Resource Graph indexes Cognitive Services accounts and projects but not model
# deployments: `microsoft.cognitiveservices/accounts/deployments` returns no rows (checked
# live), because deployments are a child resource read through ARM
# (https://learn.microsoft.com/rest/api/aiservices/accountmanagement/deployments/list).
# The one summarize query therefore counts model-hosting accounts and projects per
# subscription; per-role usable deployment counts need `count_roles`, which lists every
# account's deployments. Subscriptions without model resources stay in the result.
SUBSCRIPTION_SUMMARY_QUERY = (
    "resourcecontainers | where type =~ 'microsoft.resources/subscriptions'"
    " | project subscriptionId, subscriptionName=name, tenantId,"
    " state=tostring(properties.state)"
    " | join kind=leftouter (resources | where type in~ ("
    "'microsoft.cognitiveservices/accounts', 'microsoft.cognitiveservices/accounts/projects')"
    " | extend isAccount = type =~ 'microsoft.cognitiveservices/accounts'"
    " | summarize openaiAccounts=countif(isAccount and kind =~ 'OpenAI'),"
    " aiservicesAccounts=countif(isAccount and kind =~ 'AIServices'),"
    " projects=countif(not(isAccount)),"
    " modelAccountIds=make_set_if(tolower(id), isAccount and kind in~ ('OpenAI', "
    "'AIServices'), 100000) by subscriptionId) on subscriptionId"
    " | project subscriptionId, subscriptionName, tenantId, state,"
    " openaiAccounts=coalesce(openaiAccounts, 0),"
    " aiservicesAccounts=coalesce(aiservicesAccounts, 0), projects=coalesce(projects, 0),"
    " modelAccountIds")


def _summary_from_graph(client: Any) -> dict[str, dict[str, Any]]:
    subs = {}
    for item in _graph(client, SUBSCRIPTION_SUMMARY_QUERY, None):
        sub = str(item.get("subscriptionId") or "").lower()
        if not _GUID.fullmatch(sub):
            continue
        ids = item.get("modelAccountIds")
        subs[sub] = {"subscription_name": item.get("subscriptionName"),
                     "tenant_id": item.get("tenantId"), "state": item.get("state") or None,
                     "openai_accounts": int(item.get("openaiAccounts") or 0),
                     "aiservices_accounts": int(item.get("aiservicesAccounts") or 0),
                     "projects": int(item.get("projects") or 0),
                     "account_ids": sorted({str(i).casefold() for i in ids or []
                                            if isinstance(i, str)})}
    return subs


def _summary_from_arm(client: Any, tenant_id: str, fallback_subscriptions: list[str],
                      warnings: list[str]) -> dict[str, dict[str, Any]]:
    try:
        listed = _arm_subscriptions(client, tenant_id)
    except ArmError as error:
        if not fallback_subscriptions:
            raise DiscoveryError("Could not list subscriptions or query Resource Graph; "
                                 "pass --subscription-id to search a known subscription."
                                 ) from error
        listed = {sub: {"name": None, "tenant_id": tenant_id, "state": None}
                  for sub in fallback_subscriptions}
        warnings.append("Could not list subscriptions; summarized only "
                        + ", ".join(sorted(listed)) + ".")
    found, _, _ = _enumerate(client, tenant_id, sorted(listed), None, [], warnings,
                             use_graph=False)
    subs = {sub: {"subscription_name": info["name"], "tenant_id": info["tenant_id"],
                  "state": info["state"], "openai_accounts": 0, "aiservices_accounts": 0,
                  "projects": 0, "account_ids": []} for sub, info in listed.items()}
    for row in found:
        entry = subs.get(row["subscription_id"])
        if entry is None:
            continue
        if row["type"] == "project":
            entry["projects"] += 1
        elif row["kind"] in MODEL_HOSTING_KINDS:
            entry["openai_accounts" if row["kind"] == "OpenAI" else "aiservices_accounts"] += 1
            entry["account_ids"].append(row["resource_id"].casefold())
    return subs


def subscription_summary(client: Any, *, tenant_id: str, caller_object_id: str | None = None,
                         fallback_subscriptions: Iterable[str] = (), count_roles: bool = False,
                         max_workers: int = 16, caller_groups: Membership | None = None
                         ) -> dict[str, Any]:
    """Tier 1: one row per visible subscription, so the user picks where to look."""
    warnings: list[str] = []
    try:
        subs = _summary_from_graph(client)
        method = "resource-graph"
    except ArmError as error:
        warnings.append(f"Resource Graph was unavailable ({error}); listed subscriptions and "
                        "accounts through ARM instead.")
        subs = _summary_from_arm(client, tenant_id,
                                 sorted({s.lower() for s in fallback_subscriptions if s}),
                                 warnings)
        method = "per-subscription-fallback"
    accounts = [{"resource_id": rid} for info in subs.values() for rid in info["account_ids"]]
    access = _caller_access(client, caller_object_id, accounts, warnings,
                            per_account_fallback=False, caller_groups=caller_groups,
                            name_groups=False)
    verified = any(a.get("basis") == "resource_graph_assignments"
                   for a in access.values())
    role_counts: dict[str, dict[str, int]] = {}
    if count_roles:
        listing = discover(client, tenant_id=tenant_id, subscriptions=None,
                           fallback_subscriptions=fallback_subscriptions,
                           max_workers=max_workers)
        warnings += listing["warnings"]
        for cand in listing["candidates"]:
            counts = role_counts.setdefault(cand["subscription_id"], {
                "embedding": 0, "chat": 0, "kb": 0, "unknown": 0})
            for dep in cand["deployments"]:
                if dep["usable"] is None:
                    counts["unknown"] += 1
                elif dep["usable"]:
                    for role in dep["roles"]:
                        counts[role] += 1
    rows = []
    for sub, info in subs.items():
        ids = info["account_ids"]
        assigned = ({role: sum(access.get(rid, {}).get(role) == "assigned" for rid in ids)
                     for role in ("chat", "embedding")} if verified or not ids else None)
        usable = ({role: 0 for role in ("embedding", "chat", "kb", "unknown")}
                  | role_counts.get(sub, {})) if count_roles else None
        model_accounts = info["openai_accounts"] + info["aiservices_accounts"]
        if info["state"] and info["state"] != "Enabled":
            status = f"subscription {info['state']}"
        elif not model_accounts:
            status = "no model-hosting accounts"
        elif usable is not None and not any(usable[r] for r in ("embedding", "chat", "kb")):
            status = "no usable deployments"
        else:
            status = "has candidates"
        rows.append({"subscription_id": sub, "subscription_name": info["subscription_name"],
                     "tenant_id": info["tenant_id"], "state": info["state"],
                     "openai_accounts": info["openai_accounts"],
                     "aiservices_accounts": info["aiservices_accounts"],
                     "projects": info["projects"], "usable_deployments": usable,
                     "accounts_assigned": assigned, "status": status})
    rows.sort(key=lambda r: (str(r["subscription_name"] or "").casefold(), r["subscription_id"]))
    for number, row in enumerate(rows, 1):
        row["row"] = number
    discovery_id = stable_id("subscription-discovery", {
        "tenant": tenant_id.casefold(), "subscriptions": [r["subscription_id"] for r in rows]})
    return {
        "phase": "provision.discover.subscriptions", "status": "subscriptions",
        "tier": "subscription", "discovery_id": discovery_id,
        "scope": {"tenant_id": tenant_id, "subscriptions": "all-visible", "method": method,
                  "subscription_count": len(rows),
                  "role_counts": "counted" if count_roles else "not_counted"},
        "subscriptions": rows, "table": _subscription_table(rows),
        "rows": [{"row": r["row"], "subscription_id": r["subscription_id"],
                  "name": r.get("subscription_name")} for r in rows],
        "selection": {
            "requires_explicit_selection": True,
            "how": "Use this only when the user wants a subscription other than the signed-in "
                   "one. Ask which subscription to search by its name (show `table` if they "
                   "want the list), never by row number. Then run `next_command` with the "
                   "matching row. Roles may come from different subscriptions: repeat this "
                   "per role. Never pick a subscription for the user.",
            "next_command": (f"entity-graph-provision discover --tenant-id {tenant_id} "
                             f"--sub-row <N> --discovery-id {discovery_id}"),
        },
        "warnings": warnings,
        "uncertainty": [
            *([] if count_roles else [
                "Resource Graph doesn't index model deployments, so this table counts "
                "accounts and projects; usable deployments per role are shown once a "
                "subscription is picked (or with --count-roles, which lists every "
                "deployment and is slower)."]),
            "Access counts unconditional role assignments on OpenAI and AIServices accounts "
            "to you and to every group you belong to (nested included); PIM-eligible and "
            "conditional grants aren't counted.",
        ],
    }


def _subscription_table(rows: list[dict[str, Any]]) -> str:
    lines = ["| # | Subscription | Subscription ID | Tenant | OpenAI accounts | "
             "AIServices accounts | Foundry projects | Usable deployments "
             "(embedding/chat/kb) | Accounts with your role (chat/embedding) | Status |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    for row in rows:
        usable = row["usable_deployments"]
        usable_cell = "not counted" if usable is None else (
            f"{usable['embedding']}/{usable['chat']}/{usable['kb']}"
            + (f" (+{usable['unknown']} unknown)" if usable["unknown"] else ""))
        assigned = row["accounts_assigned"]
        total = row["openai_accounts"] + row["aiservices_accounts"]
        access_cell = ("unverified" if assigned is None
                       else f"{assigned['chat']}/{assigned['embedding']} of {total}")
        values = [row["subscription_name"] or "-", row["subscription_id"],
                  row["tenant_id"] or "-", row["openai_accounts"],
                  row["aiservices_accounts"], row["projects"], usable_cell, access_cell,
                  row["status"]]
        lines.append(f"| {row['row']} | "
                     + " | ".join(str(v).replace("|", "/") for v in values) + " |")
    return "\n".join(lines)


def pick_subscription(summary: dict[str, Any], *, sub_row: int, discovery_id: str) -> str:
    """Resolve the user's subscription row against a fresh tier-1 summary."""
    if summary["discovery_id"] != discovery_id:
        raise DiscoveryError(f"the visible subscriptions changed since discovery "
                             f"{discovery_id} (now {summary['discovery_id']}); show the new "
                             "table and ask again")
    match = next((r for r in summary["rows"] if r["row"] == sub_row), None)
    if match is None:
        raise DiscoveryError(f"subscription row {sub_row} isn't in the table "
                             f"(1-{len(summary['rows'])})")
    return match["subscription_id"]


def runtime_args(account: dict[str, Any], deployment: dict[str, Any], role: str
                 ) -> dict[str, list[str]]:
    sub, group = account["subscription_id"], account["resource_group"]
    model_id = account["model_resource_id"]
    match = _ACCOUNT_ID.fullmatch(model_id)
    model_group = match.group(2) if match else group
    endpoint = account.get("model_endpoint") or ""
    entity_flag = {"chat": "--chat", "embedding": "--embedding", "kb": "--kb"}[role]
    entity = [f"{entity_flag}-openai-resource-id", model_id,
              f"{'--kb-chat' if role == 'kb' else entity_flag}-deployment", deployment["name"]]
    if role == "embedding":
        return {"entity": entity}
    model_flags = ["--model-endpoint", endpoint, "--model-deployment", deployment["name"],
                   "--model-name", str(deployment["model"])]
    return {
        "entity": entity,
        "topicgraph_plan": model_flags,
        "topicgraph_doctor": [*model_flags, "--model-subscription-id", sub,
                              "--model-resource-group", model_group],
        "ontology": ["--model-endpoint", endpoint, "--model-deployment", deployment["name"],
                     "--model-resource-group", model_group, "--subscription-id", sub],
    }


def select_row(client: Any, listing: dict[str, Any], *, row: int, discovery_id: str, role: str,
               tenant_id: str, caller_object_id: str | None = None,
               caller_groups: Membership | None = None) -> dict[str, Any]:
    """Resolve the user's row number against a fresh listing with the same discovery ID."""
    if listing["discovery_id"] != discovery_id:
        raise DiscoveryError(f"the inventory changed since discovery {discovery_id} (now "
                             f"{listing['discovery_id']}); show the new table and ask again")
    match = next((r for r in listing["rows"] if r["row"] == row), None)
    if match is None:
        raise DiscoveryError(f"row {row} isn't in the table (1-{len(listing['rows'])})")
    if not match["select"]:
        raise DiscoveryError(f"row {row} has no deployment to select")
    result = select(client, tenant_id=tenant_id, selection=match["select"], role=role,
                    caller_object_id=caller_object_id, caller_groups=caller_groups)
    return {**result, "row": row, "discovery_id": discovery_id}


def select(client: Any, *, tenant_id: str, selection: str, role: str,
           caller_object_id: str | None = None,
           caller_groups: Membership | None = None) -> dict[str, Any]:
    """Validate one exact `<resource-id>::<deployment>` choice and return runtime flags."""
    if role not in ROLES:
        raise DiscoveryError(f"--role must be one of {', '.join(ROLES)}")
    resource_id, sep, name = selection.partition("::")
    match = _ACCOUNT_ID.fullmatch(resource_id)
    if not sep or not name or not match:
        raise DiscoveryError("--select must be '<exact account or project resource ID>::"
                             "<deployment name>' from the discovery table")
    try:
        observed = client.get(f"{ARM}{resource_id}?api-version="
                              f"{PROJECTS_API if match.group(4) else ACCOUNTS_API}")
    except ArmError as error:
        raise DiscoveryError(f"{resource_id} is missing or unreadable") from error
    chosen = _normalize({**observed, "id": observed.get("id") or resource_id}, sub_names={})
    if chosen is None or chosen["resource_id"].casefold() != _canonical(resource_id).casefold():
        raise DiscoveryError(f"{resource_id} returned a different resource")
    if chosen["type"] == "account" and chosen["kind"] not in MODEL_HOSTING_KINDS:
        raise DiscoveryError(f"{chosen['name']} is a {chosen['kind']} account; only "
                             f"{' and '.join(MODEL_HOSTING_KINDS)} accounts host model deployments")
    if chosen["type"] == "project":
        try:
            parent = _normalize(client.get(f"{ARM}{chosen['model_resource_id']}"
                                           f"?api-version={ACCOUNTS_API}"), sub_names={})
        except ArmError as error:
            raise DiscoveryError("the project's parent account is unreadable") from error
        chosen["model_endpoint"] = (parent or {}).get("endpoint")
    else:
        chosen["model_endpoint"] = chosen["endpoint"]
    model_account = {**chosen, "resource_id": chosen["model_resource_id"]}
    deployments, status = _deployments(client, model_account, {})
    if status != "listed":
        raise DiscoveryError("could not list deployments on the selected account")
    deployment = next((row for row in deployments if row["name"] == name), None)
    if deployment is None:
        raise DiscoveryError(f"deployment {name!r} isn't on {chosen['model_resource_id']}")
    if deployment["usable"] is False:
        raise DiscoveryError(f"{name} can't be used: {deployment['unusable_reason']}")
    wanted = "embedding" if role == "embedding" else "chat"
    if deployment["usable"] and wanted not in deployment["roles"]:
        raise DiscoveryError(f"{name} ({deployment['model']}) reports capabilities "
                             f"{', '.join(deployment['capabilities'])}; it can't serve {role}")
    access = _caller_access(client, caller_object_id, [model_account], [],
                            caller_groups=caller_groups)
    return {
        "phase": "provision.discover.select", "status": "selected", "role": role,
        "selection": {"resource_id": chosen["resource_id"],
                      "model_resource_id": chosen["model_resource_id"],
                      "deployment": name, "model": deployment["model"],
                      "version": deployment["version"], "sku": deployment["sku"],
                      "endpoint": chosen["model_endpoint"]},
        "deployment": deployment,
        "data_plane_access": access.get(chosen["model_resource_id"].casefold()),
        "args": runtime_args(chosen, deployment, role),
        "note": "Pass these exact flags to the runtime's plan or connect command; its plan "
                "ID binds this resource and deployment.",
    }


def _usages(client: Any, sub: str, region: str) -> dict[str, dict[str, Any]]:
    try:
        rows = _pages(client, f"{ARM}/subscriptions/{sub}/providers/Microsoft.CognitiveServices"
                              f"/locations/{region}/usages?api-version={ACCOUNTS_API}")
    except ArmError:
        return {}
    return {str((row.get("name") or {}).get("value")): row for row in rows}


def catalog_options(models: list[dict[str, Any]], usages: dict[str, dict[str, Any]], *,
                    role: str, kind: str | None = None) -> list[dict[str, Any]]:
    """Every model/version/SKU the region lists for this role, with observed quota."""
    wanted = "embedding" if role == "embedding" else "chat"
    recommended = RECOMMENDED_NEW_DEPLOYMENTS.get(wanted, {})
    merged: dict[tuple, dict[str, Any]] = {}
    for item in models:
        model = item.get("model") if isinstance(item.get("model"), dict) else {}
        if kind and item.get("kind") not in (kind, "OpenAI"):
            continue
        if wanted not in (roles_from_capabilities(model.get("capabilities")) or []):
            continue
        key = (model.get("format"), model.get("name"), str(model.get("version")))
        entry = merged.setdefault(key, {
            "model": model.get("name"), "version": model.get("version"),
            "format": model.get("format"), "lifecycle": model.get("lifecycleStatus"),
            "default_version": bool(model.get("isDefaultVersion")),
            "deprecation": model.get("deprecation"), "skus": {}})
        for sku in model.get("skus") or []:
            if not isinstance(sku, dict) or not sku.get("name"):
                continue
            usage = usages.get(str(sku.get("usageName"))) or {}
            entry["skus"][sku["name"]] = {
                "sku": sku["name"], "capacity": sku.get("capacity"),
                "quota_name": sku.get("usageName"),
                "quota_current": usage.get("currentValue"), "quota_limit": usage.get("limit"),
                "recommended_default": (model.get("name") == recommended.get("model")
                                        and (str(model.get("version")) == recommended.get("version")
                                             or (recommended.get("version") is None
                                                 and bool(model.get("isDefaultVersion"))))
                                        and sku["name"] == recommended.get("sku")),
            }
    options = []
    for entry in merged.values():
        entry["skus"] = sorted(entry["skus"].values(), key=lambda s: s["sku"].casefold())
        entry["search_model_name_admitted"] = search_admits(ENTITY_SEARCH_API, wanted,
                                                            entry["model"])
        options.append(entry)
    return sorted(options, key=lambda e: (str(e["model"]).casefold(), str(e["version"])))


def model_catalog(client: Any, *, account_id: str, role: str) -> dict[str, Any]:
    """Models, versions and SKUs the account's region offers for a new deployment."""
    match = _ACCOUNT_ID.fullmatch(account_id)
    if not match or match.group(4):
        raise DiscoveryError("--models-for needs an exact account resource ID (not a project)")
    try:
        account = _normalize(client.get(f"{ARM}{account_id}?api-version={ACCOUNTS_API}"),
                             sub_names={})
    except ArmError as error:
        raise DiscoveryError(f"{account_id} is missing or unreadable") from error
    if not account or not account["region"]:
        raise DiscoveryError(f"{account_id} returned no region")
    sub, region = account["subscription_id"], account["region"]
    try:
        models = _pages(client, f"{ARM}/subscriptions/{sub}/providers/Microsoft."
                                f"CognitiveServices/locations/{region}/models"
                                f"?api-version={ACCOUNTS_API}")
    except ArmError as error:
        raise DiscoveryError(f"could not read the {region} model catalog") from error
    options = catalog_options(models, _usages(client, sub, region), role=role,
                              kind=account["kind"])
    lines = ["| Model | Version | Format | Lifecycle | SKU | Quota used/limit | Note |",
             "|---|---|---|---|---|---|---|"]
    for entry in options:
        for sku in entry["skus"] or [{"sku": "-", "quota_current": None, "quota_limit": None,
                                      "recommended_default": False}]:
            quota = ("-" if sku["quota_limit"] is None
                     else f"{sku['quota_current']}/{sku['quota_limit']}")
            note = "recommended default" if sku["recommended_default"] else ""
            lines.append(f"| {entry['model']} | {entry['version']} | {entry['format']} | "
                         f"{entry['lifecycle'] or '-'} | {sku['sku']} | {quota} | {note} |")
    return {
        "phase": "provision.discover.models", "status": "options", "role": role,
        "account": {key: account[key] for key in ("resource_id", "kind", "region")},
        "options": options, "table": "\n".join(lines),
        "recommended_default": RECOMMENDED_NEW_DEPLOYMENTS.get(
            "embedding" if role == "embedding" else "chat"),
        "note": "Show the table verbatim and let the user choose model, version and SKU. "
                "The recommended default is only applied if the user picks it; other "
                "models listed here are also fine, and `latest` picks the newest chat model. "
                "Rows are alphabetical, not ranked by quality.",
    }
