"""Operator roles a new-provision plan doesn't need to grant.

A role the operator already holds over the new resources, directly, through a group
(nested included) or at a parent scope (resource group, subscription, management group,
root), is left off the plan and its approval card. The resources don't exist yet, so the
check reads assignments at the nearest existing scope: the resource group when the plan
reuses one, otherwise the subscription. Connect's role check uses the same matching
(`connect.roles.match_role`, `connect.openai_roles.OpenAICoverage`).
"""

from __future__ import annotations

import subprocess
from types import SimpleNamespace
from typing import Any, Callable

from ekg_core.az_identity import IdentityError, active_az_identity, az_json
from ekg_core.models import OPERATOR_ROLES, ProvisioningSpec

from . import access
from .connect.openai_roles import OpenAICoverage
from .connect.roles import match_role, membership_for
from .connect.spec import ACCEPTED_ROLES

RUNNER: Callable[..., Any] = subprocess.run
UNREAD = ("Your role assignments couldn't be read, so every operator role is planned; "
          "apply reads them again and stops if any is already held.")
_KINDS = {role: kind for _, who, role, kind in access.GRANTS if who == "operator"}


def read_scope(spec: ProvisioningSpec, *, search: bool = False) -> str:
    sub_id = spec.effective_search_subscription_id if search else spec.target.subscription_id
    group = spec.effective_search_resource_group if search else spec.target.resource_group
    sub = f"/subscriptions/{sub_id}"
    return sub if spec.create_resource_group else f"{sub}/resourceGroups/{group}"


def _evidence(row: dict[str, Any]) -> str:
    group = row.get("via_group")
    via = (f" through group {group.get('display_name') or group['id']} ({group['id']})"
           if isinstance(group, dict) else "")
    return f"{row['via_role']} at {row.get('assigned_scope')}{via}"


def operator_held(spec: ProvisioningSpec, tenant_id: str | None,
                  runner: Callable[..., Any] | None = None
                  ) -> tuple[tuple[tuple[str, str], ...], bool]:
    """((role, evidence), ...) already held by the operator, and whether assignments were read.

    Held means an active assignment to the operator or one of its groups at or above the
    target scope. When Graph can't be read and a group holds the role, the role is held
    as unverified: it may already apply, so no direct grant is planned.
    """
    access_spec = spec.build_access
    if access_spec is None or not tenant_id:
        return (), False
    runner = runner or RUNNER
    sub = spec.target.subscription_id
    operator, kind = access_spec.operator_object_id, access_spec.operator_principal_type
    try:
        identity = active_az_identity(tenant_id, sub, runner=runner)
        signed_in = identity["principal_object_id"].casefold() == operator.casefold()
    except IdentityError:
        signed_in = False
    scope = read_scope(spec)

    def read(at: str, subscription: str) -> list[Any] | None:
        try:
            # No --assignee-object-id: it hides assignments made to the operator's groups.
            rows = az_json([
                "role", "assignment", "list", "--scope", at, "--include-inherited",
                "--fill-principal-name", "false", "--subscription", subscription,
            ], runner=runner)
        except IdentityError:
            return None
        return rows if isinstance(rows, list) else None

    assignments = read(scope, sub)
    if assignments is None:
        return (), False
    search_assignments = assignments
    if spec.search_is_split:
        search_assignments = read(read_scope(spec, search=True),
                                  spec.effective_search_subscription_id)
        if search_assignments is None:
            return (), False
    membership = membership_for(operator, kind, "operator" if signed_in else "other", runner)
    held: list[tuple[str, str]] = []
    for role in OPERATOR_ROLES:
        target = access.scope(spec, _KINDS[role])
        if role == "Cognitive Services OpenAI User":
            row = OpenAICoverage(SimpleNamespace(subscription_id=sub), runner).check(
                operator, kind, scope, "operator", membership)
            if row["status"] == "assigned":
                via = row["via_roles"][0]
                group = via.get("via_group")
                held.append((role, f"{via.get('role_name')} at {via['scope']}" + (
                    f" through group {group.get('display_name') or group['id']} ({group['id']})"
                    if isinstance(group, dict) else "")))
            elif any("A group holds a role here" in item for item in row["uncertainty"]):
                held.append((role, "unverified: a group holds an OpenAI role here and "
                                   "group membership could not be read"))
            continue
        row = match_role(search_assignments if _KINDS[role] == "search" else assignments,
                         membership, target, ACCEPTED_ROLES[role], role)
        if row["status"] == "assigned":
            held.append((role, _evidence(row)))
        elif row.get("grant_recommended") is False:
            held.append((role, f"unverified: {row['detail']}"))
    return tuple(sorted(held)), True
