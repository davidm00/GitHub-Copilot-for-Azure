"""grounding-provision: connect, doctor and idempotent create-if-not-exists (resource group + Search service)."""

from __future__ import annotations

import time
import uuid
from typing import Any, Callable

from . import API_VERSION
from .azure import (AUTHZ_API, ROLE_IDS, SEARCH_ARM_API, Azure, endpoint_for, role_gaps, validate_endpoint)
from .errors import AuthError, GroundingError, ServiceError
from .names import DEFAULT_PREFIX, validate_resource_group_name, validate_service_name
from .plan import approval_card, provision_plan_id, require_plan_id
from .service_errors import append_summary, describe, from_exception, summary

WRITE_ROLES = ["Search Service Contributor", "Search Index Data Contributor"]
ALL_ROLES = WRITE_ROLES + ["Search Index Data Reader"]
DEFAULT_SKU = "basic"
# The ARM SearchServices sku.name enum (Microsoft.Search 2025-05-01):
# https://learn.microsoft.com/rest/api/searchmanagement/services/create-or-update#skuname
SKUS = ("free", "basic", "standard", "standard2", "standard3", "storage_optimized_l1", "storage_optimized_l2")


def _service_id(sub: str, rg: str, name: str) -> str:
    return f"/subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.Search/searchServices/{name}"


def _summarize(svc: Any) -> dict[str, Any]:
    parts = (svc.id or "").split("/")
    auth_options = svc.auth_options
    rg = parts[parts.index("resourceGroups") + 1] if "resourceGroups" in parts else ""
    return {"name": svc.name, "resource_group": rg, "location": svc.location,
            "sku": svc.sku.name if svc.sku else None, "endpoint": endpoint_for(svc.name or ""),
            "provisioning_state": svc.provisioning_state,
            "local_auth_disabled": bool(svc.disable_local_auth),
            "entra_auth": bool(svc.disable_local_auth) or bool(auth_options and auth_options.aad_or_api_key)}


def _search_management_client(az: Azure, sub: str) -> Any:
    from azure.mgmt.search import SearchManagementClient

    return SearchManagementClient(credential=az.credential(), subscription_id=sub, api_version=SEARCH_ARM_API)


def _search_sdk_call(operation: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    from azure.core.exceptions import HttpResponseError

    try:
        return operation(*args, **kwargs)
    except HttpResponseError as exc:
        status = exc.status_code or 0
        info = from_exception(exc) or {"status": exc.status_code}
        if status in (401, 403):
            raise AuthError("FORBIDDEN", append_summary(f"Azure Search management request returned HTTP {status}",
                                                        info),
                            "Check the Entra roles for this identity (grounding-provision doctor).",
                            service_error=info) from exc
        raise ServiceError("SERVICE_HTTP", append_summary(f"Azure Search management request returned HTTP {status}",
                                                          info),
                           service_error=info) from exc


def list_services(az: Azure, sub: str) -> list[dict[str, Any]]:
    with _search_management_client(az, sub) as client:
        return [_summarize(s) for s in _search_sdk_call(client.services.list_by_subscription)]


def probe_preview(az: Azure, endpoint: str) -> dict[str, Any]:
    """Read-only: can this identity list indexes with API 2026-11-01-preview on this service?"""
    try:
        r = az.search("GET", endpoint, "/indexes?$select=name", allow=(400, 404))
    except GroundingError as exc:
        out = {"api_version": API_VERSION, "available": None, "code": exc.code, "message": exc.message, "indexes": []}
        if exc.service_error:
            out["service_error"] = exc.service_error
        return out
    if r.get("_status") in (400, 404):
        out = {"api_version": API_VERSION, "available": False, "status": r["_status"],
               "message": str((r.get("_service_error") or {}).get("message")
                              or (r.get("error") or {}).get("message", ""))[:300], "indexes": []}
        if r.get("_service_error"):
            out["service_error"] = r["_service_error"]
        return out
    names = [i.get("name") for i in r.get("value", [])]
    return {"api_version": API_VERSION, "available": True, "indexes": names}


def check_roles(az: Azure, scope: str, roles: list[str]) -> dict[str, bool]:
    r = az.arm("GET", f"{scope}/providers/Microsoft.Authorization/permissions", api=AUTHZ_API)
    return role_gaps(r.get("value", []), roles)


def inspect_service(az: Azure, sub: str, svc: dict[str, Any]) -> dict[str, Any]:
    out = dict(svc)
    scope = _service_id(sub, svc["resource_group"], svc["name"])
    try:
        out["roles"] = check_roles(az, scope, ALL_ROLES)
    except GroundingError as exc:
        out["roles"] = {"error": exc.code}
        out["roles_error"] = {"code": exc.code, "message": exc.message}
        if exc.service_error:
            out["roles_error"]["service_error"] = exc.service_error
    preview = probe_preview(az, svc["endpoint"])
    out["preview_api"] = {k: v for k, v in preview.items() if k != "indexes"}
    out["grounding_index_names"] = [n for n in preview["indexes"] if str(n).startswith(DEFAULT_PREFIX)]
    missing = [r for r, ok in out["roles"].items() if ok is False]
    out["missing_roles"] = missing
    return out


def connect(az: Azure, ident: dict[str, Any], service: str = "", endpoint: str = "") -> dict[str, Any]:
    """Read-only discovery. The CLI layer decides whether to persist the chosen endpoint."""
    sub = ident["subscription"]
    services = list_services(az, sub)
    if endpoint:
        host = validate_endpoint(endpoint).split("//")[1].split(".")[0]
        service = service or host
    chosen = [s for s in services if s["name"] == service] if service else []
    if service and not chosen:
        raise GroundingError("SERVICE_NOT_FOUND", f"no Search service named {service!r} in this subscription",
                             "Run grounding-provision connect without --service to list services, or "
                             "grounding-provision create to plan a new one.")
    result: dict[str, Any] = {"ok": True, "tenant": ident["tenant"], "subscription": sub,
                              "services": [{k: s[k] for k in ("name", "resource_group", "location", "sku", "endpoint")}
                                           for s in services]}
    if not services:
        result["next_step"] = "No Search service found. Run `grounding-provision create` to plan one."
    if len(chosen) == 1:
        detail = inspect_service(az, sub, chosen[0])
        result["selected"] = detail
        result["warnings"] = same_service_warning()
    elif not service and services:
        result["next_step"] = "Pass --service <name> to select one and run its checks."
    return result


def same_service_warning() -> list[str]:
    return ["The grounding index must live on the same Search service as the Knowledge Source it will ground; "
            "for an existing build, connect to that build's service rather than creating a new one."]


def _locate(az: Azure, name: str) -> str | None:
    """The one subscription you can see that holds Search service `name`, via Resource Graph."""
    query = ("resources | where type =~ 'microsoft.search/searchservices' and name =~ "
             f"'{name}' | project subscriptionId")
    try:
        found = az.arm("POST", "/providers/Microsoft.ResourceGraph/resources",
                       {"query": query, "options": {"resultFormat": "objectArray"}}, api="2022-10-01")
    except GroundingError:
        return None
    subs = {str(row.get("subscriptionId")) for row in found.get("data") or [] if row.get("subscriptionId")}
    return subs.pop() if len(subs) == 1 else None


def doctor(az: Azure, ident: dict[str, Any], endpoint: str, *, search_others: bool = False) -> dict[str, Any]:
    """Read-only checks for one service. With `search_others` (no --subscription given), a service
    that isn't in the default subscription is found in whichever subscription holds it."""
    endpoint = validate_endpoint(endpoint)
    name = endpoint.split("//")[1].split(".")[0]
    sub = ident["subscription"]
    svc = next((s for s in list_services(az, sub) if s["name"] == name), None) if sub else None
    if not svc and search_others:
        other = _locate(az, name)
        if other and other != sub:
            sub = other
            svc = next((s for s in list_services(az, sub) if s["name"] == name), None)
    if not svc:
        where = ident.get("subscription_name") or sub or "your subscriptions"
        raise GroundingError("SERVICE_NOT_FOUND", f"Search service {name!r} isn't in {where}"
                             + (" or any other subscription you can see" if search_others else ""),
                             f"Pass --subscription <name or ID of the subscription that holds {name}>. Don't "
                             "run `az account set`; it changes the default for every tool.")
    d = inspect_service(az, sub, svc)
    problems = []
    if d["missing_roles"]:
        problems.append(f"missing roles: {', '.join(d['missing_roles'])}")
    if d["preview_api"].get("available") is not True:
        se = d["preview_api"].get("service_error")
        problems.append(f"API {API_VERSION} not confirmed available on this service"
                        + (f": {summary(se)}" if se else ""))
    if not d["entra_auth"]:
        problems.append("service does not have Entra (RBAC) data-plane auth enabled")
    return {"ok": not problems, "tenant": ident["tenant"], "subscription": sub,
            "service": d, "problems": problems,
            "warnings": same_service_warning() + ([f"role check failed: {d['roles_error']['code']}: "
                                                   f"{d['roles_error']['message']}"] if d.get("roles_error") else [])}



def doctor_text(out: dict[str, Any]) -> str:
    """doctor's default output: a few plain lines, no IDs."""
    d = out["service"]
    roles = ("couldn't be read" if d.get("roles_error") else
             f"missing {', '.join(d['missing_roles'])}" if d.get("missing_roles") else "all held")
    return "\n".join([
        f"Search service {d['name']}: {'ready' if out['ok'] else 'not ready'}.",
        f"- Your roles: {roles}",
        f"- Graph API ({API_VERSION}): "
        + ("available" if d["preview_api"].get("available") is True else "not available on this service"),
        f"- Entra sign-in: {'on' if d.get('entra_auth') else 'off'}",
        "Next: " + ("continue with the skill's workflow." if out["ok"] else
                    "fix the items above, then run doctor once more."),
        "Add --json for the full result.",
    ])

# ---------------------------------------------------------------------------------------------------------------
def create_plan(az: Azure, ident: dict[str, Any], *, resource_group: str, service_name: str, location: str,
                sku: str = DEFAULT_SKU) -> dict[str, Any]:
    validate_resource_group_name(resource_group)
    validate_service_name(service_name)
    if sku not in SKUS:
        raise GroundingError("SKU_INVALID", f"sku must be one of {', '.join(SKUS)} (the ARM SearchServices "
                             "sku.name enum, Microsoft.Search 2025-05-01)")
    sub = ident["subscription"]
    plan_id = provision_plan_id(ident["tenant"], sub, resource_group, service_name, location, sku)
    rg = az.arm("GET", f"/subscriptions/{sub}/resourcegroups/{resource_group}", allow=(404,))
    rg_exists = rg.get("_status") != 404
    svc_exists, svc_info = False, None
    existing = list_services(az, sub)
    for s in existing:
        if s["name"] == service_name:
            svc_exists, svc_info = True, s
    if not svc_exists:
        with _search_management_client(az, sub) as client:
            avail = _search_sdk_call(client.services.check_name_availability, service_name)
        if avail.is_name_available is False:
            raise GroundingError("SERVICE_NAME_TAKEN", f"Search service name {service_name!r} is unavailable: "
                                 f"{avail.message or avail.reason or ''}",
                                 "Choose a different --service-name (names are globally unique).")
    if svc_exists and svc_info["resource_group"].lower() != resource_group.lower():
        raise GroundingError("SERVICE_IN_OTHER_GROUP",
                             f"service {service_name!r} already exists in resource group {svc_info['resource_group']!r}",
                             "Use that resource group (it will be reused), or pick another service name.")
    changes = [
        f"Resource group {resource_group}: " + ("exists, reused" if rg_exists else f"create in {location}"),
        f"Search service {service_name}: " + ("exists, reused (no changes)" if svc_exists else
                                              f"create, sku {sku}, 1 replica, 1 partition, {location}, "
                                              "Entra (RBAC) auth only, local keys disabled"),
        "Role assignments for the signed-in identity at the service scope (only those not already held): "
        + ", ".join(ALL_ROLES),
    ]
    cost = (f"{sku} tier, 1 search unit, billed hourly while the service exists; no model or embedding calls. "
            f"This subscription currently has {len(existing)} Search service(s).")
    notices = same_service_warning()
    return {"ok": True, "kind": "provision", "plan_id": plan_id, "tenant": ident["tenant"], "subscription": sub,
            "resource_group": resource_group, "service_name": service_name, "location": location, "sku": sku,
            "resource_group_exists": rg_exists, "service_exists": svc_exists,
            "no_op": rg_exists and svc_exists, "changes": changes, "cost": cost, "notices": notices,
            "approval": approval_card(plan_id, f"create-if-not-exists Search service {service_name}", changes, cost,
                                      notices)}


def _wait_service(az: Azure, sub: str, rg: str, name: str, timeout: float = 900.0) -> Any:
    end = time.monotonic() + timeout
    with _search_management_client(az, sub) as client:
        while time.monotonic() < end:
            r = _search_sdk_call(client.services.get, rg, name)
            state = (r.provisioning_state or "").lower()
            if state == "succeeded":
                return r
            if state in ("failed", "deleting"):
                details = getattr(r, "status_details", None)
                info = describe(None, str(details)) if details else None
                raise ServiceError("PROVISIONING_FAILED", append_summary(f"service provisioning state: {state}", info),
                                   service_error=info)
            time.sleep(10)
    raise ServiceError("PROVISIONING_TIMEOUT", "service did not reach succeeded in time",
                       "Re-run create with the same --plan-id; it is idempotent.")


def create_apply(az: Azure, ident: dict[str, Any], plan_id: str, **kw: Any) -> dict[str, Any]:
    plan = create_plan(az, ident, **kw)
    require_plan_id(plan_id, plan["plan_id"])
    sub, rg, name, loc = ident["subscription"], plan["resource_group"], plan["service_name"], plan["location"]
    actions: list[str] = []
    if not plan["resource_group_exists"]:
        az.arm("PUT", f"/subscriptions/{sub}/resourcegroups/{rg}", {"location": loc})
        actions.append("resource_group_created")
    else:
        actions.append("resource_group_reused")
    if not plan["service_exists"]:
        body = {"location": loc, "sku": {"name": plan["sku"]},
                "properties": {"replicaCount": 1, "partitionCount": 1, "hostingMode": "default",
                               "publicNetworkAccess": "enabled", "disableLocalAuth": True}}
        with _search_management_client(az, sub) as client:
            poller = _search_sdk_call(client.services.begin_create_or_update, rg, name, body)
            _search_sdk_call(poller.result, timeout=900)
            if not poller.done():
                raise ServiceError("PROVISIONING_TIMEOUT", "service creation did not complete in time",
                                   "Re-run create with the same --plan-id; it is idempotent.")
        actions.append("service_created")
    else:
        actions.append("service_reused")
    svc = _wait_service(az, sub, rg, name)
    scope = _service_id(sub, rg, name)
    held = check_roles(az, scope, ALL_ROLES)
    assigned, still_needed, pending = [], [], []
    role_errors: dict[str, dict[str, Any]] = {}
    principal_type = "User" if "@" in (ident.get("principal") or "") else "ServicePrincipal"
    for role in ALL_ROLES:
        if held.get(role):
            continue
        ra = uuid.uuid5(uuid.NAMESPACE_URL, f"{scope}|{ident['principal_id']}|{role}")
        body = {"properties": {
            "roleDefinitionId": f"/subscriptions/{sub}/providers/Microsoft.Authorization/roleDefinitions/{ROLE_IDS[role]}",
            "principalId": ident["principal_id"], "principalType": principal_type}}
        try:
            if az.arm("GET", f"{scope}/providers/Microsoft.Authorization/roleAssignments/{ra}", api=AUTHZ_API,
                      allow=(404,)).get("_status") != 404:
                pending.append(role)
                continue
            az.arm("PUT", f"{scope}/providers/Microsoft.Authorization/roleAssignments/{ra}", body, api=AUTHZ_API)
            assigned.append(role)
        except AuthError as exc:
            still_needed.append(role)
            role_errors[role] = {"code": exc.code, "message": exc.message}
            if exc.service_error:
                role_errors[role]["service_error"] = exc.service_error
    final = _summarize(svc)
    out = {"ok": True, "kind": "provision", "plan_id": plan["plan_id"], "actions": actions,
            "no_op": plan["no_op"] and not assigned, "service": final, "roles_assigned": assigned,
            "roles_assigned_awaiting_propagation": pending,
            "roles_still_needed": still_needed, "roles_already_held": [r for r in ALL_ROLES if held.get(r)],
            "next_step": ("Role assignments can take a few minutes to propagate. Then run "
                          f"`grounding-provision connect --service {name}`."
                          + (f" Ask an owner to grant: {', '.join(still_needed)}." if still_needed else "")),
            "warnings": same_service_warning()}
    if role_errors:
        out["role_assignment_errors"] = role_errors
    return out
