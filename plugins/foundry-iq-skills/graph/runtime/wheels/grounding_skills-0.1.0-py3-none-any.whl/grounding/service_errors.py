"""Parse service error responses into a bounded, redacted dict the calling agent can act on.

The service's error code, message, details and request ID are returned to the local caller. Raw response bodies,
request bodies, request headers and credentials are never included.
"""

from __future__ import annotations

import html
import json
import re
from collections.abc import Mapping
from typing import Any

MAX_MESSAGE = 2000
MAX_DETAIL_MESSAGE = 500
MAX_DETAILS = 10
MAX_SHORT = 200
REQUEST_ID_HEADERS = ("x-ms-request-id", "request-id", "apim-request-id", "x-request-id", "x-ms-client-request-id")
NO_BODY = "no service error body"

_REDACTED = "[REDACTED]"
_REDACTIONS = (
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-._~+/]{16,}=*"), "Bearer " + _REDACTED),
    (re.compile(r"eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*"), _REDACTED),
    (re.compile(r"(?i)\b(sig)=[^&\s\"'<>]+"), r"\1=" + _REDACTED),
    (re.compile(r"(?i)\b(AccountKey|SharedAccessKey)=[^;&\s\"'<>]+"), r"\1=" + _REDACTED),
    (re.compile(r"(?i)([\"'](?:api-key|apikey|key)[\"']\s*:\s*)(\"[^\"]*\"|'[^']*'|[^\s,}\]]+)"),
     r"\1" + '"' + _REDACTED + '"'),
    (re.compile(r"(?i)\b(api-key|apikey|key)(\s*=\s*)[^\s&;,\"'<>]+"), r"\1\2" + _REDACTED),
)
_XML_TAG = {name: re.compile(rf"<{name}>(.*?)</{name}>", re.S | re.I)
            for name in ("Code", "Message", "AuthenticationErrorDetail")}
_HTML_DROP = re.compile(r"(?is)<(script|style)\b.*?</\1\s*>")
_TAGS = re.compile(r"(?s)<[^>]*>")


def redact(text: str) -> str:
    for pattern, repl in _REDACTIONS:
        text = pattern.sub(repl, text)
    return text


def _clean(value: Any, limit: int) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, default=str) if isinstance(value, (dict, list)) else str(value)
    text = redact(" ".join(value.split()))
    return text if len(text) <= limit else text[: limit - 3].rstrip() + "..."


def _detail(code: Any, message: Any, target: Any = None) -> dict[str, str] | None:
    d = {"code": _clean(code, MAX_SHORT), "message": _clean(message, MAX_DETAIL_MESSAGE)}
    if not d["code"] and not d["message"]:
        return None
    t = _clean(target, MAX_SHORT)
    if t:
        d["target"] = t
    return d


def _lower_headers(headers: Any) -> dict[str, str]:
    if not headers:
        return {}
    try:
        items = headers.items()
    except AttributeError:
        return {}
    out: dict[str, str] = {}
    try:
        for k, v in items:
            out.setdefault(str(k).lower(), str(v))
    except Exception:  # noqa: BLE001 - headers are best effort
        return out
    return out


def _from_json(data: Any) -> tuple[Any, Any, list[dict[str, str]]] | None:
    if not isinstance(data, dict):
        return None
    err = data.get("error")
    if isinstance(err, dict):
        code = err.get("code") or err.get("type")
        message = err.get("message") or err.get("info")
        details = []
        if err.get("target"):
            details.append(_detail(code, f"error target: {err.get('target')}", err.get("target")))
        for d in err.get("details") or []:
            if isinstance(d, dict):
                details.append(_detail(d.get("code"), d.get("message"), d.get("target")))
        inner = err.get("innererror") or err.get("innerError")
        if isinstance(inner, dict):
            details.append(_detail(inner.get("code"), inner.get("message")))
        return code, message, [d for d in details if d]
    if isinstance(err, str) and err:
        return err, data.get("error_description") or data.get("message"), []
    odata = data.get("odata.error")
    if isinstance(odata, dict):
        msg = odata.get("message")
        return odata.get("code"), msg.get("value") if isinstance(msg, dict) else msg, []
    code = data.get("code") if data.get("code") is not None else data.get("Code")
    message = data.get("message") if data.get("message") is not None else data.get("Message")
    if code is not None or message is not None:
        return code, message, []
    return None


def _from_xml(text: str) -> tuple[Any, Any, list[dict[str, str]]] | None:
    found = {k: (m.group(1) if (m := p.search(text)) else None) for k, p in _XML_TAG.items()}
    if found["Code"] is None and found["Message"] is None:
        return None
    details = []
    if found["AuthenticationErrorDetail"]:
        details.append(_detail("AuthenticationErrorDetail", html.unescape(found["AuthenticationErrorDetail"])))
    return (html.unescape(found["Code"] or ""), html.unescape(found["Message"] or ""), [d for d in details if d])


def _strip_html(text: str) -> str:
    return html.unescape(_TAGS.sub(" ", _HTML_DROP.sub(" ", text)))


def describe(status: int | None, body: bytes | str | None, headers: Mapping[str, str] | None = None) -> dict:
    """Parse a failed response into {status, code?, message?, details?, request_id?} (redacted, truncated)."""
    try:
        status = int(status) if status is not None else None
    except (TypeError, ValueError):
        status = None
    info: dict[str, Any] = {"status": status}
    if isinstance(body, (bytes, bytearray)):
        text = bytes(body).decode("utf-8", errors="replace")
    else:
        text = body if isinstance(body, str) else ""
    text = text.lstrip("\ufeff").strip()
    parsed = None
    if text[:1] in ("{", "["):
        try:
            parsed = _from_json(json.loads(text))
        except ValueError:
            parsed = None
    if parsed is None and text.startswith("<"):
        parsed = _from_xml(text)
        if parsed is None:
            text = _strip_html(text)
    code, message, details = parsed if parsed is not None else (None, text, [])
    hdrs = _lower_headers(headers)
    code = _clean(code, MAX_SHORT) or _clean(hdrs.get("x-ms-error-code"), MAX_SHORT)
    message = _clean(message, MAX_MESSAGE)
    if code:
        info["code"] = code
    if message:
        info["message"] = message
    if details:
        info["details"] = details[:MAX_DETAILS]
    rid = next((hdrs[h] for h in REQUEST_ID_HEADERS if hdrs.get(h)), "")
    if rid:
        info["request_id"] = _clean(rid, MAX_SHORT)
    return info


def _response_body(resp: Any) -> bytes | str | None:
    for attr in ("text", "content", "body"):
        try:
            value = getattr(resp, attr, None)
            if callable(value):
                value = value()
        except Exception:  # noqa: BLE001 - unread or streamed bodies are skipped
            continue
        if isinstance(value, (bytes, bytearray, str)) and value:
            return value
    return None


def from_response(resp: Any) -> dict:
    """describe() for an httpx/requests/azure-core response object."""
    status = getattr(resp, "status_code", None)
    if status is None:
        status = getattr(resp, "status", None)
    return describe(status if isinstance(status, int) else None, _response_body(resp), getattr(resp, "headers", None))


def _merge_fallback(info: dict, code: Any, message: Any, details: Any = None) -> dict:
    if "code" not in info and _clean(code, MAX_SHORT):
        info["code"] = _clean(code, MAX_SHORT)
    if "message" not in info and _clean(message, MAX_MESSAGE):
        info["message"] = _clean(message, MAX_MESSAGE)
    if "details" not in info and isinstance(details, list):
        ds = [_detail(getattr(d, "code", None), getattr(d, "message", None), getattr(d, "target", None))
              for d in details]
        ds = [d for d in ds if d][:MAX_DETAILS]
        if ds:
            info["details"] = ds
    return info


def from_exception(exc: BaseException) -> dict | None:
    """Service error dict for azure-core, openai, urllib, httpx or duck-typed HTTP exceptions; None otherwise."""
    if exc is None:
        return None
    existing = getattr(exc, "service_error", None)
    if isinstance(existing, dict):
        return existing
    resp = getattr(exc, "response", None)
    status = getattr(exc, "status_code", None)
    if status is None:
        status = getattr(exc, "status", None)
    code = getattr(exc, "code", None)
    try:
        from urllib.error import HTTPError
        is_urllib = isinstance(exc, HTTPError)
    except ImportError:  # pragma: no cover
        is_urllib = False
    if status is None and isinstance(code, int) and not isinstance(code, bool) and (is_urllib or 100 <= code < 600):
        status = code
    try:
        from azure.core.exceptions import AzureError
        is_azure = isinstance(exc, AzureError)
    except ImportError:
        is_azure = False
    http_like = (status is not None or (resp is not None and getattr(resp, "status_code", None) is not None)
                 or is_urllib or is_azure)
    if not http_like:
        return None
    if resp is not None and getattr(resp, "status_code", None) is not None:
        info = from_response(resp)
        if info.get("status") is None and isinstance(status, int):
            info["status"] = status
    elif is_urllib:
        try:
            body = exc.read()  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            body = None
        info = describe(status, body, getattr(exc, "headers", None))
    else:
        info = describe(status if isinstance(status, int) else None, None, getattr(resp, "headers", None))
    err = getattr(exc, "error", None)  # azure-core ODataV4Format
    if err is not None and not isinstance(err, (str, dict)):
        _merge_fallback(info, getattr(err, "code", None), getattr(err, "message", None),
                        getattr(err, "details", None))
    body = getattr(exc, "body", None)  # openai APIStatusError
    if isinstance(body, dict):
        parsed = _from_json(body if "error" in body else {"error": body})
        if parsed:
            _merge_fallback(info, parsed[0], parsed[1])
            if parsed[2] and "details" not in info:
                info["details"] = parsed[2][:MAX_DETAILS]
    sdk_code = next((c for c in (code, getattr(exc, "error_code", None), getattr(exc, "type", None))
                     if isinstance(c, str) and c), None)
    message = getattr(exc, "message", None) or getattr(exc, "reason", None) or str(exc) or None
    return _merge_fallback(info, sdk_code, message)


def from_index_results(failed: list[dict[str, Any]], status: int | None = None) -> dict:
    """Service error for rejected documents in a Search docs/index response (per-document errorMessage, capped)."""
    details = [_detail(r.get("statusCode"), r.get("errorMessage") or "rejected", r.get("key")) for r in failed]
    details = [d for d in details if d][:MAX_DETAILS]
    first = next((r for r in failed if r.get("errorMessage")), failed[0] if failed else {})
    if status is None:
        status = first.get("statusCode") if isinstance(first.get("statusCode"), int) else None
    info: dict[str, Any] = {"status": status}
    message = first.get("errorMessage")
    if message:
        key = first.get("key")
        info["message"] = _clean((f"document {key}: " if key else "") + str(message), MAX_MESSAGE)
    if details:
        info["details"] = details
    return info


def summary(info: dict | None) -> str:
    """One line: `HTTP 400 InvalidRequestParameter: <message> (request id <id>)`, omitting absent parts."""
    info = info or {}
    head = " ".join(p for p in (f"HTTP {info['status']}" if info.get("status") is not None else "",
                                info.get("code") or "") if p)
    message = info.get("message") or ""
    if message:
        line = f"{head}: {message}" if head else message
    elif info.get("code"):
        line = head
    else:
        line = f"{head}: {NO_BODY}" if head else NO_BODY
    if info.get("request_id"):
        line += f" (request id {info['request_id']})"
    return line


def append_summary(message: str, info: dict | None) -> str:
    return f"{message}: {summary(info)}" if info else message
