"""Optional MCP Apps presentation server for a read-only grounding index."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from collections.abc import Mapping
from importlib.resources import files
from typing import Any

from . import API_VERSION, __version__, consume, state
from .azure import Azure, validate_endpoint
from .cli_common import resolve_endpoint
from .errors import GroundingError
from .names import validate_index_name
from .service_errors import from_exception
from .wikidata_properties import property_label

try:
    from mcp.server.apps import APP_MIME_TYPE, EXTENSION_ID
except ImportError:  # base CLI install does not require mcp
    APP_MIME_TYPE = "text/html;profile=mcp-app"
    EXTENSION_ID = "io.modelcontextprotocol/ui"

EXPLORER_RESOURCE_URI = "ui://grounding-skills/explorer.html"
RESOURCE_FILES = {
    EXPLORER_RESOURCE_URI: "explorer.html",
}
ASSET_FILES = frozenset({
    "explorer.html",
    "explorer.THIRD_PARTY_NOTICES.txt",
    "build-provenance.json",
    "bundle-report.json",
})
PRESENTER_TOOLS = frozenset({"grounding_present"})
SUPPORT_TOOLS = frozenset({"grounding_overview", "grounding_search"})
APP_TOOLS = PRESENTER_TOOLS | SUPPORT_TOOLS

SEARCH_SELECT = (
    "id,subject,subject_id,subject_type,predicate,object,object_id,object_type,"
    "object_string,object_double,object_bool,object_datetime,edge_confidence,namespace,graph_name"
)

_OVERVIEW_FIELDS = frozenset({"index", "endpoint", "graph_name"})
_SEARCH_FIELDS = frozenset({"index", "endpoint", "query", "predicate", "namespace", "top"})
_PRESENT_FIELDS = _OVERVIEW_FIELDS | _SEARCH_FIELDS
_TOOL_FIELDS = {
    "grounding_present": _PRESENT_FIELDS,
    "grounding_overview": _OVERVIEW_FIELDS,
    "grounding_search": _SEARCH_FIELDS,
}
_STRING_FIELDS = frozenset({"index", "endpoint", "query", "predicate", "namespace", "graph_name"})
_LABEL_PREDICATES = frozenset({"rdfs:label", "skos:altLabel"})
_ENTITY_FACET_CAP = 10000


class AssetIntegrityError(GroundingError, RuntimeError, ValueError):
    """Raised when packaged MCP Apps assets are missing or fail integrity verification."""

    def __init__(self, message: str):
        GroundingError.__init__(self, "APP_ASSETS_INVALID", message)


def validate_raw_arguments(name: str, arguments: Any) -> None:
    """Validate raw JSON-RPC tool arguments before Pydantic coercion."""
    if type(name) is not str or name not in APP_TOOLS:
        raise ValueError("unknown Grounding Apps operation")
    if not isinstance(arguments, Mapping):
        raise ValueError("arguments must be an object")
    if any(type(key) is not str for key in arguments):
        raise ValueError("argument names must be strings")
    allowed = _TOOL_FIELDS[name]
    extra = set(arguments) - allowed
    if extra:
        raise ValueError(f"unsupported grounding tool argument(s): {', '.join(sorted(extra))}")
    for field in _STRING_FIELDS & set(arguments):
        value = arguments[field]
        if value is None:
            continue
        if type(value) is not str:
            raise ValueError(f"{field} must be a string")
        if any(ord(ch) < 32 for ch in value):
            raise ValueError(f"{field} must not contain control characters")
        if field in {"predicate", "namespace"} and "'" in value:
            raise ValueError(f"{field} must not contain a single quote")
    if "top" in allowed and "top" in arguments and arguments["top"] is not None:
        top = arguments["top"]
        if type(top) is not int or not 1 <= top <= 100:
            raise ValueError("top must be an integer in 1..100")


def load_assets() -> dict[str, str]:
    """Load and verify packaged HTML and provenance assets against SHA256 and byte length."""
    root = files("grounding").joinpath("assets")
    if not root.is_dir():
        raise AssetIntegrityError("packaged grounding assets directory is missing")
    try:
        provenance_bytes = root.joinpath("build-provenance.json").read_bytes()
        report_bytes = root.joinpath("bundle-report.json").read_bytes()
        provenance = json.loads(provenance_bytes.decode("utf-8"))
        report = json.loads(report_bytes.decode("utf-8"))
        if not isinstance(provenance, dict) or not isinstance(report, dict):
            raise ValueError("asset metadata must be JSON objects")
        resources = provenance.get("resources")
        report_resources = report.get("resources")
        if not isinstance(resources, dict) or not isinstance(report_resources, dict):
            raise ValueError("asset metadata missing resources map")

        loaded: dict[str, str] = {
            "build-provenance.json": provenance_bytes.decode("utf-8"),
            "bundle-report.json": report_bytes.decode("utf-8"),
        }
        for uri, filename in RESOURCE_FILES.items():
            entry = filename.removesuffix(".html")
            expected = resources.get(entry)
            if not isinstance(expected, dict):
                raise ValueError(f"missing provenance entry for {filename}")
            if report_resources.get(entry) != expected:
                raise ValueError(f"bundle report mismatch for {filename}")
            data = root.joinpath(filename).read_bytes()
            if (
                len(data) != expected.get("rawHtmlBytes")
                or hashlib.sha256(data).hexdigest() != expected.get("sha256")
            ):
                raise ValueError(f"packaged resource hash or size mismatch: {filename}")
            html = data.decode("utf-8")
            if not html.strip():
                raise ValueError(f"empty packaged resource: {filename}")
            loaded[filename] = html

        notices = provenance.get("notices")
        if not isinstance(notices, dict) or "explorer.THIRD_PARTY_NOTICES.txt" not in notices:
            raise ValueError("missing third-party notices provenance")
        for notice_name, expected_sha in notices.items():
            if notice_name not in ASSET_FILES:
                raise ValueError(f"unexpected notice asset: {notice_name}")
            notice_data = root.joinpath(notice_name).read_bytes()
            if hashlib.sha256(notice_data).hexdigest() != expected_sha:
                raise ValueError(f"packaged notice hash mismatch: {notice_name}")
            loaded[notice_name] = notice_data.decode("utf-8")

        manifest_node = root.joinpath("assets.json")
        if manifest_node.is_file():
            manifest = json.loads(manifest_node.read_text(encoding="utf-8"))
            if (
                not isinstance(manifest, dict)
                or manifest.get("version") != "grounding-app-assets-v1"
                or set(manifest.get("files") or {}) != ASSET_FILES
            ):
                raise ValueError("unsupported asset manifest")
            for name, expected_sha in manifest["files"].items():
                raw = root.joinpath(name).read_bytes()
                if hashlib.sha256(raw).hexdigest() != expected_sha:
                    raise ValueError(f"packaged asset manifest hash mismatch: {name}")

        if set(loaded) != ASSET_FILES:
            raise ValueError("incomplete packaged asset set")
        return loaded
    except AssetIntegrityError:
        raise
    except (OSError, ValueError, KeyError, TypeError, AttributeError, UnicodeError) as exc:
        raise AssetIntegrityError(
            f"cannot load verified packaged grounding app assets: {exc}"
        ) from exc


def _load_html(uri: str = EXPLORER_RESOURCE_URI) -> str:
    if uri not in RESOURCE_FILES:
        raise AssetIntegrityError(f"unknown grounding app resource URI: {uri}")
    filename = RESOURCE_FILES[uri]
    return load_assets()[filename]


def resolve_target(
    index: str | None = None,
    endpoint: str | None = None,
    graph_name: str = "",
    *,
    default_index: str | None = None,
    default_endpoint: str | None = None,
    default_graph_name: str = "",
) -> tuple[str, str, str]:
    """Resolve (index, endpoint, graph_name) from arguments, defaults, env vars, or active descriptors."""
    descriptors = state.list_descriptors()
    latest = descriptors[0] if descriptors else None

    resolved_index = (
        (index or "").strip()
        or (default_index or "").strip()
        or os.environ.get("GROUNDING_INDEX", "").strip()
        or (str(latest["index"]).strip() if latest and latest.get("index") else "")
    )
    if not resolved_index:
        conn = state.load_connection() or {}
        if conn.get("index"):
            resolved_index = str(conn["index"]).strip()
    if not resolved_index:
        raise GroundingError(
            "NO_INDEX",
            "no grounding index specified or found in local descriptors",
            "Pass --index, set GROUNDING_INDEX, or run `grounding-build apply` first.",
        )
    validate_index_name(resolved_index, prefix="")

    explicit_ep = (
        (endpoint or "").strip()
        or (default_endpoint or "").strip()
        or os.environ.get("GROUNDING_ENDPOINT", "").strip()
        or os.environ.get("AZURE_SEARCH_ENDPOINT", "").strip()
    )
    desc = state.load_descriptor(resolved_index, explicit_ep)
    if explicit_ep:
        resolved_endpoint = validate_endpoint(explicit_ep)
    elif desc and desc.get("endpoint"):
        resolved_endpoint = validate_endpoint(str(desc["endpoint"]))
    else:
        resolved_endpoint = resolve_endpoint("", resolved_index)

    resolved_graph_name = (
        (graph_name or "").strip()
        or (default_graph_name or "").strip()
        or os.environ.get("GROUNDING_GRAPH_NAME", "").strip()
        or (str(desc["graph_name"]).strip() if desc and desc.get("graph_name") else "")
    )
    return resolved_index, resolved_endpoint, resolved_graph_name


def _literal_value(edge: Mapping[str, Any]) -> Any:
    for key in ("object_double", "object_bool", "object_datetime", "object_string"):
        val = edge.get(key)
        if val is not None and val != "":
            return val
    return None


def aggregate_entities(edges: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Group triples by subject_id / subject into canonical entity records."""
    groups: dict[str, dict[str, Any]] = {}
    for edge in edges:
        subj = str(edge.get("subject") or "").strip()
        subj_id = str(edge.get("subject_id") or "").strip()
        key = subj_id or subj
        if not key:
            continue
        group = groups.get(key)
        if group is None:
            group = {
                "canonical_id": subj_id or subj,
                "name": "",
                "type": "",
                "namespace": "",
                "graph_name": "",
                "aliases": [],
                "properties": {},
                "edge_count": 0,
                "_primary_label": "",
            }
            groups[key] = group

        group["edge_count"] += 1
        if subj_id and group["canonical_id"] != subj_id:
            group["canonical_id"] = subj_id
        if not group["type"] and edge.get("subject_type"):
            group["type"] = str(edge["subject_type"])
        if not group["namespace"] and edge.get("namespace"):
            group["namespace"] = str(edge["namespace"])
        if not group["graph_name"] and edge.get("graph_name"):
            group["graph_name"] = str(edge["graph_name"])

        pred = str(edge.get("predicate") or "").strip()
        obj = str(edge.get("object") or edge.get("object_string") or "").strip()
        subj_display = str(edge.get("subject_id_display_name") or "").strip()

        if pred in _LABEL_PREDICATES:
            if obj and obj not in group["aliases"]:
                group["aliases"].append(obj)
            if pred == "rdfs:label" and obj and not group["_primary_label"]:
                group["_primary_label"] = obj
        else:
            if subj and subj != group["canonical_id"] and not group["name"]:
                group["name"] = subj
            if subj_display and not group["name"]:
                group["name"] = subj_display
            lit = _literal_value(edge)
            if pred and lit is not None:
                existing = group["properties"].get(pred)
                if existing is None:
                    group["properties"][pred] = lit
                elif isinstance(existing, list):
                    if lit not in existing:
                        existing.append(lit)
                elif existing != lit:
                    group["properties"][pred] = [existing, lit]

    entities: list[dict[str, Any]] = []
    for group in groups.values():
        group["property_labels"] = {pid: label for pid in group["properties"] if (label := property_label(pid))}
        primary_label = group.pop("_primary_label", "")
        if not group["name"]:
            group["name"] = primary_label or (
                group["aliases"][0] if group["aliases"] else group["canonical_id"]
            )
        entities.append(group)
    return entities


def _with_predicate_label(edge: dict[str, Any]) -> dict[str, Any]:
    label = property_label(str(edge.get("predicate") or ""))
    return {**edge, "predicate_label": label} if label else edge


def _canonical_entity_count(client: Azure, endpoint: str, index: str) -> int | None:
    """Distinct labelled subject_id values, or None when the facet is capped or unavailable."""
    try:
        res = client.search("POST", endpoint, f"/indexes/{index}/docs/search",
                            {"search": "*", "filter": consume.LABEL_FILTER, "top": 0,
                             "facets": [f"subject_id,count:{_ENTITY_FACET_CAP}"]})
        buckets = res["@search.facets"]["subject_id"]
    except Exception:
        return None
    if not isinstance(buckets, list) or len(buckets) >= _ENTITY_FACET_CAP:
        return None
    return len(buckets)


def grounding_overview(
    index: str | None = None,
    endpoint: str | None = None,
    graph_name: str = "",
    *,
    az: Azure | None = None,
    default_index: str | None = None,
    default_endpoint: str | None = None,
    default_graph_name: str = "",
) -> dict[str, Any]:
    """Combine consume.inspect and consume.ready into one read-only summary."""
    resolved_index, resolved_endpoint, resolved_graph = resolve_target(
        index,
        endpoint,
        graph_name,
        default_index=default_index,
        default_endpoint=default_endpoint,
        default_graph_name=default_graph_name,
    )
    client = az or Azure()
    inspected = consume.inspect(client, resolved_endpoint, resolved_index)
    readiness = consume.ready(client, resolved_endpoint, resolved_index, graph_name=resolved_graph)
    doc_count = (
        inspected["document_count"]
        if inspected.get("document_count") is not None
        else readiness.get("document_count", 0)
    )
    canonical = _canonical_entity_count(client, resolved_endpoint, resolved_index)
    return {
        "ok": True,
        "index": resolved_index,
        "endpoint": resolved_endpoint,
        "api_version": API_VERSION,
        "graph_name": resolved_graph,
        "graph_profile": inspected.get("graph_profile"),
        "fields": inspected.get("fields", []),
        "document_count": doc_count,
        "label_rows": readiness.get("label_rows", 0),
        **({"canonical_entities": canonical} if canonical is not None else {}),
        "storage_size_bytes": inspected.get("storage_size_bytes"),
        "sampled_documents": inspected.get("sampled_documents", 0),
        "sampled_namespaces": inspected.get("sampled_namespaces", {}),
        "sampled_graph_names": inspected.get("sampled_graph_names", {}),
        "distinct_graph_names": readiness.get("distinct_graph_names", {}),
        "sampled_top_predicates": inspected.get("sampled_top_predicates", {}),
        "predicate_labels": {pid: label for pid in inspected.get("sampled_top_predicates", {})
                             if (label := property_label(pid))},
        "descriptor": inspected.get("descriptor"),
        "ready": bool(readiness.get("ok", False)),
        "checks": readiness.get("checks", []),
        "result": readiness.get("result", "FAIL"),
        "next_step": readiness.get("next_step", ""),
    }


def grounding_search(
    index: str | None = None,
    endpoint: str | None = None,
    query: str = "*",
    predicate: str = "",
    namespace: str = "",
    top: int = 50,
    *,
    az: Azure | None = None,
    default_index: str | None = None,
    default_endpoint: str | None = None,
) -> dict[str, Any]:
    """Query grounding triples and return both raw edges and aggregated entities."""
    if type(top) is not int or not 1 <= top <= 100:
        raise GroundingError("SAMPLE_SIZE_INVALID", "top must be 1..100")
    if predicate and "'" in predicate:
        raise GroundingError("PREDICATE_INVALID", "predicate must not contain a single quote")
    if namespace and "'" in namespace:
        raise GroundingError("NAMESPACE_INVALID", "namespace must not contain a single quote")

    resolved_index, resolved_endpoint, _ = resolve_target(
        index,
        endpoint,
        default_index=default_index,
        default_endpoint=default_endpoint,
    )
    client = az or Azure()
    consume._require_index(client, resolved_endpoint, resolved_index)

    search_text = query if (isinstance(query, str) and query.strip()) else "*"
    body: dict[str, Any] = {
        "search": search_text,
        "top": top,
        "select": SEARCH_SELECT,
    }
    filters: list[str] = []
    if predicate:
        filters.append(f"predicate eq '{predicate}'")
    if namespace:
        filters.append(f"namespace eq '{namespace}'")
    if filters:
        body["filter"] = " and ".join(filters)

    res = client.search("POST", resolved_endpoint, f"/indexes/{resolved_index}/docs/search", body)
    edges = [
        _with_predicate_label({k: v for k, v in d.items() if not k.startswith("@")})
        for d in res.get("value", [])
        if isinstance(d, dict)
    ]
    entities = aggregate_entities(edges)
    payload = {
        "index": resolved_index,
        "endpoint": resolved_endpoint,
        "api_version": API_VERSION,
        "query": search_text,
        "predicate": predicate,
        "namespace": namespace,
        "entities": entities,
        "edges": edges,
        "count": len(edges),
    }
    return {
        "ok": True,
        "result": payload,
        **payload,
    }


def grounding_present(
    index: str | None = None,
    endpoint: str | None = None,
    query: str = "*",
    predicate: str = "",
    namespace: str = "",
    graph_name: str = "",
    top: int = 50,
    *,
    az: Azure | None = None,
    default_index: str | None = None,
    default_endpoint: str | None = None,
    default_graph_name: str = "",
) -> dict[str, Any]:
    """Combined presenter tool returning overview, entities, and edges for the MCP App."""
    if type(top) is not int or not 1 <= top <= 100:
        raise GroundingError("SAMPLE_SIZE_INVALID", "top must be 1..100")
    resolved_index, resolved_endpoint, resolved_graph = resolve_target(
        index,
        endpoint,
        graph_name,
        default_index=default_index,
        default_endpoint=default_endpoint,
        default_graph_name=default_graph_name,
    )
    client = az or Azure()
    overview_out = grounding_overview(
        index=resolved_index,
        endpoint=resolved_endpoint,
        graph_name=resolved_graph,
        az=client,
    )
    search_out = grounding_search(
        index=resolved_index,
        endpoint=resolved_endpoint,
        query=query,
        predicate=predicate,
        namespace=namespace,
        top=top,
        az=client,
    )
    payload = {
        "index": resolved_index,
        "endpoint": resolved_endpoint,
        "api_version": API_VERSION,
        "overview": overview_out,
        "entities": search_out["entities"],
        "edges": search_out["edges"],
        "count": search_out["count"],
    }
    return {
        "ok": True,
        "result": payload,
        **payload,
    }


def _strip_discovery_extension(result: Any) -> Any:
    if isinstance(result, Mapping):
        capabilities = result.get("capabilities")
        if isinstance(capabilities, Mapping):
            updated_caps = dict(capabilities)
            extensions = updated_caps.get("extensions")
            if isinstance(extensions, Mapping):
                remaining = {k: v for k, v in extensions.items() if k != EXTENSION_ID}
                if remaining:
                    updated_caps["extensions"] = remaining
                else:
                    updated_caps.pop("extensions", None)
                return {**result, "capabilities": updated_caps}
        return result
    capabilities = getattr(result, "capabilities", None)
    if capabilities is not None:
        extensions = dict(getattr(capabilities, "extensions", None) or {})
        extensions.pop(EXTENSION_ID, None)
        capabilities = capabilities.model_copy(update={"extensions": extensions or None})
        return result.model_copy(update={"capabilities": capabilities})
    return result


def create_server(
    *,
    index: str | None = None,
    endpoint: str | None = None,
    graph_name: str = "",
    az: Azure | None = None,
):
    """Create the MCP Apps server for grounding-skills."""
    from mcp.server.apps import (
        Apps,
        ResourceCsp,
        ResourcePermissions,
        client_supports_apps,
    )
    from mcp.server.context import CallNext, HandlerResult, ServerRequestContext
    from mcp.server.mcpserver import MCPServer
    from mcp.shared.exceptions import MCPError
    from mcp.types import (
        CallToolResult,
        ListResourcesResult,
        ListToolsResult,
        TextContent,
        ToolAnnotations,
    )

    apps = Apps()
    csp = ResourceCsp(
        connect_domains=[],
        resource_domains=[],
        frame_domains=[],
        base_uri_domains=[],
    )
    permissions = ResourcePermissions()
    for uri in RESOURCE_FILES:
        apps.add_html_resource(
            uri,
            _load_html(uri),
            name="Grounding Explorer",
            csp=csp,
            permissions=permissions,
            prefers_border=True,
        )

    class AppsMiddleware:
        async def __call__(
            self,
            ctx: ServerRequestContext[Any, Any],
            call_next: CallNext,
        ) -> HandlerResult:
            supports_apps = client_supports_apps(ctx)
            if ctx.method == "server/discover" and not supports_apps:
                result = await call_next(ctx)
                return _strip_discovery_extension(result)

            if not supports_apps:
                if ctx.method == "tools/list":
                    return ListToolsResult(tools=[])
                if ctx.method == "resources/list":
                    return ListResourcesResult(resources=[])
                if ctx.method == "resources/read":
                    params = ctx.params if isinstance(ctx.params, Mapping) else {}
                    uri = params.get("uri")
                    if type(uri) is str and uri in RESOURCE_FILES:
                        raise MCPError(-32002, "Resource not found")
                    raise MCPError(-32002, "Resource not found")
                if ctx.method == "tools/call":
                    params = ctx.params if isinstance(ctx.params, Mapping) else {}
                    name = params.get("name")
                    if type(name) is str and name in APP_TOOLS:
                        raise MCPError(-32601, "Tool not found")
                    raise MCPError(-32601, "Tool not found")
                return await call_next(ctx)

            if ctx.method == "resources/read":
                params = ctx.params if isinstance(ctx.params, Mapping) else {}
                uri = params.get("uri")
                if type(uri) is not str or uri not in RESOURCE_FILES:
                    raise MCPError(-32002, "Resource not found")

            if ctx.method == "tools/call":
                if ctx.params is not None and not isinstance(ctx.params, Mapping):
                    raise MCPError(-32602, "Request parameters must be an object")
                params = dict(ctx.params or {})
                if set(params) - {"name", "arguments", "_meta"}:
                    raise MCPError(-32602, "Unsupported tools/call parameter")
                name = params.get("name")
                if type(name) is not str or name not in APP_TOOLS:
                    raise MCPError(-32601, "Tool not found")
                arguments = params.get("arguments", {})
                try:
                    validate_raw_arguments(name, arguments)
                except ValueError as error:
                    raise MCPError(-32602, str(error)) from error
            return await call_next(ctx)

    read_only = ToolAnnotations(read_only_hint=True, open_world_hint=False)
    bound_az = az

    def _get_az() -> Azure:
        nonlocal bound_az
        if bound_az is None:
            bound_az = Azure()
        return bound_az

    def _sdk_result(fn, *args: Any, **kwargs: Any) -> Any:
        try:
            payload = fn(*args, **kwargs)
            is_error = not payload.get("ok", True)
        except GroundingError as exc:
            payload = exc.envelope()
            is_error = True
        except Exception as exc:  # noqa: BLE001 - return the failure to the client instead of a generic error
            payload = {"ok": False, "code": "UNEXPECTED", "message": f"{type(exc).__name__}: {exc}"}
            info = from_exception(exc)
            if info:
                payload["service_error"] = info
            is_error = True
        text = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        return CallToolResult(
            content=[TextContent(type="text", text=text)],
            structured_content=payload,
            is_error=is_error,
        )

    @apps.tool(
        resource_uri=EXPLORER_RESOURCE_URI,
        visibility=["model"],
        name="grounding_present",
        description="Present a grounding index overview and entity/triple explorer.",
        annotations=read_only,
        structured_output=False,
    )
    def present_tool(
        index: str | None = None,
        endpoint: str | None = None,
        query: str = "*",
        predicate: str = "",
        namespace: str = "",
        graph_name: str = "",
        top: int = 50,
    ) -> Any:
        return _sdk_result(
            grounding_present,
            index=index,
            endpoint=endpoint,
            query=query,
            predicate=predicate,
            namespace=namespace,
            graph_name=graph_name,
            top=top,
            az=_get_az(),
            default_index=default_index,
            default_endpoint=default_endpoint,
            default_graph_name=default_graph_name,
        )

    default_index = index
    default_endpoint = endpoint
    default_graph_name = graph_name

    server = MCPServer(
        name="grounding-skills",
        version=__version__,
        log_level="WARNING",
        extensions=[apps],
        middleware=[AppsMiddleware()],
    )

    @server.tool(
        name="grounding_overview",
        description="Read grounding index profile stats, sampled namespaces/predicates, and readiness checks.",
        annotations=read_only,
        meta={"ui": {"visibility": ["app"]}},
        structured_output=False,
    )
    def overview_tool(
        index: str | None = None,
        endpoint: str | None = None,
        graph_name: str = "",
    ) -> Any:
        return _sdk_result(
            grounding_overview,
            index=index,
            endpoint=endpoint,
            graph_name=graph_name,
            az=_get_az(),
            default_index=default_index,
            default_endpoint=default_endpoint,
            default_graph_name=default_graph_name,
        )

    @server.tool(
        name="grounding_search",
        description="Search grounding triples and aggregate canonical entities for the Apps explorer.",
        annotations=read_only,
        meta={"ui": {"visibility": ["app"]}},
        structured_output=False,
    )
    def search_tool(
        index: str | None = None,
        endpoint: str | None = None,
        query: str = "*",
        predicate: str = "",
        namespace: str = "",
        top: int = 50,
    ) -> Any:
        return _sdk_result(
            grounding_search,
            index=index,
            endpoint=endpoint,
            query=query,
            predicate=predicate,
            namespace=namespace,
            top=top,
            az=_get_az(),
            default_index=default_index,
            default_endpoint=default_endpoint,
        )

    return server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="grounding-apps",
        description="Serve read-only grounding MCP Apps over stdio.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"grounding-apps {__version__}",
    )
    parser.add_argument(
        "--index",
        default=os.environ.get("GROUNDING_INDEX"),
        help="default grounding index name (default: GROUNDING_INDEX or latest active descriptor)",
    )
    parser.add_argument(
        "--endpoint",
        default=os.environ.get("GROUNDING_ENDPOINT") or os.environ.get("AZURE_SEARCH_ENDPOINT"),
        help="default Search endpoint https://<service>.search.windows.net (default: GROUNDING_ENDPOINT)",
    )
    parser.add_argument(
        "--graph-name",
        default=os.environ.get("GROUNDING_GRAPH_NAME", ""),
        help="optional graph name to check alignment against",
    )
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.index:
            validate_index_name(args.index, prefix="")
        if args.endpoint:
            validate_endpoint(args.endpoint)
        server = create_server(
            index=args.index,
            endpoint=args.endpoint,
            graph_name=args.graph_name or "",
        )
    except ModuleNotFoundError as error:
        if error.name and error.name.split(".")[0] == "mcp":
            parser.exit(
                1,
                "Apps support is optional; install it with `pip install 'grounding-skills[apps]'`.\n",
            )
        raise
    except (FileNotFoundError, ValueError, RuntimeError, GroundingError) as error:
        parser.error(str(error))

    if hasattr(sys.stdin, "reconfigure"):
        sys.stdin.reconfigure(encoding="utf-8")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", newline="\n")
    server.run()


if __name__ == "__main__":
    main()
