"""Local user state (outside the repo): saved connection, plans, journals, descriptors."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .errors import GroundingError


def state_dir() -> Path:
    override = os.environ.get("GROUNDING_HOME")
    if override:
        base = Path(override)
    elif sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / ("App" + "Data") / "Local") / "grounding-skills"
    else:
        base = Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local" / "state") / "grounding-skills"
    return base


def atomic_write_text(path: Path, text: str) -> None:
    """Replace `path` atomically through a temp file only this writer owns, so concurrent writers never collide."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        for attempt in range(100):
            try:
                os.replace(tmp, path)
                break
            except PermissionError:  # Windows refuses a rename while another writer replaces the target
                if os.name != "nt" or attempt == 99:
                    raise
                time.sleep(0.01)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def _write_json(path: Path, data: Any) -> None:
    atomic_write_text(path, json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False))


def _read_json(path: Path) -> Any | None:
    if not path.is_file():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def load_connection() -> dict[str, Any] | None:
    return _read_json(state_dir() / "connection.json")


def save_connection(conn: dict[str, Any]) -> Path:
    p = state_dir() / "connection.json"
    _write_json(p, conn)
    return p


def plan_dir(plan_id: str) -> Path:
    return state_dir() / "plans" / plan_id


def save_plan(plan: dict[str, Any]) -> Path:
    p = plan_dir(plan["plan_id"]) / "plan.json"
    _write_json(p, plan)
    return p


def load_plan(plan_id: str) -> dict[str, Any] | None:
    return _read_json(plan_dir(plan_id) / "plan.json")


def save_edges(plan_id: str, edges: list[dict[str, Any]]) -> Path:
    p = plan_dir(plan_id) / "edges.jsonl"
    atomic_write_text(p, "".join(json.dumps(e, ensure_ascii=False, sort_keys=True) + "\n" for e in edges))
    return p


def load_edges(plan_id: str) -> list[dict[str, Any]]:
    p = plan_dir(plan_id) / "edges.jsonl"
    if not p.is_file():
        return []
    return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]


def journal_path(plan_id: str) -> Path:
    return plan_dir(plan_id) / "journal.json"


def load_journal(plan_id: str) -> dict[str, Any] | None:
    return _read_json(journal_path(plan_id))


def save_journal(plan_id: str, journal: dict[str, Any]) -> None:
    _write_json(journal_path(plan_id), journal)


def service_host(endpoint: str) -> str:
    return (urlparse(str(endpoint or "")).hostname or "").lower()


def save_descriptor(descriptor: dict[str, Any]) -> Path:
    """Descriptors are keyed by Search service and index, so the same index name on two services never collides."""
    host = service_host(descriptor["endpoint"])
    p = state_dir() / "descriptors" / f"{host}--{descriptor['index']}.json"
    _write_json(p, descriptor)
    _write_json(plan_dir(descriptor["plan_id"]) / "descriptor.json", descriptor)
    return p


def load_plan_descriptor(plan_id: str) -> dict[str, Any] | None:
    """The descriptor written when this plan completed."""
    return _read_json(plan_dir(plan_id) / "descriptor.json")


def load_descriptor(index: str, endpoint: str = "") -> dict[str, Any] | None:
    """The newest descriptor for `index`, on `endpoint` when given; refuses to guess between services."""
    host = service_host(endpoint) if endpoint else ""
    matches = [d for d in list_descriptors()
               if d.get("index") == index and (not host or service_host(d.get("endpoint", "")) == host)]
    services = sorted({service_host(d.get("endpoint", "")) for d in matches})
    if len(services) > 1:
        raise GroundingError("DESCRIPTOR_AMBIGUOUS",
                             f"index {index!r} has descriptors on several Search services: {', '.join(services)}",
                             "Pass --endpoint to choose the service.", detail=services)
    return matches[0] if matches else None


def list_descriptors() -> list[dict[str, Any]]:
    """Return saved descriptors ordered from most recently created/modified to oldest."""
    root = state_dir() / "descriptors"
    if not root.is_dir():
        return []
    items: list[tuple[tuple[str, float, str], dict[str, Any]]] = []
    for p in sorted(root.glob("*.json")):
        try:
            data = _read_json(p)
            if isinstance(data, dict) and data.get("index"):
                created_at = str(data.get("created_at") or "")
                mtime = p.stat().st_mtime
                items.append(((created_at, mtime, p.name), data))
        except (OSError, ValueError, TypeError):
            continue
    items.sort(key=lambda pair: pair[0], reverse=True)
    return [data for _, data in items]
