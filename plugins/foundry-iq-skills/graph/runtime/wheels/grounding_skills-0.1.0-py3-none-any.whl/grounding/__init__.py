"""Grounding index tooling: create, load and verify an Azure AI Search edgeList index."""

__version__ = "0.1.0"
API_VERSION = "2026-11-01-preview"
SCHEMA_VERSION = "1"
