"""Microsoft Entra auth and thin REST helpers for Azure Resource Manager and Azure AI Search.

No keys are read, stored or accepted: every call carries an Entra bearer token.
"""

from __future__ import annotations

import base64
import json
import os
import re
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from . import API_VERSION, __version__
from .errors import AuthError, GroundingError, ServiceError
from .service_errors import append_summary, from_exception, from_response

_GUID = re.compile(r"^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$")

SKILL_USER_AGENT = f"foundry-iq-skill-v{__version__}"

ARM = "https://management.azure.com"
ARM_SCOPE = "https://management.azure.com/.default"
SEARCH_SCOPE = "https://search.azure.com/.default"
# Reuse a token until this many seconds before it expires; each fresh one can spawn `az` (~1.5 s).
TOKEN_REFRESH_MARGIN_S = 300
SEARCH_SUFFIXES = (".search.windows.net", ".search.azure.us", ".search.azure.cn")
SEARCH_ARM_API = "2025-05-01"
RESOURCES_API = "2021-04-01"
AUTHZ_API = "2022-04-01"
RETRY_STATUS = {429, 503}

ROLE_IDS = {  # built-in role definition GUIDs (public, identical in every tenant)
    "Search Service Contributor": "7ca78c08-252a-4471-8644-bb5ff32d4ba0",
    "Search Index Data Contributor": "8ebe5a00-799e-43f5-93ac-243d3dce84a7",
    "Search Index Data Reader": "1407120a-92aa-4202-b7e9-c0e197c71c8f",
}
# What each role must grant (matched with wildcards against effective actions / dataActions).
ROLE_NEEDS = {
    "Search Service Contributor": ("actions", "Microsoft.Search/searchServices/write"),
    "Search Index Data Contributor": ("dataActions", "Microsoft.Search/searchServices/indexes/documents/write"),
    "Search Index Data Reader": ("dataActions", "Microsoft.Search/searchServices/indexes/documents/read"),
}


def validate_endpoint(endpoint: str) -> str:
    u = urlparse(endpoint)
    host = (u.hostname or "").lower()
    if u.scheme != "https" or not host.endswith(SEARCH_SUFFIXES) or u.username or u.path.strip("/"):
        raise GroundingError("ENDPOINT_INVALID", "endpoint must look like https://<service>.search.windows.net",
                             "Run grounding-provision connect to list services you can use.")
    return f"https://{host}"


def endpoint_for(service_name: str) -> str:
    return f"https://{service_name}.search.windows.net"


def _jwt_claims(token: str) -> dict[str, Any]:
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload))
    except Exception:  # noqa: BLE001 - claims are advisory only
        return {}


def default_subscription() -> str:
    sub = os.environ.get("AZURE_SUBSCRIPTION_ID", "").strip()
    if sub:
        return sub
    profile = Path(os.environ.get("AZURE_CONFIG_DIR") or Path.home() / ".azure") / "azureProfile.json"
    try:
        data = json.loads(profile.read_text(encoding="utf-8-sig"))
        for s in data.get("subscriptions", []):
            if s.get("isDefault"):
                return s["id"]
    except (OSError, ValueError):
        pass
    return ""


class Azure:
    """Entra credential plus resolved tenant/subscription identity."""

    def __init__(self, credential: Any | None = None, http: Any | None = None, say=None):
        import httpx
        self._cred = credential
        self._http = http or httpx.Client(timeout=120.0)
        self._say = say or (lambda msg: print(msg, file=sys.stderr))
        self.identity: dict[str, Any] = {}
        self._tokens: dict[str, Any] = {}
        self._token_lock = threading.Lock()

    def credential(self):
        if self._cred is None:
            from azure.identity import DefaultAzureCredential
            self._cred = DefaultAzureCredential(exclude_interactive_browser_credential=True)
        return self._cred

    def token(self, scope: str) -> str:
        with self._token_lock:
            cached = self._tokens.get(scope)
            expires = getattr(cached, "expires_on", None)
            if isinstance(expires, (int, float)) and expires - TOKEN_REFRESH_MARGIN_S > time.time():
                return cached.token
            fresh = self._fetch_token(scope)
            self._tokens[scope] = fresh
            return fresh.token

    def _fetch_token(self, scope: str) -> Any:
        try:
            return self.credential().get_token(scope)
        except Exception as exc:  # noqa: BLE001
            info = from_exception(exc)
            raise AuthError("NOT_SIGNED_IN", append_summary(f"could not obtain an Entra token: {type(exc).__name__}",
                                                            info),
                            "Sign in with `az login`, then retry.", service_error=info) from exc

    def resolve_identity(self, expected_tenant: str = "", expected_subscription: str = "",
                         need_subscription: bool = True) -> dict[str, Any]:
        """Resolve and print tenant/subscription; abort when they differ from user-confirmed values."""
        claims = _jwt_claims(self.token(ARM_SCOPE))
        ident: dict[str, Any] = {"tenant": claims.get("tid", ""), "principal_id": claims.get("oid", ""),
                                 "principal": claims.get("upn") or claims.get("appid") or "", "subscription": "",
                                 "subscription_name": ""}
        sub = self._subscription_id(expected_subscription) if expected_subscription else (
            default_subscription() if need_subscription else "")
        if sub:
            r = self._arm("GET", f"/subscriptions/{sub}", api="2022-12-01")
            ident["subscription"] = sub
            ident["subscription_name"] = r.get("displayName", "")
            ident["tenant"] = r.get("tenantId") or ident["tenant"]
        elif need_subscription:
            raise AuthError("SUBSCRIPTION_UNRESOLVED", "no subscription resolved",
                            "Pass --subscription <name or ID>. Don't run `az account set`; it changes "
                            "the default for every tool.")
        self._say(f"Tenant: {ident['tenant']}")
        if ident["subscription"]:
            self._say(f"Subscription: {ident['subscription_name']} ({ident['subscription']})")
        if expected_tenant and not self._tenant_matches(expected_tenant, ident["tenant"]):
            raise AuthError("TENANT_MISMATCH", f"you're signed in to {self._tenant_name(ident['tenant'])}, "
                            f"not {expected_tenant}",
                            f"Sign in to {expected_tenant} with `az login --tenant {expected_tenant}`, or leave "
                            "out --tenant to use the tenant you're signed in to.")
        self.identity = ident
        return ident

    def _tenants(self) -> list[dict[str, Any]]:
        return list(self._arm("GET", "/tenants", api="2022-12-01").get("value") or [])

    def _tenant_matches(self, expected: str, tenant_id: str) -> bool:
        """--tenant may be the tenant ID, its name or one of its domains."""
        if expected.casefold() == tenant_id.casefold():
            return True
        if _GUID.match(expected):
            return False
        wanted = expected.casefold()
        return any(str(row.get("tenantId", "")).casefold() == tenant_id.casefold()
                   and wanted in {str(n).casefold() for n in (row.get("displayName"),
                                                              row.get("defaultDomain"),
                                                              *(row.get("domains") or ())) if n}
                   for row in self._tenants())

    def _tenant_name(self, tenant_id: str) -> str:
        try:
            row = next((r for r in self._tenants()
                        if str(r.get("tenantId", "")).casefold() == tenant_id.casefold()), {})
        except GroundingError:
            row = {}
        return str(row.get("displayName") or row.get("defaultDomain") or "another tenant")

    def _subscription_id(self, wanted: str) -> str:
        """--subscription may be the subscription ID or its name."""
        if _GUID.match(wanted):
            return wanted
        rows = self._arm("GET", "/subscriptions", api="2022-12-01").get("value") or []
        found = [r for r in rows if str(r.get("displayName", "")).casefold() == wanted.casefold()]
        if len(found) != 1:
            raise AuthError("SUBSCRIPTION_UNRESOLVED", f"no single subscription named {wanted!r}",
                            "Pass --subscription with the subscription's exact name or ID.")
        return str(found[0]["subscriptionId"])

    def _request(self, method: str, url: str, token: str, body: Any = None,
                 ok: tuple[int, ...] = (200, 201, 202, 204, 207), allow: tuple[int, ...] = ()) -> Any:
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": SKILL_USER_AGENT,
            "x-ms-client-request-id": str(uuid.uuid4()),
        }
        for attempt in range(6):
            headers["x-ms-client-request-id"] = str(uuid.uuid4())
            r = self._http.request(method, url, headers=headers, content=None if body is None else json.dumps(body))
            if r.status_code in RETRY_STATUS and attempt < 5:
                time.sleep(min(30.0, float(r.headers.get("Retry-After", 2 ** attempt))))
                continue
            break
        if r.status_code in allow:
            out = {"_status": r.status_code, **(_json(r) if isinstance(_json(r), dict) else {})}
            if r.status_code >= 400:
                out["_service_error"] = from_response(r)
            return out
        if r.status_code in (401, 403):
            info = from_response(r)
            raise AuthError("FORBIDDEN", append_summary(f"{method} {urlparse(url).path} returned HTTP {r.status_code}",
                                                        info),
                            "Check the Entra roles for this identity (grounding-provision doctor).",
                            service_error=info)
        if r.status_code not in ok:
            info = from_response(r)
            raise ServiceError("SERVICE_HTTP", append_summary(f"{method} {urlparse(url).path} returned HTTP "
                                                              f"{r.status_code}", info),
                               service_error=info)
        return _json(r) if r.content else {}

    # --- ARM -------------------------------------------------------------------------------------------------
    def _arm(self, method: str, path: str, body: Any = None, api: str = RESOURCES_API, allow: tuple[int, ...] = ()) -> Any:
        sep = "&" if "?" in path else "?"
        return self._request(method, f"{ARM}{path}{sep}api-version={api}", self.token(ARM_SCOPE), body, allow=allow)

    def arm(self, method: str, path: str, body: Any = None, api: str = RESOURCES_API, allow: tuple[int, ...] = ()) -> Any:
        return self._arm(method, path, body, api, allow)

    # --- Search data plane ---------------------------------------------------------------------------------
    def search(self, method: str, endpoint: str, path: str, body: Any = None, allow: tuple[int, ...] = ()) -> Any:
        sep = "&" if "?" in path else "?"
        url = f"{validate_endpoint(endpoint)}{path}{sep}api-version={API_VERSION}"
        return self._request(method, url, self.token(SEARCH_SCOPE), body, allow=allow)


def _json(r: Any) -> Any:
    try:
        return r.json()
    except ValueError:
        return {"text": (r.text or "")[:500]}


def role_gaps(permissions: list[dict[str, Any]], roles: list[str]) -> dict[str, bool]:
    """Pure: which of `roles` are satisfied by effective ARM permission blocks."""
    import fnmatch

    def granted(kind: str, needed: str) -> bool:
        for block in permissions:
            allow = block.get(kind, [])
            deny = block.get("not" + kind[0].upper() + kind[1:], [])
            if any(fnmatch.fnmatchcase(needed.lower(), a.lower()) for a in allow) and not any(
                    fnmatch.fnmatchcase(needed.lower(), d.lower()) for d in deny):
                return True
        return False

    return {r: granted(*ROLE_NEEDS[r]) for r in roles}
