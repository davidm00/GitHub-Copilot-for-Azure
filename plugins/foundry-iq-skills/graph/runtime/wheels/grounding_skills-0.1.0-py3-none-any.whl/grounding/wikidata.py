"""Bounded Wikidata bootstrap: resolve seeds, walk statements, emit raw edge rows.

Only the public Wikidata Action API is used (no HTML scraping, no dumps). Wikidata content is CC0.
"""

from __future__ import annotations

import json
import re
import time
from typing import Any, Callable, Iterable

from .errors import GroundingError, ServiceError
from .normalize import WIKIDATA_EDGE_CAP
from .wikidata_properties import EXCLUDED_PROPERTIES, is_noise_label, property_label
from .service_errors import append_summary, describe, from_response

API_URL = "https://www.wikidata.org/w/api.php"
USER_AGENT = "grounding-skills/0.1 (https://github.com/microsoft/azure-skills; bounded seed queries, low rate) httpx"
NAMESPACE = "wikidata:CC0"
EDGE_CONFIDENCE = 0.9
MAX_DEPTH = 2
BATCH = 50
QID_RE = re.compile(r"^Q[1-9][0-9]*$")
KEPT_DATATYPES = {"wikibase-item", "string", "quantity", "time", "monolingualtext"}
LICENSE_NOTICE = "Wikidata content is CC0 (public domain dedication); no attribution or ShareAlike obligation."
DOMAIN_FIT_NOTICE = ("Generic Wikidata edges add noise for private or niche corpora. Use this bootstrap for demos "
                     "or corpora about broadly public topics only.")


def classify_seed(seed: str) -> str:
    return "qid" if QID_RE.match(seed.strip().upper()) else "title"


def validate_bounds(depth: int, edge_cap: int, seeds: list[str]) -> None:
    if not seeds:
        raise GroundingError("WIKIDATA_SEED_REQUIRED", "at least one seed (QID or title) is required",
                             "Full Wikidata dumps are refused; pass --seed.")
    if not 1 <= depth <= MAX_DEPTH:
        raise GroundingError("WIKIDATA_DEPTH_INVALID", f"depth must be 1..{MAX_DEPTH}")
    if not 1 <= edge_cap <= WIKIDATA_EDGE_CAP:
        raise GroundingError("WIKIDATA_CAP_INVALID", f"edge cap must be 1..{WIKIDATA_EDGE_CAP}")


def _time_to_iso(value: dict[str, Any]) -> str | None:
    """Wikidata time like '+2001-09-11T00:00:00Z'; precision below day is not representable reliably."""
    t = str(value.get("time", ""))
    m = re.match(r"^\+?(\d{4})-(\d{2})-(\d{2})T(\d{2}:\d{2}:\d{2})Z$", t)
    if not m or int(value.get("precision", 0)) < 11:
        return None
    y, mo, d, hms = m.groups()
    if mo == "00" or d == "00":
        return None
    return f"{y}-{mo}-{d}T{hms}Z"


def statements_from_entity(entity: dict[str, Any]) -> list[dict[str, Any]]:
    """Pure: convert one wbgetentities entity into statement dicts (no labels resolved yet).

    Each item: {pid, kind: item|string|double|datetime, target_id | value}.
    """
    out = []
    for pid, claims in (entity.get("claims") or {}).items():
        for c in claims:
            if c.get("rank") == "deprecated":
                continue
            snak = c.get("mainsnak") or {}
            if snak.get("snaktype") != "value" or snak.get("datatype") not in KEPT_DATATYPES:
                continue
            dv = (snak.get("datavalue") or {}).get("value")
            dt = snak["datatype"]
            item: dict[str, Any] = {"pid": pid}
            if dt == "wikibase-item" and isinstance(dv, dict) and dv.get("id"):
                item.update(kind="item", target_id=dv["id"])
            elif dt == "string" and isinstance(dv, str) and dv.strip():
                item.update(kind="string", value=dv)
            elif dt == "monolingualtext" and isinstance(dv, dict) and dv.get("language") == "en":
                item.update(kind="string", value=dv.get("text", ""))
            elif dt == "quantity" and isinstance(dv, dict) and "amount" in dv:
                try:
                    item.update(kind="double", value=float(dv["amount"]))
                except ValueError:
                    continue
            elif dt == "time" and isinstance(dv, dict):
                iso = _time_to_iso(dv)
                if iso is None:
                    continue
                item.update(kind="datetime", value=iso)
            else:
                continue
            out.append(item)
    return out


def edge_from_statement(subject_id: str, subject_label: str, st: dict[str, Any], labels: dict[str, str],
                        graph_name: str) -> dict[str, Any]:
    row: dict[str, Any] = {
        "subject": subject_label or subject_id, "subject_id": subject_id,
        "subject_display": subject_label or subject_id, "predicate": st["pid"],
        "confidence": EDGE_CONFIDENCE, "namespace": NAMESPACE, "graph_name": graph_name,
    }
    if st["kind"] == "item":
        tid = st["target_id"]
        lab = labels.get(tid) or tid
        row.update(object=lab, object_id=tid, object_display=lab)
    elif st["kind"] == "string":
        row.update(object=st["value"], object_string=st["value"])
    elif st["kind"] == "double":
        row.update(object=str(st["value"]), object_double=st["value"])
    else:
        row.update(object=st["value"], object_datetime=st["value"])
    return row


def graph_name_for(seed_ids: Iterable[str]) -> str:
    return ("wikidata-" + "-".join(sorted(s.lower() for s in seed_ids)))[:128]


class WikidataClient:
    def __init__(self, http: Any | None = None, min_interval: float = 0.25, sleep: Callable[[float], None] = time.sleep):
        import httpx
        self._http = http or httpx.Client(headers={"User-Agent": USER_AGENT}, timeout=60.0)
        self._min_interval = min_interval
        self._sleep = sleep
        self._last = 0.0
        self.requests = 0

    def _get(self, params: dict[str, Any]) -> dict[str, Any]:
        params = {**params, "format": "json", "maxlag": 5}
        lag_refusals = 0
        for attempt in range(6):
            wait = self._min_interval - (time.monotonic() - self._last)
            if wait > 0:
                self._sleep(wait)
            self._last = time.monotonic()
            self.requests += 1
            r = self._http.get(API_URL, params=params, headers={"User-Agent": USER_AGENT})
            lagged = r.status_code == 200 and r.json().get("error", {}).get("code") == "maxlag"
            if lagged:
                lag_refusals += 1
                if lag_refusals >= 2:
                    # Reads only: a long replication-lag spike should not block a bounded seed read.
                    params.pop("maxlag", None)
            if r.status_code in (429, 503) or lagged:
                self._sleep(min(30.0, float(r.headers.get("Retry-After", 2 ** attempt))))
                continue
            if r.status_code != 200:
                info = from_response(r)
                raise ServiceError("WIKIDATA_HTTP", append_summary(f"Wikidata API returned HTTP {r.status_code}", info),
                                   service_error=info)
            body = r.json()
            if "error" in body:
                info = describe(r.status_code, json.dumps({"error": body["error"]}), getattr(r, "headers", None))
                raise ServiceError("WIKIDATA_ERROR", append_summary(f"Wikidata API error: {body['error'].get('code')}",
                                                                    info),
                                   service_error=info)
            return body
        info = from_response(r)
        raise ServiceError("WIKIDATA_THROTTLED", append_summary("Wikidata API kept throttling; retry later with a "
                                                                "smaller seed", info),
                           service_error=info)

    def resolve_seed(self, seed: str, context_terms: Iterable[str] = ()) -> dict[str, str]:
        s = seed.strip()
        if classify_seed(s) == "qid":
            ents = self.get_entities([s.upper()], props="labels")
            e = ents.get(s.upper(), {})
            if "missing" in e:
                raise GroundingError("WIKIDATA_SEED_NOT_FOUND", f"{s} does not exist in Wikidata")
            return {"id": s.upper(), "label": _label(e) or s.upper(), "input": seed}
        body = self._get({"action": "wbsearchentities", "search": s, "language": "en", "type": "item", "limit": 10})
        hits = body.get("search") or []
        if not hits:
            raise GroundingError("WIKIDATA_SEED_NOT_FOUND", f"no Wikidata item matches title {seed!r}",
                                 "Use a QID, for example Q95 for Google.")
        best = _pick_best_search_hit(hits, s, context_terms)
        return {"id": best["id"], "label": best.get("label") or best["id"], "input": seed}

    def get_entities(self, ids: list[str], props: str) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for i in range(0, len(ids), BATCH):
            body = self._get({"action": "wbgetentities", "ids": "|".join(ids[i:i + BATCH]), "props": props,
                              "languages": "en|mul"})
            out.update(body.get("entities", {}))
        return out

    def labels(self, ids: list[str]) -> dict[str, str]:
        return {k: _label(v) for k, v in self.get_entities(ids, "labels").items() if _label(v)}


def _label(entity: dict[str, Any]) -> str:
    labels = entity.get("labels") or {}
    return (labels.get("en") or labels.get("mul") or {}).get("value", "")


_NOISE_DESCRIPTIONS = (
    "wikimedia disambiguation page",
    "disambiguation page",
    "family name",
    "surname",
    "given name",
    "male given name",
    "female given name",
    "wikimedia category",
    "wikimedia template",
    "wikimedia list article",
)


def _pick_best_search_hit(
    hits: list[dict[str, Any]],
    seed: str,
    context_terms: Iterable[str] = (),
) -> dict[str, Any]:
    seed_cf = seed.strip().casefold()
    ctx = [
        t.strip().casefold()
        for t in context_terms
        if t and t.strip().casefold() != seed_cf and len(t.strip()) >= 3
    ]

    def score(idx_hit: tuple[int, dict[str, Any]]) -> tuple[int, int, int, int, int]:
        idx, h = idx_hit
        label_cf = str(h.get("label") or "").strip().casefold()
        desc_cf = str(h.get("description") or "").strip().casefold()
        is_not_noise = 0 if any(noise in desc_cf for noise in _NOISE_DESCRIPTIONS) else 1
        ctx_match = 1 if any(term in desc_cf or term in label_cf for term in ctx) else 0
        exact_or_prefixed = (
            2
            if label_cf == seed_cf
            else (
                1
                if any(label_cf == f"{term} {seed_cf}" for term in ctx)
                else 0
            )
        )
        has_desc = 1 if desc_cf else 0
        return (is_not_noise, ctx_match, exact_or_prefixed, has_desc, -idx)

    return max(enumerate(hits), key=score)[1]


# People and products first when picking named examples; broad classes and places say little.
EXAMPLE_PROPERTIES = ("P169", "P488", "P112", "P1037", "P355", "P1056", "P1830", "P749", "P127", "P178", "P176")
GENERIC_PROPERTIES = frozenset({"P31", "P279", "P17", "P495", "P159", "P452", "P1454", "P740", "P361", "P527"})


def named_examples(kept: list[tuple[str, dict[str, Any]]], seeds: set[str], labels: dict[str, str],
                   limit: int = 4) -> list[str]:
    """A few named things the seeds point to, such as a CEO or a product, for the approval card."""
    rank = {pid: n for n, pid in enumerate(EXAMPLE_PROPERTIES)}
    picks = sorted(((rank.get(st["pid"], len(rank)), n, labels.get(st["target_id"], ""))
                    for n, (q, st) in enumerate(kept)
                    if q in seeds and st["kind"] == "item" and st["pid"] not in GENERIC_PROPERTIES))
    names = [label for _, _, label in picks if label and not label.startswith("Q")]
    return list(dict.fromkeys(names))[:limit]


def collect_edges(client: WikidataClient, seeds: list[str], depth: int, edge_cap: int
                  ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Walk statements from the seeds. Refuses (never truncates) when raw statements exceed the cap."""
    validate_bounds(depth, edge_cap, seeds)
    context_terms = [s.strip() for s in seeds if classify_seed(s) == "title" and s.strip()]
    resolved = []
    for s in seeds:
        try:
            r = client.resolve_seed(s, context_terms=context_terms)
        except TypeError:
            r = client.resolve_seed(s)
        resolved.append(r)
        if r.get("label") and r["label"] not in context_terms:
            context_terms.append(r["label"])
    graph = graph_name_for(r["id"] for r in resolved)
    seen: set[str] = set()
    frontier = [r["id"] for r in resolved]
    statements: list[tuple[str, dict[str, Any]]] = []
    subject_labels: dict[str, str] = {r["id"]: r["label"] for r in resolved}
    for hop in range(1, depth + 1):
        frontier = [q for q in dict.fromkeys(frontier) if q not in seen]
        seen.update(frontier)
        nxt: list[str] = []
        for qid, ent in client.get_entities(frontier, props="claims|labels").items():
            if "missing" in ent:
                continue
            subject_labels[qid] = _label(ent) or subject_labels.get(qid, qid)
            for st in statements_from_entity(ent):
                statements.append((qid, st))
                if st["kind"] == "item":
                    nxt.append(st["target_id"])
            if len(statements) > edge_cap:
                raise GroundingError(
                    "WIKIDATA_CAP_EXCEEDED",
                    f"seed expands to more than {edge_cap} statements at depth {hop}; refusing",
                    "Use fewer or narrower seeds, or a smaller depth.",
                    detail={"statements_seen": len(statements), "edge_cap": edge_cap, "depth": hop})
        frontier = nxt
    targets = sorted({st["target_id"] for _, st in statements if st["kind"] == "item"} - set(subject_labels))
    labels = {**subject_labels, **client.labels(targets)}
    kept = [(q, st) for q, st in statements if st["pid"] not in EXCLUDED_PROPERTIES
            and not (st["kind"] == "item" and is_noise_label(labels.get(st["target_id"], "")))]
    rows = [edge_from_statement(q, labels.get(q, q), st, labels, graph) for q, st in kept]
    pid_counts: dict[str, int] = {}
    named: set[str] = set()
    for _, st in kept:
        pid_counts[st["pid"]] = pid_counts.get(st["pid"], 0) + 1
        if st["kind"] != "string":
            named.add(st["pid"])
    # Properties whose values are all plain strings are identifiers (catalog IDs, codes): not worth listing.
    top = sorted(((p, c) for p, c in pid_counts.items() if p in named), key=lambda kv: (-kv[1], kv[0]))[:15]
    plabels = {p: property_label(p) for p, _ in top}
    info = {
        "seeds": resolved, "depth": depth, "edge_cap": edge_cap, "graph_name": graph,
        "statements": len(statements), "statements_skipped": len(statements) - len(kept),
        "entities_expanded": len(seen), "api_requests": client.requests,
        "top_properties": [{"pid": p, "label": plabels.get(p, ""), "count": c} for p, c in top],
        "examples": named_examples(kept, {r["id"] for r in resolved}, labels),
        "license": "CC0", "license_notice": LICENSE_NOTICE, "domain_fit_notice": DOMAIN_FIT_NOTICE,
    }
    return rows, info
