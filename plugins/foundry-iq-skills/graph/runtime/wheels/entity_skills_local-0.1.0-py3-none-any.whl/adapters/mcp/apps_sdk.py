"""Optional MCP Apps presentation over the read-only Entity Graph query."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from collections.abc import Mapping
from importlib.resources import files
from pathlib import Path
from typing import Any, Literal

from ekg_consume.service import (
    GraphBudgetExceeded,
    compact_graph_result,
    graph_counts,
    graph_query,
    hydrate_grounding,
    summarize_graph_result,
    topic_graph_options,
)
from ekg_consume.gql import (query_mode as normalize_query_mode, validate_query_text,
                            validate_readonly_gql)
from ekg_core import service_errors
from ekg_core.descriptors import resolve_current
from ekg_core.validation import validate_deployment_descriptor

EXTENSION_ID = "io.modelcontextprotocol/ui"
APP_MIME_TYPE = "text/html;profile=mcp-app"
GRAPH_RESOURCE_URI = "ui://entity-skills/graph.html"
EVIDENCE_RESOURCE_URI = "ui://entity-skills/evidence.html"
RESOURCE_FILES = {
    GRAPH_RESOURCE_URI: "graph.html",
    EVIDENCE_RESOURCE_URI: "evidence.html",
}
PRESENTER_TOOLS = frozenset({"entity_present", "entity_present_evidence"})
SUPPORT_TOOLS = frozenset({"entity_graph_query", "entity_hydrate_grounding", "entity_graph_counts"})
APP_TOOLS = PRESENTER_TOOLS | SUPPORT_TOOLS
_QUERY_FIELDS = frozenset({"query", "depth", "top", "fanout", "detail", "query_mode", "topic_diversity", "chunk_scope"})
_QUERY_LIMITS = {"depth": (1, 3), "top": (1, 10), "fanout": (1, 50)}
_GROUNDING_FIELDS = frozenset({"entities", "edge", "include_relationships"})
_ENTITY_FIELDS = frozenset({"id", "name", "type", "canonical_id"})
_EDGE_FIELDS = frozenset({"source", "predicate", "target", "from_id", "to_id", "id"})
_TOOL_FAILURES = (RuntimeError, ValueError, OSError)


def tool_error(error: BaseException) -> Any:
    """Return an MCP error result that keeps the message and any parsed service error."""
    from mcp.types import CallToolResult, TextContent

    message = str(error) or type(error).__name__
    structured: dict[str, Any] = {"status": "error", "error": message}
    info = service_errors.find(error)
    if info:
        structured["service_error"] = info
    return CallToolResult(content=[TextContent(type="text", text=message)], is_error=True,
                          structured_content=structured)


def _validate_grounding_arguments(arguments: Mapping[str, Any]) -> None:
    if set(arguments) - _GROUNDING_FIELDS:
        raise ValueError("unsupported grounding argument")
    entities = arguments.get("entities")
    edge = arguments.get("edge")
    if not isinstance(entities, list) or len(entities) > 50 or (not entities and edge is None):
        raise ValueError("entities must be a non-empty list of at most 50 items")
    for item in entities:
        if not isinstance(item, Mapping) or set(item) - _ENTITY_FIELDS:
            raise ValueError("each entity must be an object with {id?, name, type?}")
        name = item.get("name")
        if type(name) is not str or not name.strip() or len(name) > 512:
            raise ValueError("each entity requires a non-empty string name")
        for opt_key in ("id", "type", "canonical_id"):
            if opt_key in item and item[opt_key] is not None and (
                type(item[opt_key]) is not str or not item[opt_key].strip()
            ):
                raise ValueError(f"entity.{opt_key} must be a non-empty string")
    if "edge" in arguments and edge is not None:
        if not isinstance(edge, Mapping) or set(edge) - _EDGE_FIELDS:
            raise ValueError("edge must be an object with {source, predicate, target}")
        for req_key in ("source", "predicate", "target"):
            val = edge.get(req_key)
            if type(val) is not str or not val.strip():
                raise ValueError(f"edge.{req_key} must be a non-empty string")
    if "include_relationships" in arguments and type(arguments["include_relationships"]) is not bool:
        raise ValueError("include_relationships must be a boolean")


def validate_raw_arguments(name: str, arguments: Any) -> None:
    if type(name) is not str or name not in APP_TOOLS:
        raise ValueError("unknown Entity Graph Apps operation")
    if not isinstance(arguments, Mapping):
        raise ValueError("arguments must be an object")
    if name == "entity_hydrate_grounding":
        _validate_grounding_arguments(arguments)
        return
    if name == "entity_graph_counts":
        if arguments:
            raise ValueError("entity_graph_counts takes no arguments")
        return
    if set(arguments) - _QUERY_FIELDS:
        raise ValueError("unsupported graph query argument")
    validate_query_text(arguments.get("query"))
    mode = normalize_query_mode(arguments.get("query_mode"))
    if topic_graph_options(arguments.get("topic_diversity", "default")) is not None and mode not in {"kb", "nl2gql"}:
        raise ValueError("topic_diversity applies only to Knowledge Base query modes")
    if arguments.get("chunk_scope") is not None:
        from ekg_consume.chunks import validate_chunk_scope

        validate_chunk_scope(arguments["chunk_scope"])
        if mode != "traverse":
            raise ValueError("chunk_scope cannot be combined with GQL or answer synthesis")
    if mode == "gql":
        validate_readonly_gql(arguments["query"])
    for field, (minimum, maximum) in _QUERY_LIMITS.items():
        value = arguments.get(field, {"depth": 2, "top": 5, "fanout": 20}[field])
        if type(value) is not int or not minimum <= value <= maximum:
            raise ValueError(f"{field} must be an integer in {minimum}..{maximum}")
    if "detail" in arguments and (
        type(arguments["detail"]) is not str
        or arguments["detail"] not in {"compact", "full"}
    ):
        raise ValueError("detail must be compact or full")


NO_PUBLISHED_GRAPH_STEP = (
    "Publish an Entity Graph in this workspace, or start Copilot from a terminal whose "
    "ENTITY_HOME points at the workspace that has one, then try again."
)
NO_TOPIC_GRAPH_STEP = (
    "Publish a Topic Graph in this workspace, or start Copilot from a terminal whose "
    "TOPICGRAPH_HOME points at the workspace that has one, then try again."
)


def _with_step(message: str, step: str) -> str:
    message = message.rstrip()
    if step in message:
        return message
    return f"{message}{'' if message.endswith('.') else '.'} {step}"


def _load_descriptor(path: str | None) -> dict[str, Any]:
    selected = path or os.environ.get("ENTITY_DESCRIPTOR")
    if not selected:
        try:
            selected = str(resolve_current())
        except FileNotFoundError as error:
            raise FileNotFoundError(_with_step(str(error), NO_PUBLISHED_GRAPH_STEP)) from error
    descriptor_path = Path(selected).expanduser()
    if not descriptor_path.is_absolute():
        raise ValueError("descriptor path must be absolute")
    try:
        if descriptor_path.stat().st_size > 1024 * 1024:
            raise ValueError("descriptor exceeds the 1 MiB limit")
        descriptor = json.loads(descriptor_path.read_text(encoding="utf-8"))
    except FileNotFoundError as error:
        raise ValueError(_with_step(
            f"descriptor must be a readable JSON file; {descriptor_path} does not exist",
            NO_PUBLISHED_GRAPH_STEP)) from error
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ValueError("descriptor must be a readable JSON file") from error
    if not isinstance(descriptor, dict):
        raise ValueError("descriptor must be a JSON object")
    errors = validate_deployment_descriptor(descriptor)
    if errors:
        raise ValueError("descriptor is invalid: " + "; ".join(errors))
    return descriptor


def _bound_descriptor(path: str | None) -> dict[str, Any]:
    """Resolve the descriptor for one in-chat call, following the current pointer each time."""
    return _load_descriptor(path)


def _query(descriptor: dict[str, Any], query: str, depth: int, top: int,
           fanout: int, detail: str, query_mode: str | None = "traverse",
           topic_diversity: str = "default",
           chunk_scope: dict[str, Any] | None = None) -> dict[str, Any]:
    if chunk_scope is not None:
        from ekg_consume.chunks import graph_from_chunks

        if normalize_query_mode(query_mode) != "traverse":
            raise ValueError("chunk_scope cannot be combined with GQL or answer synthesis")
        if topic_graph_options(topic_diversity) is not None:
            raise ValueError("topic_diversity applies only to Knowledge Base query modes")
        result = graph_from_chunks(descriptor, query, chunk_scope)
        return compact_graph_result(result) if detail == "compact" else result
    try:
        result = graph_query(descriptor, query, depth=depth, top=top, fanout=fanout,
                             query_mode=normalize_query_mode(query_mode), topic_diversity=topic_diversity)
    except GraphBudgetExceeded as error:
        raise ValueError(
            "graph traversal exceeded its bounded Search request budget; split the question "
            "or lower top/fanout"
        ) from error
    return compact_graph_result(result) if detail == "compact" else result


# Hosts cap one MCP message at a few MiB (the standalone host at 4 MiB, including the App
# document), so a presented result must stay well below that.
PRESENTATION_BUDGET = 1_500_000
_TEXT_CAPS = (None, 1500, 800, 400)
_EDGE_FIELDS_ON_EVIDENCE = ("edgeId", "confidence", "role_confidence")


def _size(value: Any) -> int:
    return len(json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str))


def _passage_view(result: dict[str, Any]) -> dict[str, Any]:
    """Compact form with each distinct source passage once; edge-specific fields stay on the edge."""
    evidence: dict[str, dict[str, Any]] = {}

    def keep(item: Any) -> tuple[str, str, dict[str, Any]] | None:
        if not isinstance(item, dict):
            return None
        source_id = str(item.get("source_id") or item.get("citation_uri") or item.get("source") or "")
        if not source_id:
            return None
        passage = {key: value for key, value in item.items()
                   if key not in _EDGE_FIELDS_ON_EVIDENCE and key != "evidence_id"}
        identity = json.dumps(passage, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        evidence_id = "evidence-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()
        evidence.setdefault(evidence_id, {**passage, "evidence_id": evidence_id})
        return source_id, evidence_id, item

    edges = []
    for edge in result.get("edges") or []:
        if not isinstance(edge, dict):
            continue
        if "evidence_ids" in edge and "provenance" not in edge:
            records = [record for record in result.get("provenance") or []
                       if isinstance(record, dict) and record.get("evidence_id") in set(edge["evidence_ids"])]
        else:
            records = edge.get("provenance") or []
        links = [link for item in records if (link := keep(item))]
        view = {key: value for key, value in edge.items() if key not in ("provenance", "evidence_ids", "source_ids")}
        view["source_ids"] = sorted({source_id for source_id, _, _ in links})
        view["evidence_ids"] = sorted({evidence_id for _, evidence_id, _ in links})
        role = next((item["role_confidence"] for _, _, item in links if item.get("role_confidence") is not None), None)
        if role is not None and "role_confidence" not in view:
            view["role_confidence"] = role
        edges.append(view)
    for item in result.get("provenance") or []:
        keep(item)
    return {**result, "edges": edges, "provenance": list(evidence.values()), "detail": "compact"}


def _cap_texts(result: dict[str, Any], cap: int) -> dict[str, Any]:
    def cut(record: Any) -> Any:
        if isinstance(record, dict) and isinstance(record.get("text"), str) and len(record["text"]) > cap:
            return {**record, "text": record["text"][:cap].rstrip() + " …", "text_truncated": True}
        return record

    edges = [{**edge, "provenance": [cut(item) for item in edge["provenance"]]}
             if isinstance(edge, dict) and isinstance(edge.get("provenance"), list) else edge
             for edge in result.get("edges") or []]
    return {**result, "edges": edges, "provenance": [cut(item) for item in result.get("provenance") or []]}


def fit_presentation(result: dict[str, Any], *, allow_compact: bool = True,
                     budget: int = PRESENTATION_BUDGET) -> dict[str, Any]:
    """Shrink a graph result to the presentation budget, or raise ValueError with a next step."""
    original = _size(result)
    if result.get("detail") == "compact":
        attempts = [(_passage_view(result), cap) for cap in _TEXT_CAPS]
    elif allow_compact:
        grouped = _passage_view(result)
        attempts = [(result, None), *((grouped, cap) for cap in _TEXT_CAPS)]
    else:
        attempts = [(result, cap) for cap in _TEXT_CAPS]
    for candidate, cap in attempts:
        shaped = candidate if cap is None else _cap_texts(candidate, cap)
        if _size(shaped) <= budget:
            notes = []
            if shaped.get("detail") == "compact" and result.get("detail") != "compact":
                notes.append("Full detail was too large to show, so this view groups the evidence "
                             "by passage.")
            if cap is not None:
                notes.append(f"Passage text is shortened to {cap} characters to fit the view; "
                             "use entity-graph-consume for the complete text.")
            if notes:
                shaped = {**shaped, "warnings": [*(shaped.get("warnings") or []), *notes]}
            return shaped
    raise ValueError(
        f"this graph result is too large to show ({original / 1_000_000:.1f} MB); lower top or "
        "fanout, ask a narrower question, or use entity-graph-consume for the full result"
    )


def presentation_summary(result: dict[str, Any]) -> str:
    """Bounded text for the model; the App view reads the structured result."""
    summary = summarize_graph_result(result)
    summary["note"] = ("The view shows the graph and its evidence. Answer from these relationships "
                       "and cite only the files listed here; run entity-graph-consume with "
                       "--detail full for complete detail.")
    return json.dumps(summary, ensure_ascii=False, default=str)


def present(result: dict[str, Any], *, allow_compact: bool = True) -> Any:
    from mcp.types import CallToolResult, TextContent

    shaped = fit_presentation(result, allow_compact=allow_compact)
    return CallToolResult(content=[TextContent(type="text", text=presentation_summary(shaped))],
                          structured_content=shaped)


def _load_html(uri: str) -> str:
    filename = RESOURCE_FILES[uri]
    try:
        root = files("adapters.mcp").joinpath("ui")
        provenance = json.loads(root.joinpath("build-provenance.json").read_bytes())
        expected = provenance["resources"][filename.removesuffix(".html")]
        data = root.joinpath(filename).read_bytes()
        if (len(data) != expected["rawHtmlBytes"]
                or hashlib.sha256(data).hexdigest() != expected["sha256"]):
            raise ValueError("accepted resource hash or size mismatch")
        html = data.decode("utf-8")
        if not html.strip():
            raise ValueError("empty resource")
        return html
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise RuntimeError(
            f"cannot load verified packaged Entity Graph app {filename}; "
            "reinstall a complete entity-skills-local package"
        ) from error


def create_server(*, descriptor_path: str | None = None):
    from mcp.server.apps import (
        Apps,
        ResourceCsp,
        ResourcePermissions,
        client_supports_apps,
    )
    from mcp.server.context import CallNext, HandlerResult, ServerRequestContext
    from mcp.server.mcpserver import MCPServer
    from mcp.shared.exceptions import MCPError
    from mcp.types import ListResourcesResult, ListToolsResult

    descriptor = _load_descriptor(descriptor_path)
    apps = Apps()
    csp = ResourceCsp(
        connect_domains=[],
        resource_domains=[],
        frame_domains=[],
        base_uri_domains=[],
    )
    permissions = ResourcePermissions()
    for uri in RESOURCE_FILES:
        apps.add_html_resource(
            uri,
            _load_html(uri),
            csp=csp,
            permissions=permissions,
        )

    class AppsMiddleware:
        async def __call__(
            self,
            ctx: ServerRequestContext[Any, Any],
            call_next: CallNext,
        ) -> HandlerResult:
            supports_apps = client_supports_apps(ctx)
            if ctx.method == "server/discover" and not supports_apps:
                result = await call_next(ctx)
                if isinstance(result, dict):
                    capabilities = result.get("capabilities")
                    if isinstance(capabilities, dict):
                        capabilities = dict(capabilities)
                        extensions = capabilities.get("extensions")
                        if isinstance(extensions, dict):
                            extensions = dict(extensions)
                            extensions.pop(EXTENSION_ID, None)
                            if extensions:
                                capabilities["extensions"] = extensions
                            else:
                                capabilities.pop("extensions", None)
                        return {**result, "capabilities": capabilities}
                return result

            if not supports_apps:
                if ctx.method == "tools/list":
                    return ListToolsResult(tools=[])
                if ctx.method == "resources/list":
                    return ListResourcesResult(resources=[])
                if ctx.method == "resources/read":
                    params = ctx.params or {}
                    uri = params.get("uri")
                    if type(uri) is str and uri in RESOURCE_FILES:
                        raise MCPError(-32002, "Resource not found")
                if ctx.method == "tools/call":
                    params = ctx.params or {}
                    name = params.get("name")
                    if type(name) is str and name in APP_TOOLS:
                        raise MCPError(-32601, "Tool not found")
                return await call_next(ctx)

            if ctx.method == "tools/call":
                params = ctx.params or {}
                name = params.get("name")
                if type(name) is str and name in APP_TOOLS:
                    arguments = params.get("arguments", {})
                    try:
                        validate_raw_arguments(name, arguments)
                    except ValueError as error:
                        raise MCPError(-32602, str(error)) from error
            return await call_next(ctx)

    def run_graph(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                  detail: Literal["compact", "full"] = "compact",
                  query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                  topic_diversity: Literal["default", "on", "off"] = "default",
                  presenter: bool = True, chunk_scope: dict[str, Any] | None = None) -> Any:
        try:
            return present(_query(descriptor, query, depth, top, fanout, detail, query_mode, topic_diversity,
                                  chunk_scope=chunk_scope),
                           allow_compact=presenter or detail != "full")
        except _TOOL_FAILURES as error:
            return tool_error(error)

    @apps.tool(
        resource_uri=GRAPH_RESOURCE_URI,
        visibility=["model"],
        description="Show a bounded Entity Graph query with source evidence.",
    )
    def entity_present(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                       detail: Literal["compact", "full"] = "compact",
                       query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                       topic_diversity: Literal["default", "on", "off"] = "default",
                       chunk_scope: dict[str, Any] | None = None) -> Any:
        return run_graph(query, depth, top, fanout, detail, query_mode, topic_diversity, chunk_scope=chunk_scope)

    @apps.tool(
        resource_uri=EVIDENCE_RESOURCE_URI,
        visibility=["model"],
        description="Inspect graph relationships and their hydrated source evidence.",
    )
    def entity_present_evidence(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                                detail: Literal["compact", "full"] = "compact",
                                query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                                topic_diversity: Literal["default", "on", "off"] = "default",
                                chunk_scope: dict[str, Any] | None = None) -> Any:
        return run_graph(query, depth, top, fanout, detail, query_mode, topic_diversity, chunk_scope=chunk_scope)

    server = MCPServer(
        name="entity-skills",
        version="0.1.0",
        log_level="WARNING",
        extensions=[apps],
        middleware=[AppsMiddleware()],
    )

    @server.tool(
        name="entity_graph_query",
        description="Read bounded graph and source evidence for the Apps presentation.",
        meta={"ui": {"visibility": ["app"]}},
    )
    def graph_query_read(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                         detail: Literal["compact", "full"] = "full",
                         query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                         topic_diversity: Literal["default", "on", "off"] = "default",
                         chunk_scope: dict[str, Any] | None = None) -> Any:
        return run_graph(query, depth, top, fanout, detail, query_mode, topic_diversity, presenter=False,
                         chunk_scope=chunk_scope)

    @server.tool(
        name="entity_hydrate_grounding",
        description="Hydrate canonical IDs, aliases, properties, and relationships from the grounding index.",
        meta={"ui": {"visibility": ["app"]}},
    )
    def hydrate_grounding_read(
        entities: list[dict[str, Any]],
        edge: dict[str, Any] | None = None,
        include_relationships: bool = False,
    ) -> dict[str, Any]:
        try:
            return hydrate_grounding(
                descriptor,
                entities,
                edge=edge,
                include_relationships=include_relationships,
            )
        except _TOOL_FAILURES as error:
            return tool_error(error)

    @server.tool(
        name="entity_graph_counts",
        description="Read exact class, relationship-type and passage counts for the Apps presentation.",
        meta={"ui": {"visibility": ["app"]}},
    )
    def graph_counts_read() -> dict[str, Any]:
        try:
            return graph_counts(descriptor)
        except _TOOL_FAILURES as error:
            return tool_error(error)

    return server


def create_unified_server(*, descriptor_path: str | None = None):
    """Create the unified `foundry-iq-graph` MCP Apps server exposing both Entity and Topic Graph tools/resources."""
    import sys
    import threading
    from mcp.server.apps import (
        Apps,
        ResourceCsp,
        ResourcePermissions,
        client_supports_apps,
    )
    from mcp.server.context import CallNext, HandlerResult, ServerRequestContext
    from mcp.server.mcpserver import MCPServer
    from mcp.shared.exceptions import MCPError
    from mcp.types import ListResourcesResult, ListToolsResult, ToolAnnotations

    tg_site = os.environ.get("FOUNDRY_IQ_TOPICGRAPH_SITE_PACKAGES")
    if tg_site and tg_site not in sys.path:
        sys.path.append(tg_site)

    from topicgraph_consume.config import build_service, resolve_config
    from topicgraph_core.contracts import ContractError
    from topicgraph_mcp import apps as tg_apps
    from topicgraph_mcp import mcp as tg_mcp

    if descriptor_path or os.environ.get("ENTITY_DESCRIPTOR"):
        _load_descriptor(descriptor_path)
    apps = Apps()
    csp = ResourceCsp(
        connect_domains=[],
        resource_domains=[],
        frame_domains=[],
        base_uri_domains=[],
    )
    permissions = ResourcePermissions()
    for uri in RESOURCE_FILES:
        apps.add_html_resource(
            uri,
            _load_html(uri),
            csp=csp,
            permissions=permissions,
        )
    tg_loaded = tg_apps.load_assets()
    for uri, (filename, title) in tg_apps.RESOURCES.items():
        apps.add_html_resource(
            uri=uri,
            html=tg_loaded[filename],
            name=title,
            csp=csp,
            permissions=permissions,
            prefers_border=True,
        )

    all_resources = set(RESOURCE_FILES) | set(tg_apps.RESOURCES)
    all_tools = APP_TOOLS | set(tg_mcp.ARGUMENTS)

    class UnifiedAppsMiddleware:
        async def __call__(
            self,
            ctx: ServerRequestContext[Any, Any],
            call_next: CallNext,
        ) -> HandlerResult:
            supports_apps = client_supports_apps(ctx)
            if ctx.method == "server/discover" and not supports_apps:
                result = await call_next(ctx)
                if isinstance(result, dict):
                    capabilities = result.get("capabilities")
                    if isinstance(capabilities, dict):
                        capabilities = dict(capabilities)
                        extensions = capabilities.get("extensions")
                        if isinstance(extensions, dict):
                            extensions = dict(extensions)
                            extensions.pop(EXTENSION_ID, None)
                            if extensions:
                                capabilities["extensions"] = extensions
                            else:
                                capabilities.pop("extensions", None)
                        return {**result, "capabilities": capabilities}
                return result

            if not supports_apps:
                if ctx.method == "tools/list":
                    return ListToolsResult(tools=[])
                if ctx.method == "resources/list":
                    return ListResourcesResult(resources=[])
                if ctx.method == "resources/read":
                    params = ctx.params or {}
                    uri = params.get("uri")
                    if type(uri) is str and uri in all_resources:
                        raise MCPError(-32002, "Resource not found")
                if ctx.method == "tools/call":
                    params = ctx.params or {}
                    name = params.get("name")
                    if type(name) is str and name in all_tools:
                        raise MCPError(-32601, "Tool not found")
                return await call_next(ctx)

            if ctx.method == "tools/call":
                params = ctx.params or {}
                name = params.get("name")
                if type(name) is str and name in APP_TOOLS:
                    arguments = params.get("arguments", {})
                    try:
                        validate_raw_arguments(name, arguments)
                    except ValueError as error:
                        raise MCPError(-32602, str(error)) from error
                elif type(name) is str and name in tg_mcp.ARGUMENTS:
                    arguments = params.get("arguments", {})
                    try:
                        tg_mcp._validate_arguments(name, arguments)
                    except ContractError as exc:
                        raise MCPError(-32602, str(exc)) from exc
            return await call_next(ctx)

    def run_graph(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                  detail: Literal["compact", "full"] = "compact",
                  query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                  topic_diversity: Literal["default", "on", "off"] = "default",
                  presenter: bool = True, chunk_scope: dict[str, Any] | None = None) -> Any:
        try:
            return present(_query(_bound_descriptor(descriptor_path), query, depth, top, fanout, detail,
                                  query_mode, topic_diversity, chunk_scope=chunk_scope),
                           allow_compact=presenter or detail != "full")
        except _TOOL_FAILURES as error:
            return tool_error(error)

    @apps.tool(
        resource_uri=GRAPH_RESOURCE_URI,
        visibility=["model"],
        description="Show a bounded Entity Graph query with source evidence.",
    )
    def entity_present(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                       detail: Literal["compact", "full"] = "compact",
                       query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                       topic_diversity: Literal["default", "on", "off"] = "default",
                       chunk_scope: dict[str, Any] | None = None) -> Any:
        return run_graph(query, depth, top, fanout, detail, query_mode, topic_diversity, chunk_scope=chunk_scope)

    @apps.tool(
        resource_uri=EVIDENCE_RESOURCE_URI,
        visibility=["model"],
        description="Inspect graph relationships and their hydrated source evidence.",
    )
    def entity_present_evidence(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                                detail: Literal["compact", "full"] = "compact",
                                query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                                topic_diversity: Literal["default", "on", "off"] = "default",
                                chunk_scope: dict[str, Any] | None = None) -> Any:
        return run_graph(query, depth, top, fanout, detail, query_mode, topic_diversity, chunk_scope=chunk_scope)

    read_only = ToolAnnotations(readOnlyHint=True)
    app_only = {"ui": {"visibility": ["app"]}}
    bound_tg_service = None
    tg_lock = threading.Lock()

    def get_tg_service():
        nonlocal bound_tg_service
        with tg_lock:
            if bound_tg_service is None:
                bound_tg_service = build_service(resolve_config(argparse.Namespace()))
            return bound_tg_service

    def invoke_tg(name: str, arguments: dict[str, Any]) -> Any:
        try:
            service = get_tg_service()
        except (ContractError, ImportError, *_TOOL_FAILURES) as error:
            unavailable = RuntimeError(_with_step(
                f"No Topic Graph is available in this session: {error}", NO_TOPIC_GRAPH_STEP))
            unavailable.__cause__ = error
            return tool_error(unavailable)
        return tg_mcp._sdk_result(tg_mcp._dispatch(service, name, arguments))

    @apps.tool(resource_uri="ui://topicgraph/explorer.html", visibility=["model"],
               name="topicgraph_explore", description="Present a Topic Graph topic explorer.",
               annotations=read_only)
    def topicgraph_explore(level: int | None = None, page_size: int | None = 100,
                           cursor: str | None = None) -> Any:
        return invoke_tg("topicgraph_explore", {"level": level, "page_size": page_size, "cursor": cursor})

    @apps.tool(resource_uri="ui://topicgraph/evidence.html", visibility=["model"],
               name="topicgraph_evidence", description="Present Topic Graph chunk evidence.",
               annotations=read_only)
    def topicgraph_evidence(chunk_id: str) -> Any:
        return invoke_tg("topicgraph_evidence", {"chunk_id": chunk_id})

    @apps.tool(resource_uri="ui://topicgraph/sitemap.html", visibility=["model"],
               name="topicgraph_sitemap",
               description="Present the Topic Graph sitemap: the named topic hierarchy as a table of contents "
                           "with each topic's share of clustered passages.",
               annotations=read_only)
    def topicgraph_sitemap(topic_id: str | None = None, depth: int | None = None,
                           max_nodes: int | None = 500) -> Any:
        return invoke_tg("topicgraph_sitemap", {"topic_id": topic_id, "depth": depth, "max_nodes": max_nodes})

    server = MCPServer(
        name="foundry-iq-graph",
        version="0.1.0",
        log_level="WARNING",
        extensions=[apps],
        middleware=[UnifiedAppsMiddleware()],
    )

    @server.tool(
        name="entity_graph_query",
        description="Read bounded graph and source evidence for the Apps presentation.",
        meta=app_only,
    )
    def graph_query_read(query: str, depth: int = 2, top: int = 5, fanout: int = 20,
                         detail: Literal["compact", "full"] = "full",
                         query_mode: Literal["traverse", "nl2gql", "gql", "kb"] | None = "traverse",
                         topic_diversity: Literal["default", "on", "off"] = "default",
                         chunk_scope: dict[str, Any] | None = None) -> Any:
        return run_graph(query, depth, top, fanout, detail, query_mode, topic_diversity, presenter=False,
                         chunk_scope=chunk_scope)

    @server.tool(
        name="entity_hydrate_grounding",
        description="Hydrate canonical IDs, aliases, properties, and relationships from the grounding index.",
        meta=app_only,
    )
    def hydrate_grounding_read(
        entities: list[dict[str, Any]],
        edge: dict[str, Any] | None = None,
        include_relationships: bool = False,
    ) -> dict[str, Any]:
        try:
            return hydrate_grounding(
                _bound_descriptor(descriptor_path),
                entities,
                edge=edge,
                include_relationships=include_relationships,
            )
        except _TOOL_FAILURES as error:
            return tool_error(error)

    @server.tool(
        name="entity_graph_counts",
        description="Read exact class, relationship-type and passage counts for the Apps presentation.",
        meta=app_only,
    )
    def graph_counts_read() -> dict[str, Any]:
        try:
            return graph_counts(_bound_descriptor(descriptor_path))
        except _TOOL_FAILURES as error:
            return tool_error(error)

    @server.tool(name="topicgraph_status", description="Return verified status for the server-bound Topic Graph generation.",
                 annotations=read_only, meta=app_only)
    def topicgraph_status() -> Any:
        return invoke_tg("topicgraph_status", {})

    @server.tool(name="topicgraph_list_topics",
                 description="List a bounded page of topics at one hierarchy level.",
                 annotations=read_only, meta=app_only)
    def topicgraph_list_topics(level: int | None = None, page_size: int | None = 100,
                               cursor: str | None = None) -> Any:
        return invoke_tg("topicgraph_list_topics", {"level": level, "page_size": page_size, "cursor": cursor})

    @server.tool(name="topicgraph_get_topic", description="Get one topic and a bounded page of its subtopics.",
                 annotations=read_only, meta=app_only)
    def topicgraph_get_topic(topic_id: str, children_page_size: int | None = 1000,
                             children_cursor: str | None = None) -> Any:
        return invoke_tg("topicgraph_get_topic", {
            "topic_id": topic_id,
            "children_page_size": children_page_size,
            "children_cursor": children_cursor,
        })

    @server.tool(name="topicgraph_get_sitemap",
                 description="Get the bounded topic hierarchy with coverage, breadth-first.",
                 annotations=read_only, meta=app_only)
    def topicgraph_get_sitemap(topic_id: str | None = None, depth: int | None = None,
                               max_nodes: int | None = 500) -> Any:
        return invoke_tg("topicgraph_get_sitemap", {"topic_id": topic_id, "depth": depth, "max_nodes": max_nodes})

    @server.tool(name="topicgraph_get_chunk", description="Get chunk evidence by chunk ID.",
                 annotations=read_only, meta=app_only)
    def topicgraph_get_chunk(chunk_id: str) -> Any:
        return invoke_tg("topicgraph_get_chunk", {"chunk_id": chunk_id})

    @server.tool(name="topicgraph_app_list_members",
                 description="List topic members in stable order without model calls.",
                 annotations=read_only, meta=app_only)
    def topicgraph_app_list_members(topic_id: str, page_size: int | None = 100,
                                    cursor: str | None = None) -> Any:
        return invoke_tg("topicgraph_app_list_members", {
            "topic_id": topic_id,
            "page_size": page_size,
            "cursor": cursor,
        })

    @server.tool(name="topicgraph_nearest_chunks",
                 description="Select the top N chunks by the topic centroid, independent of its member count.",
                 annotations=read_only, meta=app_only)
    def topicgraph_nearest_chunks(topic_id: str, top: int | None = 100) -> Any:
        return invoke_tg("topicgraph_nearest_chunks", {"topic_id": topic_id, "top": top})

    return server


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="entity-apps")
    parser.add_argument(
        "--descriptor",
        default=os.environ.get("ENTITY_DESCRIPTOR"),
        help="operator-selected absolute published descriptor (default: ENTITY_DESCRIPTOR/current)",
    )
    args = parser.parse_args(argv)
    try:
        server = create_server(descriptor_path=args.descriptor)
    except ModuleNotFoundError as error:
        if error.name and error.name.split('.')[0] == 'mcp':
            parser.exit(1, f'Apps support is missing: {error}. Run the supplied distribution\'s '
                        '`python -I "<plugin-root>/graph/runtime/bootstrap.py" setup entity`; '
                        'for source development, install the apps extra into your explicit local venv.\n')
        raise
    except (FileNotFoundError, ValueError, RuntimeError) as error:
        parser.error(str(error))
    server.run()


def main_unified(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="foundry-iq-graph")
    parser.add_argument(
        "--descriptor",
        default=os.environ.get("ENTITY_DESCRIPTOR"),
        help="operator-selected absolute published descriptor (default: ENTITY_DESCRIPTOR/current)",
    )
    args = parser.parse_args(argv)
    try:
        server = create_unified_server(descriptor_path=args.descriptor)
    except ModuleNotFoundError as error:
        if error.name and error.name.split('.')[0] == 'mcp':
            parser.exit(1, f'Apps support is missing: {error}. Run the supplied distribution\'s '
                        '`python -I "<plugin-root>/graph/runtime/bootstrap.py" setup entity`; '
                        'for source development, install the apps extra into your explicit local venv.\n')
        raise
    except (FileNotFoundError, ValueError, RuntimeError) as error:
        parser.error(str(error))
    server.run()


if __name__ == "__main__":
    main()
