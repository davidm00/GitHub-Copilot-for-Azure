from urllib.parse import quote, unquote
from ekg_core.models import BuildSpec, stable_id
from ekg_core.ontology import load_ontology

from .managed_pipeline import (
    generated, inline_ontology_matches, knowledge_base, knowledge_source, ontology_deferred,
    search_api_version, uses_direct_blob_source,
)
from .executor import (
    BuildError, PartialIngestion, _identity_readback_matches, _read_attempt_journal, _source_record,
    _sync_status, hash_json, index_names, plan, source_provenance,
    _raise_incomplete, staging_prefix,
)

def _coverage_fields(executor, spec, name, resources, indexes) -> dict:
    from . import grounding_report
    return grounding_report.attach({}, grounding_report.measure(
        executor.adapter, spec, name, resources["graphIndex"], indexes["graph"]))


def _verify_source_journal(executor, spec):
        if spec.source_manifest is not None:
            source_spec = spec
            if spec.ontology_attached_to is not None:
                # The source journal stays the deferred build's; attach journals separately.
                from .attach import deferred_spec
                source_spec = deferred_spec(spec)
            record, _ = _read_attempt_journal(source_spec)
            expected = _source_record(source_spec, "attempt_requested")
            if any(record.get(key) != expected[key] for key in (
                "version", "run_id", "plan_id", "scope", "generation",
                "knowledge_source", "create_request_hash",
            )) or record.get("state") not in {
                "attempt_requested", "indexing", "synchronizing", "failed", "verified",
            } or (source_spec is not spec and record.get("state") != "verified"):
                raise BuildError("source journal differs from approved run identity")
            executor._source_targets(spec)
            if source_spec is not spec:
                from .attach import attached_record
                attached = attached_record(spec)
                if attached is None:
                    raise BuildError("attach-ontology has not published this generation; "
                                     "run `entity-graph-build attach-ontology` first")
                # The attach replaced the deferred definition, so its request and the
                # ETag observed at graph verification are the receipt to check.
                return {**record, "create_request_hash": attached["attach_request_hash"],
                        "create_receipt": attached["verified_receipt"]}
            return record
        return None
def _verify_managed(executor, spec, names, record):
        ontology = load_ontology(
            spec.ontology_mode, path=spec.ontology_path,
            schema_org_profile=spec.schema_org_profile,
            schema_org_version=spec.schema_org_version,
            resolve_imports=spec.resolve_imports,
        )
        deferred = ontology_deferred(spec)
        if ontology is None and not deferred:
            raise BuildError("managed graph requires an ontology")
        name = names["knowledge_source"]
        live = executor.adapter.get_knowledge_source(name)
        if not live or live.get("name") != name or live.get("kind") != "azureBlob":
            raise BuildError("managed Knowledge Source is missing or incompatible")
        binding = live.get("azureBlobParameters")
        graph = binding.get("graphExtraction") if isinstance(binding, dict) else None
        if not isinstance(graph, dict) or graph.get("graphName") != name:
            raise BuildError("managed Knowledge Source graph/ontology binding differs")
        if not inline_ontology_matches(graph.get("ontology"), ontology):
            raise BuildError("managed Knowledge Source graph/ontology binding differs")
        if live.get("description") != spec.source_description:
            raise BuildError("managed Knowledge Source description differs")
        if spec.grounding_index and (((graph.get("grounding") or {}).get("index") or {}).get(
                "indexName") != spec.grounding_index):
            raise BuildError("managed Knowledge Source grounding index differs")
        resources = generated(live, require_graph=not deferred)
        for key, kind in (("datasource", "datasources"),
                          ("skillset", "skillsets"),
                          ("indexer", "indexers")):
            resource = executor.adapter.get_resource(kind, resources[key])
            if not resource or resource.get("name") != resources[key]:
                raise BuildError(f"managed generated {key} is missing")
        indexes = {"content": executor.adapter.get_index(resources["index"])}
        if not deferred:
            indexes["graph"] = executor.adapter.get_index(resources["graphIndex"])
        if any(value is None for value in indexes.values()):
            raise BuildError("managed Knowledge Source generated indexes are missing")
        content = indexes["content"] or {}
        content_fields = {
            item.get("name"): item for item in content.get("fields", [])
            if isinstance(item, dict)
        }
        if not content.get("vectorSearch") or not {
            "uid", "snippet", "snippet_vector", "snippet_parent_id", "blob_url"
        }.issubset(content_fields):
            raise BuildError("managed content schema lacks required retrieval fields")
        vector_field = content_fields["snippet_vector"]
        if (vector_field.get("type") != "Collection(Edm.Single)" or
                vector_field.get("dimensions") != spec.embedding_dimensions):
            raise BuildError("managed content vector dimensions differ from the configured model")
        if not deferred and (indexes["graph"] or {}).get("graphProfile", {}).get("kind") != "edgeList":
            raise BuildError("managed graph index lacks an edge-list graph profile")
        from .ingestion import load_acceptance
        acceptance = load_acceptance(spec)
        accepted_missing = set(acceptance["missing_sources"]) if acceptance else set()
        _sync_status(executor.adapter.knowledge_source_status(name),
                     acceptance["failed_count"] if acceptance else 0) or (
            _raise_incomplete()
        )
        counts = {"content": executor.adapter.count(resources["index"])}
        if not deferred:
            counts["graph"] = executor.adapter.count(resources["graphIndex"])
        direct_blob = uses_direct_blob_source(spec)
        source_count = spec.source_manifest.document_count
        if direct_blob:
            if counts["content"] < 1:
                raise BuildError("managed content or graph index has insufficient documents")
        else:
            expected_count = source_count - len(accepted_missing)
            if counts["content"] < expected_count:
                raise PartialIngestion(
                    source_count - counts["content"],
                    f"managed content index has insufficient documents: {counts['content']} "
                    f"chunk(s) for {source_count} source document(s)")
        if counts.get("graph", 1) == 0:
            raise BuildError("managed content or graph index has insufficient documents")
        evidence_sample = None
        if ontology is not None and ontology.edge_types:
            for domain, predicate, range_name in ontology.edge_types:
                gql = (f"MATCH (s:`{domain}`)-[r:`{predicate}`]->"
                       f"(o:`{range_name}`) RETURN r LIMIT 1")
                result = executor.adapter.graph_search(resources["graphIndex"], gql)
                diagnostics = result.get("@search.graphDiagnostics") or []
                if any(item.get("severity") == "error" for item in diagnostics):
                    raise BuildError("native graph probe returned an error diagnostic")
                for row in result["value"]:
                    proof = row.get("@search.graphProvenance") or {}
                    if any(isinstance(item, dict) and item.get("chunkId")
                           for item in proof.get("evidence") or []):
                        evidence_sample = proof["evidence"]
                        break
                if evidence_sample is not None:
                    break
            if evidence_sample is None:
                raise BuildError("managed graph has no ontology edge with source provenance")
        facts = None
        if ontology is not None and ontology.edge_types and not deferred:
            from .trial import EDGE_LIMIT, fact_counts, fact_rows
            facts = {**fact_counts(ontology, fact_rows(executor.adapter, resources["graphIndex"], ontology)),
                     "edge_limit": EDGE_LIMIT}
        source_drift = None
        if spec.source_manifest is not None:
            mapping = source_provenance(spec)
            binding = live.get("azureBlobParameters") or {}
            expected_definition = knowledge_source(
                spec, name=name,
                graph_name=name, prefix=staging_prefix(spec), ontology=ontology,
            )
            expected_binding = expected_definition["azureBlobParameters"]
            expected_identity = expected_binding["ingestionParameters"].get("identity")
            observed_ingestion = binding.get("ingestionParameters")
            if not isinstance(observed_ingestion, dict):
                raise BuildError("SOURCE_MAPPING_UNVERIFIED: managed staging destination differs")
            identities = [(observed_ingestion.get("identity"), expected_identity)]
            for model_name in ("embeddingModel", "chatCompletionModel"):
                model = observed_ingestion.get(model_name)
                expected_model = expected_binding["ingestionParameters"][model_name]
                parameters = model.get("azureOpenAIParameters") if isinstance(model, dict) else None
                expected_parameters = expected_model["azureOpenAIParameters"]
                if (not isinstance(model, dict) or model.get("kind") != expected_model["kind"]
                        or not isinstance(parameters, dict)
                        or any(parameters.get(key) != expected_parameters[key]
                               for key in ("resourceUri", "deploymentId", "modelName"))):
                    raise BuildError("SOURCE_MAPPING_UNVERIFIED: managed model binding differs")
                identities.append((parameters.get("authIdentity"),
                                   expected_parameters.get("authIdentity")))
            if any(binding.get(key) != expected_binding[key] for key in (
                "containerName", "folderPath",
            )) or any(not _identity_readback_matches(observed, approved)
                      for observed, approved in identities):
                raise BuildError("SOURCE_MAPPING_UNVERIFIED: managed staging destination differs")
            expected_ingestion = expected_binding["ingestionParameters"]
            if ((observed_ingestion.get("contentExtractionMode") or "minimal")
                    != expected_ingestion["contentExtractionMode"]
                    or (observed_ingestion.get("aiServices") or {}).get("uri")
                    != (expected_ingestion.get("aiServices") or {}).get("uri")):
                raise BuildError(
                    "SOURCE_MAPPING_UNVERIFIED: managed content extraction binding differs")
            receipt = record.get("create_receipt")
            if (record.get("create_request_hash") != hash_json(expected_definition)
                    or not isinstance(receipt, dict)
                    or set(receipt) != {"name", "kind", "etag"}
                    or receipt.get("name") != name or receipt.get("kind") != "azureBlob"
                    or not isinstance(receipt.get("etag"), str) or not receipt["etag"].strip()
                    or live.get("@odata.etag") != receipt["etag"]):
                raise BuildError("SOURCE_MAPPING_UNVERIFIED: exact create receipt or live ETag is missing")
            observed_connection = binding.get("connectionString")
            if (observed_connection != expected_binding["connectionString"]
                    and (not isinstance(observed_connection, str)
                         or observed_connection.casefold() != "<redacted>")):
                raise BuildError("SOURCE_MAPPING_UNVERIFIED: managed staging destination differs")
            if not callable(getattr(executor.adapter, "search_page", None)):
                raise BuildError("SOURCE_PAGINATION_REQUIRED: exhaustive readback is unavailable")
            seen_urls: set[str] = set()
            seen_chunks: set[str] = set()
            offset = 0
            prefix_base = (
                f"{spec.source.reference}/{quote(spec.source.container, safe='')}/"
                if direct_blob and spec.source else ""
            )
            expected_prefix_uri = (
                f"{prefix_base}{quote(spec.source.prefix, safe='/')}"
                if direct_blob and spec.source else ""
            )
            while offset < counts["content"]:
                size = min(1000, counts["content"] - offset)
                documents = executor.adapter.search_page(resources["index"], skip=offset, top=size)
                if (not isinstance(documents, list) or not documents
                        or len(documents) > size):
                    raise BuildError("SOURCE_MAPPING_UNVERIFIED: generated content page is incomplete")
                for document in documents:
                    if not isinstance(document, dict):
                        raise BuildError("SOURCE_MAPPING_UNVERIFIED: generated chunk is malformed")
                    url, uid = document.get("blob_url"), document.get("uid")
                    url_ok = (
                        isinstance(url, str) and url.startswith(expected_prefix_uri)
                        and url != expected_prefix_uri
                        if direct_blob else
                        isinstance(url, str) and url in mapping
                    )
                    if not url_ok or not isinstance(uid, str) or not uid or uid in seen_chunks:
                        raise BuildError("SOURCE_MAPPING_UNVERIFIED: chunk lacks an exact staged URI or ID")
                    seen_urls.add(url)
                    seen_chunks.add(uid)
                offset += len(documents)
            if not direct_blob:
                unmatched = set(mapping) - seen_urls - accepted_missing
                if unmatched:
                    raise PartialIngestion(
                        len(unmatched),
                        f"SOURCE_MAPPING_UNVERIFIED: {len(unmatched)} original source(s) produced no "
                        "chunks; they failed ingestion")
            if direct_blob:
                if not seen_urls or any(
                    not isinstance(item, dict) or item.get("chunkId") not in seen_chunks
                    for item in (evidence_sample or [])
                ):
                    raise BuildError("SOURCE_MAPPING_UNVERIFIED: original sources or graph chunks are unmatched")
                if seen_urls != set(mapping):
                    effective_mapping: dict[str, dict[str, str]] = {}
                    for url in sorted(seen_urls):
                        if url in mapping:
                            effective_mapping[url] = mapping[url]
                        else:
                            blob_name = unquote(url.removeprefix(prefix_base))
                            effective_mapping[url] = {
                                "source_id": stable_id("blob", {"source": spec.source.source_id, "name": blob_name}),
                                "original_uri": url,
                                "citation_uri": url,
                                "version_or_hash": "live:indexer_verified",
                            }
                    if spec.trial is None:
                        source_drift = {
                            "approved_documents": len(mapping),
                            "indexed_documents": len(seen_urls),
                            "added_uris": sorted(seen_urls - set(mapping)),
                            "removed_uris": sorted(set(mapping) - seen_urls),
                        }
                    mapping = effective_mapping
            elif any(
                not isinstance(item, dict) or item.get("chunkId") not in seen_chunks
                for item in (evidence_sample or [])
            ):
                raise BuildError("SOURCE_MAPPING_UNVERIFIED: original sources or graph chunks are unmatched")
        kb_name = names.get("knowledge_base")
        if kb_name:
            live_kb = executor.adapter.get_knowledge_base(kb_name)
            expected_kb = knowledge_base(
                spec, name=kb_name, knowledge_source_name=name,
            )
            if not isinstance(live_kb, dict) or live_kb.get("name") != kb_name:
                raise BuildError("managed Knowledge Base is missing or incompatible")
            observed_sources = (
                [{k: v for k, v in item.items() if v is not None} if isinstance(item, dict) else item
                 for item in live_kb.get("knowledgeSources")]
                if isinstance(live_kb.get("knowledgeSources"), list) else None
            )
            if observed_sources != expected_kb["knowledgeSources"]:
                raise BuildError("managed Knowledge Base Knowledge Source binding differs")
            if (live_kb.get("outputMode") != expected_kb["outputMode"]
                    or live_kb.get("answerInstructions") != expected_kb["answerInstructions"]
                    or live_kb.get("retrievalReasoningEffort") != expected_kb["retrievalReasoningEffort"]
                    or live_kb.get("retrievalInstructions") != expected_kb["retrievalInstructions"]):
                raise BuildError("managed Knowledge Base retrieval configuration differs")
            observed_models = live_kb.get("models")
            expected_model = expected_kb["models"][0]
            expected_params = expected_model["azureOpenAIParameters"]
            observed_model = (observed_models[0] if isinstance(observed_models, list)
                              and len(observed_models) == 1 else None)
            observed_params = (observed_model.get("azureOpenAIParameters")
                               if isinstance(observed_model, dict) else None)
            if (not isinstance(observed_model, dict)
                    or observed_model.get("kind") != expected_model["kind"]
                    or not isinstance(observed_params, dict)
                    or observed_params.get("apiKey") is not None
                    or any(observed_params.get(key) != expected_params[key]
                           for key in ("resourceUri", "deploymentId", "modelName"))
                    or not _identity_readback_matches(
                        observed_params.get("authIdentity"), expected_params.get("authIdentity"))):
                raise BuildError("managed Knowledge Base model or identity binding differs")
        return {"status": "verified", "counts": counts, "indexes": indexes,
                "created_resources": resources, "knowledge_source": name,
                **({"knowledge_base": kb_name} if kb_name else {}),
                "graph_provenance_sample_count": len(evidence_sample or []),
                **({"facts": facts} if facts else {}),
                **({} if deferred else _coverage_fields(executor, spec, name, resources, indexes)),
                **({"ontology_deferred": True} if deferred else {}),
                **({"source_drift": source_drift} if source_drift else {}),
                **({"source_provenance": mapping, "manifest_digest": spec.source_manifest.digest}
                   if spec.source_manifest else {})}

def verify(executor, spec: BuildSpec) -> dict:
        desired = plan(spec)
        blockers = desired.blocked_by
        if blockers:
            raise BuildError("; ".join(blockers))
        if spec.source_manifest is None:
            raise BuildError("SOURCE_MANIFEST_REQUIRED: verification needs the build's --source-manifest")
        if (getattr(executor.adapter, "search_api_version", search_api_version(spec))
                != search_api_version(spec)):
            raise BuildError(f"managed graph requires Search {search_api_version(spec)}")
        record = _verify_source_journal(executor, spec)
        names = index_names(spec)
        return _verify_managed(executor, spec, names, record)
