from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any
from urllib.parse import quote

from ekg_core import service_errors
from ekg_core.execution import ApplyResult, ApprovalRequired
from ekg_core.models import BuildSpec, SourceKind, stable_id
from ekg_core.ontology import load_ontology
from ekg_core.telemetry import service_window_event

from .adapters import DataPlane, SearchRequestError
from .document_types import staged_suffix
from .managed_pipeline import knowledge_source, ontology_deferred, uses_direct_blob_source
from .planner import plan
from .preflight import ResourceReader, blob_soft_delete, preflight
from .blob_sources import BlobReader
from .local_sources import approved_local_bytes, approved_local_sample
from .target_validation import graph_input_error, search_resource_id
from ekg_core.files import LockHeld, atomic_write_bytes, exclusive_lock


class BuildError(RuntimeError):
    pass


class PartialIngestion(BuildError):
    """Some documents did not ingest; the user must investigate or explicitly accept them."""

    def __init__(self, failed: int, message: str | None = None) -> None:
        super().__init__(message or (
            f"managed synchronization reported failed items: {failed} document(s) did not "
            "ingest"))
        self.failed = failed


PARTIAL_NEXT_ACTION = (
    "Some documents did not ingest, so the build is paused, not finished. Run "
    "`entity-graph-build failures` with the same flags, show the user the failed documents and "
    "errors, then ask them to choose: (A) investigate and fix the failures, or (B) accept exactly "
    "those documents with `entity-graph-build accept-failures --acceptance-id <id>` and continue "
    "with the next step. When `failures` shows a retry ID, also offer (C) one retry with "
    "`entity-graph-build retry-failures --retry-id <id>`. Never stop without offering every choice."
)


def _verify_managed_target(spec: BuildSpec, adapter: DataPlane) -> dict[str, Any]:
    reason = graph_input_error(spec)
    if reason:
        raise BuildError(reason)
    resource_id = search_resource_id(spec)
    observed = adapter.inspect_search_service(resource_id, spec.tenant_id)
    if not isinstance(observed, dict):
        raise BuildError("Search service GET failed; no writes permitted")
    properties = observed.get("properties")
    sku = observed.get("sku")
    if not isinstance(properties, dict) or not isinstance(sku, dict):
        raise BuildError("Search service metadata is malformed; no writes permitted")
    name = resource_id.rsplit("/", 1)[-1]
    if (
        str(observed.get("id", "")).casefold() != resource_id.casefold()
        or str(observed.get("name", "")).casefold() != name.casefold()
        or str(observed.get("location", "")).replace(" ", "").casefold() !=
            str(spec.target.location or "").casefold()
        or not isinstance(sku.get("name"), str)
        or sku["name"].casefold() != spec.search_sku.casefold()
        or str(properties.get("provisioningState", "")).casefold() != "succeeded"
        or properties.get("endpoint") != spec.target.search_endpoint
    ):
        raise BuildError("exact Search service identity, region, SKU or endpoint differs; no writes permitted")
    return {"status": "target_verified",
            "evidence_origin": "fresh_arm_service_identity",
            "resource_id": resource_id, "region": observed["location"], "sku": sku["name"],
            "tenant_id": spec.tenant_id}


def _failure_detail(error: Exception) -> dict[str, Any]:
    detail: dict[str, Any] = {"error_type": type(error).__name__}
    info = service_errors.find(error)
    if isinstance(error, BuildError):
        detail["error_message"] = str(error)
    elif isinstance(error, SearchRequestError):
        detail["error_message"] = (
            f"Search request failed: {service_errors.summary(info)}" if info
            else f"Search request failed with HTTP {error.status}")
    elif info:
        detail["error_message"] = service_errors.with_summary("Service request failed", info)
    if info:
        detail["service_error"] = info
    return detail


def generation(spec: BuildSpec) -> str:
    if spec.ontology_attached_to is not None:
        # An attached ontology completes the deferred build in place, under its names.
        return spec.ontology_attached_to
    if spec.source_manifest is None:
        raise ValueError("SOURCE_MANIFEST_REQUIRED: inventory the source and pass --source-manifest")
    ontology = load_ontology(
        spec.ontology_mode, path=spec.ontology_path,
        schema_org_profile=spec.schema_org_profile,
        schema_org_version=spec.schema_org_version,
        resolve_imports=spec.resolve_imports,
    )
    spec_dict = {k: v for k, v in asdict(spec).items()
                 if k not in ("readers", "ontology_attached_to", "source_description")
                 and not (k in ("trial", "grounding_index", "kb_chat_deployment", "kb_chat_model", "run_prefix") and v is None)}
    for target_opt in (
        "cache_storage_resource_id", "embedding_openai_endpoint", "embedding_openai_resource_id",
        "chat_openai_endpoint", "chat_openai_resource_id", "kb_openai_endpoint", "kb_openai_resource_id",
    ):
        if getattr(spec.target, target_opt, None) is None:
            spec_dict["target"].pop(target_opt, None)
    return stable_id("entity", {
        "spec": {**spec_dict, "source_manifest": spec.source_manifest.digest},
        "ontology_schema_id": ontology.schema_id if ontology else None,
    })[-16:]


def staging_prefix(spec: BuildSpec) -> str:
    """Blob folder the generation's documents are staged under; trials stay apart."""
    folder = f"{spec.run_prefix}-entity-{generation(spec)}" if spec.run_prefix else generation(spec)
    return f"trial/{folder}" if spec.trial is not None else folder


def index_names(spec: BuildSpec) -> dict[str, str]:
    suffix = generation(spec)
    source = f"{spec.run_prefix}-entity-{suffix}" if spec.run_prefix else f"entity-managed-{suffix}"
    base = f"{spec.run_prefix}-kb-{suffix}" if spec.run_prefix else f"entity-kb-{suffix}"
    # A deferred-ontology source has no graph to serve yet; attach-ontology creates the KB.
    kb = ({"knowledge_base": base}
          if spec.trial is None and not ontology_deferred(spec) else {})
    return {"knowledge_source": source, **kb}


def source_provenance(spec: BuildSpec, prefix: str | None = None) -> dict[str, dict[str, str]]:
    """Deterministic one-to-one source or staging identity."""
    manifest = spec.source_manifest
    if uses_direct_blob_source(spec):
        if manifest is None or spec.source is None or not spec.source.reference:
            raise BuildError("approved source manifest and destination are required")
        result = {}
        for item in manifest.items:
            url = item.original_uri
            if url in result:
                raise BuildError("SOURCE_MAPPING_AMBIGUOUS: duplicate blob URI in manifest")
            result[url] = {
                "source_id": item.source_id, "original_uri": item.original_uri,
                "citation_uri": item.citation_uri, "version_or_hash": item.version_or_hash,
            }
        return result
    if manifest is None or not spec.target.storage_endpoint:
        raise BuildError("approved source manifest and destination are required")
    prefix = prefix or staging_prefix(spec)
    result = {}
    for item in manifest.items:
        suffix = staged_suffix(item.media_type)
        name = f"{prefix}/{item.source_id}{suffix}"
        url = (f"{spec.target.storage_endpoint}/{quote(spec.storage_container, safe='')}/"
               f"{quote(name, safe='/')}")
        if url in result:
            raise BuildError("SOURCE_MAPPING_AMBIGUOUS: duplicate staging destination")
        result[url] = {
            "source_id": item.source_id, "original_uri": item.original_uri,
            "citation_uri": item.citation_uri, "version_or_hash": item.version_or_hash,
        }
    return result


def _source_bytes(spec: BuildSpec, reader: BlobReader | None) -> tuple[bytes, ...]:
    manifest = spec.source_manifest
    if manifest is None or spec.source is None:
        raise BuildError("SOURCE_MANIFEST_REQUIRED: inventory source before approval")
    if spec.source.kind in {SourceKind.LOCAL_PATH, SourceKind.ZIP_ARCHIVE}:
        if spec.trial is not None:
            return tuple(value.content for value in approved_local_sample(
                manifest, spec.trial.corpus_digest))
        return tuple(value.content for value in approved_local_bytes(manifest, manifest.digest))
    if spec.source.kind is SourceKind.BLOB_PREFIX:
        return ()
    raise BuildError("UNSUPPORTED_GRAPH_ROUTE: source kind cannot be staged")


def _source_record(spec: BuildSpec, state: str) -> dict[str, Any]:
    desired = plan(spec)
    names = index_names(spec)
    definition = knowledge_source(
        spec, name=names["knowledge_source"],
        graph_name=names["knowledge_source"], prefix=staging_prefix(spec),
    )
    return {
        "version": 2, "run_id": f"build-{generation(spec)}", "plan_id": desired.plan_id,
        "scope": desired.scope, "generation": generation(spec),
        "knowledge_source": names["knowledge_source"],
        "create_request_hash": hash_json(definition), "create_receipt": None,
        "state": state,
        "counts": {}, "timings_ms": {}, "readers": list(spec.readers),
    }


def _create_source_journal(spec: BuildSpec) -> bytes:
    if not spec.build_journal:
        raise BuildError("source graph requires a durable build journal")
    path = Path(spec.build_journal)
    if spec.source and spec.source.kind in {SourceKind.LOCAL_PATH, SourceKind.ZIP_ARCHIVE}:
        source_path = Path(spec.source.reference).resolve()
        if path.resolve() == source_path or (
            source_path.is_dir() and path.resolve().is_relative_to(source_path)
        ):
            raise BuildError("build journal must be outside the caller-owned source")
    return _journal(spec, _source_record(spec, "attempt_requested"))


def _advance_source_journal(spec: BuildSpec, original: bytes, **changes: Any) -> bytes:
    path = Path(spec.build_journal or "")
    record = json.loads(original)
    if any(key in changes for key in (
        "scope", "plan_id", "generation", "run_id", "create_request_hash",
    )):
        raise BuildError("immutable journal identity cannot be changed")
    updated = json.dumps({**record, **changes}, sort_keys=True).encode("utf-8")
    # The compare and the replace happen under one lock, so a concurrent run cannot slip in between.
    try:
        with exclusive_lock(path.with_name(path.name + ".lock"), wait=5):
            if path.read_bytes() != original:
                raise BuildError("build journal changed during the run")
            atomic_write_bytes(path, updated, durable=True)
    except LockHeld:
        raise BuildError("another run is updating this build journal; wait for it to finish") from None
    return updated


def hash_json(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return f"sha256:{hashlib.sha256(raw).hexdigest()}"


def _identity_readback_matches(observed: Any, expected: dict[str, str] | None) -> bool:
    if expected is None:
        return observed is None or observed == {
            "@odata.type": "#Microsoft.Azure.Search.DataNoneIdentity",
        }
    if not isinstance(observed, dict):
        return False
    return observed == expected or observed == {
        **expected, "federatedIdentityClientId": None,
    }


def _journal(spec: BuildSpec, record: dict[str, Any]) -> bytes:
    if not spec.build_journal:
        raise BuildError("managed builds require a journal")
    path = Path(spec.build_journal)
    original = json.dumps(record, sort_keys=True).encode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(original)
        stream.flush()
        os.fsync(stream.fileno())
    return original


def _read_attempt_journal(spec: BuildSpec) -> tuple[dict[str, Any], bytes]:
    path = Path(spec.build_journal or "")
    if not path.is_file():
        raise BuildError("managed build attempt journal is missing")
    original = path.read_bytes()
    try:
        record = json.loads(original)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise BuildError("managed build attempt journal is malformed") from error
    if not isinstance(record, dict):
        raise BuildError("managed build attempt journal is malformed")
    return record, original


def _state_text(item: dict[str, Any]) -> str:
    parts = [item.get("errorMessage"), item.get("message"), item.get("details")]
    for key in ("errors", "itemErrors", "warnings"):
        for entry in item.get(key) or []:
            if isinstance(entry, dict):
                parts.extend([entry.get("errorMessage"), entry.get("message"), entry.get("details")])
            else:
                parts.append(entry)
    return " ".join(str(part) for part in parts if part).casefold()


def _indexer_time_quota_checkpoint(item: dict[str, Any]) -> bool:
    status = str(
        item.get("status") or item.get("synchronizationStatus") or item.get("state") or ""
    ).lower()
    text = _state_text(item)
    return (
        status == "transientfailure"
        and "indexer execution time quota" in text
        and "120 minutes" in text
    )


def _sync_checkpoint(status: dict[str, Any]) -> dict[str, Any] | None:
    current = status.get("currentSynchronizationState") or {}
    last = status.get("lastSynchronizationState") or {}
    for item in (current, last):
        if isinstance(item, dict) and _indexer_time_quota_checkpoint(item):
            return item
    return None


def _count_value(value: Any) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) and value > 0 else 0


def failed_items(item: dict[str, Any]) -> int:
    """Documents a synchronization state or indexer run reports as failed."""
    if not isinstance(item, dict):
        return 0
    return max(_count_value(item.get("itemsUpdatesFailed")), _count_value(item.get("itemsFailed")),
               len(item.get("errors") or ()), len(item.get("itemErrors") or ()))


def _sync_running(item: dict[str, Any]) -> bool:
    return bool(item) and (not item.get("endTime") or str(
        item.get("status") or item.get("synchronizationStatus") or item.get("state") or ""
    ).lower() in {"running", "inprogress"})


def _sync_status(status: dict[str, Any], accepted_failed: int = 0) -> dict[str, Any] | None:
    """Finished state, None while running; failed documents beyond ``accepted_failed`` raise."""
    state = status.get("lastSynchronizationState") or {}
    current = status.get("currentSynchronizationState") or {}
    if not isinstance(state, dict) or not isinstance(current, dict):
        raise BuildError("managed synchronization status is malformed")
    for item in (state, current):
        if _indexer_time_quota_checkpoint(item):
            continue
        failed = failed_items(item)
        if failed:
            # Judge failed documents only once the run has finished.
            if _sync_running(item):
                continue
            if failed > accepted_failed:
                raise PartialIngestion(failed)
            continue
        status_name = str(
            item.get("status") or item.get("synchronizationStatus") or item.get("state") or ""
        ).lower()
        if status_name in {
            "failed", "failure", "error", "partialsuccess",
            "transientfailure", "persistentfailure", "cancelled", "canceled",
        }:
            raise BuildError("managed synchronization failed")
    if current and (
        not current.get("endTime") or
        str(current.get("status") or current.get("synchronizationStatus")
            or current.get("state") or "").lower() in {"running", "inprogress"}
        or _indexer_time_quota_checkpoint(current)
    ):
        return None
    if state.get("endTime"):
        if _indexer_time_quota_checkpoint(state):
            return None
        terminal = str(
            state.get("status") or state.get("synchronizationStatus")
            or state.get("state") or ""
        ).lower()
        if terminal and terminal not in {"success", "succeeded", "completed", "complete"} \
                and not 0 < failed_items(state) <= accepted_failed:
            raise BuildError("managed synchronization ended without a success status")
        return state
    return None


def _synchronization_event(state: dict[str, Any]) -> dict[str, Any] | None:
    """Service-side managed synchronization window from Knowledge Source status."""
    if not isinstance(state, dict):
        return None
    counts = {key: value for key, value in (
        ("items_processed", state.get("itemsUpdatesProcessed")),
        ("items_failed", state.get("itemsUpdatesFailed")),
        ("items_skipped", state.get("itemsSkipped")),
    ) if isinstance(value, int) and not isinstance(value, bool)}
    return service_window_event(
        "build", "managed_synchronization", state.get("startTime"), state.get("endTime"),
        origin="live_knowledge_source_status", counts=counts,
    )


def _merge_telemetry(prior: list[Any], new: list[dict[str, Any]]) -> list[Any]:
    """Append new events, replacing an earlier service window for the same synchronization."""
    windows = {(event.get("operation"), event.get("started_at")) for event in new
               if isinstance(event, dict) and event.get("origin") == "live_knowledge_source_status"}
    kept = [event for event in prior if not (
        isinstance(event, dict) and (event.get("operation"), event.get("started_at")) in windows)]
    return [*kept, *new]



class BuildExecutor:
    def __init__(self, adapter: DataPlane, *,
                 blob_reader: BlobReader | None = None,
                 target_reader: ResourceReader | None = None,
                 upload_concurrency: int = 16) -> None:
        self.adapter = adapter
        self.blob_reader = blob_reader
        self.target_reader = target_reader
        self.upload_concurrency = upload_concurrency

    def _source_targets(self, spec: BuildSpec) -> dict[str, Any]:
        if self.target_reader is None or not hasattr(self.target_reader, "inspect_resource"):
            raise BuildError("TARGET_VERIFICATION_REQUIRED: exact Search, Storage and OpenAI ARM reader required")
        inspected = preflight(spec, self.target_reader, arm=self.adapter)
        if inspected.status == "blocked":
            raise BuildError("; ".join(inspected.events[0].data["blockers"]))
        evidence = inspected.events[0].data["evidence"]
        if not all(evidence.get(key) is True for key in (
            "search_arm_observed", "storage_arm_observed", "openai_arm_observed",
        )):
            raise BuildError("TARGET_VERIFICATION_REQUIRED: all exact target identities must be observed")
        warnings = inspected.events[0].data.get("warnings")
        return {**_verify_managed_target(spec, self.adapter),
                **({"warnings": warnings} if warnings else {})}

    def inspect(self, spec: BuildSpec) -> dict[str, Any]:
        desired = plan(spec)
        if desired.blocked_by:
            return preflight(spec).to_dict()
        soft_delete = blob_soft_delete(self.adapter, spec)
        return {"plan_id": desired.plan_id,
                **_verify_managed_target(spec, self.adapter),
                **({"warnings": [soft_delete[1]]} if soft_delete and soft_delete[1] else {})}

    def apply(self, spec: BuildSpec, *, approved_plan_id: str,
              approved: bool = False, wait_for_sync: bool = True) -> ApplyResult:
        desired = plan(spec)
        if desired.blocked_by:
            raise BuildError("; ".join(desired.blocked_by))
        if approved_plan_id != desired.plan_id or not approved:
            raise ApprovalRequired(f"explicit approval of plan {desired.plan_id} is required")
        if spec.vector_retrieval and not spec.embedding_deployment:
            raise BuildError("vector builds require an embedding deployment")
        return self._apply_source(spec, wait_for_sync=wait_for_sync)

    def progress(self, spec: BuildSpec) -> dict[str, Any]:
        from .wait_progress import progress
        return progress(self, spec)

    def reconcile(self, spec: BuildSpec) -> dict[str, Any]:
        from .reconcile import reconcile
        return reconcile(self, spec)

    def _apply_source(self, spec: BuildSpec, *, wait_for_sync: bool = True) -> ApplyResult:
        from .staging import _apply_source
        return _apply_source(self, spec, wait_for_sync=wait_for_sync)

    def verify(self, spec: BuildSpec) -> dict[str, Any]:
        from .verify_publish import verify
        return verify(self, spec)


def _raise_incomplete() -> None:
    raise BuildError("managed synchronization is incomplete")
