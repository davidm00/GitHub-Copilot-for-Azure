import json
import sys
import time
from pathlib import Path

from ekg_core.models import BuildSpec

from .executor import (BuildError, PARTIAL_NEXT_ACTION, PartialIngestion, _sync_checkpoint,
                       _sync_status, index_names)

def _indexer_run(executor, name: str) -> tuple[str | None, dict]:
        """The generated indexer and its newest run (never its scheduled top-level status)."""
        from .managed_pipeline import generated
        from .update import latest_run
        adapter = executor.adapter
        if not callable(getattr(adapter, "indexer_status", None)):
            return None, {}
        try:
            live = adapter.get_knowledge_source(name)
            indexer = generated(live, require_graph=False)["indexer"] if isinstance(live, dict) else None
        except (ValueError, KeyError, TypeError):
            return None, {}
        if not indexer:
            return None, {}
        return indexer, latest_run(adapter.indexer_status(indexer))


def _indexer_failure(indexer: str | None, run: dict) -> str | None:
        """The indexer's last run, when it failed outright (e.g. identity errors)."""
        from .ingestion import _text
        if not indexer or str(run.get("status") or "").lower() not in ("error", "transientfailure"):
            return None
        message = _text(run.get("errorMessage")) or "the indexer run failed without a message"
        return f"Indexer {indexer} failed: {message}"


def _minutes(seconds: float) -> str:
    return f"{seconds / 60:.0f} min"


def _documents(state: dict) -> str:
    done, total = state.get("items_processed"), state.get("document_count")
    if done is None:
        return "no documents reported yet"
    return f"{done}/{total} documents" if total else f"{done} documents"


def wait_for_sync(executor, spec: BuildSpec, *, timeout_minutes: float, poll_seconds: float = 30,
                  sleep=time.sleep, clock=time.monotonic) -> dict:
    """Wait inside one command until managed synchronization finishes, fails or times out.

    Prints a line when the state changes and at least once a minute while indexing runs, so
    nobody needs a shell polling loop. Returns the last progress read when synchronized or
    partial (verify then reports those); raises SYNC_FAILED or, on timeout, SYNC_IN_PROGRESS.
    """
    from ekg_core.cli import Blocked
    from .update import RETRY_BACKOFF_SECONDS, SyncRetry
    started = clock()
    shown, shown_at = None, None
    retry, retried = SyncRetry(executor.adapter, None, _retry_note(spec)), None
    while True:
        state = progress(executor, spec)
        status, elapsed = state["status"], clock() - started
        if status == "retry_requested":
            run = state["indexer_run"]
            if run.get("startTime") != retried:
                retry.indexer = state["indexer"]
                if not retry(run):
                    raise retry.exhausted(run, "`entity-graph-build verify` with the same flags; "
                                               "it runs the indexer again")
                retried = run.get("startTime")
                sleep(RETRY_BACKOFF_SECONDS)
                continue
            status = "synchronizing"  # the rerun was requested and has not started yet
        if status in ("synchronized", "partial"):
            if shown is not None:
                _say(f"Indexing finished: {_documents(state)} ({_minutes(elapsed)}).")
            return state
        if status == "failed":
            raise Blocked("SYNC_FAILED", state["error"] or "synchronization failed",
                          result=state, advice=state["next_action"])
        if elapsed >= timeout_minutes * 60:
            raise Blocked("SYNC_IN_PROGRESS",
                          f"still indexing after {_minutes(elapsed)}: {_documents(state)}",
                          result=state)
        key = (status, state.get("items_processed"))
        if key != shown or clock() - shown_at >= 60:
            _say(("Indexing paused at the 120-minute checkpoint; the next scheduled run "
                  "continues it" if status == "continuing" else "Still indexing")
                 + f": {_documents(state)} ({_minutes(elapsed)}).")
            shown, shown_at = key, clock()
        sleep(poll_seconds)


def _say(line: str) -> None:
    print(line, file=sys.stderr, flush=True)


def _retry_note(spec: BuildSpec):
    """Journal each indexer rerun next to the build journal."""
    if not spec.build_journal:
        return None
    path = Path(spec.build_journal).with_name(f"{index_names(spec)['knowledge_source']}.sync-retries.json")

    def note(entry: dict, run: dict) -> None:
        entries = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else []
        path.write_text(json.dumps(entries + [entry], indent=2), encoding="utf-8")
    return note


def progress(executor, spec: BuildSpec) -> dict:
        """Read live managed synchronization progress; performs no writes."""
        from .ingestion import accepted_failed
        return knowledge_source_progress(
            executor, index_names(spec)["knowledge_source"], accepted_failed(spec),
            spec.source_manifest.document_count if spec.source_manifest else None)


def knowledge_source_progress(executor, name: str, accepted: int, documents: int | None) -> dict:
        """Progress of one named Knowledge Source; `executor` needs only `.adapter`."""
        status = executor.adapter.knowledge_source_status(name)
        current = status.get("currentSynchronizationState") or {}
        last = status.get("lastSynchronizationState") or {}
        error = None
        partial = False
        try:
            finished = _sync_status(status, accepted) is not None
        except PartialIngestion as failure:
            finished, error, partial = False, str(failure), True
        except BuildError as failure:
            finished, error = False, str(failure)
        checkpoint = _sync_checkpoint(status)
        from .update import needs_retry
        indexer, run = (None, {}) if (finished or partial or checkpoint) else _indexer_run(executor, name)
        # Search ended the run asking for another one; the Knowledge Source can still read
        # "synchronizing" because the indexer then idles until its daily schedule.
        retry = bool(indexer) and needs_retry(run)
        indexer_failed = None if (retry or error) else _indexer_failure(indexer, run)
        error = None if retry else error or indexer_failed
        state = current if current else last
        status_name = "partial" if partial else "retry_requested" if retry else "failed" if error else (
            "synchronized" if finished else "continuing" if checkpoint else "synchronizing")
        extra = {"indexer": indexer, "indexer_run": {key: run.get(key) for key in (
            "status", "startTime", "endTime", "errorMessage", "itemsProcessed", "itemsFailed")}} if retry else {}
        return {
            "phase": "build.progress", "knowledge_source": name,
            "status": status_name,
            "items_processed": state.get("itemsUpdatesProcessed"),
            "items_failed": state.get("itemsUpdatesFailed"),
            "document_count": documents,
            "started_at": state.get("startTime"), "finished_at": last.get("endTime"),
            "error": error, "evidence_origin": "live_knowledge_source_status", **extra,
            "next_action": (
                "Search asked for a retry (a normal, expected state, not a failure). A running "
                "`verify` or `attach-ontology` reruns the indexer itself; if none is running, run "
                "the same `verify` or `attach-ontology` command again." if retry else
                PARTIAL_NEXT_ACTION if partial else
                "Reconcile this exact attempt read-only before publish." if finished else
                ("The indexer could not start. For a managed-identity error, check the Search "
                 "identity and its roles (`entity-graph-provision connect`), then run the indexer "
                 "once; do not re-run plan or apply." if indexer_failed else
                 "Do not retry writes; run `entity-graph-build failures` and reconcile read-only.")
                if error else
                "Indexer reached the normal 120-minute checkpoint; the next scheduled run continues it." if checkpoint else
                "Synchronization is still running; check again later or reconcile when finished."
            ),
        }
