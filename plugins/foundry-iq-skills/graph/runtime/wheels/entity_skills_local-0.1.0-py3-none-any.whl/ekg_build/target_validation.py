from __future__ import annotations

import re
from dataclasses import replace

from ekg_core.models import BuildSpec
from ekg_core.search_models import SEARCH_MODEL_NAMES, SEARCH_MODEL_SOURCES

# Bound into plan identities; the admitted names themselves live in ekg_core.search_models.
GRAPH_MODEL_POLICY_VERSION = "search-model-name-2026-10-16"


def new_build_spec(spec: BuildSpec) -> BuildSpec:
    """Bind concrete defaults when constructing a new extraction plan.

    Reconciling an existing plan must not call this constructor, so its identity
    stays exact. Explicit settings remain unchanged.
    """
    if not spec.chat_model:
        # Incomplete plans remain blocked by the existing explicit-model prerequisite.
        return spec
    if spec.extraction_parallelism is None:
        from .managed_pipeline import DEFAULT_EXTRACTION_PARALLELISM

        spec = replace(spec, extraction_parallelism=DEFAULT_EXTRACTION_PARALLELISM)
    return spec


def graph_model_error(spec: BuildSpec) -> str | None:
    from .managed_pipeline import search_api_version

    version = search_api_version(spec)
    # AzureOpenAIParameters.modelName is the API-versioned AzureOpenAIModelName enum.
    admitted = (SEARCH_MODEL_NAMES.get(version) or {}).get("chat", frozenset())
    source = SEARCH_MODEL_SOURCES.get(version, "no published modelName list for this API")
    for label, model in (("chat", spec.chat_model), ("KB chat", spec.kb_chat_model)):
        if model and model not in admitted:
            return (f"GRAPH_MODEL_UNSUPPORTED: {label} model {model!r} is not admitted by "
                    f"Search API {version} (AzureOpenAIParameters.modelName; source: "
                    f"{source}). Pick a deployment whose model Search admits from "
                    "`entity-graph-provision discover`, then create a new plan.")
    return None


_SEARCH_ARM_ID = re.compile(
    r"^/subscriptions/([0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})"
    r"/resourceGroups/([a-zA-Z0-9_.()\-]{1,90})/providers/Microsoft\.Search/searchServices/([a-z0-9][a-z0-9-]{0,58}[a-z0-9])$",
    re.IGNORECASE,
)


def search_resource_id(spec: BuildSpec) -> str:
    target = spec.target
    endpoint = target.search_endpoint or ""
    match = re.fullmatch(
        r"https://([a-z0-9][a-z0-9-]{0,58}[a-z0-9])\.search\.windows\.net",
        endpoint,
    )
    sub_id = target.subscription_id
    rg = target.resource_group
    if match and (not sub_id or not rg) and target.search_resource_id:
        arm_match = _SEARCH_ARM_ID.fullmatch(target.search_resource_id)
        if arm_match and arm_match.group(3).lower() == match.group(1).lower():
            sub_id = sub_id or arm_match.group(1)
            rg = rg or arm_match.group(2)
    if (
        not match
        or not isinstance(sub_id, str)
        or not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", sub_id)
        or not isinstance(rg, str)
        or not re.fullmatch(r"[a-zA-Z0-9_.()\-]{1,90}", rg)
    ):
        raise ValueError("managed graph requires an exact Search service endpoint, subscription and RG")
    return (
        f"/subscriptions/{sub_id}/resourceGroups/{rg}"
        f"/providers/Microsoft.Search/searchServices/{match.group(1)}"
    )


def graph_input_error(spec: BuildSpec) -> str | None:
    try:
        search_resource_id(spec)
    except ValueError:
        return "GRAPH_TARGET_INVALID: exact Search endpoint, subscription and resource group are required"
    if not isinstance(spec.tenant_id, str) or not re.fullmatch(
        r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", spec.tenant_id
    ):
        return "TENANT_REQUIRED: explicit tenant_id is required for fresh identity verification"
    if not isinstance(spec.search_sku, str) or not spec.search_sku.strip():
        return "SEARCH_SKU_REQUIRED: explicit Search SKU is required"
    if not isinstance(spec.target.location, str) or not spec.target.location.strip():
        return "SEARCH_REGION_REQUIRED: explicit Search region is required"
    return None
