from __future__ import annotations

from dataclasses import asdict

from ekg_core import grounding
from ekg_core.models import BuildSpec, Operation, Plan, OntologyMode, SourceKind, stable_id
from ekg_core.ontology import load_ontology
from .estimates import plan_estimates
from .preflight import route, scope, target_blockers
from .target_validation import GRAPH_MODEL_POLICY_VERSION, graph_input_error, graph_model_error
from .managed_pipeline import (content_understanding_error, search_api_version,
                               ontology_deferred, uses_content_understanding,
                               uses_direct_blob_source)


def plan(spec: BuildSpec) -> Plan:
    if spec.ontology_mode is OntologyMode.OWL_FILE and not spec.ontology_path:
        raise ValueError("owl_file mode requires ontology_path")
    decision = route(spec)
    ontology = load_ontology(
        spec.ontology_mode,
        path=spec.ontology_path,
        schema_org_profile=spec.schema_org_profile,
        schema_org_version=spec.schema_org_version,
        resolve_imports=spec.resolve_imports,
    )
    deferred = ontology_deferred(spec)
    direct_blob = uses_direct_blob_source(spec)
    operations = []
    if not direct_blob:
        operations.append(
            Operation(
                id="stage-corpus", plane="build", action="synchronize",
                resource="blob_corpus", name=spec.source.source_id if spec.source else "source",
                risk="data_upload", reversible=True, requires_approval=True,
                evidence=("source_count", "uploaded_count"),
            ),
        )
    operations.extend([
        Operation(
            id="create-managed-knowledge-source", plane="build", action="create",
            resource="knowledge_source", name="managed-blob",
            risk="remote_mutation", reversible=True, requires_approval=True,
            evidence=("knowledge_source_id", "created_resources"),
        ),
        *(
            [Operation(
                id="create-managed-knowledge-base", plane="build", action="create",
                resource="knowledge_base", name="managed-kb",
                risk="remote_mutation", reversible=True, requires_approval=True,
                evidence=("knowledge_base_id",),
            )] if spec.trial is None and not deferred else []
        ),
        Operation(
            id="verify-managed-synchronization", plane="build", action="verify",
            resource="knowledge_source", name="managed-blob",
            risk="read_only", evidence=("document_count", "graph_document_count",
                                          "serving_state"),
        ),
    ])
    if spec.readers:
        operations.append(Operation(
            id="grant-readers", plane="build", action="grant", resource="role_assignment",
            name=f"{len(spec.readers)} reader(s)", risk="remote_mutation", reversible=True,
            requires_approval=True, evidence=("granted", "missing"),
        ))
    if decision.capability != "verified_path":
        operations = [Operation(
            id="preflight-source-route", plane="build", action="inspect",
            resource="source_route", name=spec.source.source_id if spec.source else "source",
            evidence=("source_kind", "requested_outcome", "knowledge_source_kind",
                      "manifest_digest"),
        )]
    if deferred:
        warnings = ("Ontology deferred: chunks, vectors and the enrichment cache are built now; "
                    "no relationships are extracted until `entity-graph-build attach-ontology` runs.",)
    else:
        warnings = ()
    blockers = list(decision.blocked_by)
    blockers.extend(target_blockers(spec))
    if spec.source_manifest and not spec.source_manifest.items:
        blockers.append("EMPTY_MANIFEST: source manifest has no eligible documents")
    if spec.source_manifest and decision.capability == "verified_path":
        has_storage_id = bool(
            spec.target.storage_resource_id
            or (direct_blob and spec.source is not None and spec.source.resource_id)
        )
        has_openai_id = bool(
            spec.target.openai_resource_id
            or (
                spec.target.effective_embedding_openai_resource_id
                and spec.target.effective_chat_openai_resource_id
            )
        )
        if not all((spec.target.search_resource_id, has_storage_id, has_openai_id)):
            blockers.append("TARGET_ID_REQUIRED: source graph builds need exact Search, Storage and OpenAI ARM IDs")
        if spec.source_manifest.transform_config_id != "identity" or any(
            item.transform_id is not None or item.transform_version is not None
            or item.materialized_blob_path is not None
            for item in spec.source_manifest.items
        ):
            blockers.append("SOURCE_TRANSFORM_UNSUPPORTED: only original identity bytes may be staged")
        if spec.source.kind not in {SourceKind.LOCAL_PATH, SourceKind.ZIP_ARCHIVE,
                                    SourceKind.BLOB_PREFIX}:
            blockers.append("UNSUPPORTED_GRAPH_ROUTE: source kind cannot be staged")
        if (not direct_blob
                and spec.source.kind is SourceKind.BLOB_PREFIX
                and spec.source.resource_id.casefold() ==
                    (spec.target.storage_resource_id or "").casefold()
                and spec.source.container == spec.storage_container):
            from .executor import staging_prefix
            if staging_prefix(spec).startswith(spec.source.prefix):
                blockers.append("SOURCE_DESTINATION_OVERLAP: staging would write inside the caller-owned prefix")
    if spec.readers and not (spec.source_manifest and spec.target.search_resource_id):
        blockers.append("READERS_UNSUPPORTED: reader grants need a managed source build "
                        "with --search-resource-id")
    if spec.trial is not None and not ontology:
        blockers.append("TRIAL_NEEDS_ONTOLOGY: a trial build measures graph extraction; "
                        "choose --ontology owl_file or schema_org")
    blockers.extend(grounding_blockers(spec))
    if uses_content_understanding(spec):
        if content_understanding_error(spec):
            blockers.append(content_understanding_error(spec))
        else:
            warnings += ("Non-text documents (PDFs, Office files or images) detected; they "
                         "will be read with Content Understanding at "
                         f"{spec.target.content_understanding_endpoint}. That account must be "
                         "in a Content Understanding region, hold deployments named like "
                         "the chat and embedding deployments, and grant the Search identity "
                         "the Cognitive Services User role.",)
    evidence_error = graph_input_error(spec)
    if evidence_error:
        blockers.append(evidence_error)
    if model_error := graph_model_error(spec):
        blockers.append(model_error)
    if not all((spec.embedding_deployment, spec.embedding_model, spec.embedding_dimensions,
                spec.chat_deployment, spec.chat_model, spec.search_identity_resource_id)):
        blockers.append("managed graph needs explicit models, dimensions and Search identity")
    if not spec.build_journal:
        blockers.append("managed graph needs a durable build journal path")
    if not spec.source_description:
        blockers.append("SOURCE_DESCRIPTION_REQUIRED: sample the documents, draft a short factual "
                        "summary of their subject matter, document types and main coverage, and "
                        "pass it as --source-description")
    has_storage_ep = bool(
        spec.target.storage_endpoint
        or (direct_blob and spec.source is not None and spec.source.reference)
    )
    has_openai_ep = bool(
        spec.target.openai_endpoint
        or (
            spec.target.effective_embedding_openai_endpoint
            and spec.target.effective_chat_openai_endpoint
        )
    )
    if not all((spec.search_sku, spec.target.location,
                (spec.target.subscription_id and spec.target.resource_group) or spec.target.search_resource_id,
                spec.target.search_endpoint, has_storage_ep, has_openai_ep)):
        blockers.append("managed graph needs explicit Search SKU, region, Storage and OpenAI targets")
    identity = {"spec": {k: v for k, v in asdict(spec).items()
                         if k != "run_prefix" or v is not None}}
    if spec.source is not None:
        bound_spec = asdict(spec)
        if spec.run_prefix is None:
            bound_spec.pop("run_prefix")
        bound_spec.pop("readers")
        if spec.source_description is None:
            bound_spec.pop("source_description")
        if spec.trial is None:
            bound_spec.pop("trial")
        if spec.grounding_index is None:
            bound_spec.pop("grounding_index")
        if spec.ontology_attached_to is None:
            bound_spec.pop("ontology_attached_to", None)
        for spec_opt in ("kb_chat_deployment", "kb_chat_model"):
            if getattr(spec, spec_opt, None) is None:
                bound_spec.pop(spec_opt, None)
        for target_opt in (
            "cache_storage_resource_id", "embedding_openai_endpoint", "embedding_openai_resource_id",
            "chat_openai_endpoint", "chat_openai_resource_id", "kb_openai_endpoint", "kb_openai_resource_id",
        ):
            if getattr(spec.target, target_opt, None) is None:
                bound_spec["target"].pop(target_opt, None)
        bound_spec["source"] = spec.source.source_id
        bound_spec["source_manifest"] = (
            spec.source_manifest.digest if spec.source_manifest else None
        )
        identity = {
            "spec": bound_spec,
            "ontology_schema_id": ontology.schema_id if ontology else None,
        }
    from .managed_pipeline import extraction_settings
    identity["managed_extraction"] = extraction_settings(spec)
    identity["graph_model_policy"] = GRAPH_MODEL_POLICY_VERSION
    if ontology is not None:
        identity["inline_ontology"] = {
            "schema_id": ontology.schema_id,
            "transport": "inlineJsonLd",
            "search_api_version": search_api_version(spec),
        }
    if spec.readers:
        identity["readers"] = list(spec.readers)
    return Plan(
        plan_id=stable_id("build-plan", identity),
        operations=tuple(operations),
        warnings=warnings + ((
            f"Grants read access to {len(spec.readers)} "
            f"{'identity' if len(spec.readers) == 1 else 'identities'} on the new build "
            "(Search Index Data Reader on its content and graph indexes). The Build "
            "identity needs Microsoft.Authorization/roleAssignments/write for that.",
        ) if spec.readers else ()) + ((
            f"Grounding index {spec.grounding_index} is checked read-only when plan is given "
            "--search-endpoint, and again before apply; entity-graph-build never creates it.",
        ) if spec.grounding_index and not blockers else ()),
        blocked_by=tuple(blockers),
        route=decision,
        scope={
            **scope(spec, decision),
            "ontology_schema_id": ontology.schema_id if ontology else None,
            **({"knowledge_source_description": spec.source_description}
               if spec.source_description else {}),
            **({
                "ontology_transport": "inlineJsonLd",
                "search_api_version": search_api_version(spec),
            } if ontology is not None else {}),
            **({"search_api_version": search_api_version(spec)}
               if ontology is None and ontology_deferred(spec) else {}),
            **({"trial": trial_scope(spec)} if spec.trial else {}),
        },
        estimates=plan_estimates(spec) if ontology else {},
        grounding=grounding_block(spec),
    )


def grounding_block(spec: BuildSpec) -> dict:
    """The exact graph_name the service will filter grounding rows on, with the next step."""
    if not spec.grounding_index or grounding.name_blocker(spec.grounding_index):
        return {}
    from .executor import index_names
    try:
        graph_name = index_names(spec)["knowledge_source"]
    except (ValueError, OSError):
        return {}
    return grounding.plan_block(spec.grounding_index, graph_name)


def grounding_blockers(spec: BuildSpec) -> list[str]:
    """Offline checks on the optional grounding index; the live check runs separately."""
    name = spec.grounding_index
    if name is None:
        return []
    invalid = grounding.name_blocker(name)
    if invalid:
        return [invalid]
    if spec.source_manifest is None:
        return []
    from .executor import index_names
    owned = index_names(spec)
    source = owned["knowledge_source"]
    collision = grounding.collision_blocker(
        name, (*owned.values(), f"{source}-index", f"{source}-graph-index"))
    return [collision] if collision else []


def trial_scope(spec: BuildSpec) -> dict:
    from .executor import staging_prefix
    trial = spec.trial
    return {"sample_documents": trial.size, "corpus_documents": trial.corpus_documents,
            "corpus_digest": trial.corpus_digest, "selection": trial.selection,
            "staging_prefix": staging_prefix(spec),
            "source_ids": [item.source_id for item in spec.source_manifest.items]}

