from __future__ import annotations

import hashlib
import json
import re
import sys
import threading
import time
from types import SimpleNamespace
from collections.abc import Mapping
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable

from ekg_core import service_errors
from ekg_core.execution import ApplyResult, ApprovalRequired, apply_plan
from ekg_core.models import ModelDeploymentSpec, Operation, Plan, ProvisioningSpec, stable_id
from ekg_core.telemetry import TelemetryRecorder
from ekg_core.arm_retry import POLICY_TEXT, report, sdk_retry_policy
from .arm import read_json
from .capacity import quota_preflight, read_regional_quota
from ekg_core.az_identity import IdentityError, active_az_identity, claims
from . import access
from .journal import ProvisioningJournal, journal_spec
from .network import NETWORK_API, network_desired, network_evidence, network_id, validate_network
from .planner import plan
from .public_test import validate_public_test
from .search import (
    management_api, read_serverless_availability, search_view, serverless_preflight,
    validate_search, validate_search_placement,
)


class ProvisioningError(RuntimeError):
    """The observed Azure state cannot safely satisfy the requested spec."""



_API_VERSIONS = {
    "search_service": "2025-05-01",
    "storage_account": "2023-05-01",
    "openai_resource": "2023-05-01",
    "content_understanding": "2023-05-01",
    "model_deployment": "2024-10-01",
    "search_identity": access.IDENTITY_API,
    "blob_container": access.CONTAINER_API,
    "role_assignment": access.ROLE_API,
}
_ACCESS = ("search_identity", "blob_container", "role_assignment")
# Cognitive Services 2023-05-01 GET omits networkAcls.bypass even when a
# 2024-10-01 GET explicitly reports None. Never treat an omitted bypass as safe.
_READ_API_VERSIONS = {**_API_VERSIONS, "openai_resource": "2024-10-01"}
_PROVIDERS = {
    "search_service": "Microsoft.Search/searchServices",
    "storage_account": "Microsoft.Storage/storageAccounts",
    "openai_resource": "Microsoft.CognitiveServices/accounts",
    "content_understanding": "Microsoft.CognitiveServices/accounts",
}


def _progress(line: str) -> None:
    """One apply progress line (stderr; stdout stays the result)."""
    print(line, file=sys.stderr, flush=True)


def _elapsed(seconds: float) -> str:
    return f"{seconds:.0f} s" if seconds < 90 else f"{seconds / 60:.0f} min"


def _field(value: Any, key: str, default: Any = None) -> Any:
    # Newer ARM SDK models are Mappings keyed by REST names; their attributes
    # use snake_case names and enum types, so read them by key like a dict.
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def _same_location(observed: Any, requested: str) -> bool:
    if not isinstance(observed, str):
        return False
    # ARM providers may return the region's display name instead of its canonical name.
    return observed.replace(" ", "").casefold() == requested.casefold()


def _validate(spec: ProvisioningSpec, *, require_active: bool = True) -> None:
    target = spec.target
    fields = {
        "subscription_id": (target.subscription_id, r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"),
        "resource_group": (target.resource_group, r"[a-zA-Z0-9_.()\-]{1,90}"),
        "location": (target.location, r"[a-zA-Z0-9-]+"),
        "search_name": (spec.search_name, r"[a-z0-9][a-z0-9-]{0,58}[a-z0-9]"),
        "storage_name": (spec.storage_name, r"[a-z0-9]{3,24}"),
        "openai_name": (spec.openai_name, r"[a-zA-Z0-9][a-zA-Z0-9_-]{1,63}"),
        "search_sku": (spec.search_sku, r"[a-zA-Z0-9_]+"),
    }
    if spec.content_understanding_name is not None:
        fields["content_understanding_name"] = (
            spec.content_understanding_name, r"[a-zA-Z0-9][a-zA-Z0-9_-]{1,63}"
        )
    if spec.cache_storage_name is not None:
        fields["cache_storage_name"] = (spec.cache_storage_name, r"[a-z0-9]{3,24}")
    if spec.search_location is not None:
        fields["search_location"] = (spec.search_location, r"[a-zA-Z0-9-]+")
    if spec.openai_location is not None:
        fields["openai_location"] = (spec.openai_location, r"[a-zA-Z0-9-]+")
    for name, (value, pattern) in fields.items():
        if not isinstance(value, str) or not re.fullmatch(pattern, value):
            detail = f": {value!r}" if isinstance(value, str) and value else ""
            raise ValueError(f"invalid or missing {name}{detail}")
    if target.resource_group.endswith("."):
        raise ValueError("resource_group cannot end in a period")
    if spec.content_understanding_name == spec.openai_name:
        raise ValueError("Cognitive Services resource names must be distinct")
    validate_network(spec)
    validate_search(spec)
    validate_search_placement(spec)
    validate_public_test(spec, require_active=require_active)


def _public_tags(spec: ProvisioningSpec) -> dict[str, str]:
    assert spec.public_endpoint is not None
    tags = {"entity-plan-id": plan(spec, require_active=False).plan_id}
    if spec.public_test is not None:
        tags["entity-public-test-expires-at"] = spec.public_test.expires_at
    return tags


def _resource_id(spec: ProvisioningSpec, operation: Operation) -> str:
    base = f"/subscriptions/{spec.target.subscription_id}/resourceGroups/{spec.target.resource_group}"
    if operation.id == "create-search-resource-group":
        return access.search_base(spec)
    if operation.resource == "resource_group":
        return base
    if operation.resource == "search_service":
        return access.search_id(spec)
    if operation.resource in NETWORK_API:
        return network_id(spec, operation)
    if operation.resource == "search_identity":
        return access.identity_id(spec)
    if operation.resource == "blob_container":
        return access.container_id(spec)
    if operation.resource == "role_assignment":
        return access.role_assignment_id(spec, operation.id)
    if operation.resource == "model_deployment":
        return (f"{base}/providers/{_PROVIDERS['openai_resource']}/{spec.openai_name}"
                f"/deployments/{operation.name}")
    return f"{base}/providers/{_PROVIDERS[operation.resource]}/{operation.name}"


def _deployment(spec: ProvisioningSpec, operation: Operation) -> ModelDeploymentSpec:
    return next(item for item in spec.model_deployments if item.name == operation.name)


def _desired(spec: ProvisioningSpec, operation: Operation, *,
             identity_principal: str | None = None) -> dict:
    resource = operation.resource
    if resource in NETWORK_API:
        return network_desired(spec, operation)
    if resource in _ACCESS:
        return access.desired(
            spec, operation,
            principal_id=(access.principal_for(spec, operation.id, identity_principal)
                          if resource == "role_assignment" else None),
            tags=_public_tags(spec) if spec.public_endpoint else None,
        )
    if resource == "model_deployment":
        deployment = _deployment(spec, operation)
        return {
            "sku": {"name": deployment.sku, "capacity": deployment.capacity},
            "properties": {
                "model": {"format": "OpenAI", "name": deployment.model,
                          "version": deployment.version},
                "versionUpgradeOption": "NoAutoUpgrade",
            },
        }
    payload: dict[str, Any] = {"location": spec.target.location}
    if spec.public_endpoint:
        payload["tags"] = _public_tags(spec)
    entra_only = spec.public_endpoint is not None and spec.public_endpoint.mode == "entra_only"
    if resource == "search_service":
        search_loc = spec.effective_search_location
        payload["location"] = search_loc
        payload.update(
            sku={"name": spec.search_sku},
            identity=({"type": "SystemAssigned, UserAssigned",
                       "userAssignedIdentities": {access.identity_id(spec): {}}}
                      if (spec.build_access and not spec.build_access.uses_system_identity)
                      else {"type": "SystemAssigned"}),
            properties={
                **({"hostingMode": "Default"} if spec.search_sku == "serverless" else
                   {"replicaCount": 1, "partitionCount": 1, "hostingMode": "default"}),
                "publicNetworkAccess": "Disabled",
            },
        )
        if spec.public_endpoint:
            payload["properties"].update(
                publicNetworkAccess="Enabled", disableLocalAuth=True,
                networkRuleSet={
                    "bypass": "None",
                    "ipRules": [{"value": ip} for ip in spec.public_endpoint.egress_ips],
                },
            )
    elif resource == "storage_account":
        payload.update(
            sku={"name": "Standard_LRS"}, kind="StorageV2",
            properties={
                "allowBlobPublicAccess": False,
                "minimumTlsVersion": "TLS1_2",
                "supportsHttpsTrafficOnly": True,
                "publicNetworkAccess": "Disabled",
            },
        )
        if spec.public_endpoint:
            payload["properties"].update(
                publicNetworkAccess="Enabled", allowSharedKeyAccess=False,
                defaultToOAuthAuthentication=True, isLocalUserEnabled=False,
                isSftpEnabled=False,
                networkAcls={
                    "defaultAction": "Allow" if entra_only else "Deny", "bypass": "None",
                    "ipRules": [
                        {"value": ip, "action": "Allow"} for ip in spec.public_endpoint.egress_ips
                    ],
                    "virtualNetworkRules": [], "resourceAccessRules": [],
                },
            )
    elif resource in ("openai_resource", "content_understanding"):
        if resource == "openai_resource":
            payload["location"] = spec.effective_openai_location
        payload.update(
            kind="OpenAI" if resource == "openai_resource" else "AIServices",
            sku={"name": "S0"},
            properties={
                "customSubDomainName": operation.name,
                "publicNetworkAccess": "Disabled",
            },
        )
        if spec.public_endpoint:
            payload["properties"].update(
                publicNetworkAccess="Enabled", disableLocalAuth=True,
                networkAcls={
                    "defaultAction": "Allow" if entra_only else "Deny", "bypass": "None",
                    "ipRules": [{"value": ip} for ip in spec.public_endpoint.egress_ips],
                    "virtualNetworkRules": [],
                },
            )
    return payload


def _verify_public_acl(resource: str, actual: Any, expected: dict) -> None:
    if _field(actual, "bypass") != "None":
        raise ProvisioningError(f"{resource}: firewall bypass must be None")
    if "defaultAction" in expected and _field(actual, "defaultAction") != expected["defaultAction"]:
        raise ProvisioningError(f"{resource}: firewall defaultAction differs")
    rules = _field(actual, "ipRules")
    if not isinstance(rules, list) or len(rules) != len(expected["ipRules"]):
        raise ProvisioningError(f"{resource}: firewall ipRules differ")
    if sorted(rules, key=lambda rule: _field(rule, "value", "")) != sorted(
        expected["ipRules"], key=lambda rule: rule["value"]
    ):
        raise ProvisioningError(f"{resource}: firewall ipRules differ")
    for key in ("virtualNetworkRules", "resourceAccessRules"):
        if key in expected and _field(actual, key, []) != []:
            raise ProvisioningError(f"{resource}: unexpected {key} bypass")


class _TenantBoundCredential:
    def __init__(self, credential: Any, tenant_id: str,
                 principal_object_id: str | None = None) -> None:
        self.credential = credential
        self.tenant_id = tenant_id
        self.principal_object_id = principal_object_id

    def get_token(self, *scopes: str, **kwargs: Any) -> Any:
        if kwargs.get("tenant_id") not in (None, self.tenant_id):
            raise ProvisioningError("Azure SDK requested a different tenant")
        token = self.credential.get_token(*scopes, **{**kwargs, "tenant_id": self.tenant_id})
        try:
            parsed = claims(token.token)
        except IdentityError as error:
            raise ProvisioningError("cannot validate Azure credential tenant") from error
        if str(parsed.get("tid", "")).lower() != self.tenant_id.lower():
            raise ProvisioningError("Azure credential is not from the approved tenant")
        if self.principal_object_id and str(parsed.get("oid", "")).lower() != (
            self.principal_object_id.lower()
        ):
            raise ProvisioningError("Azure SDK principal differs from the active az identity")
        return token


def _access_evidence(spec: ProvisioningSpec, operation: Operation, observed: Any,
                     actual_id: str, identity_principal: str | None) -> dict:
    properties = _field(observed, "properties", {}) or {}
    if operation.resource == "blob_container":
        if _field(properties, "publicAccess", "None") not in ("None", None):
            raise ProvisioningError(f"{operation.id}: container allows public access")
        return {"resource_id": actual_id, "public_access": "None"}
    if operation.resource == "search_identity":
        if not _same_location(_field(observed, "location"), spec.target.location):
            raise ProvisioningError(f"{operation.id}: location differs from requested location")
        principal = _field(properties, "principalId")
        if not isinstance(principal, str) or not principal:
            raise ProvisioningError(f"{operation.id}: managed identity has no principal ID")
        return {"resource_id": actual_id, "location": _field(observed, "location"),
                "principal_id": principal, "client_id": _field(properties, "clientId")}
    _, role, kind = access.grant(operation.id)
    expected_principal = access.principal_for(spec, operation.id, identity_principal)
    role_definition = str(_field(properties, "roleDefinitionId", ""))
    if not role_definition.lower().endswith(access.ROLE_IDS[role]):
        raise ProvisioningError(f"{operation.id}: role assignment has a different role")
    if str(_field(properties, "scope", "")).lower() != access.scope(spec, kind).lower():
        raise ProvisioningError(f"{operation.id}: role assignment has a different scope")
    principal = _field(properties, "principalId")
    if expected_principal and str(principal).lower() != expected_principal.lower():
        raise ProvisioningError(f"{operation.id}: role assignment has a different principal")
    return {"resource_id": actual_id, "role": role, "principal_id": principal,
            "scope": access.scope(spec, kind)}


def _search_identity_ok(spec: ProvisioningSpec, identity: Any) -> bool:
    kind = str(_field(identity, "type", ""))
    if not spec.build_access or spec.build_access.uses_system_identity:
        return kind == "SystemAssigned"
    attached = {str(key).lower() for key in (_field(identity, "userAssignedIdentities") or {})}
    return (kind.replace(" ", "").lower() == "systemassigned,userassigned"
            and access.identity_id(spec).lower() in attached)


def _evidence(spec: ProvisioningSpec, operation: Operation, observed: Any, *,
              identity_principal: str | None = None) -> dict:
    resource = operation.resource
    if resource in NETWORK_API:
        return network_evidence(spec, operation, observed)
    resource_id = _resource_id(spec, operation)
    actual_id = _field(observed, "id")
    if not isinstance(actual_id, str) or actual_id.lower() != resource_id.lower():
        raise ProvisioningError(f"{operation.id}: Azure returned an unexpected resource ID")
    if resource == "model_deployment":
        return _deployment_evidence(spec, operation, observed, actual_id)
    if resource in _ACCESS:
        return _access_evidence(spec, operation, observed, actual_id, identity_principal)
    location = _field(observed, "location")
    expected_location = (
        spec.effective_search_location
        if resource == "search_service" or operation.id == "create-search-resource-group"
        else spec.effective_openai_location if resource == "openai_resource"
        else spec.target.location
    )
    if not _same_location(location, expected_location):
        raise ProvisioningError(f"{operation.id}: location differs from requested location")
    evidence = {"resource_id": actual_id, "location": location}
    if spec.public_endpoint:
        tags = _field(observed, "tags", {}) or {}
        if spec.public_data is not None:
            # A resource made by any earlier Entity Graph plan can be kept as it is.
            if not str(_field(tags, "entity-plan-id") or "").startswith("provision-plan-"):
                raise ProvisioningError(
                    f"{operation.name} already exists and wasn't created by an Entity Graph plan")
        elif any(_field(tags, key) != value for key, value in _public_tags(spec).items()):
            raise ProvisioningError(f"{operation.id}: public endpoint plan/expiry tags differ")
    if resource == "resource_group":
        return evidence
    desired = _desired(spec, operation)
    actual_sku = _field(_field(observed, "sku"), "name")
    if str(actual_sku).lower() != desired["sku"]["name"].lower():
        raise ProvisioningError(f"{operation.id}: SKU differs from requested SKU")
    if "kind" in desired and str(_field(observed, "kind")).lower() != desired["kind"].lower():
        raise ProvisioningError(f"{operation.id}: resource kind differs from requested kind")
    properties = _field(observed, "properties", {})
    if resource == "storage_account":
        for key, expected in desired["properties"].items():
            if key == "networkAcls":
                _verify_public_acl(operation.id, _field(properties, key), expected)
                continue
            if _field(properties, key) != expected:
                raise ProvisioningError(f"{operation.id}: {key} differs from requested setting")
        endpoint = _field(_field(properties, "primaryEndpoints", {}), "blob")
    elif resource == "search_service":
        if not _search_identity_ok(spec, _field(observed, "identity")):
            has_uai = bool(spec.build_access and not spec.build_access.uses_system_identity)
            raise ProvisioningError(
                f"{operation.id}: system-assigned identity"
                + (" and the attached Search identity are" if has_uai else " is")
                + " required")
        for key, expected in desired["properties"].items():
            if key == "networkRuleSet":
                _verify_public_acl(operation.id, _field(properties, key), expected)
                continue
            if _field(properties, key) != expected:
                raise ProvisioningError(f"{operation.id}: {key} differs from requested setting")
        endpoint = str(_field(properties, "endpoint") or f"https://{operation.name}.search.windows.net").rstrip("/")
    else:
        for key, expected in desired["properties"].items():
            if key == "networkAcls":
                _verify_public_acl(operation.id, _field(properties, key), expected)
                continue
            if _field(properties, key) != expected:
                raise ProvisioningError(f"{operation.id}: {key} differs from requested setting")
        endpoint = _field(properties, "endpoint")
    state = _field(properties, "provisioningState")
    if not isinstance(state, str) or state.lower() != "succeeded":
        raise ProvisioningError(f"{operation.id}: provisioning state is {state!r}, not Succeeded")
    if not isinstance(endpoint, str) or not endpoint.startswith("https://"):
        raise ProvisioningError(f"{operation.id}: HTTPS endpoint is unavailable")
    evidence.update(
        endpoint=endpoint, provisioning_state=state,
        public_network_access=_field(properties, "publicNetworkAccess"),
    )
    if resource == "search_service":
        evidence["sku"] = actual_sku
    if spec.public_endpoint:
        evidence["auth_posture"] = spec.public_endpoint.mode
        if spec.public_data:
            evidence["data_policy"] = "public_data_only"
    return evidence


def _deployment_evidence(spec: ProvisioningSpec, operation: Operation, observed: Any,
                         actual_id: str) -> dict:
    desired = _deployment(spec, operation)
    sku = _field(observed, "sku")
    properties = _field(observed, "properties", {})
    model = _field(properties, "model", {})
    if str(_field(sku, "name")).lower() != desired.sku.lower():
        raise ProvisioningError(f"{operation.id}: SKU differs from requested SKU")
    if _field(sku, "capacity") != desired.capacity:
        raise ProvisioningError(
            f"{operation.id}: capacity is {_field(sku, 'capacity')}K TPM, not "
            f"{desired.capacity}K; review with `entity-graph-provision plan-capacity` instead of re-provisioning"
        )
    if (_field(model, "name"), str(_field(model, "version"))) != (desired.model, desired.version):
        raise ProvisioningError(f"{operation.id}: model or version differs from requested")
    state = _field(properties, "provisioningState")
    if not isinstance(state, str) or state.lower() != "succeeded":
        raise ProvisioningError(f"{operation.id}: provisioning state is {state!r}, not Succeeded")
    return {"resource_id": actual_id, "sku": desired.sku, "capacity": desired.capacity,
            "model": f"{desired.model}@{desired.version}", "provisioning_state": state}


def _recovery_evidence(value: dict[str, Any]) -> dict[str, Any]:
    """Normalize only ARM identities and provider-defined case-insensitive fields."""
    result = {}
    for key in (
        "resource_id", "location", "principal_id", "client_id", "scope", "endpoint",
        "sku", "capacity", "model", "role", "public_access", "auth_posture", "data_policy",
    ):
        if key not in value:
            continue
        item = value[key]
        if key in ("resource_id", "scope", "principal_id", "client_id", "sku"):
            item = item.lower() if isinstance(item, str) else item
        elif key == "location" and isinstance(item, str):
            item = item.replace(" ", "").lower()
        result[key] = item
    return result


def _recovery_projection(
    spec: ProvisioningSpec, operation: Operation, value: dict[str, Any],
    evidence: dict[str, Any], identity_evidence: dict[str, Any] | None,
) -> dict[str, Any]:
    properties = _field(value, "properties", {}) or {}
    projection = _recovery_evidence(evidence)
    if operation.resource in (
        "resource_group", "search_identity", "search_service", "storage_account", "openai_resource",
    ):
        projection["tags"] = value.get("tags")
    identity = value.get("identity")
    if operation.resource == "search_service":
        if not isinstance(identity, dict):
            raise ProvisioningError("Search identity observation is unresolved")
        tenant, principal = identity.get("tenantId"), identity.get("principalId")
        if (not isinstance(tenant, str) or tenant.lower() != spec.public_data.tenant_id.lower()
            or not isinstance(principal, str)
            or not re.fullmatch(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}", principal)):
            raise ProvisioningError("Search system identity tenant/principal is unresolved")
        attached = identity.get("userAssignedIdentities")
        if (not isinstance(attached, dict) or identity_evidence is None
            or {key.lower() for key in attached} != {access.identity_id(spec).lower()}):
            raise ProvisioningError("Search has missing or unexpected attached identities")
        for item in attached.values():
            if not isinstance(item, dict):
                raise ProvisioningError("Search attached identity observation is unresolved")
            for field, receipt in (("principalId", "principal_id"), ("clientId", "client_id")):
                if field in item and str(item[field]).lower() != str(identity_evidence[receipt]).lower():
                    raise ProvisioningError("Search attached identity differs from the owned identity")
        projection["identity"] = {
            "tenant_id": tenant.lower(), "principal_id": principal.lower(),
            "user_assigned_identities": [access.identity_id(spec).lower()],
        }
    elif identity not in (None, {}, {"type": "None"}):
        raise ProvisioningError(f"{operation.id}: unexpected identity")
    if operation.resource == "search_identity":
        if not isinstance(evidence.get("client_id"), str) or not evidence["client_id"]:
            raise ProvisioningError("managed identity client is unresolved")
        projection["tenant_id"] = properties["tenantId"].lower()
    if operation.resource == "model_deployment":
        if (properties.get("model", {}).get("format") != "OpenAI"
            or properties.get("versionUpgradeOption") != "NoAutoUpgrade"):
            raise ProvisioningError(f"{operation.id}: model format/upgrade policy differs")
    if operation.resource == "role_assignment":
        expected = _desired(spec, operation, identity_principal=(
            identity_evidence["principal_id"] if identity_evidence else None))["properties"]
        if (str(properties.get("roleDefinitionId", "")).lower()
            != expected["roleDefinitionId"].lower()
            or properties.get("principalType") != expected["principalType"]
            or properties.get("condition") or properties.get("conditionVersion")
            or properties.get("delegatedManagedIdentityResourceId")):
            raise ProvisioningError(f"{operation.id}: role invariants differ")
    # _evidence validates every approved desired property before this projection is used.
    if operation.resource != "resource_group":
        projection["desired"] = _desired(spec, operation, identity_principal=(
            identity_evidence["principal_id"].lower() if identity_evidence else None))
    return projection


def read_subscription_permissions(spec: ProvisioningSpec, **kwargs: Any) -> dict:
    """Read-only: the signed-in identity's effective actions on the subscription."""
    url = (f"https://management.azure.com/subscriptions/{spec.target.subscription_id}"
           "/providers/Microsoft.Authorization/permissions?api-version=2022-04-01")
    return read_json(spec, "get", url, **kwargs)


def read_subscription(spec: ProvisioningSpec, **kwargs: Any) -> dict:
    """Read-only: the subscription record, including the tenant it belongs to."""
    url = (f"https://management.azure.com/subscriptions/{spec.target.subscription_id}"
           "?api-version=2022-12-01")
    return read_json(spec, "get", url, **kwargs)


def scoped_actions(spec: ProvisioningSpec) -> dict[str, tuple[str, ...]]:
    """Every ARM Action the plan needs, keyed by the subscription it is needed in."""
    actions = plan(spec, require_active=False).required_permissions
    data, search = spec.target.subscription_id, spec.effective_search_subscription_id
    if data.casefold() == search.casefold():
        return {data: actions}
    granted_kinds = {access.grant(operation.id, spec)[2]
                     for operation in plan(spec, require_active=False).operations
                     if operation.resource == "role_assignment"}

    def search_side(action: str) -> bool:
        return (action.startswith("Microsoft.Search/")
                or action == "Microsoft.Resources/subscriptions/providers/read")

    def wanted(action: str, in_search: bool) -> bool:
        if action.startswith("Microsoft.Resources/subscriptions/resourceGroups/"):
            return True
        if action.startswith("Microsoft.Authorization/"):
            return ("search" in granted_kinds) if in_search else bool(granted_kinds - {"search"})
        return search_side(action) == in_search

    return {data: tuple(a for a in actions if wanted(a, False)),
            search: tuple(a for a in actions if wanted(a, True))}


class AzureSdkBackend:
    """ARM resource-group and generic-resource client; never updates existing resources."""

    # Seconds between "still waiting" lines while one Azure operation runs.
    progress_interval = 60.0

    def __init__(
        self, credential: Any = None, *, client: Any = None,
        journal_root: str | Path | None = None, expected_tenant_id: str | None = None,
        quota_reader: Callable[[ProvisioningSpec], dict] | None = None,
        permission_reader: Callable[[ProvisioningSpec], dict] | None = None,
        search_availability_reader: Callable[[ProvisioningSpec], dict] | None = None,
        subscription_reader: Callable[[ProvisioningSpec], dict] | None = None,
        sleep: Callable[[float], None] = time.sleep,
        search_client: Any = None,
    ) -> None:
        self.credential = credential
        self.quota_reader = quota_reader or (
            lambda spec: read_regional_quota(spec, observe=self._request_event))
        self.permission_reader = permission_reader or (
            lambda spec: read_subscription_permissions(spec, observe=self._request_event))
        self.search_availability_reader = search_availability_reader or (
            lambda spec: read_serverless_availability(spec, observe=self._request_event))
        self.subscription_reader = subscription_reader or (
            lambda spec: read_subscription(spec, observe=self._request_event))
        self._search_availability: dict[str, str] = {}
        self._sleep = sleep
        self._principal_object_id: str | None = None
        self._principal_type: str | None = None
        self._quota: dict[str, Any] = {}
        self.expected_tenant_id = expected_tenant_id
        self._injected_client = client
        self._injected_search_client = search_client
        self._sdk_client: Any = None
        self._search_sdk_client: Any = None
        self._search_client_subscription: str | None = None
        self._sdk_credential: Any = None
        self._client_subscription: str | None = None
        self._client_tenant: str | None = None
        self._client_public_data: bool | None = None
        self._active_operation: tuple[str, str] | None = None
        self._cancelled = threading.Event()
        self.journal = ProvisioningJournal(
            journal_root if journal_root is not None else Path.cwd() / ".entity" / "provision-runs"
        )
        self.last_run_id: str | None = None

    def _request_event(self, event: dict[str, Any]) -> None:
        report(event)
        if self._active_operation is not None:
            run_id, operation_id = self._active_operation
            self.journal.record_request(run_id, {**event, "operation": operation_id}, operation_id)

    def _run_started(self, run_id: str) -> None:
        self.last_run_id = run_id
        _progress(f"Run journal (each resource's status): {self.journal.path(run_id)}")

    def _client(self, spec: ProvisioningSpec) -> Any:
        if self._injected_client is not None:
            return self._injected_client
        tenant = spec.public_endpoint.tenant_id if spec.public_endpoint else self.expected_tenant_id
        if not tenant or (self.expected_tenant_id and self.expected_tenant_id != tenant):
            raise ProvisioningError("an explicit matching tenant ID is required for live Azure access")
        public_data = spec.public_data is not None
        if (self._client_subscription != spec.target.subscription_id
                or self._client_tenant != tenant or self._client_public_data != public_data):
            try:
                from azure.identity import AzureCliCredential
                try:
                    from azure.mgmt.resource.resources import ResourceManagementClient
                except ImportError:
                    from azure.mgmt.resource import ResourceManagementClient
            except ImportError as error:
                raise RuntimeError(
                    "Azure SDK backend requires the optional provision dependencies"
                ) from error
            identity = active_az_identity(tenant, spec.target.subscription_id)
            self._principal_object_id = identity["principal_object_id"]
            self._principal_type = identity["principal_type"]
            credential = self.credential if self.credential is not None else AzureCliCredential(
                tenant_id=tenant
            )
            credential = _TenantBoundCredential(
                credential, tenant, identity["principal_object_id"]
            )
            credential.get_token("https://management.azure.com/.default")
            self._sdk_credential = credential
            self._sdk_client = ResourceManagementClient(
                credential, spec.target.subscription_id,
                retry_policy=sdk_retry_policy(
                    self._request_event, cancelled=self._cancelled.is_set),
            )
            self._client_subscription = spec.target.subscription_id
            self._client_tenant = tenant
            self._client_public_data = public_data
            self._search_sdk_client = None
            self._search_client_subscription = None
        return self._sdk_client

    def _client_for(self, client: Any, spec: ProvisioningSpec, operation: Operation) -> Any:
        """The client for the subscription that holds this operation's resource."""
        if not spec.search_is_split or operation.id not in (
                "create-search-resource-group", "create-search_service"):
            return client
        if self._injected_client is not None:
            return self._injected_search_client or client
        subscription = spec.effective_search_subscription_id
        if subscription.casefold() == (spec.target.subscription_id or "").casefold():
            return client
        if self._search_sdk_client is None or self._search_client_subscription != subscription:
            try:
                from azure.mgmt.resource.resources import ResourceManagementClient
            except ImportError:
                from azure.mgmt.resource import ResourceManagementClient
            tenant = spec.public_endpoint.tenant_id if spec.public_endpoint else self.expected_tenant_id
            # Fails unless the signed-in identity can see the Search subscription in this tenant.
            active_az_identity(tenant, subscription)
            self._search_sdk_client = ResourceManagementClient(
                self._sdk_credential, subscription,
                retry_policy=sdk_retry_policy(
                    self._request_event, cancelled=self._cancelled.is_set),
            )
            self._search_client_subscription = subscription
        return self._search_sdk_client

    def _listed_ids(self, client: Any, spec: ProvisioningSpec) -> list[str]:
        """Resource IDs listed in the data group and, when placed apart, the Search group."""
        groups = [(client, spec.target.resource_group)]
        if spec.search_is_split:
            search_group = Operation(
                "create-search-resource-group", "provision", "ensure", "resource_group",
                spec.effective_search_resource_group or "")
            if self._get(client, spec, search_group) is not None:
                groups.append((self._client_for(client, spec, search_group), search_group.name))
        return [str(_field(item, "id", "")).lower()
                for owner, name in groups for item in owner.resources.list_by_resource_group(name)]

    def _get(self, client: Any, spec: ProvisioningSpec, operation: Operation) -> Any | None:
        client = self._client_for(client, spec, operation)
        try:
            if operation.resource == "resource_group":
                return client.resource_groups.get(operation.name)
            return client.resources.get_by_id(
                _resource_id(spec, operation),
                api_version=(management_api(spec) if operation.resource == "search_service"
                             else (NETWORK_API if operation.resource in NETWORK_API
                                   else _READ_API_VERSIONS)[operation.resource]),
            )
        except Exception as error:
            if getattr(error, "status_code", None) == 404:
                return None
            raise

    def inspect(self, spec: ProvisioningSpec) -> dict:
        _validate(spec, require_active=False)
        client = self._client(spec)
        resource_group = Operation(
            "create-resource-group", "provision", "ensure", "resource_group",
            spec.target.resource_group or "",
        )
        operations = (resource_group, *(
            operation for operation in plan(spec, require_active=False).operations
            if operation.id != "create-resource-group"
        ))
        group = self._get(client, spec, resource_group)
        search_group = group
        if spec.search_is_split:
            search_group = self._get(client, spec, Operation(
                "create-search-resource-group", "provision", "ensure", "resource_group",
                spec.effective_search_resource_group or "",
            ))
        resources = {}
        identity_principal = None
        search_system_principal = None
        for operation in operations:
            parent = (search_group if operation.id in (
                "create-search-resource-group", "create-search_service") else group)
            observed = (
                group if operation.resource == "resource_group"
                and operation.id != "create-search-resource-group"
                else search_group if operation.id == "create-search-resource-group"
                else self._get(client, spec, operation) if parent is not None else None
            )
            if observed is not None:
                op_principal = (
                    search_system_principal
                    if (operation.resource == "role_assignment"
                        and access.grant(operation.id, spec)[0] == "search_system_identity")
                    else identity_principal
                )
                evidence = _evidence(spec, operation, observed,
                                     identity_principal=op_principal)
                if operation.resource == "search_identity":
                    identity_principal = evidence["principal_id"]
                elif operation.resource == "search_service":
                    search_system_principal = _field(
                        _field(observed, "identity", {}) or {}, "principalId"
                    )
            resources[operation.id] = (
                {"status": "present", **evidence}
                if observed is not None else
                {"status": "missing", "resource_id": _resource_id(spec, operation)}
            )
        result = {"plan_id": plan(spec, require_active=False).plan_id, "resources": resources}
        tenant = self._client_tenant or (
            spec.public_endpoint.tenant_id if spec.public_endpoint else self.expected_tenant_id
        )
        if tenant:
            result["tenant_id"] = tenant
        return result

    def verify(self, spec: ProvisioningSpec) -> dict:
        result = self.inspect(spec)
        missing = [key for key, value in result["resources"].items() if value["status"] == "missing"]
        if missing:
            raise ProvisioningError(f"verification failed; missing: {', '.join(missing)}")
        return {"status": "verified", **result}

    def apply(self, spec: ProvisioningSpec, *, approved_plan_id: str,
              confirmed_public_test: bool = False, confirmed_public_data: bool = False) -> ApplyResult:
        if spec.public_endpoint is None:
            raise ProvisioningError(
                "live provisioning apply is disabled pending a separately approved deployment decision"
            )
        if not (confirmed_public_data if spec.public_data else confirmed_public_test):
            raise ApprovalRequired("public provisioning requires explicit billable deployment confirmation")
        _validate(spec)
        if spec.public_data is None:
            desired_plan = plan(spec)
            if not approved_plan_id or approved_plan_id != desired_plan.plan_id:
                raise ApprovalRequired(f"explicit approval of plan {desired_plan.plan_id} is required")
        if self._injected_client is None:
            self._client(spec)
            self._sdk_credential.get_token("https://management.azure.com/.default")
            access_spec = spec.build_access
            if spec.public_data and access_spec and (
                (self._principal_object_id or "").lower() != access_spec.operator_object_id.lower()
                or self._principal_type != access_spec.operator_principal_type
            ):
                raise ProvisioningError("public-data operator must match the active Azure CLI principal and type")
            if (access_spec and access_spec.operator_principal_type == "User"
                    and (self._principal_object_id or "").lower()
                    != access_spec.operator_object_id.lower()):
                raise ProvisioningError(
                    "the operator object ID is not the signed-in Azure CLI user; "
                    "use `az ad signed-in-user show --query id -o tsv`")
        return self._apply_approved(spec, approved_plan_id=approved_plan_id,
                                    allow_live=True)

    def _resume_state(
        self, spec: ProvisioningSpec, source_run_id: str,
        *, created: tuple[str, ...] = (),
    ) -> tuple[dict[str, Any], dict[str, Any], str]:
        _validate(spec)
        if spec.public_test is None or spec.network is not None:
            raise ProvisioningError("resume requires the original active public-test spec")
        source_path = self.journal.path(source_run_id)
        source_bytes = source_path.read_bytes()
        source = json.loads(source_bytes)
        original = plan(spec)
        operations = {operation.id: operation for operation in original.operations}
        if (source.get("version") != 1 or source.get("run_id") != source_run_id
            or source.get("plan_id") != original.plan_id
            or source.get("spec") != json.loads(json.dumps(journal_spec(spec)))
            or source.get("completed") is not False
            or set(source.get("operations", {})) != set(operations)):
            raise ProvisioningError("original journal is not the exact incomplete public-test run")
        expected_status = {
            "create-resource-group": "create_response_verified",
            "create-search_service": "uncertain",
            "create-storage_account": "pending",
            "create-openai_resource": "pending",
        }
        if "create-search-resource-group" in operations:
            expected_status["create-search-resource-group"] = "create_response_verified"
        if any(
            source["operations"][key].get("status") != status
            or source["operations"][key].get("preflight") != "missing"
            or source["operations"][key].get("resource_id") != _resource_id(spec, operations[key])
            for key, status in expected_status.items()
        ):
            raise ProvisioningError("original journal has a different operation outcome")
        client = self._client(spec)
        inspection = self.inspect(spec)
        groups = {key for key, operation in operations.items()
                  if operation.resource == "resource_group"}
        expected_present = {*groups, "create-search_service", *created}
        if any(
            value["status"] != ("present" if key in expected_present else "missing")
            for key, value in inspection["resources"].items()
        ):
            raise ProvisioningError("resume requires exactly the expected present and missing services")
        group = self._get(client, spec, operations["create-resource-group"])
        search = self._get(client, spec, operations["create-search_service"])
        if group is None or search is None:
            raise ProvisioningError("resume source resources disappeared")
        for key, observed in (("create-resource-group", group), ("create-search_service", search)):
            _evidence(spec, operations[key], observed)

        def raw(value: Any) -> Any:
            return value if isinstance(value, dict) else value.as_dict()

        identity = raw(_field(search, "identity"))
        if (not isinstance(_field(identity, "principalId"), str)
            or not _field(identity, "principalId")
            or str(_field(identity, "tenantId", "")).lower() != spec.public_test.tenant_id.lower()):
            raise ProvisioningError("Search system identity lacks the expected tenant and principal")
        allowed_ids = {
            _resource_id(spec, operations[key]).lower()
            for key in expected_present if key not in groups
        }
        actual_ids = self._listed_ids(client, spec)
        if len(actual_ids) != len(allowed_ids) or set(actual_ids) != allowed_ids:
            raise ProvisioningError("resource group contains unexpected or missing resources")

        snapshot = {
            "source_journal_sha256": hashlib.sha256(source_bytes).hexdigest(),
            "resource_ids": [_resource_id(
                spec, operations["create-search_service"]
            ).lower()],
            "resource_group": raw(group),
            "search_service": raw(search),
        }
        if "create-search-resource-group" in operations:
            search_group = self._get(client, spec, operations["create-search-resource-group"])
            if search_group is None:
                raise ProvisioningError("resume source Search resource group disappeared")
            _evidence(spec, operations["create-search-resource-group"], search_group)
            snapshot["search_resource_group"] = raw(search_group)
        snapshot_hash = hashlib.sha256(json.dumps(
            snapshot, sort_keys=True, separators=(",", ":"), default=str,
        ).encode("utf-8")).hexdigest()
        return inspection, source, snapshot_hash

    def _public_data_resume_state(
        self, spec: ProvisioningSpec, source_run_id: str,
        *, created: dict[str, Any] | None = None, active_run_id: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any], str, dict[str, Any]]:
        _validate(spec)
        if spec.public_data is None or spec.network is not None:
            raise ProvisioningError("recovery requires the original active public-data spec")
        created = {} if created is None else created
        try:
            chain = self.journal.lineage(source_run_id)
        except (OSError, ValueError, KeyError, TypeError) as error:
            raise ProvisioningError(f"invalid recovery journal lineage: {error}") from error
        lineage = self.journal.lineage_binding(chain)
        source = chain[-1][0]
        original = plan(spec)
        operations = {operation.id: operation for operation in original.operations}
        settled = {"create_response_verified", "verified"}
        for index, (record, _) in enumerate(chain):
            if (record.get("spec") != json.loads(json.dumps(journal_spec(spec)))
                or record.get("completed") is not False
                or set(record.get("operations", {})) != set(operations)
                or (index == 0 and record.get("plan_id") != original.plan_id)):
                raise ProvisioningError("journal is not an exact incomplete public-data run")
            for key, operation in operations.items():
                entry = record["operations"][key]
                parent = chain[index - 1][0]["operations"][key] if index else None
                if (entry.get("preflight") not in ({"missing"} if not index else {"missing", "present"})
                    or str(entry.get("resource_id", "")).lower() != _resource_id(spec, operation).lower()
                    or entry.get("depends_on") != list(operation.depends_on)
                    or entry.get("status") not in settled | {"pending", "uncertain", "failed"}
                    or (parent and entry.get("preflight") == "present"
                        and parent["status"] not in settled | {"uncertain"})
                    or (parent and parent["status"] in settled and (
                        entry.get("preflight") != "present" or entry["status"] not in settled))):
                    raise ProvisioningError(f"{key}: journal has an unsupported or disconnected outcome")
                if entry["status"] in settled and (
                    str(entry.get("evidence", {}).get("resource_id", "")).lower()
                    != _resource_id(spec, operation).lower()
                ):
                    raise ProvisioningError(f"{key}: positive receipt identity is missing or changed")
            if index:
                link = record["resume_from"]
                identity = {
                    "source_run_id": link["source_run_id"],
                    "source_plan_id": link["source_plan_id"],
                    "snapshot_sha256": link["snapshot_sha256"],
                    "operations": tuple(operation for operation in original.operations
                                        if record["operations"][operation.id]["preflight"] == "missing"),
                }
                if "journal_lineage" in link:
                    identity["journal_lineage"] = link["journal_lineage"]
                if record["plan_id"] != stable_id("public-data-resume-plan", identity):
                    raise ProvisioningError("linked journal does not match its exact recovery plan")
        if chain[0][0]["operations"]["create-resource-group"]["status"] not in settled:
            raise ProvisioningError("recovery requires a confirmed originally created resource group")
        ancestors = {record["run_id"] for record, _ in chain}
        for path in self.journal.root.glob("*.json"):
            if not re.fullmatch(r"[0-9a-f]{32}", path.stem) or path.stem == active_run_id:
                continue
            record = self.journal.read(path.stem)
            if ((record.get("resume_from") or {}).get("source_run_id") in ancestors
                and path.stem not in ancestors):
                raise ProvisioningError("source lineage has a later or competing continuation; inspect it first")

        def raw(value: Any) -> Any:
            if isinstance(value, Mapping):
                return {key: raw(item) for key, item in value.items()}
            if isinstance(value, (list, tuple)):
                return [raw(item) for item in value]
            if value is None or isinstance(value, (str, int, float, bool)):
                return value
            raise ProvisioningError("unsupported resource metadata in recovery snapshot")

        client = self._client(spec)
        if self._injected_client is None and (
            (self._principal_object_id or "").lower()
            != spec.build_access.operator_object_id.lower()
            or self._principal_type != spec.build_access.operator_principal_type
        ):
            raise ProvisioningError("public-data recovery operator must match the original approved principal")
        observed = {}
        resources = {}
        projections = {}
        identity_principal = None
        search_system_principal = None
        identity_evidence = None
        for key, operation in operations.items():
            value = self._get(client, spec, operation)
            entry = source["operations"][key]
            if value is None:
                if entry["status"] in settled or key in created:
                    raise ProvisioningError(f"{key}: confirmed resource disappeared")
                if any(record["operations"][key].get("accepted_requests") for record, _ in chain):
                    raise ProvisioningError(
                        f"{key}: Azure accepted the original write; GET 404 does not prove "
                        "noncreation. Reconcile its original operation before recovery; no new PUT."
                    )
                if entry["status"] == "uncertain" and not re.search(
                    r"(?:\bHTTP |\()429\b", entry.get("reason", "")
                ):
                    raise ProvisioningError(f"{key}: absent resource has an unresolved write outcome")
                resources[key] = {"status": "missing", "resource_id": _resource_id(spec, operation)}
                observed[key] = None
                projections[key] = None
                continue
            if key not in created and entry["status"] not in settled | {"uncertain"}:
                raise ProvisioningError(f"{key}: unrecorded resource appeared after the original run")
            if any(resources[dependency]["status"] != "present"
                   for dependency in operation.depends_on):
                raise ProvisioningError(f"{key}: a required resource is missing")
            op_principal = (
                search_system_principal
                if (operation.resource == "role_assignment"
                    and access.grant(operation.id, spec)[0] == "search_system_identity")
                else identity_principal
            )
            evidence = _evidence(spec, operation, value, identity_principal=op_principal)
            if operation.resource == "search_service":
                search_system_principal = _field(
                    _field(value, "identity", {}) or {}, "principalId"
                )
            properties = _field(value, "properties", {}) or {}
            if operation.resource in (
                "resource_group", "search_identity", "search_service", "storage_account",
                "openai_resource",
            ):
                if any(_field(_field(value, "tags", {}), tag) != expected
                       for tag, expected in _public_tags(spec).items()):
                    raise ProvisioningError(f"{key}: recovery ownership/expiry tags differ")
            if operation.resource == "resource_group":
                if str(_field(properties, "provisioningState", "")).lower() != "succeeded":
                    raise ProvisioningError("resource group has an ambiguous provisioning state")
            if operation.resource == "search_identity":
                if (str(_field(properties, "tenantId", "")).lower()
                    != spec.public_data.tenant_id.lower()
                    or not re.fullmatch(
                        r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}",
                        evidence["principal_id"],
                    )
                    or str(_field(properties, "provisioningState", "Succeeded")).lower()
                    != "succeeded"):
                    raise ProvisioningError("managed identity tenant/principal is ambiguous")
                identity_principal = evidence["principal_id"]
                identity_evidence = evidence
            if operation.resource == "role_assignment" and _field(properties, "condition"):
                raise ProvisioningError(f"{key}: conditional role is not the approved assignment")
            observed[key] = raw(value)
            projection = _recovery_projection(
                spec, operation, observed[key], evidence, identity_evidence)
            for record, _ in chain:
                receipt = record["operations"][key]
                if receipt["status"] in settled:
                    expected = _recovery_evidence(receipt["evidence"])
                    if any(projection.get(field) != item for field, item in expected.items()):
                        raise ProvisioningError(f"{key}: positive receipt invariants changed")
                for snapshot in record.get("recovery_snapshots", []):
                    prior = snapshot["validated_resources"].get(key)
                    if prior is not None and prior != projection:
                        raise ProvisioningError(f"{key}: recorded recovery invariants changed")
            projections[key] = projection
            if key in created and created[key] is not None and projection != created[key]:
                raise ProvisioningError(f"{key}: recovered resource changed")
            resources[key] = {"status": "present", **evidence}
        if resources["create-resource-group"]["status"] != "present":
            raise ProvisioningError("original resource group is missing")
        present_ids = {
            _resource_id(spec, operations[key]).lower()
            for key, value in observed.items()
            if value is not None and operations[key].resource != "resource_group"
        }
        listed = self._listed_ids(client, spec)
        top_level_ids = {
            _resource_id(spec, operation).lower() for key, operation in operations.items()
            if observed[key] is not None and operation.resource in (
                "search_identity", "search_service", "storage_account", "openai_resource",
            )
        }
        if (len(listed) != len(set(listed)) or not set(listed).issubset(present_ids)
            or not top_level_ids.issubset(listed)):
            raise ProvisioningError("resource group contains unexpected or missing resources")
        if self.journal.lineage_binding(self.journal.lineage(source_run_id)) != lineage:
            raise ProvisioningError("source journal lineage changed during reconciliation")
        snapshot = {
            "journal_lineage": lineage,
            "validated_resources": projections,
        }
        snapshot_hash = hashlib.sha256(json.dumps(
            snapshot, sort_keys=True, separators=(",", ":"), allow_nan=False,
        ).encode()).hexdigest()
        return {
            "resources": resources, "journal_lineage": lineage,
            "validated_resources": projections,
            "audit_snapshot": {"raw_resources": observed, "validated_resources": projections,
                               "snapshot_sha256": snapshot_hash},
        }, source, snapshot_hash, observed

    def resume_plan(self, spec: ProvisioningSpec, source_run_id: str) -> dict[str, Any]:
        self._search_tenant_gate(spec)
        if spec.public_data:
            source_hash = hashlib.sha256(self.journal.path(source_run_id).read_bytes()).hexdigest()
            inspection, source, snapshot_hash, _ = self._public_data_resume_state(spec, source_run_id)
            original = plan(spec)
            operations = tuple(operation for operation in original.operations
                               if inspection["resources"][operation.id]["status"] == "missing")
            if not operations:
                raise ProvisioningError("nothing is missing; verify the completed resources instead")
            self._quota_gate(spec, tuple(
                item for item in spec.model_deployments
                if any(operation.id == f"create-{item.role}-deployment" for operation in operations)
            ))
            self._permission_gate(spec)
            if hashlib.sha256(self.journal.path(source_run_id).read_bytes()).hexdigest() != source_hash:
                raise ProvisioningError("source journal changed while preparing recovery")
            return {
                "plan_id": stable_id("public-data-resume-plan", {
                    "source_run_id": source_run_id, "source_plan_id": source["plan_id"],
                    "snapshot_sha256": snapshot_hash, "operations": operations,
                    "journal_lineage": inspection["journal_lineage"],
                }),
                "source_run_id": source_run_id, "source_plan_id": source["plan_id"],
                "source_journal_sha256": source_hash, "snapshot_sha256": snapshot_hash,
                "journal_lineage": inspection["journal_lineage"],
                "recovery_snapshot": inspection["audit_snapshot"],
                "source_resource_ids": [
                    value["resource_id"] for value in inspection["resources"].values()
                    if value["status"] == "present"
                ],
                "operations": [asdict(operation) for operation in operations],
                "writes": access.plain_writes(spec, operations),
                "warnings": [
                    "New exact approval required; retain existing resources without updating them.",
                    "The original uncertain journal stays immutable; reconciliation does not prove deletion ownership.",
                    POLICY_TEXT,
                ],
            }
        inspection, source, snapshot_hash = self._resume_state(spec, source_run_id)
        if spec.search_is_split:
            self._permission_gate(spec)
        original = plan(spec)
        operations = tuple(operation for operation in original.operations if operation.id in (
            "create-storage_account", "create-openai_resource",
        ))
        resume_id = stable_id("public-resume-plan", {
            "source_run_id": source_run_id,
            "source_plan_id": source["plan_id"],
            "snapshot_sha256": snapshot_hash,
            "operations": operations,
        })
        return {
            "plan_id": resume_id, "source_run_id": source_run_id,
            "source_plan_id": source["plan_id"],
            "snapshot_sha256": snapshot_hash,
            "source_resource_ids": [
                inspection["resources"][key]["resource_id"]
                for key in ("create-resource-group", "create-search_service")
            ],
            "operations": [asdict(operation) for operation in operations],
            "warnings": [
                "New approval required: create only Storage and OpenAI; never recreate RG/Search.",
                "The original journal remains uncertain and immutable; cleanup remains manual-only.",
            ],
        }

    def resume_apply(
        self, spec: ProvisioningSpec, source_run_id: str, *,
        approved_plan_id: str, confirmed_public_test: bool = False,
        confirmed_public_data: bool = False,
    ) -> ApplyResult:
        if spec.public_data:
            if not confirmed_public_data:
                raise ApprovalRequired("public-data resume requires explicit billable deployment confirmation")
            review = self.resume_plan(spec, source_run_id)
            if not approved_plan_id or approved_plan_id != review["plan_id"]:
                raise ApprovalRequired(f"explicit approval of resume plan {review['plan_id']} is required")
            inspection, _, snapshot_hash, _ = self._public_data_resume_state(spec, source_run_id)
            baseline = inspection["validated_resources"]
            if snapshot_hash != review["snapshot_sha256"]:
                raise ProvisioningError("resume snapshot changed; a new plan and approval are required")
            if spec.search_sku == "serverless":
                self._search_availability = serverless_preflight(
                    spec, self.search_availability_reader(spec))
            desired = Plan(
                plan_id=review["plan_id"],
                operations=tuple(operation for operation in plan(spec).operations
                                 if inspection["resources"][operation.id]["status"] == "missing"),
            )
            journal_plan = Plan(plan_id=desired.plan_id, operations=plan(spec).operations)
            run_id = self.journal.begin(spec, journal_plan, inspection, resume_from={
                key: review[key] for key in (
                    "source_run_id", "source_plan_id", "source_journal_sha256", "snapshot_sha256",
                    "journal_lineage",
                )
            })
            self._run_started(run_id)
            self.journal.record_recovery_snapshot(run_id, inspection["audit_snapshot"])
            for key, value in inspection["resources"].items():
                if value["status"] == "present":
                    self.journal.update(run_id, key, "verified", evidence={
                        field: item for field, item in value.items() if field != "status"
                    })
            created: dict[str, Any] = {}

            def reconcile() -> dict[str, Any]:
                if hashlib.sha256(self.journal.path(source_run_id).read_bytes()).hexdigest() != review[
                    "source_journal_sha256"
                ]:
                    raise ProvisioningError("source journal changed during recovery")
                current, _, _, _ = self._public_data_resume_state(
                    spec, source_run_id, created=created, active_run_id=run_id)
                observed = current["validated_resources"]
                if any(value != observed[key] for key, value in baseline.items()
                       if key not in created):
                    raise ProvisioningError("resume source snapshot changed before or after write")
                self.journal.record_recovery_snapshot(run_id, current["audit_snapshot"])
                return observed

            def execute(operation: Operation) -> dict:
                reconcile()
                evidence = self._execute_operation(
                    spec, operation, run_id, desired.plan_id, require_missing=True)
                created[operation.id] = None
                created[operation.id] = reconcile()[operation.id]
                return evidence

            result = apply_plan(desired, approved=True, executor=execute)
            self.journal.finish(run_id, result.completed)
            return result
        if not confirmed_public_test:
            raise ApprovalRequired("resume requires explicit billable deployment confirmation")
        review = self.resume_plan(spec, source_run_id)
        if not approved_plan_id or approved_plan_id != review["plan_id"]:
            raise ApprovalRequired(f"explicit approval of resume plan {review['plan_id']} is required")
        inspection, _, fresh_hash = self._resume_state(spec, source_run_id)
        if fresh_hash != review["snapshot_sha256"]:
            raise ProvisioningError("resume snapshot changed; a new plan and approval are required")
        desired = Plan(
            plan_id=review["plan_id"],
            operations=tuple(operation for operation in plan(spec).operations if operation.id in (
                "create-storage_account", "create-openai_resource",
            )),
        )
        run_id = self.journal.begin(spec, desired, inspection, resume_from={
            "source_run_id": source_run_id,
            "source_plan_id": review["source_plan_id"],
            "snapshot_sha256": review["snapshot_sha256"],
        })
        self._run_started(run_id)
        created: list[str] = []

        def execute(operation: Operation) -> dict:
            _, _, current_hash = self._resume_state(spec, source_run_id, created=tuple(created))
            if current_hash != review["snapshot_sha256"]:
                raise ProvisioningError("resume source snapshot changed before write")
            evidence = self._execute_operation(
                spec, operation, run_id, desired.plan_id, require_missing=True,
            )
            created.append(operation.id)
            _, _, current_hash = self._resume_state(spec, source_run_id, created=tuple(created))
            if current_hash != review["snapshot_sha256"]:
                raise ProvisioningError("resume source snapshot changed after write")
            return evidence

        result = apply_plan(desired, approved=True, executor=execute)
        self.journal.finish(run_id, result.completed)
        return result

    def _execute_operation(
        self, spec: ProvisioningSpec, operation: Operation, run_id: str, plan_id: str,
        *, require_missing: bool = False,
    ) -> dict[str, Any]:
        recorder = TelemetryRecorder("provision")
        outcome: dict[str, Any] = {}
        self._active_operation = (run_id, operation.id)
        label = access.plain_writes(spec, (operation,))[0]
        started = time.monotonic()
        finished = threading.Event()

        def waiting() -> None:
            # Long-running Azure creates block in .result(); say so instead of going silent.
            while not finished.wait(self.progress_interval):
                _progress(f"Still waiting on Azure: {label} "
                          f"({_elapsed(time.monotonic() - started)} so far)")

        _progress(f"Starting: {label}")
        threading.Thread(target=waiting, daemon=True).start()
        try:
            with recorder.span(operation.id, resource=operation.resource):
                outcome = self._execute_operation_untimed(
                    spec, operation, run_id, plan_id, require_missing=require_missing,
                )
        except KeyboardInterrupt:
            self._cancelled.set()
            raise
        finally:
            finished.set()
            took = _elapsed(time.monotonic() - started)
            change = outcome.get("change")
            _progress(f"Done: {label} ({'already there' if change == 'existing' else 'created'}, "
                      f"{took})" if change else
                      f"Stopped: {label} after {took}; the run journal records the outcome")
            self._active_operation = None
            event = recorder.events[-1] if recorder.events else None
            if event is not None:
                event["counts"] = {"created": int(outcome.get("change") == "created")}
                try:
                    self.journal.record_telemetry(run_id, event)
                except (OSError, ValueError):
                    pass
        return outcome

    def _execute_operation_untimed(
        self, spec: ProvisioningSpec, operation: Operation, run_id: str, plan_id: str,
        *, require_missing: bool = False,
    ) -> dict[str, Any]:
        client = self._client(spec)
        attempted = False
        try:
            _validate(spec)
            observed = self._get(client, spec, operation)
            if require_missing and observed is not None:
                raise ProvisioningError(
                    f"{operation.id}: resource appeared after "
                    + ("preflight" if spec.public_data else "resume preflight")
                    + "; no update permitted"
                )
            created = observed is None
            if created and operation.resource == "model_deployment":
                self._quota_gate(spec, (_deployment(spec, operation),))
            identity_principal = self._identity_principal(client, spec, operation)
            if created:
                self.journal.update(run_id, operation.id, "uncertain",
                                    reason="create attempted; outcome not confirmed")
                attempted = True
                writer = self._client_for(client, spec, operation)
                if operation.resource == "resource_group":
                    payload = {"location": (
                        spec.effective_search_location
                        if operation.id == "create-search-resource-group"
                        else spec.target.location)}
                    if spec.public_endpoint:
                        payload["tags"] = _public_tags(spec)
                    if spec.network:
                        payload["tags"] = {"entity-run-id": run_id, "entity-plan-id": plan_id}
                    observed = writer.resource_groups.create_or_update(
                        operation.name, payload,
                        headers={"If-None-Match": "*"},
                    )
                else:
                    payload = (
                        network_desired(spec, operation, run_id=run_id,
                                        plan_id=plan_id)
                        if operation.resource in NETWORK_API else
                        _desired(spec, operation, identity_principal=identity_principal)
                    )
                    observed = writer.resources.begin_create_or_update_by_id(
                        _resource_id(spec, operation),
                        payload,
                        api_version=(management_api(spec) if operation.resource == "search_service"
                                     else (NETWORK_API if operation.resource in NETWORK_API
                                           else _API_VERSIONS)[operation.resource]),
                        # Role assignments reject If-None-Match; their name is deterministic.
                        **({} if operation.resource == "role_assignment"
                           else {"headers": {"If-None-Match": "*"}}),
                        # Identity, container and role PUTs complete synchronously. SDK
                        # polling after the identity's 201 sent a request without
                        # api-version; the reread below is the authoritative check.
                        **({"polling": False} if operation.resource in _ACCESS else {}),
                    ).result()
            # Cognitive Services' create API can omit networkAcls.bypass even
            # though the authoritative read API returns the persisted value.
            # Validate newly created accounts from the required post-create
            # reread instead of treating that incomplete create response as drift.
            if not (created and operation.resource == "openai_resource"):
                _evidence(spec, operation, observed, identity_principal=identity_principal)
            verified = self._get(client, spec, operation)
            for _ in range(6 if operation.resource == "role_assignment" else 0):
                if verified is not None:
                    break
                # New role assignments can take a few seconds to become readable.
                self._sleep(5)
                verified = self._get(client, spec, operation)
            if verified is None:
                raise ProvisioningError(f"{operation.id}: resource missing after apply")
            evidence = _evidence(spec, operation, verified, identity_principal=identity_principal)
            if created and spec.network and (
                operation.resource in ("resource_group", "vnet", "zone", "zone_link", "endpoint")
            ):
                expected_tags = {"entity-run-id": run_id, "entity-plan-id": plan_id}
                if any(_field(_field(verified, "tags", {}), key) != value
                       for key, value in expected_tags.items()):
                    raise ProvisioningError(f"{operation.id}: run/plan tags missing after create")
            etag = _field(verified, "etag")
            if isinstance(etag, str):
                evidence["etag"] = etag
            if operation.resource == "model_deployment" and operation.name in self._quota:
                evidence["quota_preflight"] = self._quota[operation.name]
            if (operation.resource == "search_service" and spec.search_sku == "serverless"
                    and self._search_availability):
                evidence["availability_preflight"] = self._search_availability
            self.journal.update(
                run_id, operation.id,
                "create_response_verified" if created else "existing",
                evidence=evidence,
            )
            return {**evidence, "change": "created" if created else "existing"}
        except Exception as error:
            info = service_errors.find(error)
            try:
                self.journal.update(
                    run_id, operation.id, "uncertain" if attempted else "failed",
                    reason=f"{type(error).__name__}: {error}",
                    **({"service_error": info} if info else {}),
                )
            except Exception as journal_error:
                raise ProvisioningError(
                    f"{operation.id}: {error}; journal update failed: {journal_error}"
                ) from journal_error
            raise

    def _identity_principal(self, client: Any, spec: ProvisioningSpec,
                            operation: Operation) -> str | None:
        if operation.resource != "role_assignment":
            return None
        who = access.grant(operation.id, spec)[0]
        if who == "search_system_identity":
            search = self._get(client, spec, Operation(
                "create-search_service", "provision", "ensure", "search_service",
                spec.search_name,
            ))
            principal = _field(_field(search, "identity", {}) or {}, "principalId")
            if not isinstance(principal, str) or not principal:
                raise ProvisioningError(f"{operation.id}: the Search system identity has no principal ID yet")
            return principal
        if who != "search_identity":
            return None
        identity = self._get(client, spec, Operation(
            "create-search-identity", "provision", "ensure", "search_identity",
            spec.build_access.search_identity_name if spec.build_access else "",
        ))
        principal = _field(_field(identity, "properties", {}) or {}, "principalId")
        if not isinstance(principal, str) or not principal:
            raise ProvisioningError(f"{operation.id}: the Search identity has no principal ID yet")
        return principal

    def _search_tenant_gate(self, spec: ProvisioningSpec) -> None:
        """Read-only: a separate Search subscription must belong to the approved tenant."""
        subscription = spec.effective_search_subscription_id
        if subscription.casefold() == spec.target.subscription_id.casefold():
            return
        tenant = spec.public_endpoint.tenant_id if spec.public_endpoint else self.expected_tenant_id
        try:
            record = self.subscription_reader(search_view(spec))
        except Exception as error:
            raise ProvisioningError(
                f"can't read the Search subscription {subscription} in tenant {tenant}: {error}. "
                "It may be in another tenant, or you may lack access to it. No changes were made. "
                f"Next step: choose a Search subscription you can read in tenant {tenant}, "
                "then plan again.") from error
        observed = str(_field(record, "tenantId", "") or "")
        if (str(_field(record, "subscriptionId", "") or "").casefold() != subscription.casefold()
                or not tenant or observed.casefold() != tenant.casefold()):
            raise ProvisioningError(
                f"the Search subscription {subscription} is in tenant {observed or 'unknown'}, "
                f"not the approved tenant {tenant}. Search must be in the same tenant as the "
                "other resources. No changes were made. Next step: choose a Search subscription "
                f"in tenant {tenant}, then plan again.")

    def _permission_gate(self, spec: ProvisioningSpec) -> None:
        """Read-only: each subscription grants every Action the plan needs there."""
        for subscription, actions in scoped_actions(spec).items():
            view = (spec if subscription.casefold() == spec.target.subscription_id.casefold()
                    else search_view(spec))
            try:
                permissions = self.permission_reader(view)
            except Exception as error:
                raise ProvisioningError(
                    f"permission check failed for subscription {subscription}: {error}") from error
            missing = access.missing_actions(permissions, actions)
            if not missing:
                continue
            others = [action for action in missing if action != access.ROLE_WRITE]
            also = f" Your role there also lacks: {', '.join(others)}." if others else ""
            if access.ROLE_WRITE in missing:
                raise ProvisioningError(
                    f"you can't assign roles in subscription {subscription}, so setup would "
                    f"stop halfway.{also} No changes were made. Next step: ask for Owner or Role "
                    "Based Access Control Administrator on the subscription, then rerun apply "
                    "with the same plan.")
            raise ProvisioningError(
                f"your role in subscription {subscription} doesn't allow: {', '.join(others)}, "
                "so setup would stop halfway. No changes were made. Next step: ask for a role "
                "that grants these actions on the subscription, then rerun apply with the "
                "same plan.")

    def _quota_gate(self, spec: ProvisioningSpec,
                    deployments: tuple[ModelDeploymentSpec, ...]) -> None:
        try:
            quota = self.quota_reader(spec)
        except Exception as error:
            raise ProvisioningError(f"quota preflight failed: {error}") from error
        report = quota_preflight(spec, quota, deployments=deployments)
        for row in report["deployments"]:
            self._quota[row["deployment"]] = {
                key: row[key] for key in ("quota_name", "quota_current_k_tpm",
                                          "quota_limit_k_tpm", "requested_capacity_k_tpm")
            }
        if report["blocked"]:
            raise ProvisioningError("quota preflight blocked: " + "; ".join(
                blocker for row in report["deployments"] for blocker in row["blockers"]
            ))

    def _apply_approved(self, spec: ProvisioningSpec, *, approved_plan_id: str,
                        allow_live: bool = False) -> ApplyResult:
        """Guarded execution path; only bounded public modes may use live clients."""
        if self._injected_client is None and not (allow_live and spec.public_endpoint):
            raise ProvisioningError("the internal execution path requires an injected test client")
        _validate(spec)
        if spec.public_data is None:
            desired_plan = plan(spec)
            if not approved_plan_id or approved_plan_id != desired_plan.plan_id:
                raise ApprovalRequired(
                    f"explicit approval of plan {desired_plan.plan_id} is required"
                )
        self._search_tenant_gate(spec)
        self._search_availability = {}
        if spec.search_sku == "serverless":
            self._client(spec)
            try:
                self._search_availability = serverless_preflight(
                    spec, self.search_availability_reader(spec))
            except (ValueError, IdentityError) as error:
                raise ProvisioningError(f"Search availability check failed: {error}") from error
        inspection = self.inspect(spec)
        kept = kept_operations(inspection) if spec.public_data else frozenset()
        if spec.public_data is not None:
            desired_plan = plan(spec, kept=kept)
            if not approved_plan_id or approved_plan_id != desired_plan.plan_id:
                raise ApprovalRequired(
                    f"explicit approval of plan {desired_plan.plan_id} is required; what "
                    "already exists in Azure changed since the plan, so plan again")
        if spec.public_test and inspection["resources"]["create-resource-group"]["status"] != "missing":
            raise ProvisioningError("public test requires an absent isolated resource group")
        search_group = inspection["resources"].get("create-search-resource-group")
        if spec.public_test and search_group and search_group["status"] != "missing":
            raise ProvisioningError(
                "public test requires an absent isolated resource group for Search")
        if inspection["resources"]["create-resource-group"]["status"] == "missing" and not spec.create_resource_group:
            raise ProvisioningError("resource group is missing; approve a plan with create_resource_group")
        missing_deployments = tuple(
            deployment for deployment in spec.model_deployments
            if inspection["resources"][f"create-{deployment.role}-deployment"]["status"] == "missing"
        )
        if missing_deployments:
            # Read-only quota gate before any write in this run.
            self._quota_gate(spec, missing_deployments)
        if spec.build_access is not None or spec.search_is_split:
            # Read-only check of every needed Action, per subscription, before any write.
            self._permission_gate(spec)
        run_id = self.journal.begin(spec, desired_plan, inspection)
        self._run_started(run_id)

        def execute(operation: Operation) -> dict:
            # Kept resources are re-read and checked; everything else must still be missing.
            return self._execute_operation(
                spec, operation, run_id, desired_plan.plan_id,
                require_missing=spec.public_data is not None and operation.id not in kept,
            )

        result = apply_plan(desired_plan, approved=True, executor=execute)
        self.journal.finish(run_id, result.completed)
        return result


def kept_operations(inspection: dict[str, Any]) -> frozenset[str]:
    """Operations whose resource already exists (and passed inspection's checks)."""
    return frozenset(key for key, value in inspection["resources"].items()
                     if value["status"] == "present")


class _ArmReads:
    """Read-only ARM client over a JSON reader, for the existence check `plan` runs."""

    def __init__(self, spec: ProvisioningSpec, reader: Callable[..., Any],
                 subscription: str | None) -> None:
        arm = "https://management.azure.com"
        self.resource_groups = SimpleNamespace(get=lambda name: reader(
            spec, "get", f"{arm}/subscriptions/{subscription}/resourcegroups/{name}"
                         "?api-version=2021-04-01"))
        self.resources = SimpleNamespace(get_by_id=lambda resource_id, api_version: reader(
            spec, "get", f"{arm}{resource_id}?api-version={api_version}"))


def existing_resources(spec: ProvisioningSpec, reader: Callable[..., Any]) -> frozenset[str]:
    """Plan-time existence check, the same one apply runs: the operations to keep.

    Raises ProvisioningError when something already exists that this plan can't keep.
    """
    backend = AzureSdkBackend(
        client=_ArmReads(spec, reader, spec.target.subscription_id),
        search_client=_ArmReads(spec, reader, spec.effective_search_subscription_id))
    return kept_operations(backend.inspect(spec))
