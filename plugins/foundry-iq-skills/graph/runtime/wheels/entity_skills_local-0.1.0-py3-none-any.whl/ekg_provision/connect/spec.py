import re
import subprocess
from dataclasses import dataclass
from typing import Any, Callable
from ..capacity import API_VERSION as OPENAI_API_VERSION
from ekg_core.az_identity import IdentityError, az_json
from ekg_core.models import TPM_CAPACITY_SKUS
ARM = "https://management.azure.com"
DEFAULT_RUNNER: Callable[..., Any] = subprocess.run
SEARCH_DATA_API_VERSION = "2024-07-01"
_TYPES = {"search": ("Microsoft.Search/searchServices", "2025-05-01"), "storage": ("Microsoft.Storage/storageAccounts", "2023-05-01"), "openai": ("Microsoft.CognitiveServices/accounts", OPENAI_API_VERSION), "identity": ("Microsoft.ManagedIdentity/userAssignedIdentities", "2023-01-31")}
_ID = re.compile(r"/subscriptions/([^/]+)/resourceGroups/([^/]+)/providers/"
                 r"([^/]+/[^/]+)/([^/]+)", re.IGNORECASE)
ACCEPTED_ROLES = {
    "Search Service Contributor": ("Search Service Contributor", "Contributor", "Owner"),
    "Search Index Data Contributor": ("Search Index Data Contributor",),
    "Storage Blob Data Contributor": ("Storage Blob Data Contributor", "Storage Blob Data Owner"),
    "Storage Table Data Contributor": ("Storage Table Data Contributor",),
    "Storage Blob Data Reader": ("Storage Blob Data Reader", "Storage Blob Data Contributor",
                                 "Storage Blob Data Owner"),
}
UNVERIFIED_ROLE = ("No active assignment to this principal, or to any group it belongs to "
                   "(nested groups included), was found at this scope or above. "
                   "PIM-eligible and conditional grants are not inferred.")
# Data-plane embeddings call, used only with --probe-embedding-dimensions:
# https://learn.microsoft.com/azure/ai-foundry/openai/reference#embeddings
PROBE_EMBEDDINGS_API = "2024-10-21"


def probe_embedding_dimensions(endpoint: str, deployment: str,
                               runner: Callable[..., Any]) -> int:
    """One embeddings call on a fixed string; returns the vector length."""
    import json
    url = (f"{endpoint.rstrip('/')}/openai/deployments/{deployment}/embeddings"
           f"?api-version={PROBE_EMBEDDINGS_API}")
    body = json.dumps({"input": "dimension probe"})
    result = az_json(["rest", "--method", "post", "--url", url, "--body", body,
                      "--headers", "Content-Type=application/json",
                      "--resource", "https://cognitiveservices.azure.com"], runner=runner)
    vector = (((result or {}).get("data") or [{}])[0] or {}).get("embedding")
    if not isinstance(vector, list) or not vector:
        raise IdentityError("the embeddings response had no vector")
    return len(vector)
class ConnectError(RuntimeError):
    pass
@dataclass(frozen=True)
class ConnectSpec:
    tenant_id: str
    subscription_id: str | None = None
    resource_group: str | None = None
    search: str | None = None
    storage: str | None = None
    openai: str | None = None
    storage_container: str | None = None
    embedding_deployment: str | None = None
    chat_deployment: str | None = None
    search_identity_resource_id: str | None = None
    embedding_dimensions: int | None = None
    documents: int | None = None
    cache_storage: str | None = None
    cache_same_as_source: bool = False
    embedding_openai: str | None = None
    chat_openai: str | None = None
    kb_openai: str | None = None
    kb_chat_deployment: str | None = None
    use_system_identity: bool = False
    # New-deployment choices when a named deployment is missing; None = recommended default.
    embedding_model: str | None = None
    embedding_model_version: str | None = None
    embedding_sku: str | None = None
    embedding_capacity: int | None = None
    chat_model: str | None = None
    chat_model_version: str | None = None
    chat_sku: str | None = None
    chat_capacity: int | None = None
    probe_embedding_dimensions: bool = False
    # Search placed apart from storage and models (default: subscription_id, resource_group).
    search_subscription_id: str | None = None
    search_resource_group: str | None = None
    run_prefix: str | None = None
    @property
    def search_subscription(self) -> str:
        return self.search_subscription_id or str(self.subscription_id)
    @property
    def search_group(self) -> str | None:
        return self.search_resource_group or self.resource_group
    def __post_init__(self) -> None:
        if self.run_prefix is not None:
            from ekg_core.run_naming import context
            context(self.run_prefix)
        guid = r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"
        if not isinstance(self.tenant_id, str) or not re.fullmatch(guid, self.tenant_id):
            raise ValueError("connect needs explicit tenant and subscription GUIDs")
        for key in ("openai", "embedding_openai", "chat_openai", "kb_openai"):
            value = getattr(self, key)
            if value is not None and not _ID.fullmatch(str(value)):
                flag = key.replace("_", "-")
                raise ValueError(f"--{flag}-resource-id must be the exact account resource ID "
                                 "returned by `entity-graph-provision discover`")
        sub = self.subscription_id
        if sub is None:
            for candidate in (
                self.search, self.storage, self.openai, self.cache_storage,
                self.embedding_openai, self.chat_openai, self.kb_openai,
                self.search_identity_resource_id,
            ):
                m = _ID.fullmatch(str(candidate or ""))
                if m and re.fullmatch(guid, m.group(1)):
                    sub = m.group(1)
                    object.__setattr__(self, "subscription_id", sub)
                    break
        if not isinstance(sub, str) or not re.fullmatch(guid, sub):
            raise ValueError("connect needs explicit tenant and subscription GUIDs")
        if self.search_subscription_id is not None and not re.fullmatch(
                guid, str(self.search_subscription_id)):
            raise ValueError("--search-subscription-id must be a subscription GUID")
        if self.search_resource_group is not None and not re.fullmatch(
                r"[-\w.()]{0,89}[-\w()]", str(self.search_resource_group)):
            raise ValueError("--search-resource-group must be a resource group name")
        placed = _ID.fullmatch(str(self.search or ""))
        if placed and (
            (self.search_subscription_id
             and placed.group(1).casefold() != self.search_subscription_id.casefold())
            or (self.search_resource_group
                and placed.group(2).casefold() != self.search_resource_group.casefold())):
            raise ValueError(
                f"--search-resource-id is in subscription {placed.group(1)}, resource group "
                f"{placed.group(2)}, which doesn't match --search-subscription-id or "
                "--search-resource-group; pass the resource ID alone, or matching values")
        for key in ("embedding_dimensions", "documents", "embedding_capacity", "chat_capacity"):
            value = getattr(self, key)
            if value is not None and (not isinstance(value, int) or isinstance(value, bool)
                                      or value < 1):
                raise ValueError(f"{key} must be a positive integer")
        for role in ("embedding", "chat"):
            sku = getattr(self, f"{role}_sku")
            if sku and sku not in TPM_CAPACITY_SKUS and getattr(self, f"{role}_capacity") is None:
                raise ValueError(f"--{role}-sku {sku} does not count capacity in tokens per "
                                 f"minute; pass --{role}-capacity from `entity-graph-provision "
                                 "discover --models-for`")
def _check(checks: list[dict[str, Any]], check_id: str, status: str, detail: str,
           **evidence: Any) -> None:
    checks.append({"id": check_id, "status": status, "detail": detail,
                   **({"evidence": evidence} if evidence else {})})
def _subscription(resource_id: str | None, fallback: str | None = None) -> str:
    if isinstance(resource_id, str):
        match = re.match(r"^/subscriptions/([^/]+)/", resource_id, re.IGNORECASE)
        if match:
            return match.group(1)
    return fallback or ""
def _resource_id(spec: ConnectSpec, kind: str, value: str | None) -> str | None:
    if value is None:
        return None
    if kind == "identity" and value.strip().lower() in (
        "system", "systemassigned", "system-assigned", "system_assigned",
    ):
        return "system"
    provider = _TYPES[kind][0]
    match = _ID.fullmatch(value)
    if match:
        guid = r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}"
        if not re.fullmatch(guid, match.group(1)):
            raise ValueError(f"{kind} resource ID has an invalid subscription GUID")
        if match.group(3).lower() != provider.lower():
            raise ValueError(f"{kind} resource ID must be a {provider}")
        return value
    if "/" in value:
        raise ValueError(f"{kind} must be a resource name or an exact ARM resource ID")
    if kind == "search":
        if not spec.search_group:
            raise ValueError(f"--search-resource-group or --resource-group is required to "
                             f"resolve search name {value}")
        return (f"/subscriptions/{spec.search_subscription}/resourceGroups/{spec.search_group}"
                f"/providers/{provider}/{value}")
    if not spec.resource_group:
        raise ValueError(f"--resource-group is required to resolve {kind} name {value}")
    return (f"/subscriptions/{spec.subscription_id}/resourceGroups/{spec.resource_group}"
            f"/providers/{provider}/{value}")
def _region(value: Any) -> str | None:
    """ARM returns display names for some services (``East US 2``); Build uses ``eastus2``."""
    return str(value).replace(" ", "").lower() if value else None
def _canonical(resource_id: str) -> str:
    """ARM may return lowercase segment names (``resourcegroups``); Build needs one form."""
    match = _ID.fullmatch(resource_id)
    if not match:
        return resource_id
    return (f"/subscriptions/{match.group(1)}/resourceGroups/{match.group(2)}/providers/"
            f"{match.group(3)}/{match.group(4)}")
def _parts(resource_id: str) -> tuple[str, str]:
    match = _ID.fullmatch(resource_id)
    assert match is not None
    return match.group(2), match.group(4)
def _show(resource_id: str, kind: str, runner: Callable[..., Any]) -> dict[str, Any] | None:
    try:
        observed = az_json(["resource", "show", "--ids", resource_id,
                            "--api-version", _TYPES[kind][1]], runner=runner)
    except IdentityError:
        return None
    if not isinstance(observed, dict) or str(observed.get("id", "")).lower() != resource_id.lower():
        return None
    return observed
def _get(url: str, runner: Callable[..., Any], resource: str | None = None) -> Any:
    args = ["rest", "--method", "get", "--url", url]
    return az_json(args + (["--resource", resource] if resource else []), runner=runner)
from ..discovery import MODEL_HOSTING_KINDS as FOUNDRY_ACCOUNT_KINDS

# Model accounts are chosen only through `entity-graph-provision discover`; connect never
# enumerates or guesses them.
DISCOVER_HINT = {
    "command": "entity-graph-provision discover --tenant-id <tenant>",
    "requires_explicit_selection": True,
    "detail": "No Foundry/OpenAI account was selected. Ask whether to use the signed-in "
              "subscription, by name; list subscriptions with discover only if the user wants "
              "another. Run `discover --subscription-id <sub>`, show the resource table, ask "
              "which model to use for each role by name, and pass the flags `discover "
              "--subscription-id <sub> --row <N> --discovery-id <id> --role <role>` returns.",
    "account_kinds": list(FOUNDRY_ACCOUNT_KINDS),
}


def _candidates(
    spec: ConnectSpec, kind: str, runner: Callable[..., Any],
) -> list[dict[str, Any]] | dict[str, Any]:
    if kind == "openai":
        return dict(DISCOVER_HINT)
    sub_id = spec.search_subscription if kind == "search" else spec.subscription_id
    group = spec.search_group if kind == "search" else spec.resource_group
    args = ["resource", "list", "--resource-type", _TYPES[kind][0],
            "--subscription", str(sub_id)]
    if group:
        args += ["--resource-group", group]
    try:
        listed = az_json(args, runner=runner)
    except IdentityError:
        return []
    results: list[dict[str, Any]] = []
    for item in listed or []:
        if not isinstance(item, dict):
            continue
        raw_id = str(item.get("id") or "")
        match = _ID.fullmatch(raw_id)
        results.append({
            "name": item.get("name"),
            "resource_id": _canonical(raw_id) if raw_id else None,
            "subscription_id": match.group(1) if match else sub_id,
            "resource_group": match.group(2) if match else (item.get("resourceGroup") or group),
            "location": item.get("location"),
            "kind": item.get("kind"),
            "sku": (item.get("sku") or {}).get("name"),
        })
    return sorted(results, key=lambda row: (str(row["resource_group"] or "").casefold(),
                                            str(row["name"] or "").casefold()))
def _search_tenant(spec: ConnectSpec, search_sub: str, checks: list[dict[str, Any]],
                   runner: Callable[..., Any]) -> bool:
    """Read-only: Search in another subscription must be in the connect tenant."""
    url = f"https://management.azure.com/subscriptions/{search_sub}?api-version=2022-12-01"
    try:
        observed = _get(url, runner)
    except IdentityError as error:
        _check(checks, "search.subscription_tenant", "fail",
               f"Can't read the Search subscription {search_sub} from tenant {spec.tenant_id} "
               f"({error}). It may be in another tenant, or you may lack Reader on it. Choose "
               f"a Search service in a subscription you can read in tenant {spec.tenant_id}, "
               "or ask for Reader on that subscription, then run connect again.",
               subscription_id=search_sub)
        return False
    tenant = str((observed or {}).get("tenantId") or "") if isinstance(observed, dict) else ""
    if tenant.casefold() != spec.tenant_id.casefold():
        _check(checks, "search.subscription_tenant", "fail",
               f"The Search subscription {search_sub} is in tenant {tenant or 'unknown'}, not "
               f"{spec.tenant_id}. Search must be in the same tenant as the other resources "
               f"and your sign-in. Choose a Search service in tenant {spec.tenant_id}, then "
               "run connect again.", subscription_id=search_sub, tenant_id=tenant or None)
        return False
    _check(checks, "search.subscription_tenant", "ok",
           f"Search subscription {search_sub} is in tenant {spec.tenant_id}.",
           subscription_id=search_sub)
    return True


def _props(observed: dict[str, Any] | None) -> dict[str, Any]:
    return (observed or {}).get("properties") or {}
def _network(checks: list[dict[str, Any]], kind: str, props: dict[str, Any],
             reach: str) -> dict[str, Any]:
    acls = props.get("networkAcls") or props.get("networkRuleSet") or {}
    public = props.get("publicNetworkAccess")
    summary = {"public_network_access": public, "default_action": acls.get("defaultAction"),
               "bypass": acls.get("bypass"), "ip_rules": len(acls.get("ipRules") or []),
               "private_endpoints": len(props.get("privateEndpointConnections") or []),
               "service_to_service_access": "unverified"}
    if str(public).lower() == "securedbyperimeter":
        _check(checks, f"{kind}.network", "warn",
               f"Network security perimeter access is restricted. Verify {reach} for each "
               "caller and service-to-service leg; a successful host probe proves neither.",
               **summary)
    elif str(public).lower() == "disabled":
        _check(checks, f"{kind}.network", "warn",
               f"Public network access is disabled. {reach} needs private connectivity "
               "(private endpoint or shared private link); a host probe does not verify "
               "service-to-service access.", **summary)
    elif str(public).lower() != "enabled":
        _check(checks, f"{kind}.network", "warn",
               f"Public network access state is unknown. Verify {reach} separately; "
               "host access does not establish service-to-service access.", **summary)
    elif str(acls.get("defaultAction", "")).lower() == "deny" or summary["ip_rules"]:
        _check(checks, f"{kind}.network", "warn",
               f"A network firewall is on. {reach} must be allowed by an IP, trusted-service "
               "or resource-instance rule; the data-plane probe checks this host only.",
               **summary)
    else:
        _check(checks, f"{kind}.network", "ok", "Public network access is enabled; host probes "
               "do not establish service-to-service access or authorization.", **summary)
    return summary
