"""House style shared by every entity-skills CLI.

* argparse subparsers; a bare invocation prints help.
* A 3-6 line human summary by default; ``--json`` (before or after the verb) prints the
  full result.
* Every blocked or error result is ``{"status": "blocked", "error_code", "error",
  "next_step"}`` with exit code 2. ``next_step`` comes from :data:`NEXT_STEPS`, one table
  keyed by ``error_code``.
"""

from __future__ import annotations

import argparse
import json
import re
import string
import sys
from pathlib import Path
from typing import Any, NoReturn, Sequence

from . import service_errors

EXIT_BLOCKED = 2

# One next step per error code. Placeholders are filled from the blocking context; any
# placeholder without a value is rendered as ``<name>``.
NEXT_STEPS: dict[str, str] = {
    "USAGE": "Run `{prog} {command} --help` and supply the missing or corrected flags.",
    "NODE_REQUIRED": "Tell the user in one line to install Node.js 22 LTS (22.13 or later) from "
                     "nodejs.org, then run `{prog}` again. Don't look for Node yourself.",
    "PLAYGROUND_FAILED": "Tell the user in one plain line that it didn't start, then run `{prog}` again "
                         "once; if it fails again, say so and stop. The launcher's log is `log`.",
    "PLAYGROUND_UNAVAILABLE": "Reinstall the plugin, then run `{prog}` again.",
    "WORKSPACE_CONFIG_EXISTS": "Launch with the existing {path}, choose another --output, or add "
                               "--replace to overwrite it.",
    "WORKSPACE_OUTPUT_INVALID": "Choose an --output path outside the installed plugin, such as "
                                "your workspace folder.",
    "INVALID_INPUT": "Correct the input named in the error, then run `{prog} {command}` again.",
    "LOCAL_IO": "Check that the named local file or folder exists and is readable or "
                "writable, then run `{prog} {command}` again.",
    "APPROVAL_REQUIRED": "Review the plan with `{prog} {plan_verb}`, get explicit approval "
                         "of its plan ID, then run `{prog} {command}` with the same flags "
                         "plus --plan-id <approved-id> --confirm-writes.",
    "TENANT_MISMATCH": "Name the intended tenant, then select it with `az login --tenant "
                       "<tenant-id>` and run `{prog} doctor --tenant-id <tenant-id>`.",
    "AZ_SIGNIN": "Name the intended tenant, then sign in with `az login --tenant "
                 "<tenant-id>` and run `{prog} doctor --tenant-id <tenant-id>`.",
    "AZURE_ERROR": "Run `{prog} doctor` to check sign-in and access, then retry the "
                   "read-only command; never retry a write whose outcome is unknown.",
    "PLAN_BLOCKED": "Resolve the first blocker, then run `{prog} plan` again and review "
                    "the new plan ID.",
    "APPLY_INCOMPLETE": "Run `{prog} reconcile` with the same flags to learn the outcome; "
                        "do not re-run apply until reconcile says it is safe.",
    "RETIRE_BLOCKED": "Resolve the blocker, then run `{prog} plan-retire` again and review "
                      "the new plan ID.",
    "RETIRE_STOPPED": "Run `{prog} plan-retire` again with the same flags to see what is "
                      "left, and approve that new plan ID.",
    "UPDATE_BLOCKED": "Resolve the blocker, then run `{prog} plan-update` again and review "
                      "the new plan ID.",
    "UPDATE_WAITING": "Run `{prog} update` again with the same --plan-id to finish; it "
                      "resumes from the journal.",
    "UPDATE_STOPPED": "Run `{prog} update` again with the same --plan-id; it resumes from "
                      "the journal and never repeats a write whose outcome is unknown.",
    "UPDATE_INCONSISTENT": "Rebuild with `{prog} plan` and `{prog} apply`; the in-place update "
                           "left the graph inconsistent.",
    "ATTACH_BLOCKED": "Resolve the blocker, then run `{prog} plan-attach-ontology` again and "
                      "review the new plan ID.",
    "ATTACH_WAITING": "Run `{prog} attach-ontology` again with the same --plan-id to finish; "
                      "it resumes from the journal.",
    "ATTACH_STOPPED": "Fix the cause, then run `{prog} attach-ontology` again with the same "
                      "--plan-id; it resumes from the journal.",
    "ATTACH_STALE": "The Knowledge Source changed after review and nothing was written; run "
                    "`{prog} plan-attach-ontology` again and approve the new plan ID.",
    "ATTACH_INCONSISTENT": "Retire the generation and rebuild with `{prog} plan` and "
                           "`{prog} apply`; the attached graph did not verify.",
    "INGESTION_PARTIAL": "Some documents did not ingest, so the build is paused, not "
                         "finished. Run `{prog} failures` with the same flags and show the "
                         "user the failed documents and errors. Then ask them to choose: (A) "
                         "investigate and fix the failures, or (B) run `{prog} accept-failures "
                         "--acceptance-id <id>` with the same flags and then `{prog} reconcile` "
                         "to continue to the next step. When `failures` also shows a retry ID, "
                         "offer (C) retry once with `{prog} retry-failures --retry-id <id>`. "
                         "Never stop without offering every choice shown.",
    "ATTACH_PARTIAL": "Some documents failed graph extraction, so attach is paused, not "
                      "finished. Run `{prog} failures` with the same flags and show the user "
                      "the failed documents and errors. Then ask them to choose: (A) "
                      "investigate and fix the failures (rerunning attach-ontology without "
                      "accepting retries the indexer), or (B) run `{prog} accept-failures "
                      "--acceptance-id <id>` with the same flags, then `{prog} attach-ontology` "
                      "again with the same --plan-id. Never stop without offering both.",
    "SOURCE_UNAVAILABLE": "Check the source location and your read access to it, then run "
                          "`{prog} inventory` again.",
    "RBAC_BLOCKED": "Resolve the blocker, then run `{prog} plan-rbac` again and review the "
                    "new plan ID.",
    "DOCTOR_CACHE_ROLES": "Run `entity-graph-provision connect` (or `entity-graph-provision plan`) "
                          "to grant Storage Blob Data Contributor and Storage Table Data "
                          "Contributor to the Search identity on {scope}.",
    "CACHE_ROLES_MISSING": "Run `entity-graph-provision connect` to grant the Search identity "
                           "Storage Blob Data Contributor and Storage Table Data Contributor on "
                           "the cache storage account.",
    "BUILD_BLOCKED": "Resolve the blocker in the plan, then run `{prog} plan` again.",
    "SYNC_IN_PROGRESS": "Indexing is still running in Azure AI Search. Run `{prog} verify` again "
                        "with the same flags; it waits inside the command (pass a larger "
                        "--timeout to wait longer). Never write a shell polling loop, and do not "
                        "re-run plan or apply.",
    "SYNC_FAILED": "{advice} Do not re-run plan or apply.",
    "SYNC_RETRY_EXHAUSTED": "Search kept asking for a retry after every indexer rerun; nothing "
                            "is lost and the approval still holds. Resume with {resume}. Do not "
                            "re-run plan or apply, and never write a shell polling loop.",
    "GENERATION_MISMATCH": "Check status with `{prog} progress --descriptor {descriptor}` and "
                           "no other flags; it reads the published generation. Never rebuild "
                           "flags or judge progress from elapsed time.",
    "PROVISION_INCOMPLETE": "Run `{prog} inspect` with the same flags, then review "
                            "`{prog} plan-resume`; never retry an unknown-outcome write.",
    "PROVISION_FAILED": "Run `{prog} inspect` with the same flags to see what exists, then "
                        "review `{prog} plan-resume` before any further write.",
    "PUBLIC_DATA_STOPPED": "Run `{prog} inspect` with the same flags and review the local "
                           "journal. Do not retry, resume or clean up automatically. "
                           "Review `{prog} plan-resume` against the original run and "
                           "obtain new exact approval of the reconciled remaining operations "
                           "before further provisioning; cleanup needs separate approval.",
    "POLICY_DENIED": "Nothing was created. Show the user which Azure Policy blocks which "
                     "resource. {advice} Then run `{prog} plan` again with the other flags "
                     "unchanged and show the new approval card. Don't suggest policy "
                     "exemptions, portal changes or private networking: Serverless Search "
                     "can't reach storage or models that only allow private access.",
    "EXISTING_RESOURCE_CONFLICT": "Nothing was created. Tell the user what's in the way, then "
                                  "run `{prog} plan` again with a new resource group name, "
                                  "such as {suggested_group}, or the same settings the "
                                  "earlier plan used.",
    "MODEL_UNAVAILABLE": "Nothing was created. Tell the user in one plain line what's missing "
                         "in {region}, then offer {offer}, and run `{prog} plan` again with "
                         "the same other flags.",
    "MODEL_QUOTA_SHORT": "Nothing was created. Tell the user {region} doesn't have room for "
                         "the models, then offer a smaller capacity, another model, or "
                         "another region for the models (--location), and run `{prog} plan` "
                         "again.",
    "SEARCH_REGION_UNAVAILABLE": "Nothing was created. Show the user the error, then ask "
                                 "for a Search region that offers Serverless (--search-location, "
                                 "check the spelling of {search_location}) or another "
                                 "subscription for Search (--search-subscription-id with "
                                 "--search-resource-group), and run `{prog} plan` again.",
    "SMOKE_FAILED": "Run `{prog} inspect` to confirm what exists, then review "
                    "`{prog} plan-smoke` again.",
    "CAPACITY_BLOCKED": "Resolve the blocker, then run `{prog} plan-capacity` again and "
                        "review the new plan ID.",
    "CONNECT_BLOCKED": "Resolve the first blocker, then run `{prog} connect` again.",
    "DISCOVERY_BLOCKED": "Sign in with `az login` to the target tenant, then run `{prog} discover` again.",
    "DESCRIPTOR_INVALID": "Publish a build with `entity-graph-build publish`, or pass --descriptor "
                          "<file>.",
    "CAPABILITY_UNAVAILABLE": "Use an operation the descriptor advertises; run "
                              "`entity-graph-consume capabilities --descriptor <path>` to list them.",
    "CONSUME_FAILED": "Run `entity-graph-consume doctor --descriptor <path>` to check the descriptor "
                      "and reader access, then retry the read-only query.",
    "DOCTOR_CLI_VERSION": "For a supplied distribution, run "
                          '`python -I "<plugin-root>\\graph\\runtime\\bootstrap.py" setup entity`, then '
                          '`python -I "<plugin-root>\\graph\\runtime\\bootstrap.py" run entity {prog} '
                          "doctor`. If that bootstrap is absent, follow canonical source "
                          "CONTRIBUTING.md to refresh its explicitly prepared local virtual environment.",
    "DOCTOR_PYTHON": "Use a Python version the plugin supports (listed in its README) for explicit "
                     "distribution setup or recreate the source "
                     "checkout's local virtual environment using CONTRIBUTING.md; then run `{prog} doctor`. "
                     "Do not change global tools or shell profiles.",
    "DOCTOR_AZURE_SIGNIN": "Name the intended tenant, then run `az login --tenant "
                           "<tenant-id>` yourself and run `{prog} doctor --tenant-id "
                           "<tenant-id>` again.",
    "DOCTOR_STATE_DIR": "Make the state folder writable (or pass a writable "
                        "--state-dir), and remove leftover *.tmp files only after checking "
                        "no other command is running.",
    "DOCTOR_JOURNAL": "Run `{prog} {journal_verb}` with the same flags before anything "
                      "else; never re-run a write whose outcome is unknown.",
    "DOCTOR_DESCRIPTOR": "Pass --descriptor with a readable published descriptor written by "
                         "`entity-graph-build publish --output`.",
    "DOCTOR_SEARCH_READER": "Ask an owner of the Search service to grant your identity "
                            "Search Index Data Reader on the index, then run `{prog} doctor` "
                            "again.",
    "DOCTOR_GROUNDING_INDEX": "Use an existing Search index with an edgeList graph profile "
                              "(entity-graph-skills never creates one), readable by your identity, "
                              "with label rows (rdfs:label / skos:altLabel) whose graph_name "
                              "equals the plan's grounding.graph_name; then run `{prog} "
                              "doctor` again.",
    "GROUNDING_INDEX_UNREADABLE": "Ask an owner of the Search service to run `az role "
                                  "assignment create --assignee <your-object-id> --role "
                                  "\"Search Index Data Reader\" --scope "
                                  "<search-service-resource-id>`, then run `{prog} doctor` "
                                  "again.",
    "GROUNDING_INDEX_NOT_FOUND": "Check the grounding index name and Search endpoint (the "
                                 "index must already exist; entity-graph-skills never creates it), "
                                 "then run `{prog} doctor` again.",
    "DOCTOR_MODEL_ROLE": "Ask an owner to verify model-list authorization at {scope}: "
                         "assigned role-definition permissions, groups, active PIM, conditions "
                         "and deny policy. Do not infer a missing role or grant one automatically; "
                         "any optional grant needs separate approval. Then run `{prog} doctor` again.",
    "DOCTOR_MODEL_ENDPOINT": "Pass --openai-endpoint with the account's https endpoint (as "
                             "shown by `entity-graph-provision connect`), then run `{prog} doctor` again.",
    "DOCTOR_MODEL_DEPLOYMENT": "Fix the deployment name (list them with `entity-graph-provision "
                               "connect`), then run `{prog} doctor` again.",
}


class Blocked(Exception):
    """A blocked result with a known error code; ``result`` is merged into the envelope."""

    def __init__(self, code: str, error: str, *, result: dict[str, Any] | None = None,
                 service_error: dict[str, Any] | None = None, **context: Any) -> None:
        if code not in NEXT_STEPS:
            raise KeyError(f"unknown error_code {code}")
        super().__init__(error)
        self.code = code
        self.error = error
        self.result = result
        self.context = context
        if service_error:
            self.service_error = dict(service_error)


class _Defaults(dict):
    def __missing__(self, key: str) -> str:
        return f"<{key}>"


def next_step(code: str, **context: Any) -> str:
    template = NEXT_STEPS[code]
    values = _Defaults({"plan_verb": "plan", "journal_verb": "reconcile", "command": "",
                        **{k: v for k, v in context.items() if v is not None}})
    text = " ".join(string.Formatter().vformat(template, (), values).split())
    return re.sub(r" +`(?=[\s.,;:)]|$)", "`", text)


def envelope(code: str, error: str, *, service_error: dict[str, Any] | None = None,
             **context: Any) -> dict[str, Any]:
    body = {"status": "blocked", "error_code": code, "error": error,
            "next_step": next_step(code, **context)}
    if service_error:
        body["service_error"] = service_error
    return body


_JSON_MODE = False


def json_mode() -> bool:
    return _JSON_MODE


def emit_blocked(code: str, error: str, *, result: dict[str, Any] | None = None,
                 service_error: dict[str, Any] | None = None, **context: Any) -> NoReturn:
    body = {**(result or {}), **envelope(code, error, service_error=service_error, **context)}
    if _JSON_MODE:
        print(json.dumps(body, indent=2, default=str))
    else:
        print(f"Blocked ({code}): {error}")
        if service_error:
            detail = service_errors.summary(service_error)
            if detail not in error:
                print(f"Service error: {detail}")
        print(f"Next: {body['next_step']}")
    raise SystemExit(EXIT_BLOCKED)


def _result_service_error(result: dict[str, Any] | None) -> dict[str, Any] | None:
    result = result if isinstance(result, dict) else {}
    if isinstance(result.get("service_error"), dict):
        return result["service_error"]
    for event in reversed(result.get("events") or []):
        data = event.get("data") if isinstance(event, dict) else None
        if isinstance(data, dict) and isinstance(data.get("service_error"), dict):
            return data["service_error"]
    return None


def report(error: Blocked, *, prog: str, command: str,
           cause: BaseException | None = None) -> NoReturn:
    """Emit ``error``; ``service_error`` comes from it, its causes, ``cause`` or its result."""
    info = (service_errors.find(error) or service_errors.find(cause)
            or _result_service_error(error.result))
    emit_blocked(error.code, error.error, result=error.result, service_error=info,
                 **{"prog": prog, "command": command, **error.context})


class HouseParser(argparse.ArgumentParser):
    """Argument errors use the blocked envelope with code USAGE and exit code 2."""

    def error(self, message: str) -> NoReturn:
        prog, _, command = self.prog.partition(" ")
        emit_blocked("USAGE", message, prog=prog, command=command or "")


def add_json(parser: argparse.ArgumentParser, *, top: bool = False) -> None:
    parser.add_argument("--json", action="store_true",
                        default=False if top else argparse.SUPPRESS,
                        help="print the full JSON result instead of the summary")


def new_parser(prog: str, description: str, version: str) -> tuple[HouseParser, Any]:
    parser = HouseParser(prog=prog, description=description)
    parser.add_argument("--version", action="version", version=f"%(prog)s {version}")
    add_json(parser, top=True)
    commands = parser.add_subparsers(dest="command", metavar="<command>")
    return parser, commands


def add_command(commands: Any, name: str, help_text: str,
                parents: Sequence[argparse.ArgumentParser] = ()) -> argparse.ArgumentParser:
    sub = commands.add_parser(name, help=help_text, description=help_text,
                              parents=list(parents))
    add_json(sub)
    return sub


def _with_build_args(parser: Any, argv: list[str], subparsers: dict[str, Any]) -> list[str]:
    """Expand ``--build-args <file>`` (saved by connect) into the flags this command knows.

    Flags given on the command line win; saved flags the command doesn't take are skipped.
    """
    if "--build-args" not in argv:
        return argv
    at = argv.index("--build-args")
    if at + 1 >= len(argv):
        parser.error("--build-args needs the path connect saved, such as .entity/build-args.json")
    path = Path(argv[at + 1])
    rest = argv[:at] + argv[at + 2:]
    try:
        binding = json.loads(path.read_text(encoding="utf-8"))
        saved = binding["build_args"]
        from .run_naming import binding_prefix
        prefix = binding_prefix(binding, [*rest, *saved])
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.error(f"--build-args {path} isn't a build-args file from "
                     f"`entity-graph-provision connect` ({error})")
    command = next((token for token in rest if token in subparsers), None)
    known = set(subparsers[command]._option_string_actions) if command else set()
    given = {token for token in rest if token.startswith("--")}
    extra = [part for flag, value in zip(saved[::2], saved[1::2])
             if flag in known and flag not in given for part in (flag, value)]
    if prefix and "--run-prefix" in known and "--run-prefix" not in saved and "--run-prefix" not in given:
        extra += ["--run-prefix", prefix]
    if command is None:
        return rest + extra
    index = rest.index(command)
    return rest[:index + 1] + extra + rest[index + 1:]


def parse(parser: HouseParser, argv: Sequence[str] | None,
          defaults: dict[str, Any] | None = None) -> argparse.Namespace:
    global _JSON_MODE
    argv = list(sys.argv[1:] if argv is None else argv)
    _JSON_MODE = "--json" in argv
    if not argv:
        parser.print_help()
        raise SystemExit(0)
    subparsers = next((a.choices for a in parser._actions
                       if isinstance(a, argparse._SubParsersAction)), {})
    argv = _with_build_args(parser, argv, subparsers)
    if subparsers and argv[0] not in subparsers and not any(
        x in ("-h", "--help", "--version") for x in argv
    ):
        for idx, token in enumerate(argv):
            if token in subparsers and (
                idx == 0 or not argv[idx - 1].startswith("-") or argv[idx - 1] == "--json"
            ):
                argv = [token] + argv[:idx] + argv[idx + 1:]
                break
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        raise SystemExit(0)
    for key, value in (defaults or {}).items():
        if not hasattr(args, key):
            setattr(args, key, list(value) if isinstance(value, list) else value)
    _JSON_MODE = bool(args.json)
    return args


def summary_lines(result: Any, *, prog: str, command: str) -> list[str]:
    if not isinstance(result, dict):
        return [f"{prog} {command}: done."]
    card = result.get("approval_card")
    if isinstance(card, str) and card and not (result.get("blocked_by") or result.get("blockers")):
        # The approval card is shown verbatim; it is the one thing a user approves. The
        # lines after it are for the agent: the user never types an ID.
        lines = card.splitlines()
        if isinstance(result.get("apply_command"), str):
            lines.append(f"For the agent, after the user approves, run: {result['apply_command']}")
        elif isinstance(result.get("plan_id"), str):
            lines.append(f"For the agent: after the user approves, pass --plan-id "
                         f"{result['plan_id']}; never ask the user to type it.")
        details = result.get("details")
        if isinstance(details, list) and details:
            lines += ["Details (show only if the user asks):", *(f"  - {d}" for d in details)]
        return lines + ["Add --json for the full result."]
    status = result.get("status")
    if status is None and "completed" in result:
        status = "completed" if result["completed"] else "incomplete"
    head = str(result.get("summary") or f"{prog} {command}: {status or 'done'}.").splitlines()
    extra = []
    facts = []
    for key, label in (("plan_id", "Plan ID"), ("run_id", "Run ID"),
                       ("generation", "Generation")):
        if isinstance(result.get(key), str):
            facts.append(f"{label}: {result[key]}")
    if status and "summary" in result:
        facts.append(f"Status: {status}")
    if facts:
        extra.append("; ".join(facts))
    blockers = result.get("blocked_by") or result.get("blockers")
    counted = result.get("facts")
    if isinstance(counted, dict):
        zero = counted["zero_hit"]
        edges = sum(row["edges"] for row in counted["predicates"].values())
        empty = "; ".join(f"no {label}: {', '.join(names)}" for label, names in (
            ("relationships of type", zero["predicates"]), ("entities of class", zero["classes"])) if names)
        extra.append(f"Facts: {edges} relationship(s) across {len(counted['predicates'])} types and "
                     f"{len(counted['classes'])} classes; {empty or 'every type and class has facts'}")
    covered = result.get("grounding_coverage")
    if isinstance(covered, dict) and covered.get("status") == "measured":
        confidence = covered.get("mean_confidence")
        extra.append(f"Grounding: {covered['end_share']:.0%} of {covered['edges']} edges' "
                     "endpoints resolved" + (f", mean confidence {confidence}"
                                              if confidence is not None else ""))
    if isinstance(blockers, list) and blockers:
        more = f" (+{len(blockers) - 1} more)" if len(blockers) > 1 else ""
        extra.append(f"Blocked by: {blockers[0]}{more}")
    if result.get("warning"):
        # A warning is never squeezed out by the line budget below.
        head.append(f"Warning: {result['warning']}")
    tail = []
    step = result.get("next_step") or result.get("next_action")
    if isinstance(step, str) and step:
        tail.append(f"Next: {step}")
    if len(head) < 5:
        tail.append("Add --json for the full result.")
    room = max(0, 6 - len(head) - len(tail))
    return head + extra[:room] + tail


# Steps that run for minutes: they say so before starting and save their full result.
LONG_STEPS = frozenset({"apply", "resume-apply", "attach-ontology", "update", "verify"})


def announce(time: str) -> None:
    """Tell the user, before a long step starts, how long it takes (stderr; stdout stays the result)."""
    print(f"Starting now; this takes {time}. I'll report when it's done.", file=sys.stderr, flush=True)


def result_path(prog: str, command: str) -> Path:
    return Path.cwd() / ".entity" / "results" / f"{prog}-{command}.json"


def save_query_result(prog: str, result: Any) -> Path:
    """One file per query, so a later narration reads it instead of re-running the query or
    searching session logs."""
    from datetime import datetime, timezone
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    folder = Path.cwd() / ".entity" / "results"
    folder.mkdir(parents=True, exist_ok=True)
    for n in range(1, 1000):
        path = folder / f"{prog}-query-{stamp}{f'-{n}' if n > 1 else ''}.json"
        try:
            with path.open("x", encoding="utf-8") as stream:
                stream.write(json.dumps(result, indent=2, default=str) + "\n")
            return path
        except FileExistsError:
            continue
    raise FileExistsError(f"too many query results saved at {stamp} in {folder}")


def say(result: Any, args: argparse.Namespace, *, prog: str, file: Any = None) -> None:
    if args.command in LONG_STEPS and isinstance(result, dict):
        # Read this afterwards instead of re-running the step or parsing a long output.
        path = result_path(prog, args.command)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(result, indent=2, default=str) + "\n", encoding="utf-8")
        result = {**result, "result_file": str(path)}
        if not args.json:
            lines = summary_lines(result, prog=prog, command=args.command)
            for line in [*lines[:-1], f"Full result: {path}", *lines[-1:]]:
                print(line, file=file)
            return
    if args.json:
        print(json.dumps(result, indent=2, default=str), file=file)
        return
    for line in summary_lines(result, prog=prog, command=args.command):
        print(line, file=file)
