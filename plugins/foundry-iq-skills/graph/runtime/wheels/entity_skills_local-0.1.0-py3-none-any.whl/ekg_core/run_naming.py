"""Versioned naming contract, bundled independently in each isolated graph runtime."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import secrets

PREFIX_PATTERN = r"fiq-[a-z0-9]+(?:-[a-z0-9]+)*-[0-9a-f]{8}"


def context(prefix: str) -> dict:
    match = re.fullmatch(r"fiq-([a-z0-9]+(?:-[a-z0-9]+)*)-([0-9a-f]{8})", prefix) if isinstance(prefix, str) else None
    if match is None or len(match[1]) > 24:
        raise ValueError("run prefix must be fiq-<name>-<8 lowercase hex>, with a 1..24 character name")
    return {"version": 1, "name": match[1], "prefix": prefix}


def binding_prefix(binding: dict, arguments=()) -> str | None:
    if "run_naming" not in binding:
        return None
    saved = binding["run_naming"]
    if (not isinstance(saved, dict) or type(saved.get("version")) is not int
            or saved != context(saved.get("prefix"))):
        raise ValueError("invalid run_naming in build binding")
    for i, flag in enumerate(arguments):
        explicit = (arguments[i + 1] if flag == "--run-prefix" and i + 1 < len(arguments)
                    else flag.split("=", 1)[1] if flag.startswith("--run-prefix=") else None)
        if explicit is not None and explicit != saved["prefix"]:
            raise ValueError("--run-prefix conflicts with the build binding")
    return saved["prefix"]


def resolve(directory: Path, name: str | None = None, prefix: str | None = None, *,
            persist: bool = True) -> str | None:
    path = Path(directory) / "run-naming.json"
    saved = None
    if path.exists():
        saved = json.loads(path.read_text(encoding="utf-8"))
        if (not isinstance(saved, dict) or type(saved.get("version")) is not int
                or saved != context(saved.get("prefix"))):
            raise ValueError(f"invalid run naming context: {path}")
    label = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") if name is not None else None
    if label is not None and not 1 <= len(label) <= 24:
        raise ValueError("run name must normalize to 1..24 lowercase letters, digits or single dashes")
    selected = context(prefix) if prefix is not None else saved
    if selected is not None and label is not None and label != selected["name"]:
        raise ValueError("run name conflicts with the resolved prefix; use a different run state directory")
    if saved is not None and selected != saved:
        raise ValueError("run prefix conflicts with saved state; use a different run state directory")
    if selected is None and label is not None:
        selected = context(f"fiq-{label}-{secrets.token_hex(4)}")
    if selected is None:
        return None
    if saved is None and persist:
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with path.open("x", encoding="utf-8") as stream:
                stream.write(json.dumps(selected, indent=2) + "\n")
        except FileExistsError:
            return resolve(directory, name, prefix, persist=persist)
    return selected["prefix"]


def resource_names(prefix: str) -> dict[str, str]:
    context(prefix)
    compact = prefix.replace("-", "")[:14] + hashlib.sha256(prefix.encode()).hexdigest()[:8]
    return {"resource_group": f"{prefix}-rg", "search_name": f"{prefix}-search",
            "storage_name": f"{compact}st", "cache_storage_name": f"{compact}ca",
            "openai_name": f"{prefix}-openai", "search_identity_name": f"{prefix}-identity"}
