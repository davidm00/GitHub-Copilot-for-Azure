"""Read-only operator-environment checks shared by every entity-skills CLI.

``doctor`` never signs in, never writes to Azure or disk, and sends no completions or
embeddings (the model checks only list models and read deployment metadata). A check
that lacks its input reports ``skip``. ``preflight``, ``inspect`` and ``rbac-check`` check
resources; ``doctor`` checks the operator's environment.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote

from . import package_version
from . import grounding
from . import service_errors
from .az_identity import IdentityError, az_command, az_json
from .az_identity import _rest_query_as_parameters as _rest_query
from .cli import next_step as _next_step
from .descriptors import descriptor_name, resolve_current

ARM = "https://management.azure.com"
SEARCH_RESOURCE = "https://search.azure.com"
SEARCH_API_VERSION = "2024-07-01"
GROUNDING_API_VERSION = "2026-11-01-preview"
OPENAI_API_VERSION = "2024-10-01"
OPENAI_RESOURCE = "https://ai.azure.com"
_AUTH_DENIED = ("401", "403", "forbidden", "unauthorized", "permissiondenied",
                "authorizationfailed")
MIN_PYTHON = (3, 12)
# Build journal states whose Azure outcome is not yet known: reconcile before anything else.
BUILD_UNSETTLED = {"attempt_requested", "staging", "indexing", "synchronizing", "failed"}

Runner = Callable[..., Any]


def _check(check_id: str, status: str, detail: str, code: str | None = None,
           **extra: Any) -> dict[str, Any]:
    item = {"id": check_id, "status": status, "detail": detail}
    if code:
        item["error_code"] = code
    item.update({key: value for key, value in extra.items() if value is not None})
    return item


def _version_tuple(value: str) -> tuple[int, ...] | None:
    parts = re.findall(r"\d+", value or "")
    return tuple(int(part) for part in parts[:3]) if parts else None


def plugin_manifest(start: Path | None = None) -> Path | None:
    explicit = os.environ.get("PLUGIN_ROOT") or os.environ.get("CLAUDE_PLUGIN_ROOT")
    here = (start or Path(__file__)).resolve()
    candidates = [Path(explicit).expanduser()] if explicit else list(here.parents)
    for folder in candidates:
        for path in (folder / ".plugin" / "plugin.json", folder / "plugin.json",
                     folder / ".claude-plugin" / "plugin.json",
                     folder / ".cursor-plugin" / "plugin.json"):
            if path.is_file():
                return path
    return Path(explicit).expanduser() / ".plugin" / "plugin.json" if explicit else None


def check_cli_version(manifest: Path | None = None, *,
                      prog: str = "entity-graph-build") -> dict[str, Any]:
    installed = package_version()
    root = os.environ.get("PLUGIN_ROOT") or os.environ.get("CLAUDE_PLUGIN_ROOT")
    expected = None
    version_source = "plugin.json"
    if manifest is None and root:
        runtime_manifest = Path(root) / "graph" / "runtime" / "manifest.json"
        try:
            metadata = json.loads(runtime_manifest.read_text(encoding="utf-8"))
        except FileNotFoundError:
            if not Path(root).is_dir():
                return _check("cli_version", "FAIL",
                              f"Explicit plugin root does not exist: {root}",
                              code="DOCTOR_CLI_VERSION", prog=prog, cli_version=installed)
            source_manifest = plugin_manifest()
            if (Path(root) / "graph" / "runtime" / "entity-skills" / "pyproject.toml").is_file() and source_manifest is not None:
                return check_cli_version(source_manifest, prog=prog)
            return _check("cli_version", "skip",
                          f"{installed}; no runtime manifest at {runtime_manifest}; "
                          "the Entity Graph wheel version was not compared", version=installed)
        except (OSError, ValueError) as exc:
            return _check("cli_version", "fail", f"cannot read runtime manifest {runtime_manifest}: {exc}",
                          "DOCTOR_CLI_VERSION", version=installed)
        if (not isinstance(metadata, dict) or type(metadata.get("schema_version")) is not int
                or metadata["schema_version"] != 2 or not isinstance(metadata.get("runtimes"), dict)):
            return _check("cli_version", "fail", "invalid runtime manifest: expected schema_version 2 and a runtimes object",
                          "DOCTOR_CLI_VERSION", version=installed)
        domain_key = "entity" if "entity" in metadata["runtimes"] else None
        if domain_key is None:
            return _check("cli_version", "skip", f"{installed}; runtime manifest has no Entity Graph runtime; "
                          "the Entity Graph wheel version was not compared", version=installed)
        runtime = metadata["runtimes"][domain_key]
        wheel = runtime.get("wheel") if isinstance(runtime, dict) else None
        expected = wheel.get("version") if isinstance(wheel, dict) else None
        if not isinstance(expected, str) or not expected.strip():
            return _check("cli_version", "fail", "invalid runtime manifest: "
                          f"runtimes.{domain_key}.wheel.version must be a nonempty string",
                          "DOCTOR_CLI_VERSION", version=installed)
        version_source = "runtime manifest"
    if expected is not None:
        return _version_check(installed, expected, version_source, prog)
    manifest = manifest or plugin_manifest()
    if manifest is None:
        return _check("cli_version", "ok", f"{installed}; package source version not compared; "
                      "set PLUGIN_ROOT to the installed or extracted package root",
                      version=installed)
    try:
        metadata = json.loads(manifest.read_text(encoding="utf-8"))
        if not isinstance(metadata, dict):
            raise ValueError("manifest must be an object")
        expected = metadata.get("version", "")
        if metadata.get("name") == "foundry-iq-skills":
            import tomllib

            root = manifest.parent.parent if manifest.parent.name in (
                ".plugin", ".claude-plugin", ".cursor-plugin") else manifest.parent
            pyproject_path = root / "graph" / "runtime" / "entity-skills" / "pyproject.toml"
            project = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))["project"]
            if project["name"] != "entity-skills-local":
                raise ValueError("expected the entity-skills-local runtime project")
            expected = project["version"]
        if not isinstance(expected, str) or not expected:
            raise ValueError("source version is missing")
    except (OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        return _check("cli_version", "fail", f"{installed}; cannot read source version: {exc}",
                      "DOCTOR_CLI_VERSION",
                      version=installed)
    return _version_check(installed, expected, version_source, prog)


def _version_check(installed: str, expected: str, version_source: str, prog: str) -> dict[str, Any]:
    have, want = _version_tuple(installed), _version_tuple(expected)
    warning = None
    if installed == "checkout":
        detail = f"running from a source checkout; {version_source} says {expected}"
    elif have is not None and want is not None and have < want:
        detail = f"{installed} is older than {version_source} {expected}"
        warning = (f"CLI {installed} is older than {version_source} {expected}; "
                   + _next_step("DOCTOR_CLI_VERSION", prog=prog))
    else:
        detail = f"{installed} ({version_source} {expected})"
    return _check("cli_version", "ok", detail, version=installed, plugin_version=expected,
                  warning=warning)


def check_python(version: tuple[int, ...] | None = None) -> dict[str, Any]:
    version = tuple(version or sys.version_info[:3])
    text = ".".join(str(part) for part in version)
    if version[:2] >= MIN_PYTHON:
        return _check("python", "ok", f"Python {text}")
    return _check("python", "fail", f"Python {text} is older than 3.12", "DOCTOR_PYTHON")


def check_azure_signin(tenant_id: str | None, runner: Runner) -> dict[str, Any]:
    if not tenant_id:
        # Default to the Azure CLI's current tenant; not being signed in is not a blocker here.
        try:
            account = az_json(["account", "show"], runner=runner)
        except IdentityError:
            account = None
        active = str(account.get("tenantId") or "") if isinstance(account, dict) else ""
        if not active:
            return _check("azure_signin", "skip",
                          "not signed in to the Azure CLI; run az login, then doctor again")
        return _check("azure_signin", "ok", f"signed in to tenant {active} (the current "
                      "Azure CLI tenant)", active_tenant=active, subscription=account.get("id"))
    try:
        account = az_json(["account", "show"], runner=runner)
    except IdentityError as error:
        info = service_errors.find(error)
        return _check("azure_signin", "fail", service_errors.with_summary(
                      f"no active Azure CLI sign-in for tenant {tenant_id}", info),
                      "DOCTOR_AZURE_SIGNIN", service_error=info)
    active = str((account or {}).get("tenantId", "")) if isinstance(account, dict) else ""
    if active.lower() != tenant_id.lower():
        return _check("azure_signin", "fail",
                      f"active tenant {active or 'unknown'} is not --tenant-id {tenant_id}",
                      "DOCTOR_AZURE_SIGNIN", active_tenant=active or None)
    return _check("azure_signin", "ok", f"signed in to tenant {active}",
                  active_tenant=active, subscription=account.get("id"))


def _existing(path: Path) -> Path | None:
    for folder in (path, *path.parents):
        if folder.exists():
            return folder
    return None


def check_state_dir(state_dir: str | Path | None) -> dict[str, Any]:
    if not state_dir:
        return _check("state_dir", "skip", "no state folder or journal given")
    folder = Path(state_dir).expanduser()
    base = _existing(folder)
    if base is None or not base.is_dir() or not os.access(base, os.W_OK | os.X_OK):
        return _check("state_dir", "fail", f"{folder} is not writable", "DOCTOR_STATE_DIR")
    leftovers = sorted(p.name for p in folder.glob("*.tmp")) if folder.is_dir() else []
    if leftovers:
        return _check("state_dir", "fail",
                      f"{folder} has partial writes ({', '.join(leftovers[:3])}); another "
                      "command may be running or one was interrupted", "DOCTOR_STATE_DIR")
    where = folder if folder.exists() else f"{folder} (created on first write under {base})"
    return _check("state_dir", "ok", f"{where} is writable and no write is in progress")


def check_build_journal(journal: str | None) -> dict[str, Any]:
    if not journal:
        return _check("journal", "skip", "no --build-journal given")
    path = Path(journal).expanduser()
    problems: list[tuple[str, str]] = []
    if path.is_file():
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return _check("journal", "fail", f"{path} is not readable JSON", "DOCTOR_JOURNAL",
                          journal_verb="status")
        state = record.get("state") if isinstance(record, dict) else None
        if state in BUILD_UNSETTLED:
            problems.append((f"build journal state is {state}; the outcome is not settled",
                             "reconcile"))
    for update in sorted(path.parent.glob("update-plan-*.json")) if path.parent.is_dir() else ():
        try:
            record = json.loads(update.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        state = record.get("state")
        if state not in (None, "published"):
            verb = ("plan" if state == "inconsistent" else
                    f"update --plan-id {update.stem} --confirm-writes")
            problems.append((f"update {update.stem} stopped in state {state}", verb))
    if problems:
        detail, verb = problems[0]
        return _check("journal", "fail", detail, "DOCTOR_JOURNAL", journal_verb=verb)
    if not path.exists():
        return _check("journal", "ok", f"{path} does not exist yet; nothing unsettled")
    return _check("journal", "ok", "no unknown-outcome entries; nothing to reconcile")


def check_provision_journal(state_dir: str | Path | None) -> dict[str, Any]:
    folder = Path(state_dir or Path.cwd() / ".entity" / "provision-runs").expanduser()
    if not folder.is_dir():
        return _check("journal", "ok", f"{folder} has no provisioning runs yet")
    records = {}
    for path in sorted(folder.glob("*.json")):
        if not re.fullmatch(r"[0-9a-f]{32}", path.stem):
            continue
        try:
            content = path.read_bytes()
            record = json.loads(content)
            operations = record["operations"]
        except (OSError, ValueError, KeyError, TypeError):
            return _check("journal", "fail", f"{path.name} is not a readable run record",
                          "DOCTOR_JOURNAL", journal_verb="inspect")
        records[path.stem] = (record, hashlib.sha256(content).hexdigest())
    settled = {"create_response_verified", "existing", "verified"}
    for run_id, (record, source_hash) in records.items():
        operations = record["operations"]
        reconciled = set()
        if record.get("spec", {}).get("public_data"):
            from ekg_provision.journal import ProvisioningJournal
            journal = ProvisioningJournal(folder)
            for child, _ in records.values():
                child_operations = child.get("operations", {})
                if not child.get("resume_from") or child.get("completed") is not True:
                    continue
                try:
                    lineage = journal.lineage(child["run_id"])
                except (OSError, ValueError, KeyError, TypeError):
                    continue
                ancestors = {item["run_id"]: digest for item, digest in lineage[:-1]}
                if (child.get("completed") is True and child.get("finished_at")
                    and ancestors.get(run_id) == source_hash
                    and child.get("plan_id", "").startswith("public-data-resume-plan-")
                    and child.get("spec") == record.get("spec")
                    and set(child_operations) == set(operations)
                    and all(item.get("status") in settled for item in child_operations.values())):
                    reconciled.update(
                        key for key, item in child_operations.items()
                        if str(item.get("resource_id", "")).lower()
                        == str(operations[key].get("resource_id", "")).lower()
                        and str(item.get("evidence", {}).get("resource_id", "")).lower()
                        == str(item.get("resource_id", "")).lower()
                    )
        uncertain = [key for key, item in operations.items()
                     if item.get("status") == "uncertain" and key not in reconciled]
        interrupted = "finished_at" not in record and any(
            item.get("status") == "pending" for item in operations.values())
        if uncertain or interrupted:
            what = (f"operation {uncertain[0]} has an unknown outcome" if uncertain else
                    "the run stopped before finishing")
            return _check("journal", "fail", f"run {run_id}: {what}", "DOCTOR_JOURNAL",
                          journal_verb="inspect", run_id=run_id)
    return _check("journal", "ok", "no unknown-outcome operations in provisioning runs")


def read_descriptor(path: str | None) -> tuple[dict[str, Any] | None, dict[str, Any]]:
    from .validation import validate_deployment_descriptor
    if not path:
        return None, _check("descriptor", "skip", "no --descriptor given")
    file = Path(path).expanduser()
    try:
        if file.stat().st_size > 1024 * 1024:
            raise ValueError("larger than 1 MiB")
        value = json.loads(file.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        return None, _check("descriptor", "fail", f"{file} is not readable JSON ({error})",
                            "DOCTOR_DESCRIPTOR")
    errors = validate_deployment_descriptor(value)
    if errors:
        return None, _check("descriptor", "fail", f"{file}: {errors[0]}", "DOCTOR_DESCRIPTOR")
    return value, _check("descriptor", "ok", f"{file} has the known descriptor shape "
                         f"(build {value['build_id']})")


def check_search_reader(endpoint: str | None, index: str | None, signed_in: bool,
                        runner: Runner) -> dict[str, Any]:
    if not endpoint or not index:
        return _check("search_reader", "skip", "no Search endpoint and index to probe")
    if not signed_in:
        return _check("search_reader", "skip", "Azure sign-in not verified")
    url = (f"{endpoint.rstrip('/')}/indexes/{quote(index, safe='')}/docs"
           f"?api-version={SEARCH_API_VERSION}&search=*&$top=0")
    try:
        az_json(["rest", "--method", "get", "--url", url, "--resource", SEARCH_RESOURCE],
                runner=runner)
    except IdentityError as error:
        info = service_errors.find(error)
        return _check("search_reader", "fail",
                      service_errors.with_summary(f"cannot read index {index}", info),
                      "DOCTOR_SEARCH_READER", service_error=info)
    return _check("search_reader", "ok", f"can read index {index}")


def _search_get(url: str, runner: Runner) -> tuple[Any, int | None]:
    """(json, None) on success, else (None, 403/404/None) classified from stderr."""
    value, status, _ = _search_get_detail(url, runner)
    return value, status


def _search_get_detail(url: str, runner: Runner) -> tuple[Any, int | None, dict | None]:
    """Like ``_search_get`` and also the parsed, redacted service error from stderr."""
    arguments = _rest_query(["rest", "--method", "get", "--url", url,
                             "--resource", SEARCH_RESOURCE])
    try:
        done = runner(az_command([*arguments, "--output", "json"], runner),
                      capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30, check=False)
    except (IdentityError, OSError, subprocess.TimeoutExpired):
        return None, None, None
    if done.returncode != 0:
        info = service_errors.from_cli_stderr(done.stderr)
        error = (done.stderr or "").lower()
        if any(marker in error for marker in ("403", "forbidden", "authorizationfailed",
                                              "permissiondenied")):
            return None, 403, info
        return (None, 404 if any(m in error for m in ("404", "notfound", "not found")) else None,
                info)
    try:
        return json.loads(done.stdout), None, None
    except ValueError:
        return None, None, None


def check_grounding_index(endpoint: str | None, index: str | None, signed_in: bool,
                          runner: Runner, graph_name: str | None = None) -> dict[str, Any]:
    if not index:
        return _check("grounding_index", "skip", "no grounding index to check")
    if not endpoint:
        return _check("grounding_index", "skip", "no Search endpoint to check it on")
    if not signed_in:
        return _check("grounding_index", "skip", "Azure sign-in not verified")
    invalid = grounding.name_blocker(index)
    if invalid:
        return _check("grounding_index", "fail", invalid, "DOCTOR_GROUNDING_INDEX")
    # Path form, not indexes('x'): cmd.exe rejects unquoted parentheses when az is a .cmd shim.
    url = (f"{endpoint.rstrip('/')}/indexes/{quote(index, safe='')}"
           f"?api-version={GROUNDING_API_VERSION}")
    definition, status, info = _search_get_detail(url, runner)
    if status == 403 or status == 404:
        blocker = grounding.classify(index, None, status=status, service_error=info)
        if status == 404 and info:
            blocker = f"{blocker}. Service error: {service_errors.summary(info)}"
        return _check("grounding_index", "fail", blocker,
                      "GROUNDING_INDEX_UNREADABLE" if status == 403
                      else "GROUNDING_INDEX_NOT_FOUND", service_error=info)
    if definition is None:
        detail = (f"cannot read index {index}: check the Search endpoint, sign-in and "
                  "that the identity has Search Index Data Reader and Reader on the "
                  "Search service")
        if info:
            detail += f". Service error: {service_errors.summary(info)}"
        return _check("grounding_index", "fail", detail, "DOCTOR_GROUNDING_INDEX",
                      service_error=info)
    blocker = grounding.classify(index, definition if isinstance(definition, dict) else None)
    if blocker:
        return _check("grounding_index", "fail", blocker, "DOCTOR_GROUNDING_INDEX")
    detail = f"index {index} has an {grounding.PROFILE_KIND} graph profile"
    try:
        rows = _grounding_rows(endpoint, index, graph_name, runner)
    except PermissionError as error:
        info = service_errors.find(error)
        return _check("grounding_index", "fail",
                      grounding.classify(index, None, status=403, service_error=info),
                      "GROUNDING_INDEX_UNREADABLE", service_error=info)
    if rows is None:
        return _check("grounding_index", "ok", detail,
                      warning="could not count rows; label rows and graph_name are unchecked")
    names, labels, label_names = rows
    shown = ", ".join(sorted(names)) or "none"
    if labels == 0:
        return _check("grounding_index", "fail",
                      f"{detail}, but it has no label rows (predicate rdfs:label or "
                      f"skos:altLabel with subject_id); graph_names present: {shown}",
                      "DOCTOR_GROUNDING_INDEX", graph_names=sorted(names))
    if graph_name and graph_name not in label_names:
        return _check("grounding_index", "fail",
                      f"{detail}, but no label rows have graph_name {graph_name}; label rows "
                      f"are under: {', '.join(sorted(label_names)) or 'none'}",
                      "DOCTOR_GROUNDING_INDEX", graph_names=sorted(names))
    return _check("grounding_index", "ok",
                  f"{detail}; {labels} label rows; graph_names: {shown}",
                  graph_names=sorted(names))


def _grounding_rows(endpoint: str, index: str, graph_name: str | None,
                    runner: Runner) -> tuple[dict[str, int], int, dict[str, int]] | None:
    """(graph_names, label row count, label graph_names) from read-only filtered counts."""
    base = (f"{endpoint.rstrip('/')}/indexes/{quote(index, safe='')}/docs"
            f"?api-version={GROUNDING_API_VERSION}&search=*&$top=0&$count=true"
            "&facet=graph_name,count:200")
    labels = " or ".join(f"predicate eq '{item}'" for item in grounding.LABEL_PREDICATES)

    def read(extra: str = "") -> dict[str, Any]:
        value = None
        for url in (base + extra, base.split("&facet=")[0] + extra):
            value, status, info = _search_get_detail(url, runner)
            if status == 403:
                raise service_errors.attach(PermissionError("denied"), info)
            if value is not None:
                break
        if not isinstance(value, dict):
            raise IdentityError("unexpected response")
        return value

    def facet(value: dict[str, Any]) -> dict[str, int]:
        items = (value.get("@search.facets") or {}).get("graph_name") or []
        return {item["value"]: item.get("count", 0) for item in items
                if isinstance(item, dict) and item.get("value")}

    try:
        names = facet(read())
        found = read("&$filter=" + quote(labels, safe=""))
        label_names = facet(found)
        if graph_name and not label_names and found.get("@odata.count"):
            # graph_name is not facetable in this index: ask for the exact value instead.
            exact = read("&$filter=" + quote(f"graph_name eq '{graph_name}' and ({labels})",
                                             safe=""))
            label_names = {graph_name: exact.get("@odata.count", 0)} if exact.get(
                "@odata.count") else {}
        return names, int(found.get("@odata.count") or 0), label_names
    except (IdentityError, KeyError, TypeError, ValueError):
        return None


def check_model_data_plane(endpoint: str | None, resource_id: str | None, signed_in: bool,
                            runner: Runner) -> dict[str, Any]:
    """List models on the data plane with the caller's Entra token (no completion, no spend).

    Success proves only model-list access for this caller, not inference or a named role."""
    if not endpoint:
        return _check("model_data_plane", "skip", "no --openai-endpoint or descriptor endpoint")
    if not signed_in:
        return _check("model_data_plane", "skip", "Azure sign-in not verified")
    scope = resource_id or "<openai-resource-id>"
    if not endpoint.startswith("https://"):
        return _check("model_data_plane", "fail", "OpenAI endpoint must be https",
                      "DOCTOR_MODEL_ENDPOINT")
    url = f"{endpoint.rstrip('/')}/openai/v1/models"
    try:
        done = runner(az_command(["rest", "--method", "get", "--url", url,
                       "--resource", OPENAI_RESOURCE, "--output", "json"], runner),
                      capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30, check=False)
    except (IdentityError, OSError, subprocess.TimeoutExpired):
        return _check("model_data_plane", "fail", "cannot reach the OpenAI endpoint",
                      "DOCTOR_MODEL_ENDPOINT")
    if done.returncode == 0:
        return _check("model_data_plane", "ok", "can list models with your Entra token; "
                      "inference permissions and the Search identity's access remain unverified "
                      "(no completion sent)")
    # Classify from stderr; report only its parsed, redacted service error.
    info = service_errors.from_cli_stderr(done.stderr)
    if any(marker in (done.stderr or "").lower() for marker in _AUTH_DENIED):
        return _check("model_data_plane", "fail", service_errors.with_summary(
                      "model listing was denied for this caller; "
                      "this does not establish a missing role", info), "DOCTOR_MODEL_ROLE",
                      scope=scope, service_error=info)
    return _check("model_data_plane", "fail",
                  service_errors.with_summary("cannot reach the OpenAI endpoint", info),
                  "DOCTOR_MODEL_ENDPOINT", service_error=info)


def check_model_deployment(resource_id: str | None, deployment: str | None, signed_in: bool,
                           runner: Runner) -> dict[str, Any]:
    if not resource_id or not deployment:
        return _check("model_deployment", "skip", "subscription/resource unknown: no "
                      "--openai-resource-id and deployment")
    if not signed_in:
        return _check("model_deployment", "skip", "Azure sign-in not verified")
    url = (f"{ARM}{resource_id.rstrip('/')}/deployments/{quote(deployment, safe='')}"
           f"?api-version={OPENAI_API_VERSION}")
    try:
        found = az_json(["rest", "--method", "get", "--url", url], runner=runner)
    except IdentityError as error:
        info = service_errors.find(error)
        return _check("model_deployment", "fail", service_errors.with_summary(
                      f"deployment {deployment} was not found", info),
                      "DOCTOR_MODEL_DEPLOYMENT", service_error=info)
    state = ((found or {}).get("properties") or {}).get("provisioningState")
    if state and state != "Succeeded":
        return _check("model_deployment", "fail", f"deployment {deployment} is {state}",
                      "DOCTOR_MODEL_DEPLOYMENT")
    return _check("model_deployment", "ok", f"deployment {deployment} exists (metadata only)")


def check_cache_roles(cache_storage_resource_id: str | None,
                      search_identity_resource_id: str | None,
                      signed_in: bool, runner: Runner,
                      *, search_resource_id: str | None = None) -> dict[str, Any]:
    """Verify the Search cache principal has both Blob and Table Data Contributor on the cache account."""
    from .models import CACHE_USES_SYSTEM_ASSIGNED_IDENTITY
    target_id = (
        (search_resource_id or search_identity_resource_id)
        if CACHE_USES_SYSTEM_ASSIGNED_IDENTITY
        else (search_identity_resource_id or search_resource_id)
    )
    if not cache_storage_resource_id or not target_id:
        return _check("cache_roles", "skip",
                      "no --cache-storage-resource-id and --search-resource-id")
    if not signed_in:
        return _check("cache_roles", "skip", "Azure sign-in not verified")
    is_search_service = "/searchservices/" in target_id.lower()
    api_ver = "2025-05-01" if is_search_service else "2023-01-31"
    who_label = (
        "Search system-assigned identity"
        if (CACHE_USES_SYSTEM_ASSIGNED_IDENTITY or is_search_service)
        else "Search identity"
    )
    try:
        res = az_json(["resource", "show", "--ids", target_id,
                       "--api-version", api_ver], runner=runner)
    except IdentityError as error:
        info = service_errors.find(error)
        return _check("cache_roles", "fail", service_errors.with_summary(
                      f"{target_id.rsplit('/', 1)[-1]} was not found", info),
                      "DOCTOR_CACHE_ROLES", scope=cache_storage_resource_id,
                      service_error=info)
    principal = (
        ((res or {}).get("identity") or {}).get("principalId")
        or ((res or {}).get("properties") or {}).get("principalId")
    )
    if not isinstance(principal, str) or not principal:
        return _check("cache_roles", "fail",
                      f"{who_label} has no principalId",
                      "DOCTOR_CACHE_ROLES", scope=cache_storage_resource_id)
    cache_sub_match = re.match(r"^/subscriptions/([^/]+)/", cache_storage_resource_id, re.IGNORECASE)
    # No --assignee-object-id: it hides assignments made to groups the identity is in.
    role_list_args = [
        "role", "assignment", "list", "--scope", cache_storage_resource_id,
        "--include-inherited", "--fill-principal-name", "false",
    ]
    if cache_sub_match:
        role_list_args += ["--subscription", cache_sub_match.group(1)]
    try:
        assignments = az_json(role_list_args, runner=runner)
    except IdentityError as error:
        info = service_errors.find(error)
        return _check("cache_roles", "fail", service_errors.with_summary(
                      f"cannot read role assignments on {cache_storage_resource_id}", info),
                      "DOCTOR_CACHE_ROLES", scope=cache_storage_resource_id,
                      service_error=info)
    from .group_membership import UNREADABLE, member_groups
    membership = member_groups(principal, "ServicePrincipal", runner)
    held = [row for row in (assignments or []) if isinstance(row, dict)]
    assigned = {str(row.get("roleDefinitionName") or "") for row in held
                if membership.holder(row.get("principalId")) is not None}
    missing = []
    if not (assigned & {"Storage Blob Data Contributor", "Storage Blob Data Owner"}):
        missing.append("Storage Blob Data Contributor")
    if "Storage Table Data Contributor" not in assigned:
        missing.append("Storage Table Data Contributor")
    if missing and not membership.readable and any(
            str(row.get("principalType") or "").casefold() == "group"
            and (str(row.get("roleDefinitionName") or "") in missing
                 or (row.get("roleDefinitionName") == "Storage Blob Data Owner"
                     and "Storage Blob Data Contributor" in missing))
            for row in held):
        return _check("cache_roles", "unverified",
                      f"{who_label} has no direct {', '.join(missing)} on cache storage account "
                      f"{cache_storage_resource_id.rsplit('/', 1)[-1]}, and a group holds it, "
                      f"but {UNREADABLE}",
                      "DOCTOR_CACHE_ROLES", scope=cache_storage_resource_id)
    if missing:
        return _check("cache_roles", "fail",
                      f"{who_label} lacks {', '.join(missing)} on cache storage account "
                      f"{cache_storage_resource_id.rsplit('/', 1)[-1]}",
                      "DOCTOR_CACHE_ROLES", scope=cache_storage_resource_id)
    return _check("cache_roles", "ok",
                  f"{who_label} has Storage Blob Data Contributor and Storage Table Data "
                  "Contributor on the cache storage account")


def doctor(prog: str, *, tenant_id: str | None = None, state_dir: str | None = None,
           build_journal: str | None = None, provision_journal: bool = False,
           descriptor: str | None = None, search_endpoint: str | None = None,
           index: str | None = None, openai_resource_id: str | None = None,
           deployment: str | None = None, openai_endpoint: str | None = None,
           grounding_index: str | None = None, grounding_graph_name: str | None = None,
           cache_storage_resource_id: str | None = None,
           search_identity_resource_id: str | None = None,
           search_resource_id: str | None = None,
           runner: Runner = subprocess.run) -> dict[str, Any]:
    checks = [check_cli_version(prog=prog), check_python()]
    signin = check_azure_signin(tenant_id, runner)
    tenant_id = tenant_id or signin.get("active_tenant")
    checks.append(signin)
    checks.append(check_state_dir(state_dir))
    if provision_journal:
        checks.append(check_provision_journal(state_dir))
    else:
        checks.append(check_build_journal(build_journal))
    served, described = read_descriptor(descriptor)
    if prog not in ("entity-provision", "entity-graph-provision"):
        checks.append(described)
    endpoints = (served or {}).get("endpoints") or {}
    signed_in = signin["status"] == "ok"
    checks.append(check_search_reader(search_endpoint or endpoints.get("search"),
                                      index or endpoints.get("content_index"), signed_in,
                                      runner))
    checks.append(check_grounding_index(search_endpoint or endpoints.get("search"),
                                        grounding_index, signed_in, runner,
                                        graph_name=grounding_graph_name))
    checks.append(check_model_data_plane(openai_endpoint or endpoints.get("openai"),
                                         openai_resource_id, signed_in, runner))
    checks.append(check_model_deployment(openai_resource_id, deployment, signed_in, runner))
    if cache_storage_resource_id or search_identity_resource_id or search_resource_id:
        checks.append(check_cache_roles(
            cache_storage_resource_id or endpoints.get("cache_storage_resource_id"),
            search_identity_resource_id, signed_in, runner,
            search_resource_id=search_resource_id))
    failed = next((item for item in checks if item["status"] == "fail"), None)
    result: dict[str, Any] = {"status": "blocked" if failed else "ok", "tenant_id": tenant_id,
                              "checks": checks}
    if failed:
        result.update(error_code=failed["error_code"], error=failed["detail"],
                      next_step=_next_step(failed["error_code"], prog=prog, command="doctor",
                                           journal_verb=failed.get("journal_verb"),
                                           scope=failed.get("scope")))
        if failed.get("service_error"):
            result["service_error"] = failed["service_error"]
    else:
        result["next_step"] = _ready_step(prog, checks)
    warnings = [item["warning"] for item in checks if item.get("warning")]
    if warnings:
        result["warnings"] = warnings
    return result


# The flags that turn each optional check on, so the next step can name them.
_CHECK_FLAGS = {
    "descriptor": "--descriptor <descriptor.json>",
    "search_reader": "--descriptor <descriptor.json> (or --search-endpoint <url> --index <name>)",
    "grounding_index": "--search-endpoint <url> --grounding-index <name>",
    "model_data_plane": "--openai-endpoint <url>",
    "model_deployment": "--openai-resource-id <id> --chat-deployment <name>",
}


def _ready_step(prog: str, checks: list[dict[str, Any]]) -> str:
    """Say plainly whether there is anything left to check, and with which flags."""
    if all(c["status"] == "ok" for c in checks):
        return "Environment is ready; continue with the skill's workflow."
    if prog in ("entity-provision", "entity-graph-provision"):
        return ("Ready. There's nothing more to check before planning new resources; don't "
                "run doctor again. For existing resources, `connect` checks them.")
    flags = sorted({_CHECK_FLAGS[c["id"]] for c in checks
                    if c["status"] == "skip" and c["id"] in _CHECK_FLAGS})
    if not flags:
        return "Ready for what was checked; continue with the skill's workflow."
    return ("Ready for what was checked; don't run doctor again with the same flags. To also "
            "check existing resources, add: " + "; ".join(flags) + ".")


def render(result: dict[str, Any]) -> list[str]:
    tenant = result.get("tenant_id")
    lines = [f"Tenant: {tenant}" if tenant else "Tenant: none given (Azure checks skipped)"]
    marks = {"ok": "ok  ", "fail": "FAIL", "skip": "skip", "unverified": "warn"}
    for item in result["checks"]:
        line = f"{marks[item['status']]} {item['id']}: {item['detail']}"
        if item.get("warning"):
            line += f" (warning: {item['warning']})"
        lines.append(line)
    lines.append(f"next_step: {result['next_step']}")
    return lines


_BUILD_ARG_ONLY_FLAGS = (
    "--subscription-id", "--resource-group", "--location", "--search-sku",
    "--storage-endpoint", "--storage-resource-id", "--storage-container",
    "--embedding-model", "--embedding-dimensions", "--chat-model",
)


def add_arguments(parser: Any, *, build: bool = False, provision: bool = False) -> None:
    """Doctor inputs; every one is optional so doctor runs before any config exists."""
    parser.add_argument("--tenant-id", help="tenant to compare with the active az sign-in")
    if provision:
        parser.add_argument("--state-dir", help="provisioning journal folder "
                            "(default ./.entity/provision-runs)")
    if not provision:
        parser.add_argument("--build-journal", help="build journal to check for unsettled runs")
        # Accept every connect build_binding.build_args flag so it can be pasted unchanged.
        target = parser.add_argument_group(
            "connect build_args", "accepted unchanged from `entity-graph-provision connect`; "
            "not otherwise checked")
        for flag in _BUILD_ARG_ONLY_FLAGS:
            target.add_argument(flag, dest=f"target_{flag[2:].replace('-', '_')}")
    if build:
        parser.add_argument("--grounding-index", help="existing grounding index to validate "
                            "read-only (needs --search-endpoint)")
        parser.add_argument("--grounding-graph-name", help="the plan's grounding.graph_name; "
                            "checks the index has label rows under it")
    parser.add_argument("--descriptor", action="append", default=[],
                        help="published descriptor to read and whose index to probe")
    parser.add_argument("--search-endpoint", help="Search endpoint for the reader probe")
    parser.add_argument("--index", help="index for the reader probe (default: descriptor's)")
    parser.add_argument("--openai-endpoint", help="Azure OpenAI/Foundry endpoint for the "
                        "data-plane models-list probe (default: descriptor's)")
    parser.add_argument("--openai-resource-id", help="Azure OpenAI/Foundry account ARM ID")
    parser.add_argument("--search-resource-id",
                        help="Search service ARM ID for system-assigned cache role checks")
    parser.add_argument("--cache-storage-resource-id",
                        help="enrichment-cache StorageV2 account ARM ID to check roles on")
    parser.add_argument("--search-identity-resource-id",
                        help="Search user-assigned identity ARM ID for cache role checks")
    parser.add_argument("--chat-deployment", help="deployment whose metadata to read")
    parser.add_argument("--embedding-deployment",
                        help="deployment whose metadata to read when no chat deployment")


def from_args(prog: str, args: Any, *, runner: Runner = subprocess.run) -> dict[str, Any]:
    journal = getattr(args, "build_journal", None)
    state_dir = getattr(args, "state_dir", None)
    provision = prog in ("entity-provision", "entity-graph-provision")
    if provision:
        state_dir = state_dir or str(Path.cwd() / ".entity" / "provision-runs")
    elif journal:
        state_dir = str(Path(journal).expanduser().parent)
    descriptors = getattr(args, "descriptor", None) or []
    if isinstance(descriptors, str):
        descriptors = [descriptors]
    if not descriptors and os.environ.get("ENTITY_DESCRIPTOR"):
        descriptors = [os.environ["ENTITY_DESCRIPTOR"]]
    return doctor(prog, tenant_id=getattr(args, "tenant_id", None), state_dir=state_dir,
                  build_journal=journal, provision_journal=provision,
                  descriptor=descriptors[0] if descriptors else None,
                  search_endpoint=getattr(args, "search_endpoint", None),
                  index=getattr(args, "index", None),
                  grounding_index=getattr(args, "grounding_index", None),
                  grounding_graph_name=getattr(args, "grounding_graph_name", None),
                  openai_resource_id=getattr(args, "openai_resource_id", None),
                  openai_endpoint=getattr(args, "openai_endpoint", None),
                  deployment=(getattr(args, "chat_deployment", None)
                              or getattr(args, "embedding_deployment", None)),
                  cache_storage_resource_id=getattr(args, "cache_storage_resource_id", None),
                  search_identity_resource_id=getattr(args, "search_identity_resource_id", None),
                  search_resource_id=getattr(args, "search_resource_id", None),
                  runner=runner)


def _signed_in(runner: Runner) -> dict[str, str | None]:
    try:
        account = az_json(["account", "show"], runner=runner)
    except Exception:
        account = None
    if not isinstance(account, dict):
        return {"tenant_id": None, "account": None}
    user = account.get("user") if isinstance(account.get("user"), dict) else {}
    info: dict[str, str | None] = {
        "tenant_id": account.get("tenantId") or None,
        "account": user.get("name") or None,
    }
    if account.get("tenantDisplayName"):
        info["tenant_name"] = str(account["tenantDisplayName"])
    if account.get("id"):
        info["subscription_id"] = str(account["id"])
    if account.get("name"):
        info["subscription_name"] = str(account["name"])
    return info


def _current() -> dict[str, str] | None:
    try:
        path = resolve_current()
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    ident = (value.get("build_id") or value.get("deployment_id")
             if isinstance(value, dict) else None) or descriptor_name(value)
    return {"kind": "descriptor", "path": str(path), "id": str(ident)}


def contract(result: dict[str, Any], *, runner: Runner = subprocess.run) -> dict[str, Any]:
    """The stable, documented `doctor --json` shape (docs/contract.md)."""
    checks = []
    for item in result["checks"]:
        status = {"ok": "pass", "fail": "fail"}.get(item["status"], "warn")
        if status == "pass" and item.get("warning"):
            status = "warn"
        detail = item["detail"] + (f" (warning: {item['warning']})"
                                   if item.get("warning") else "")
        checks.append({"name": item["id"], "status": status, "detail": detail,
                       **({"service_error": item["service_error"]}
                          if item.get("service_error") else {})})
    return {
        "plugin": "entity-graph-skills",
        "version": package_version(),
        "ready": result["status"] == "ok",
        "signed_in": _signed_in(runner),
        "current": _current(),
        "checks": checks,
        "next_step": result["next_step"],
    }


def run(prog: str, args: Any, *, runner: Runner = subprocess.run) -> None:
    result = from_args(prog, args, runner=runner)
    if getattr(args, "json", False):
        # Agents read the shape, not the exit code; not-ready is still a successful read.
        print(json.dumps(contract(result, runner=runner), indent=2))
        return
    print("\n".join(render(result)))
    if result["status"] != "ok":
        raise SystemExit(2)
