"""Candidate TopicGraph contracts; not a stable product API."""

from __future__ import annotations


def package_version() -> str:
    from importlib.metadata import PackageNotFoundError, version
    try:
        return version("topicgraph-skills")
    except PackageNotFoundError:
        return "unknown"


def skill_user_agent() -> str:
    return f"foundry-iq-skill-v{package_version()}"

