"""Durable event envelope and single-publisher offline lock."""

from __future__ import annotations

import json
import os
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from topicgraph_core.contracts import PUBLICATION_VERSION, ContractError, canonical_json
from topicgraph_core.files import LockHeld, atomic_write_text, exclusive_lock


class State:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def record(self, operation_id: str, generation_id: str | None, stage: str, state: str,
               expected: dict[str, int] | None = None, observed: dict[str, int] | None = None,
               evidence_ids: list[str] | None = None, error_code: str | None = None) -> dict[str, Any]:
        if state not in {"planned", "running", "verified", "published", "failed", "blocked"}:
            raise ContractError("STATE_INVALID", state)
        event = {
            "operation_id": operation_id, "generation_id": generation_id,
            "stage": stage, "state": state, "timestamp": datetime.now(timezone.utc).isoformat(),
            "expected_counts": expected or {}, "observed_counts": observed or {},
            "evidence_ids": evidence_ids or [], "error_code": error_code,
        }
        path = self.root / "events.jsonl"
        with path.open("a", encoding="utf-8") as stream:
            stream.write(canonical_json(event) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        return event

    def events(self) -> list[dict[str, Any]]:
        path = self.root / "events.jsonl"
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()] if path.exists() else []

    def save_generation(self, generation_id: str, record: dict[str, Any]) -> None:
        if not 12 <= len(generation_id) <= 64 or any(c not in "0123456789abcdef" for c in generation_id):
            raise ContractError("GENERATION_INVALID", "Expected a lowercase hex release content identity")
        atomic_write_text(self.root / f"{generation_id}.json", canonical_json(record))

    def generation(self, generation_id: str) -> dict[str, Any]:
        path = self.root / f"{generation_id}.json"
        if not path.exists():
            raise ContractError("GENERATION_UNKNOWN", generation_id)
        return json.loads(path.read_text(encoding="utf-8"))


    def record_write(self, plan_id: str, generation_id: str | None, operation: str, phase: str,
                     target: str, *, key_digest: str | None = None,
                     status: str = "intent", error_code: str | None = None,
                     detail: dict[str, Any] | None = None) -> dict[str, Any]:
        if status not in {"intent", "confirmed", "failed", "ambiguous", "reconciled"}:
            raise ContractError("STATE_INVALID", status)
        event = {
            "plan_id": plan_id, "generation_id": generation_id, "operation": operation,
            "phase": phase, "target": target, "key_digest": key_digest,
            "status": status, "error_code": error_code, "detail": detail or {},
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        path = self.root / "writes.jsonl"
        with path.open("a", encoding="utf-8") as stream:
            stream.write(canonical_json(event) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        return event

    def write_events(self) -> list[dict[str, Any]]:
        path = self.root / "writes.jsonl"
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()] if path.exists() else []

    def unresolved_writes(self, plan_id: str) -> list[dict[str, Any]]:
        events = [event for event in self.write_events() if event.get("plan_id") == plan_id]
        latest = {(e.get("phase"), e.get("target"), e.get("key_digest")): e for e in events}
        return [e for e in latest.values() if e.get("status") in {"intent", "failed", "ambiguous"}]

    def has_reconcile(self, plan_id: str) -> bool:
        events = [e for e in self.write_events() if e.get("plan_id") == plan_id]
        last = max((i for i, e in enumerate(events) if e.get("operation") == "reconcile"
                    and e.get("status") == "reconciled"), default=-1)
        unresolved = self.unresolved_writes(plan_id)
        return last >= 0 and not any(e in unresolved for e in events[last + 1:])

    def resume_required(self, plan_id: str) -> bool:
        gates = [e["phase"] for e in self.write_events() if e.get("plan_id") == plan_id
                 and e.get("phase") in {"resume-required", "resume-approved"}]
        return bool(gates) and gates[-1] == "resume-required"

    def owns_index(self, plan_id: str, index: str) -> bool:
        return any(e.get("plan_id") == plan_id and e.get("target") == index and e.get("phase") == "create-index"
                   and e.get("status") in {"intent", "confirmed", "reconciled"} for e in self.write_events())

    def staging_owner(self, index: str) -> dict[str, Any] | None:
        writes = [e for e in self.write_events() if e.get("target") == index]
        owners = [e for e in writes if e.get("phase") == "create-index" and e.get("status") == "confirmed"
                  and (e.get("detail") or {}).get("publication_version") == PUBLICATION_VERSION]
        if not owners or len({e["plan_id"] for e in owners}) != 1:
            return None
        return owners[0]

    def protected_index(self, index: str) -> bool:
        if any(e.get("target") == index and e.get("phase") in {
            "retention-protect", "publish-current", "built-at",
        } for e in self.write_events()):
            return True
        if any(e.get("state") in {"verified", "published"} and index in e.get("evidence_ids", [])
               for e in self.events()):
            return True
        owner = self.staging_owner(index)
        if owner is not None:
            try:
                record = self.generation(owner["generation_id"])
            except ContractError as exc:
                if exc.code != "GENERATION_UNKNOWN":
                    raise
            else:
                return (record.get("descriptor") or {}).get("physical_index") == index
        return False

    def retiring_index(self, index: str) -> bool:
        return any(e.get("target") == index and e.get("phase") == "retire"
                   for e in self.write_events())

    @contextmanager
    def publisher_lock(self) -> Iterator[None]:
        """Cross-process; the OS releases it if the holder dies, so a crash never leaves a stale lock."""
        try:
            with exclusive_lock(self.root / "publisher.lock", wait=0):
                yield
        except LockHeld as exc:
            raise ContractError("PUBLISHER_BUSY", "Another operation is publishing from this state folder; "
                                "wait for it to finish") from exc
