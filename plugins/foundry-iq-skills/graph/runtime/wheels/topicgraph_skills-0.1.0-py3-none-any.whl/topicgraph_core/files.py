"""Local state files: atomic replacement through private temp files, and cross-process locks."""

from __future__ import annotations

import os
import tempfile
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path


class LockHeld(RuntimeError):
    """Another process holds the lock."""


def atomic_write_bytes(path: str | Path, data: bytes, *, durable: bool = False) -> None:
    """Replace `path` through a temp file only this writer owns, so concurrent writers never share one."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=target.parent, prefix=f".{target.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            if durable:
                stream.flush()
                os.fsync(stream.fileno())
        _replace(temporary, target)
    except BaseException:
        Path(temporary).unlink(missing_ok=True)
        raise


def _replace(source: str, target: Path) -> None:
    # Windows refuses a rename while another writer is replacing the same target; that clears in moments.
    for attempt in range(100):
        try:
            os.replace(source, target)
            return
        except PermissionError:
            if os.name != "nt" or attempt == 99:
                raise
            time.sleep(0.01)


def atomic_write_text(path: str | Path, text: str, *, durable: bool = False) -> None:
    atomic_write_bytes(path, text.encode("utf-8"), durable=durable)


@contextmanager
def exclusive_lock(path: str | Path, *, wait: float = 30.0) -> Iterator[None]:
    """Hold an OS lock on `path` across processes; raise LockHeld after `wait` seconds (0 = fail fast).

    The OS releases the lock if the holder dies, so a crashed run never leaves it stuck.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(target, os.O_RDWR | os.O_CREAT, 0o600)
    deadline = time.monotonic() + wait
    locked = False
    try:
        while True:
            try:
                _lock(fd)
                locked = True
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise LockHeld(str(target)) from None
                time.sleep(0.05)
        yield
    finally:
        if locked:
            _unlock(fd)
        os.close(fd)


if os.name == "nt":
    import msvcrt

    def _lock(fd: int) -> None:
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)

    def _unlock(fd: int) -> None:
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
else:
    import fcntl

    def _lock(fd: int) -> None:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock(fd: int) -> None:
        fcntl.flock(fd, fcntl.LOCK_UN)


def lock_held(path: str | Path) -> bool:
    """True when another process holds the lock at `path` (an unheld leftover file is not a lock)."""
    if not Path(path).exists():
        return False
    try:
        with exclusive_lock(path, wait=0):
            return False
    except LockHeld:
        return True
