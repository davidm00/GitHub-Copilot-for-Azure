"""Parse a failed service response into a safe, structured `service_error`.

`describe(status, body, headers)` returns `{"status", "code", "message", "details", "request_id"}` (only
`status` is always present). Every string is redacted (bearer tokens, JWTs, SAS signatures, account and
access keys, `key=` values) and truncated. The raw body, request body and request headers are never kept,
so the calling agent can correct the request or tell the user what the service said.
The same API exists in each foundry-iq runtime; there are no cross-runtime imports.
"""

from __future__ import annotations

import html
import json
import re
from collections.abc import Mapping
from typing import Any

MAX_MESSAGE = 2000
MAX_DETAIL_MESSAGE = 500
MAX_DETAILS = 10
MAX_CODE = 200
REDACTED = "[REDACTED]"
REQUEST_ID_HEADERS = ("x-ms-request-id", "request-id", "apim-request-id", "x-request-id", "x-ms-client-request-id")

_SECRETS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"(?i)\bbearer\s+[A-Za-z0-9\-._~+/]+=*"), "Bearer " + REDACTED),
    (re.compile(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*"), REDACTED),
    (re.compile(r"(?i)\bsig=[^&\s\"'<>;,]+"), "sig=" + REDACTED),
    (re.compile(r"(?i)\b(AccountKey|SharedAccessKey)=[^;\s\"'<>]+"), r"\1=" + REDACTED),
    (re.compile(r"(?i)(\"(?:api[-_]?key|apikey|key)\"\s*:\s*)\"[^\"]*\""), r'\1"' + REDACTED + '"'),
    (re.compile(r"(?i)\b(api[-_]?key|apikey|key)(\s*[=:]\s*)(?!\[REDACTED\])[^&;,\s\"'<>]+"), r"\1\2" + REDACTED),
)
_TAGS = re.compile(r"<[^>]*>")
_SCRIPTS = re.compile(r"(?is)<(script|style)\b.*?</\1\s*>")
_SPACE = re.compile(r"\s+")


def redact(text: str) -> str:
    """`text` with every known secret shape replaced by `[REDACTED]`."""
    for pattern, replacement in _SECRETS:
        text = pattern.sub(replacement, text)
    return text


def _clean(value: Any, limit: int) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (dict, list)) else str(value)
    text = redact(_SPACE.sub(" ", value).strip())
    if not text:
        return None
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _detail(code: Any, message: Any, target: Any = None) -> dict[str, str] | None:
    item: dict[str, str] = {}
    for key, value, limit in (("code", code, MAX_CODE), ("message", message, MAX_DETAIL_MESSAGE),
                              ("target", target, MAX_CODE)):
        cleaned = _clean(value, limit)
        if cleaned is not None:
            item[key] = cleaned
    return item or None


def _error_object(err: Mapping[str, Any]) -> tuple[Any, Any, list[dict[str, str]]]:
    code = err.get("code") if err.get("code") is not None else err.get("type")
    message = err.get("message")
    if isinstance(message, Mapping):
        message = message.get("value")
    details: list[dict[str, str]] = []
    raw_details = err.get("details")
    if isinstance(raw_details, list):
        for item in raw_details:
            if isinstance(item, Mapping):
                d = _detail(item.get("code"), item.get("message"), item.get("target"))
                if d:
                    details.append(d)
    inner = err.get("innererror") or err.get("innerError")
    depth = 0
    while isinstance(inner, Mapping) and depth < 5:
        d = _detail(inner.get("code"), inner.get("message"))
        if d:
            details.append(d)
        inner = inner.get("innererror") or inner.get("innerError")
        depth += 1
    return code, message, details


def _parse_json(obj: Any) -> tuple[Any, Any, list[dict[str, str]]] | None:
    if not isinstance(obj, Mapping):
        return None
    err = obj.get("error")
    if isinstance(err, Mapping):
        return _error_object(err)
    if isinstance(err, str) and err.strip():
        return err, obj.get("error_description") or obj.get("message"), []
    odata = obj.get("odata.error")
    if isinstance(odata, Mapping):
        return _error_object(odata)
    code = obj.get("code", obj.get("Code"))
    message = obj.get("message", obj.get("Message"))
    if code is not None or message is not None:
        return _error_object({"code": code, "message": message, "details": obj.get("details"),
                              "innererror": obj.get("innererror")})
    return None


def _xml_tag(text: str, tag: str) -> str | None:
    match = re.search(rf"(?is)<{tag}\b[^>]*>(.*?)</{tag}\s*>", text)
    return html.unescape(_TAGS.sub(" ", match.group(1))) if match else None


def _parse(text: str) -> tuple[Any, Any, list[dict[str, str]]]:
    stripped = text.strip()
    if not stripped:
        return None, None, []
    if stripped[:1] in "{[":
        try:
            parsed = _parse_json(json.loads(stripped))
        except ValueError:
            parsed = None
        if parsed is not None:
            return parsed
    if stripped.startswith("<") and re.search(r"(?i)<Code\b", stripped) and not re.search(r"(?i)<html\b", stripped):
        code, message = _xml_tag(stripped, "Code"), _xml_tag(stripped, "Message")
        auth = _xml_tag(stripped, "AuthenticationErrorDetail")
        details = [d for d in [_detail("AuthenticationErrorDetail", auth)] if d] if auth else []
        if code or message:
            return code, message, details
    if "<" in stripped and ">" in stripped:
        stripped = html.unescape(_TAGS.sub(" ", _SCRIPTS.sub(" ", stripped)))
    return None, stripped, []


def _text(body: bytes | str | None) -> str:
    if body is None:
        return ""
    if isinstance(body, (bytes, bytearray, memoryview)):
        return bytes(body).decode("utf-8-sig", errors="replace")
    return str(body)


def _headers(headers: Any) -> dict[str, str]:
    if not headers:
        return {}
    try:
        items = list(headers.items())
    except Exception:  # noqa: BLE001 - headers are best-effort context
        return {}
    return {str(k).lower(): str(v) for k, v in items}


def describe(status: int | None, body: bytes | str | None, headers: Mapping[str, str] | None = None) -> dict:
    """The parsed service error for one failed response. Never includes the raw body."""
    try:
        status_value = int(status) if status is not None else None
    except (TypeError, ValueError):
        status_value = None
    info: dict[str, Any] = {"status": status_value}
    lower = _headers(headers)
    code, message, details = _parse(_text(body))
    code = _clean(code, MAX_CODE) or _clean(lower.get("x-ms-error-code"), MAX_CODE)
    message = _clean(message, MAX_MESSAGE)
    if code:
        info["code"] = code
    if message:
        info["message"] = message
    if details:
        info["details"] = details[:MAX_DETAILS]
    request_id = next((_clean(lower[h], MAX_CODE) for h in REQUEST_ID_HEADERS if lower.get(h)), None)
    if request_id:
        info["request_id"] = request_id
    return info


def _int_status(value: Any) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) and 100 <= value <= 599 else None


def _attr(obj: Any, name: str) -> Any:
    try:
        return getattr(obj, name, None)
    except Exception:  # noqa: BLE001 - e.g. azure-core raises ResponseNotReadError for unread content
        return None


def _response_body(response: Any) -> bytes | str | None:
    for name in ("text", "content", "body"):
        value = _attr(response, name)
        if callable(value):
            try:
                value = value()
            except Exception:  # noqa: BLE001 - a consumed or closed stream has no body to report
                continue
        if isinstance(value, (bytes, bytearray, str)) and value:
            return value
    return None


def from_response(response: Any) -> dict:
    """`describe` for a non-success response object (requests, httpx or azure-core): status, body and headers."""
    status = _int_status(_attr(response, "status_code")) or _int_status(_attr(response, "status"))
    return describe(status, _response_body(response), _attr(response, "headers"))


def from_exception(exc: BaseException | None) -> dict | None:
    """The service error carried by an SDK/HTTP exception (azure.core `HttpResponseError`, openai
    `APIStatusError`, urllib/requests `HTTPError`, or anything duck-typed with a status), else None."""
    if exc is None:
        return None
    existing = _attr(exc, "service_error")
    if isinstance(existing, dict):
        return existing
    azure_error = False
    try:
        from azure.core.exceptions import HttpResponseError

        azure_error = isinstance(exc, HttpResponseError)
    except ImportError:  # pragma: no cover - azure-core is a dependency
        pass
    response = _attr(exc, "response")
    status = (_int_status(_attr(exc, "status_code")) or _int_status(_attr(exc, "status"))
              or _int_status(_attr(response, "status_code")) or _int_status(_attr(response, "status")))
    body: bytes | str | None = None
    headers: Any = _attr(response, "headers")
    if response is not None:
        body = _response_body(response)
    if status is None:
        status = _int_status(_attr(exc, "code"))
    if status is not None and response is None:
        # urllib's HTTPError is its own response: the body is read from the exception.
        if body is None and callable(_attr(exc, "read")):
            try:
                body = exc.read()  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                body = None
        headers = headers or _attr(exc, "headers") or _attr(exc, "hdrs")
    if status is None and not azure_error and response is None:
        return None
    if body is None and isinstance(_attr(exc, "body"), Mapping):
        raw = exc.body  # type: ignore[attr-defined]
        body = json.dumps(raw if "error" in raw else {"error": raw})
    info = describe(status, body, headers)
    if "code" not in info or "message" not in info:
        err = _attr(exc, "error")
        code = _attr(err, "code") or _attr(exc, "error_code")
        if code is None and isinstance(_attr(exc, "code"), str):
            code = _attr(exc, "code")
        message = _attr(err, "message") or _attr(exc, "message")
        if not isinstance(message, str) or not message:
            message = str(exc) or None
        if "code" not in info and _clean(code, MAX_CODE):
            info["code"] = _clean(code, MAX_CODE)
        if "message" not in info and _clean(message, MAX_MESSAGE):
            info["message"] = _clean(message, MAX_MESSAGE)
    try:  # a body stream reads once; later lookups (CLI envelope, journal) reuse this result
        exc.service_error = info  # type: ignore[union-attr]
    except Exception:  # noqa: BLE001 - some exception types refuse new attributes
        pass
    return info


def response_json(response: Any, what: str, *, empty_ok: bool = False) -> Any:
    """A 2xx response's JSON. An empty body is ``{}`` when ``empty_ok`` (writes often answer
    204); a body that isn't JSON is the service's fault, never the caller's input."""
    from .contracts import ContractError
    body = _response_body(response)
    status = _int_status(_attr(response, "status_code"))
    if not (body.strip() if isinstance(body, (bytes, str)) else body):
        if empty_ok:
            return {}
        detail = "an empty body"
    else:
        try:
            return response.json()
        except ValueError:
            detail = "a body that isn't JSON"
    # The service error summary carries the HTTP status and request ID.
    raise ContractError("AZURE_RESPONSE_INVALID", f"{what} returned HTTP {status} with {detail}",
                        service_error=from_response(response))


def find(exc: BaseException | None) -> dict | None:
    """The first service error along `exc` and its `__cause__`/`__context__` chain, else None."""
    seen: set[int] = set()
    stack = [exc]
    while stack:
        current = stack.pop(0)
        if current is None or id(current) in seen:
            continue
        seen.add(id(current))
        # A coded error (ContractError) carries `service_error` itself, even when None; only its cause can add one.
        if not (hasattr(current, "service_error") and current.service_error is None):
            info = from_exception(current)
            if info is not None:
                return info
        stack += [current.__cause__, None if current.__suppress_context__ else current.__context__]
    return None


def summary(info: dict) -> str:
    """One line: `HTTP 400 InvalidRequestParameter: <message> (request id <id>)`, omitting absent parts."""
    head = " ".join(p for p in (f"HTTP {info['status']}" if info.get("status") is not None else "",
                                str(info.get("code") or "")) if p)
    message = info.get("message")
    if message:
        text = f"{head}: {message}" if head else str(message)
    elif info.get("code"):
        text = head
    else:
        text = f"{head}: no service error body" if head else "no service error body"
    if info.get("request_id"):
        text += f" (request id {info['request_id']})"
    return text


def with_summary(detail: str, info: dict | None) -> str:
    """`detail` followed by the service error summary, when there is one."""
    return f"{detail}. Service error: {summary(info)}" if info else detail
