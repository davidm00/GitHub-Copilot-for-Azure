"""Versioned standalone contracts and deterministic identities."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from typing import Any

BUILD_VERSION = "topic-graph-build-v2"
SCHEMA_VERSION = "topicgraph-release-v1"
DESCRIPTOR_VERSION = "topicgraph-descriptor-v2"
PUBLICATION_VERSION = "topicgraph-publication-v3"
PINNED_DEPENDENCIES = {"topicGraphBuildTool": "github-release:Azure/foundry-iq-tool-releases:latest"}
MIN_LEAF_SIZE, MAX_LEAF_SIZE = 2, 100


class ContractError(ValueError):
    """A coded failure. `service_error` carries the parsed service response (see `service_errors`), when any;
    its one-line summary is appended to the message so humans and agents see what the service said."""

    def __init__(self, code: str, detail: str, *, service_error: dict[str, Any] | None = None):
        if service_error:
            from topicgraph_core.service_errors import with_summary

            detail = with_summary(detail, service_error)
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.service_error = service_error


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class SourceIdentity:
    service: str
    index: str
    embedding_model_id: str
    dimension: int
    expected_count: int

    def validate(self) -> None:
        if not all((self.service, self.index, self.embedding_model_id)):
            raise ContractError("SOURCE_IDENTITY_INVALID", "Service, index and model ID are required")
        if self.dimension < 1 or self.expected_count < 1:
            raise ContractError("SOURCE_IDENTITY_INVALID", "Positive dimension and count are required")


Source = SourceIdentity


def source_identity(fields: dict[str, Any]) -> Source:
    try:
        source = SourceIdentity(**fields)
    except (TypeError, ValueError) as exc:
        raise ContractError("SOURCE_IDENTITY_INVALID", "Invalid source identity fields") from exc
    source.validate()
    return source


@dataclass(frozen=True)
class BuildProfile:
    """Clustering settings passed to the TopicGraph build tool."""
    max_leaf_size: int = 100
    sampling_percentage: int = 4
    minimum_sample_count: int = 30000
    probe_seed: int = 1234
    concurrency: int = 8
    requests_per_second: int = 25
    version: str = BUILD_VERSION

    def validate(self) -> None:
        if self.version != BUILD_VERSION:
            raise ContractError("BUILD_PROFILE_INVALID", "Unsupported build profile version")
        values = (self.max_leaf_size, self.minimum_sample_count, self.concurrency, self.requests_per_second)
        if any(type(v) is not int or v < 1 for v in values) or type(self.probe_seed) is not int:
            raise ContractError("BUILD_PROFILE_INVALID", "Leaf size, sample count, concurrency and request rate must be positive integers")
        if not MIN_LEAF_SIZE <= self.max_leaf_size <= MAX_LEAF_SIZE:
            raise ContractError("BUILD_PROFILE_INVALID", f"Maximum leaf size must be from {MIN_LEAF_SIZE} to {MAX_LEAF_SIZE}")
        if type(self.sampling_percentage) is not int or not 1 <= self.sampling_percentage <= 100:
            raise ContractError("BUILD_PROFILE_INVALID", "Sampling percentage must be an integer from 1 to 100")


@dataclass(frozen=True)
class Descriptor:
    physical_index: str
    generation_id: str
    source_service: str
    source_index: str
    embedding_model_id: str
    dimension: int
    schema_version: str = SCHEMA_VERSION
    version: str = DESCRIPTOR_VERSION
    key_field: str = ""
    text_field: str = ""
    vector_field: str = ""
    title_field: str | None = None
    source_field: str | None = None
    release_id: str = ""
    source_document_count: int | None = None
    # Optional {staged source URL: original document name}, recorded at plan time from the local Entity Graph
    # build that owns the source index. Absent (and omitted from to_dict) for builds without one.
    source_names: dict[str, str] | None = None

    def validate(self) -> None:
        if self.version != DESCRIPTOR_VERSION or self.schema_version != SCHEMA_VERSION:
            raise ContractError("SCHEMA_UNSUPPORTED", "Descriptor/schema version mismatch")
        if not all((self.physical_index, self.generation_id, self.source_service, self.source_index, self.embedding_model_id,
                    self.key_field, self.text_field, self.vector_field, self.release_id)) or self.dimension < 1:
            raise ContractError("DESCRIPTOR_INVALID", "Incomplete physical index/generation/model/field identity")
        count = self.source_document_count
        if count is not None and (type(count) is not int or count < 1):
            raise ContractError("DESCRIPTOR_INVALID", "source_document_count must be a positive integer")
        if self.source_names is not None:
            from topicgraph_core.source_names import check_names

            try:
                check_names(self.source_names)
            except ValueError as exc:
                raise ContractError("DESCRIPTOR_INVALID", str(exc)) from exc

    def to_dict(self) -> dict[str, Any]:
        record = asdict(self)
        if record["source_names"] is None:
            del record["source_names"]  # builds without names keep their original descriptor and digest
        return record


def require_publication_version(record: dict[str, Any]) -> None:
    if record.get("publication_version") != PUBLICATION_VERSION:
        raise ContractError("PLAN_CHANGED", f"This record is not {PUBLICATION_VERSION}; create and approve a new plan")
