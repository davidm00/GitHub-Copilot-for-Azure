"""Human document names for source chunks.

An Entity Graph build stages each original document as an opaque blob (``.../source-item-<hash>.txt``), and
TopicGraph reads that build's content index in place, so a chunk's ``source_id`` is the staged blob URL.
The Entity Graph deployment descriptor records, for each staged URL, the document it came from
(``source_provenance.staged``); its source manifest records the same by ``source_id``. This module turns
either into ``{staged URL or source_id: display name}`` and finds the descriptor that owns a source index.
Everything here is read-only and local; it never calls Azure.
"""

from __future__ import annotations

import json
import os
import posixpath
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit

MAX_SOURCE_NAMES = 10_000
MAX_NAME_LENGTH = 512
MAX_ENTITY_DESCRIPTORS = 256
MAX_ENTITY_DESCRIPTOR_BYTES = 32 * 1024 * 1024
STAGED_PREFIX = "source-item-"


def display_name(uri: Any) -> str | None:
    """The last path segment of a URI or path, decoded: ``file:///c:/corpus/FY24Q3.txt`` -> ``FY24Q3.txt``."""
    if not isinstance(uri, str) or not uri.strip():
        return None
    text = uri.strip()
    path = urlsplit(text).path if "://" in text else text
    name = unquote(posixpath.basename(path.replace("\\", "/").rstrip("/")))
    name = "".join(ch for ch in name if ch.isprintable()).strip()
    return name[:MAX_NAME_LENGTH] or None


def _stem(source: str) -> str:
    """The Entity Graph source ID a staged blob is named after: ``.../source-item-<hash>.txt`` ->
    ``source-item-<hash>``; empty for any other name, so ordinary document names are never matched loosely."""
    base = display_name(source) or ""
    stem = base.rsplit(".", 1)[0] if "." in base else base
    return stem if stem.startswith(STAGED_PREFIX) and len(stem) > len(STAGED_PREFIX) else ""


def _record_name(record: Any) -> str | None:
    if not isinstance(record, Mapping):
        return None
    return display_name(record.get("original_uri")) or display_name(record.get("citation_uri"))


def names_from_entity(document: Any) -> dict[str, str]:
    """Names from an Entity Graph deployment descriptor or source manifest; empty when it is neither."""
    if not isinstance(document, Mapping):
        return {}
    names: dict[str, str] = {}
    provenance = document.get("source_provenance")
    staged = provenance.get("staged") if isinstance(provenance, Mapping) else None
    if isinstance(staged, Mapping):
        for uri, record in staged.items():
            name = _record_name(record)
            if isinstance(uri, str) and uri and name:
                names[uri] = name
        return names
    manifest = document.get("manifest") if isinstance(document.get("manifest"), Mapping) else document
    items = manifest.get("items") if isinstance(manifest, Mapping) else None
    for item in items if isinstance(items, list) else ():
        name = _record_name(item)
        source_id = item.get("source_id") if isinstance(item, Mapping) else None
        if isinstance(source_id, str) and source_id and name:
            names[source_id] = name
    return names


def check_names(names: Any) -> dict[str, str]:
    """A bounded ``{source: name}`` map of nonempty strings, or ``ValueError``."""
    if not isinstance(names, Mapping) or not names or len(names) > MAX_SOURCE_NAMES:
        raise ValueError(f"source_names must be a map of 1 to {MAX_SOURCE_NAMES:,} entries")
    if not all(isinstance(key, str) and key and isinstance(value, str) and value
               and len(value) <= MAX_NAME_LENGTH for key, value in names.items()):
        raise ValueError("source_names keys and names must be nonempty strings")
    return dict(names)


def _search_name(value: Any) -> str:
    text = str(value or "").strip().lower()
    return text.split("://", 1)[-1].split("/", 1)[0].split(".", 1)[0]


def _entity_descriptor_paths() -> list[Path]:
    home = Path(os.environ.get("ENTITY_HOME") or Path.home() / ".entity").expanduser()
    folder = home / "descriptors"
    paths: list[Path] = []
    selected = os.environ.get("ENTITY_DESCRIPTOR")
    if selected:
        paths.append(Path(selected).expanduser())
    try:
        pointer = (folder / "current").read_text(encoding="utf-8").strip()
    except OSError:
        pointer = ""
    if pointer and Path(pointer).is_absolute():
        paths.append(Path(pointer))
    if folder.is_dir():
        paths.extend(sorted(folder.glob("*.json"))[:MAX_ENTITY_DESCRIPTORS])
    return list(dict.fromkeys(paths))


def discover_entity_names(service: str, source_index: str) -> dict[str, str] | None:
    """Names from the local Entity Graph descriptor(s) whose content index is ``source_index`` on ``service``.

    Looks in ``ENTITY_DESCRIPTOR`` and ``ENTITY_HOME`` (default ``~/.entity``) ``descriptors/``. Unreadable or
    unrelated files are skipped; None when nothing matches.
    """
    wanted = _search_name(service)
    names: dict[str, str] = {}
    for path in _entity_descriptor_paths():
        try:
            if not path.is_file() or path.stat().st_size > MAX_ENTITY_DESCRIPTOR_BYTES:
                continue
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        endpoints = document.get("endpoints") if isinstance(document, dict) else None
        if (not isinstance(endpoints, dict) or endpoints.get("content_index") != source_index
                or _search_name(endpoints.get("search")) != wanted):
            continue
        names.update(names_from_entity(document))
    if not names or len(names) > MAX_SOURCE_NAMES:
        return None
    return dict(sorted(names.items()))


def load_names_file(path: Path) -> dict[str, str]:
    """Names from an explicit Entity Graph descriptor or source manifest file."""
    try:
        document = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError(f"cannot read source names from {path}: {exc}") from exc
    names = names_from_entity(document)
    if not names:
        raise ValueError(f"{path} is not an Entity Graph descriptor or source manifest with document names")
    return check_names(names)


class SourceNames:
    """Look a chunk's ``source_id`` up by exact key, then by its staged ``source-item-<hash>`` stem."""

    def __init__(self, names: Mapping[str, str] | None = None):
        self._exact = dict(names or {})
        self._stems: dict[str, str] = {}
        for key, name in self._exact.items():
            stem = _stem(key)
            if stem:
                self._stems.setdefault(stem, name)

    def __bool__(self) -> bool:
        return bool(self._exact)

    def name(self, source_id: Any) -> str | None:
        if not isinstance(source_id, str) or not source_id or not self._exact:
            return None
        found = self._exact.get(source_id)
        stem = _stem(source_id) if found is None else ""
        return found or (self._stems.get(stem) if stem else None)
