"""Read one published topic graph release index: its topic hierarchy, member chunks and chunk text.

The release index holds topic-form edge-list documents (`topicgraph_core.graph_contract`): the
``topicgraph-topic`` graph whose topics are ``topic:<n>``; level 0 is the broadest. A community-form index from
build tool 1.0.7 or earlier fails closed. A topic may have no title when its label was skipped.
Member chunks are not stored in the release: a topic's members are the source chunks nearest its centroid,
and its member count is its share of the clustered source chunks.
"""

from __future__ import annotations

import json
import math
import threading
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Protocol

from topicgraph_core.contracts import ContractError, Descriptor
from topicgraph_core.graph_contract import TOPIC_FORM, check_topic_graph
from topicgraph_core.source_names import SourceNames

from .paging import check_page_size, decode_cursor, encode_cursor

MAX_RELEASE_DOCUMENTS = 10_000
MAX_MEMBERS = 1000
TOPIC_PREFIX = "topic:"
VERIFICATION_SCOPE = "release_index_readback"
TITLE, DESCRIPTION, LEVEL, PROPORTION, PARENT_PROPORTION, CENTROID = (
    "prop:title", "prop:description", "prop:level", "prop:proportion", "prop:parentProportion", "HasCentroidVector")
# Optional facts on the graph root; newer toolkit builds add version, coverage and build stats.
GRAPH_FIELDS = {"prop:generatedAt": "generated_at", "prop:version": "version", "prop:coverage": "coverage",
                "prop:buildStats": "build_stats"}
SITEMAP_DEFAULT_NODES, SITEMAP_MAX_NODES = 500, 2000


class ReleaseStore(Protocol):
    def release_documents(self, descriptor: Descriptor) -> list[dict[str, Any]]:
        """Every release document except vectors, plus the centroid documents with their vectors."""
    def nearest(self, descriptor: Descriptor, vector: list[float], k: int, skip: int,
                top: int) -> list[dict[str, Any]]:
        """Rows ``{key, source, score}`` of the k source chunks nearest ``vector``, paged by skip/top."""
    def lookup(self, descriptor: Descriptor, key: str) -> dict[str, Any] | None:
        """``{key, source, text}`` for one source chunk, or None when it does not exist."""


def invalid(detail: str) -> ContractError:
    return ContractError("TOPIC_INDEX_INVALID", detail)


def check_document_count(count: int) -> None:
    if count > MAX_RELEASE_DOCUMENTS:
        raise ContractError("TOPIC_INDEX_TOO_LARGE", f"The topic index has more than "
                            f"{MAX_RELEASE_DOCUMENTS:,} documents; this reader loads at most that many")


@dataclass
class Topic:
    topic_id: str
    level: int
    proportion: float
    member_count: int
    parent_id: str | None = None
    parent_proportion: float | None = None
    label: str | None = None
    description: str | None = None
    children: list[str] = field(default_factory=list)
    centroid: list[float] | None = None

    def summary(self, children: list[str]) -> dict[str, Any]:
        return {"topic_id": self.topic_id, "level": self.level, "parent_id": self.parent_id,
                "children": list(children), "member_count": self.member_count,
                "label": self.label, "label_status": "named" if self.label else "unnamed"}


def _number(value: Any) -> float | None:
    return float(value) if type(value) in (int, float) and math.isfinite(value) else None


def _vector(value: Any, dimension: int, topic_ref: str) -> list[float]:
    if not isinstance(value, list) or len(value) != dimension or any(_number(v) is None for v in value):
        raise invalid(f"{topic_ref} has no centroid of {dimension} finite numbers")
    return [float(v) for v in value]


def _single(found: dict[str, Any], topic_ref: str, value: Any, name: str) -> None:
    if topic_ref in found:
        raise invalid(f"{topic_ref} repeats its {name}")
    found[topic_ref] = value


def build_hierarchy(documents: list[dict[str, Any]], descriptor: Descriptor) -> dict[str, Topic]:
    """Check the release documents form a forest whose levels match depth, then index it by node ID."""
    check_document_count(len(documents))
    clustered = descriptor.source_document_count
    if not clustered:
        raise ContractError("DESCRIPTOR_INVALID", "The descriptor has no source_document_count; "
                            "it predates the topic index format")
    form = check_topic_graph(documents)

    def topic(value: Any) -> str | None:
        return value if isinstance(value, str) and value.startswith(form.topic_prefix) else None

    roots: set[str] = set()
    parents: dict[str, Any] = {}
    titles: dict[str, Any] = {}
    descriptions: dict[str, Any] = {}
    levels: dict[str, Any] = {}
    proportions: dict[str, Any] = {}
    parent_proportions: dict[str, Any] = {}
    centroids: dict[str, Any] = {}
    for doc in documents:
        predicate, subject, obj = doc.get("predicate"), topic(doc.get("subject_id")), topic(doc.get("object_id"))
        if predicate == form.root:
            if obj is None or obj in roots:
                raise invalid(f"Root edge {doc.get('id')} has a missing or repeated topic")
            roots.add(obj)
            continue
        if subject is None:
            continue
        if predicate == form.child:
            if obj is None:
                raise invalid(f"Child edge {doc.get('id')} has no topic")
            if obj in parents:
                raise invalid(f"{obj} has more than one parent")
            parents[obj] = subject
        elif predicate == TITLE:
            _single(titles, subject, doc.get("object_string"), "title")
        elif predicate == DESCRIPTION:
            _single(descriptions, subject, doc.get("object_string"), "description")
        elif predicate == LEVEL:
            _single(levels, subject, doc.get("object_double"), "level")
        elif predicate == PROPORTION:
            _single(proportions, subject, doc.get("object_double"), "proportion")
        elif predicate == PARENT_PROPORTION:
            _single(parent_proportions, subject, doc.get("object_double"), "parent proportion")
        elif predicate == CENTROID:
            _single(centroids, subject, doc.get("object_vector"), "centroid")
    if not roots:
        raise invalid("The topic index has no root topics")
    ids = roots | set(parents) | set(parents.values()) | set(titles) | set(levels) | set(proportions) | set(centroids)
    if roots & set(parents):
        raise invalid("A root topic also has a parent")
    topics: dict[str, Topic] = {}
    for cid in sorted(ids):
        level, proportion = _number(levels.get(cid)), _number(proportions.get(cid))
        if level is None or level != int(level) or level < 0:
            raise invalid(f"{cid} has no whole-number level")
        if proportion is None or not 0 <= proportion <= 1:
            raise invalid(f"{cid} has no proportion between 0 and 1")
        parent_proportion = None
        if cid in parent_proportions:
            parent_proportion = _number(parent_proportions[cid])
            if parent_proportion is None or not 0 <= parent_proportion <= 1:
                raise invalid(f"{cid} has a parent proportion outside 0 to 1")
        title, description = titles.get(cid), descriptions.get(cid)
        topics[cid] = Topic(
            cid, int(level), proportion, round(proportion * clustered), parent_id=parents.get(cid),
            parent_proportion=parent_proportion,
            label=title.strip() if isinstance(title, str) and title.strip() else None,
            description=description if isinstance(description, str) and description else None)
    for child, parent in parents.items():
        topics[parent].children.append(child)
    seen: set[str] = set()
    frontier = sorted(roots)
    depth = 0
    while frontier:
        following = []
        for cid in frontier:
            if cid in seen:
                raise invalid(f"{cid} is reached twice; the hierarchy has a cycle")
            seen.add(cid)
            if topics[cid].level != depth:
                raise invalid(f"{cid} is at depth {depth} but says level {topics[cid].level}")
            following.extend(topics[cid].children)
        frontier, depth = following, depth + 1
    if seen != set(topics):
        raise invalid(f"{len(set(topics) - seen)} topics are not under any root")
    for node in topics.values():
        node.children.sort(key=lambda c: (-topics[c].proportion, c))
        if not node.children:
            node.centroid = _vector(centroids.get(node.topic_id), descriptor.dimension,
                                         node.topic_id)
    for node in sorted(topics.values(), key=lambda c: -c.level):
        if node.children:
            # A parent has no stored centroid: use the proportion-weighted mean of its leaf descendants' centroids.
            leaves = _leaves(node, topics)
            total = sum(leaf.proportion for leaf in leaves)
            weights = [leaf.proportion / total if total else 1 / len(leaves) for leaf in leaves]
            node.centroid = [sum(w * leaf.centroid[i] for w, leaf in zip(weights, leaves))  # type: ignore[index]
                                  for i in range(descriptor.dimension)]
    return topics


def graph_metadata(documents: list[dict[str, Any]]) -> dict[str, Any]:
    """Optional facts recorded on the graph root; absent facts are None."""
    found: dict[str, Any] = {name: None for name in GRAPH_FIELDS.values()}
    form = TOPIC_FORM
    for doc in documents:
        subject, name = doc.get("subject_id"), GRAPH_FIELDS.get(doc.get("predicate"))  # type: ignore[arg-type]
        if name is None or subject != form.graph_prefix + form.graph_name:
            continue
        value = next((doc[key] for key in ("object_datetime", "object_string", "object_double", "object_bool")
                      if doc.get(key) is not None), None)
        if name == "build_stats" and isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError:
                pass
        if name == "coverage":
            value = _number(value)
        found[name] = value
    return found


def _leaves(node: Topic, topics: dict[str, Topic]) -> list[Topic]:
    if not node.children:
        return [node]
    return [leaf for child in node.children for leaf in _leaves(topics[child], topics)]


class ReleaseReader:
    """Browse one published release index; the hierarchy is read once and kept, since a physical index never changes."""

    def __init__(self, store: ReleaseStore, descriptor: Descriptor,
                 source_names: Callable[[], SourceNames] | None = None):
        for name in ("key_field", "text_field", "vector_field"):
            if not getattr(descriptor, name):
                raise ContractError("DESCRIPTOR_INVALID", f"The descriptor has no {name}")
        self.store = store
        self.descriptor = descriptor
        self._topics: dict[str, Topic] | None = None
        self._graph: dict[str, Any] = {}
        self._lock = threading.Lock()
        self._load_names = source_names or (lambda: SourceNames(descriptor.source_names))
        self._names: SourceNames | None = None
        self._names_lock = threading.Lock()

    def source_name(self, source_id: Any) -> str | None:
        """The original document name for a chunk's source, when the build or local Entity Graph records it."""
        with self._names_lock:
            if self._names is None:
                self._names = self._load_names()
        return self._names.name(source_id)

    def topics(self) -> dict[str, Topic]:
        with self._lock:
            if self._topics is None:
                documents = self.store.release_documents(self.descriptor)
                self._topics = build_hierarchy(documents, self.descriptor)
                self._graph = graph_metadata(documents)
            return self._topics

    def _context(self, operation: str, scope: Any) -> list[Any]:
        return [self.descriptor.physical_index, self.descriptor.generation_id, operation, scope]

    def _topic(self, topic_ref: Any) -> Topic:
        node = self.topics().get(topic_ref) if isinstance(topic_ref, str) else None
        if node is None:
            raise ContractError("TOPIC_NOT_FOUND", str(topic_ref))
        return node

    def level_counts(self) -> dict[int, int]:
        counts: dict[int, int] = {}
        for node in self.topics().values():
            counts[node.level] = counts.get(node.level, 0) + 1
        return dict(sorted(counts.items()))

    def unnamed_count(self) -> int:
        return sum(1 for node in self.topics().values() if not node.label)

    def _page_ids(self, ids: list[str], page_size: int, cursor: str | None, context: list[Any]) -> tuple[list[str], str | None]:
        size = check_page_size(page_size)
        last = decode_cursor(cursor, context)
        if last is None:
            start = 0
        elif last in ids:
            start = ids.index(last) + 1
        else:
            raise ContractError("CURSOR_INVALID", "Invalid or mismatched continuation cursor")
        page = ids[start:start + size]
        return page, encode_cursor(page[-1], context) if start + size < len(ids) else None

    def list_topics(self, level: int | None, page_size: int, cursor: str | None) -> dict[str, Any]:
        topics = self.topics()
        ordered = sorted((c for c in topics.values() if level is None or c.level == level),
                         key=lambda c: (c.level, -c.proportion, c.topic_id))
        page, next_cursor = self._page_ids([c.topic_id for c in ordered], page_size, cursor,
                                           self._context("topic", level))
        return {"items": [topics[cid].summary(list(topics[cid].children)) for cid in page],
                "next_cursor": next_cursor}

    def get_topic(self, topic_id: str, children_page_size: int, children_cursor: str | None) -> dict[str, Any]:
        node = self._topic(topic_id)
        page, next_cursor = self._page_ids(node.children, children_page_size, children_cursor,
                                           self._context("children", node.topic_id))
        return {**node.summary(page), "description": node.description, "children_next_cursor": next_cursor}

    def list_members(self, topic_id: str, page_size: int, cursor: str | None) -> dict[str, Any]:
        node = self._topic(topic_id)
        size = check_page_size(page_size)
        context = self._context("member", node.topic_id)
        last = decode_cursor(cursor, context)
        if last is not None and not last.isdigit():
            raise ContractError("CURSOR_INVALID", "Invalid or mismatched continuation cursor")
        skip = int(last) if last is not None else 0
        total = min(node.member_count, MAX_MEMBERS)
        top = min(size, total - skip)
        if top <= 0:
            return {"items": [], "next_cursor": None}
        rows = self.store.nearest(self.descriptor, node.centroid or [], total, skip, top)
        items = []
        for rank, row in enumerate(rows[:top], skip + 1):
            key = row.get("key")
            if not isinstance(key, str) or not key:
                raise ContractError("SEARCH_REQUEST_FAILED", "The source index returned a chunk without a key")
            source = row.get("source")
            has_source = isinstance(source, str) and bool(source)
            items.append({"chunk_id": key, "source_id": source if has_source else key,
                          "source_name": self.source_name(source) if has_source else None,
                          "sort_key": f"{rank:06d}", "rank": rank, "score": _number(row.get("score"))})
        end = skip + len(items)
        return {"items": items, "next_cursor": encode_cursor(str(end), context)
                if len(items) == top and end < total else None}

    def nearest_chunks(self, topic_id: str, top: int = 100) -> dict[str, Any]:
        node = self._topic(topic_id)
        size = check_page_size(top)
        rows = self.store.nearest(self.descriptor, node.centroid or [], size, 0, size)
        chunk_ids = []
        for row in rows:
            key = row.get("key")
            if not isinstance(key, str) or not key or key in chunk_ids:
                raise ContractError("SEARCH_REQUEST_FAILED", "The source index returned invalid chunk keys")
            chunk_ids.append(key)
        return {
            "topic_id": node.topic_id,
            "generation_id": self.descriptor.generation_id,
            "source_index": self.descriptor.source_index,
            "requested_top": size,
            "chunk_ids": chunk_ids,
        }

    def sitemap(self, topic_id: str | None = None, depth: int | None = None,
                max_nodes: int = SITEMAP_DEFAULT_NODES) -> dict[str, Any]:
        """The named hierarchy as a flat, breadth-first table of contents with coverage, bounded by max_nodes."""
        if type(max_nodes) is not int or not 1 <= max_nodes <= SITEMAP_MAX_NODES:
            raise ContractError("QUERY_INVALID", f"max_nodes must be an integer from 1 to {SITEMAP_MAX_NODES}")
        if depth is not None and (type(depth) is not int or depth < 0):
            raise ContractError("QUERY_INVALID", "depth must be a nonnegative integer")
        topics = self.topics()
        if topic_id is None:
            start = sorted((c for c in topics.values() if c.parent_id is None),
                           key=lambda c: (-c.proportion, c.topic_id))
            root = None
        else:
            start = [self._topic(topic_id)]
            root = start[0].topic_id
        queue = deque((node, 0) for node in start)
        nodes: list[dict[str, Any]] = []
        truncated = False
        while queue:
            node, below = queue.popleft()
            if len(nodes) >= max_nodes:
                truncated = True
                break
            nodes.append({
                "topic_id": node.topic_id,
                "parent_id": node.parent_id,
                "level": node.level,
                "title": node.label,
                "description": node.description,
                "label_status": "named" if node.label else "unnamed",
                "coverage": node.proportion,
                "parent_coverage": node.parent_proportion if node.parent_id else None,
                "member_count": node.member_count,
                "children": list(node.children),
                "has_centroid": not node.children,
            })
            if depth is None or below < depth:
                queue.extend((topics[child], below + 1) for child in node.children)
        return {
            "graph": {**self._graph, "topic_count": len(topics),
                      "levels": {str(level): count for level, count in self.level_counts().items()}},
            "root": root,
            "nodes": nodes,
            "truncated": truncated,
        }

    def get_chunk(self, chunk_id: str) -> dict[str, Any]:
        if not isinstance(chunk_id, str) or not chunk_id:
            raise ContractError("QUERY_INVALID", "chunk_id must be a nonempty string")
        row = self.store.lookup(self.descriptor, chunk_id)
        if row is None:
            raise ContractError("CHUNK_NOT_FOUND", chunk_id)
        source, text = row.get("source"), row.get("text")
        has_source = isinstance(source, str) and bool(source)
        return {"chunk_id": chunk_id, "source_id": source if has_source else chunk_id,
                "source_name": self.source_name(source) if has_source else None,
                "text": text if isinstance(text, str) else ""}
