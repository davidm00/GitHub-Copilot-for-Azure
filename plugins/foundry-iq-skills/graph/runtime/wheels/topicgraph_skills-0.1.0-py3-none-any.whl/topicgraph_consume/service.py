"""Validated, generation-bound browsing of one published topic index."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from topicgraph_core.contracts import ContractError, Descriptor
from topicgraph_core.source_names import SourceNames

from .release_reader import SITEMAP_DEFAULT_NODES, VERIFICATION_SCOPE, ReleaseReader, ReleaseStore

__all__ = ["ConsumeService", "browse_level"]


def _check_level(level: Any) -> None:
    if type(level) is not int or level < 0:
        raise ContractError("LEVEL_INVALID", "level must be a nonnegative integer")


BROWSE_TARGET = 20


def browse_level(per_level: dict[int, int]) -> int | None:
    """Pick the level a person can scan at a glance: 10-30 topics, else the count nearest 20."""
    if not per_level:
        return None
    return min(per_level, key=lambda level: (not 10 <= per_level[level] <= 30,
                                             abs(per_level[level] - BROWSE_TARGET), -level))


class ConsumeService:
    """Browse one explicitly bound physical index without alias privileges.

    The store needs only read access to the topic index and its source index: no alias,
    index-management, embedding or mutation capability. Callers opt into a new descriptor when a
    publisher cuts over to a new build.
    """

    def __init__(self, store: ReleaseStore, descriptor: Descriptor,
                 source_names: Callable[[], SourceNames] | None = None):
        descriptor.validate()
        self.store = store
        self.descriptor = descriptor
        self._reader = ReleaseReader(store, descriptor, source_names)

    def status(self) -> dict[str, Any]:
        per_level = self._reader.level_counts()
        unnamed = self._reader.unnamed_count()
        return {
            "physical_index": self.descriptor.physical_index,
            "generation_id": self.descriptor.generation_id,
            "schema_version": self.descriptor.schema_version,
            "build_health": "verified" if not unnamed else "unlabeled",
            "active": "unknown",
            "verified": True,
            "verification_scope": VERIFICATION_SCOPE,
            "topics_per_level": {str(level): count for level, count in per_level.items()},
            "browse_level": browse_level(per_level),
            "indexed_chunks": self.descriptor.source_document_count,
            "unnamed_topics": unnamed,
        }

    def browse_level(self) -> int | None:
        """The level to show when the caller doesn't pick one."""
        return browse_level(self._reader.level_counts())

    def list_topics(
        self, level: int | None = None, page_size: int = 100, cursor: str | None = None
    ) -> dict[str, Any]:
        if level is not None:
            _check_level(level)
            if level not in self._reader.level_counts():
                raise ContractError("LEVEL_NOT_FOUND", f"This build has no level {level}")
        return self._reader.list_topics(level, page_size, cursor)

    def get_topic(
        self, topic_id: str, children_page_size: int = 1000, children_cursor: str | None = None,
    ) -> dict[str, Any]:
        return self._reader.get_topic(topic_id, children_page_size, children_cursor)

    def list_members(self, topic_id: str, page_size: int = 100, cursor: str | None = None) -> dict[str, Any]:
        return self._reader.list_members(topic_id, page_size, cursor)

    def nearest_chunks(self, topic_id: str, top: int = 100) -> dict[str, Any]:
        from .config import descriptor_endpoint

        if self.descriptor.key_field != "uid":
            raise ContractError("QUERY_INVALID", "Knowledge Graph handoff requires the content chunk key 'uid'")
        return {"chunk_scope": {
            **self._reader.nearest_chunks(topic_id, top),
            "source_endpoint": descriptor_endpoint(self.descriptor),
        }}

    def sitemap(self, topic_id: str | None = None, depth: int | None = None,
                max_nodes: int = SITEMAP_DEFAULT_NODES) -> dict[str, Any]:
        return self._reader.sitemap(topic_id, depth, max_nodes)

    def get_chunk(self, chunk_id: str) -> dict[str, Any]:
        return self._reader.get_chunk(chunk_id)
