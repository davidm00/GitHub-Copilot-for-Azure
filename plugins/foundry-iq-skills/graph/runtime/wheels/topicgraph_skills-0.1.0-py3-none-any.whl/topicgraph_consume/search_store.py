"""Query-only Azure Search adapter for a published topic index and the source index it was built from."""

from __future__ import annotations

import re
import threading
from typing import Any
from urllib.parse import unquote, urlparse

from topicgraph_core import skill_user_agent
from topicgraph_core.contracts import ContractError, Descriptor
from topicgraph_core.service_errors import from_response, with_summary
from .endpoint import validate_search_endpoint
from .release_reader import CENTROID, check_document_count

SEARCH_API_VERSION = "2026-04-01"
RELEASE_FIELDS = ("id", "graph_name", "subject_id", "subject_type", "predicate", "object_id", "object_type",
                  "object_string", "object_double",
                  "object_bool", "object_datetime", "object_vector")
_DOCS_PATH = re.compile(r"^/indexes(?:/([^/()]+)|\('((?:[^']|'')+)'\))/docs(.*)$", re.IGNORECASE)
_READ_TAILS = re.compile(r"^(?:/search(?:\.post\.search)?|/\$count)$", re.IGNORECASE)
_LOOKUP_TAIL = re.compile(r"^(?:\('(?:[^']|'')+'\)|/(?!(?:search|autocomplete|suggest)(?:\.|$))[^/]+)$", re.IGNORECASE)

try:
    from azure.core.pipeline.policies import SansIOHTTPPolicy
except ImportError:  # pragma: no cover
    class SansIOHTTPPolicy:  # type: ignore[no-redef]
        pass


class QueryOnlyPolicy(SansIOHTTPPolicy):
    """Client-side guard that permits only document reads on the topic index and its source index."""

    def __init__(self, physical_index: str, auth: str = "entra", *, endpoint: str | None = None,
                 source_index: str | None = None):
        if not isinstance(physical_index, str) or not physical_index:
            raise ContractError("QUERY_ONLY_VIOLATION", "Physical index binding is required")
        if source_index is not None and (not isinstance(source_index, str) or not source_index):
            raise ContractError("QUERY_ONLY_VIOLATION", "Source index binding must be a nonempty name")
        self.physical_index = physical_index
        self.source_index = source_index
        self.indexes = frozenset(name for name in (physical_index, source_index) if name)
        self.auth = auth
        self.endpoint = validate_search_endpoint(endpoint) if endpoint is not None else None

    def on_response(self, request: Any, response: Any) -> None:
        status = getattr(getattr(response, "http_response", response), "status_code", None)
        if status != 403:
            return
        match = _DOCS_PATH.match(unquote(urlparse(str(getattr(getattr(request, "http_request", request), "url", ""))).path))
        index = (match.group(1) or match.group(2).replace("''", "'")) if match else None
        names = index if index in self.indexes else " and ".join(sorted(self.indexes))
        info = from_response(getattr(response, "http_response", response))
        if self.auth == "query-key":
            error = ContractError("READ_ACCESS_DENIED", with_summary(f"The query key can't read {names}", info)
                                  + ". Next step: ask the builder for a current query key for this service.")
        else:
            error = ContractError("READ_ACCESS_DENIED", with_summary(f"This identity can't read {names}; it needs "
                                                                     "Search Index Data Reader there", info)
                                  + f". Next step: ask the builder to grant Search Index Data Reader on {names}.")
        error.service_error = info
        raise error

    def on_request(self, request: Any) -> None:
        http = getattr(request, "http_request", request)
        method = str(getattr(http, "method", "")).upper()
        parsed = urlparse(str(getattr(http, "url", "")))
        if self.endpoint is not None and f"{parsed.scheme}://{parsed.netloc}" != self.endpoint:
            raise ContractError("QUERY_ONLY_VIOLATION", "Request is not bound to the configured Search origin")
        path = unquote(parsed.path)
        lowered = path.lower()
        if "/aliases" in lowered or lowered.rstrip("/").endswith("/indexes"):
            raise ContractError("QUERY_ONLY_VIOLATION", "Admin Search paths are not permitted")
        match = _DOCS_PATH.match(path)
        index = (match.group(1) or match.group(2).replace("''", "'")) if match else None
        if index not in self.indexes:
            raise ContractError("QUERY_ONLY_VIOLATION", "Request is not bound to the descriptor's indexes")
        tail = match.group(3)  # type: ignore[union-attr]
        if tail.lower().startswith("/index"):
            raise ContractError("QUERY_ONLY_VIOLATION", "Document indexing is not permitted")
        read = method in {"GET", "POST"} and _READ_TAILS.match(tail) is not None
        lookup = method == "GET" and _READ_TAILS.match(tail) is None and _LOOKUP_TAIL.match(tail) is not None
        if not (read or lookup):
            raise ContractError("QUERY_ONLY_VIOLATION", "Only docs search/count/lookup reads are permitted")


def _literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _clean(item: Any) -> dict[str, Any]:
    return {key: val for key, val in dict(item).items() if not key.startswith("@search.") and val is not None}


class _PooledSearchClientProxy:
    """Wrap a pooled SearchClient so per-query .close() does not tear down the shared transport."""

    def __init__(self, inner: Any):
        self._inner = inner

    def close(self) -> None:
        pass

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)


class AzureSearchReadStore:
    """Read the topic index and its source index with injected query-only credentials; never an admin client.

    Topic index documents are paged by ``id gt last``; source chunks are read by vector query and key lookup.
    """

    def __init__(self, endpoint: str, credential: Any, page_size: int = 1000, *, policies: list[Any] | None = None):
        endpoint = validate_search_endpoint(endpoint)
        if type(page_size) is not int or not 1 <= page_size <= 1000:
            raise ContractError("PAGE_SIZE_INVALID", "Azure page size must be 1..1000")
        try:
            from azure.search.documents import SearchClient
        except ImportError as exc:
            raise RuntimeError("Install the azure optional dependency to use Azure Search") from exc
        self.endpoint = endpoint
        self.credential = credential
        self.page_size = page_size
        self._client_type = SearchClient
        self.policies = list(policies or [])
        self._lock = threading.Lock()
        self._pooled_clients: dict[str, Any] = {}

    def _new_client(self, index: str, **extra: Any) -> Any:
        return self._client_type(
            endpoint=self.endpoint, index_name=index, credential=self.credential,
            audience="https://search.azure.com", api_version=SEARCH_API_VERSION, permit_redirects=False,
            user_agent=skill_user_agent(), per_call_policies=[*self.policies, QueryOnlyPolicy(index, endpoint=self.endpoint)],
            **extra,
        )

    def _client(self, index: str) -> Any:
        from azure.search.documents import SearchClient
        if self._client_type is not SearchClient:
            return self._new_client(index)
        with self._lock:
            proxy = self._pooled_clients.get(index)
            if proxy is None:
                import requests
                from azure.core.pipeline.transport import RequestsTransport
                from requests.adapters import HTTPAdapter

                session = requests.Session()
                adapter = HTTPAdapter(pool_connections=16, pool_maxsize=16)
                session.mount("https://", adapter)
                proxy = _PooledSearchClientProxy(
                    self._new_client(index, transport=RequestsTransport(session=session, session_owner=False)))
                self._pooled_clients[index] = proxy
            return proxy

    def release_documents(self, descriptor: Descriptor) -> list[dict[str, Any]]:
        """Every topic index document, in id order; refuses indexes too large to hold in memory."""
        rows: list[dict[str, Any]] = []
        last: str | None = None
        while True:
            client = self._client(descriptor.physical_index)
            try:
                page = [_clean(item) for item in client.search(
                    search_text="*", filter=f"id gt {_literal(last)}" if last is not None else None,
                    order_by=["id asc"], top=self.page_size, select=list(RELEASE_FIELDS), include_total_count=False)]
            finally:
                client.close()
            for row in page:
                key = row.get("id")
                if not isinstance(key, str) or (last is not None and key <= last):
                    raise ContractError("TOPIC_INDEX_INVALID", "Search returned topic documents out of id order")
                if row.get("predicate") != CENTROID:
                    row.pop("object_vector", None)
                last = key
            rows.extend(page)
            check_document_count(len(rows))
            if len(page) < self.page_size:
                return rows

    def nearest(self, descriptor: Descriptor, vector: list[float], k: int, skip: int, top: int) -> list[dict[str, Any]]:
        from azure.search.documents.models import VectorizedQuery

        key, source = descriptor.key_field, descriptor.source_field
        client = self._client(descriptor.source_index)
        try:
            results = [dict(item) for item in client.search(
                search_text=None, vector_queries=[VectorizedQuery(vector=vector, k_nearest_neighbors=k,
                                                                  fields=descriptor.vector_field)],
                select=[key, *([source] if source else [])], top=top, skip=skip, include_total_count=False)]
        finally:
            client.close()
        return [{"key": row.get(key), "source": row.get(source) if source else None,
                 "score": row.get("@search.score")} for row in results]

    def source_count(self, descriptor: Descriptor) -> int:
        """Read-only probe of the source index: the same reader role that member and chunk reads need."""
        client = self._client(descriptor.source_index)
        try:
            return int(client.get_document_count())
        finally:
            client.close()

    def lookup(self, descriptor: Descriptor, key: str) -> dict[str, Any] | None:
        from azure.core.exceptions import ResourceNotFoundError

        fields = [descriptor.key_field, descriptor.text_field, *([descriptor.source_field] if descriptor.source_field else [])]
        client = self._client(descriptor.source_index)
        try:
            row = dict(client.get_document(key=key, selected_fields=fields))
        except ResourceNotFoundError:
            return None
        finally:
            client.close()
        return {"key": row.get(descriptor.key_field), "text": row.get(descriptor.text_field),
                "source": row.get(descriptor.source_field) if descriptor.source_field else None}
