"""Read-only browsing of a published topic index."""

from .service import ConsumeService

__all__ = ["ConsumeService"]
