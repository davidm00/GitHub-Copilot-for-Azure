"""One connection config for topic-graph-consume and topicgraph-mcp: flags first, then TOPICGRAPH_* environment variables."""

from __future__ import annotations

import argparse
import json
import os
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from topicgraph_core.contracts import ContractError, Descriptor
from topicgraph_core.current import read_current, scope_of
from topicgraph_core.source_names import SourceNames, discover_entity_names, load_names_file

from .service import ConsumeService
from .endpoint import validate_search_endpoint

AUTH_MODES = ("query-key", "entra")


@dataclass(frozen=True)
class ConsumeConfig:
    descriptor: Path | None = None
    documents: Path | None = None
    endpoint: str | None = None
    auth: str = "entra"
    tenant_id: str | None = None
    query_key: str | None = None
    from_current: bool = False
    source_names: Path | None = None


def descriptor_endpoint(descriptor: Descriptor) -> str:
    """Published topic indexes live on the source Search service, not the prior binding."""
    service = descriptor.source_service
    if service.startswith("https://"):
        return validate_search_endpoint(service)
    from topicgraph_build.live import service_endpoint
    return validate_search_endpoint(service_endpoint(service))


def _env_path(name: str) -> Path | None:
    value = os.environ.get(name)
    return Path(value) if value else None


def add_connection_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--descriptor", type=Path, help="Published physical-index descriptor JSON (or TOPICGRAPH_DESCRIPTOR)")
    parser.add_argument("--documents", type=Path, help="Offline test/dev only: JSON object with the topic index \"documents\" and source \"chunks\" ({key, source, text, vector}) (or TOPICGRAPH_DOCUMENTS)")
    parser.add_argument("--endpoint", help="HTTPS Azure Search endpoint (or TOPICGRAPH_SEARCH_ENDPOINT)")
    parser.add_argument("--auth", choices=AUTH_MODES, help="Azure auth mode (or TOPICGRAPH_SEARCH_AUTH); default entra with your signed-in tenant; "
                             "query-key reads TOPICGRAPH_SEARCH_QUERY_KEY")
    parser.add_argument("--tenant-id", help="Tenant ID for --auth entra (or TOPICGRAPH_TENANT_ID); default: the tenant you are signed in to")
    parser.add_argument("--source-names", type=Path,
                        help="Entity Graph descriptor or source manifest JSON naming the source documents "
                             "(or TOPICGRAPH_SOURCE_NAMES); default: the descriptor's names, then a local Entity Graph")


def resolve_config(args: argparse.Namespace) -> ConsumeConfig:
    """Flags, then TOPICGRAPH_* variables, then the build the user last published. Missing pieces are reported later."""
    auth = getattr(args, "auth", None) or os.environ.get("TOPICGRAPH_SEARCH_AUTH")
    config = ConsumeConfig(
        descriptor=getattr(args, "descriptor", None) or _env_path("TOPICGRAPH_DESCRIPTOR"),
        documents=getattr(args, "documents", None) or _env_path("TOPICGRAPH_DOCUMENTS"),
        endpoint=getattr(args, "endpoint", None) or os.environ.get("TOPICGRAPH_SEARCH_ENDPOINT"),
        auth=auth or "entra",
        tenant_id=getattr(args, "tenant_id", None) or os.environ.get("TOPICGRAPH_TENANT_ID"),
        query_key=getattr(args, "query_key", None),
        source_names=getattr(args, "source_names", None) or _env_path("TOPICGRAPH_SOURCE_NAMES"),
    )
    if config.descriptor is None and config.documents is None:
        current = read_current()
        if current is not None:
            config = replace(config, descriptor=Path(current["descriptor"]), from_current=True,
                             endpoint=config.endpoint or current["endpoint"], auth=auth or current["auth"],
                             tenant_id=config.tenant_id or current["tenant_id"])
    elif config.descriptor is not None and config.documents is None and not config.endpoint:
        current = _current_for(config.descriptor)
        if current is not None and Path(current["descriptor"]).resolve() == config.descriptor.resolve():
            config = replace(config, endpoint=current["endpoint"], auth=auth or current["auth"],
                             tenant_id=config.tenant_id or current["tenant_id"])
    if config.auth not in AUTH_MODES:
        raise ContractError("AUTH_UNSUPPORTED", f"Auth mode {config.auth!r} is not query-key or entra")
    return config


def _current_for(path: Path) -> dict[str, Any] | None:
    """The published pointer for this descriptor's source, when the descriptor is readable."""
    try:
        return read_current(scope_of(json.loads(path.read_text(encoding="utf-8"))))
    except (OSError, ValueError, TypeError, KeyError):
        return None


def load_descriptor(config: ConsumeConfig) -> Descriptor:
    if config.descriptor is None:
        raise ContractError("DESCRIPTOR_REQUIRED", "No build to browse: nothing published from this account, "
                                                   "and no --descriptor or TOPICGRAPH_DESCRIPTOR")
    try:
        data = json.loads(config.descriptor.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"Cannot read {config.descriptor}: {exc.strerror or exc}") from exc
    except json.JSONDecodeError as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"{config.descriptor} is not JSON") from exc
    if not isinstance(data, dict):
        raise ContractError("DESCRIPTOR_INVALID", f"{config.descriptor} is not a descriptor object")
    try:
        descriptor = Descriptor(**data)
    except TypeError as exc:
        raise ContractError("DESCRIPTOR_INVALID", f"{config.descriptor} has unknown or missing fields") from exc
    descriptor.validate()
    return descriptor


def source_names_loader(descriptor: Descriptor, explicit: Path | None = None) -> Callable[[], SourceNames]:
    """Document names, first found: an explicit Entity Graph descriptor or source manifest, the names this
    build recorded in its descriptor, then a local Entity Graph descriptor for the same source index.

    An explicit file is read now so a bad path fails at startup; discovery waits for the first member read.
    """
    if explicit is not None:
        try:
            names = SourceNames(load_names_file(explicit))
        except ValueError as exc:
            raise ContractError("SOURCE_NAMES_INVALID", str(exc)) from exc
        return lambda: names
    if descriptor.source_names:
        return lambda: SourceNames(descriptor.source_names)
    if not descriptor.source_field:
        return SourceNames
    return lambda: SourceNames(discover_entity_names(descriptor.source_service, descriptor.source_index))


def build_service(config: ConsumeConfig) -> ConsumeService:
    descriptor = load_descriptor(config)
    names = source_names_loader(descriptor, config.source_names)
    if config.documents is None and not config.endpoint:
        # The descriptor names the Search service that holds the topic and source indexes.
        config = replace(config, endpoint=descriptor_endpoint(descriptor))
    if config.documents is not None and config.endpoint:
        raise ContractError("SOURCE_REQUIRED", "Pass --documents or --endpoint, not both "
                                               "(or TOPICGRAPH_DOCUMENTS / TOPICGRAPH_SEARCH_ENDPOINT)")
    if config.documents is not None:
        if config.query_key:
            raise ContractError("QUERY_INVALID", "--query-key cannot be used with offline documents")
        from .offline_store import load_offline_store

        store = load_offline_store(config.documents)
    else:
        from .connect import build_store

        store = build_store(descriptor, config.endpoint or "", config.auth, config.tenant_id,  # type: ignore[arg-type]
                            query_key=config.query_key)
    return ConsumeService(store, descriptor, names)
