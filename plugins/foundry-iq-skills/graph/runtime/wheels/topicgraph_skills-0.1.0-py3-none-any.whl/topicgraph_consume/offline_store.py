"""Offline test/dev store: release documents and source chunks from one JSON file, with cosine nearest neighbours.

File shape: ``{"documents": [release index documents], "chunks": [{"key", "source", "text", "vector"}]}``.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from topicgraph_core.contracts import ContractError, Descriptor

from .release_reader import check_document_count


def _input(detail: str) -> ContractError:
    return ContractError("INPUT_INVALID", detail)


def _cosine(left: list[float], right: list[float]) -> float:
    norms = math.sqrt(sum(v * v for v in left)) * math.sqrt(sum(v * v for v in right))
    return sum(a * b for a, b in zip(left, right)) / norms if norms else 0.0


class OfflineReleaseStore:
    def __init__(self, documents: list[dict[str, Any]], chunks: list[dict[str, Any]]):
        check_document_count(len(documents))
        if any(not isinstance(doc, dict) or not isinstance(doc.get("id"), str) for doc in documents):
            raise _input("Every release document needs an id")
        self.documents = documents
        self.chunks: dict[str, dict[str, Any]] = {}
        for chunk in chunks:
            key = chunk.get("key") if isinstance(chunk, dict) else None
            vector = chunk.get("vector") if isinstance(chunk, dict) else None
            if not isinstance(key, str) or not key or key in self.chunks:
                raise _input("Every chunk needs a unique key")
            if not isinstance(vector, list) or not vector or any(type(v) not in (int, float) for v in vector):
                raise _input(f"Chunk {key} has no vector")
            self.chunks[key] = chunk

    def release_documents(self, descriptor: Descriptor) -> list[dict[str, Any]]:
        return [dict(doc) for doc in self.documents]

    def nearest(self, descriptor: Descriptor, vector: list[float], k: int, skip: int, top: int) -> list[dict[str, Any]]:
        scored = sorted(((_cosine(vector, chunk["vector"]), key) for key, chunk in self.chunks.items()
                         if len(chunk["vector"]) == len(vector)), key=lambda item: (-item[0], item[1]))
        return [{"key": key, "source": self.chunks[key].get("source"), "score": score}
                for score, key in scored[:k][skip:skip + top]]

    def lookup(self, descriptor: Descriptor, key: str) -> dict[str, Any] | None:
        chunk = self.chunks.get(key)
        return None if chunk is None else {"key": key, "source": chunk.get("source"), "text": chunk.get("text")}


def load_offline_store(path: Path) -> OfflineReleaseStore:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except OSError as exc:
        raise _input(f"Cannot read {path}: {exc.strerror or exc}") from exc
    except json.JSONDecodeError as exc:
        raise _input(f"{path} is not JSON") from exc
    if not isinstance(data, dict) or not isinstance(data.get("documents"), list) or not isinstance(data.get("chunks"), list):
        raise _input(f"{path} needs a documents list and a chunks list")
    return OfflineReleaseStore(data["documents"], data["chunks"])
