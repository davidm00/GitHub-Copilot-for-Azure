"""Read-only CLI for a published topic index."""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Callable

from topicgraph_core.cli_output import add_json_option, add_version_option, error_body, emit
from topicgraph_core.doctor import emit_doctor
from topicgraph_core.contracts import ContractError
from topicgraph_core.service_errors import find

from .config import add_connection_options, build_service, resolve_config
from .release_reader import SITEMAP_DEFAULT_NODES, SITEMAP_MAX_NODES
from .service import ConsumeService

JSON_SCHEMA_VERSION = "topic-graph-consume-v1"


def add_source_options(parser: argparse.ArgumentParser) -> None:
    add_connection_options(parser)
    parser.add_argument("--query-key", help="Azure Search query key; prefer TOPICGRAPH_SEARCH_QUERY_KEY")


def make_service(args: argparse.Namespace) -> ConsumeService:
    return build_service(resolve_config(args))


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(prog="topic-graph-consume", description="Preview read-only topic graph browser")
    add_source_options(result)
    add_json_option(result)
    add_version_option(result)
    commands = result.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="Read only: check this machine, sign-in, descriptor and topic index access")
    commands.add_parser("status")
    listing = commands.add_parser("list-topics", help="List topics at one level, broadest first")
    listing.add_argument("--level", type=int, help="Defaults to the level with about 10-30 topics; 0 is broadest")
    listing.add_argument("--page-size", type=int, default=100, help="1-1000 (default 100)")
    listing.add_argument("--cursor", help="next_cursor from the previous page (default: first page)")
    topic = commands.add_parser("get-topic", help="One topic with its description and children")
    topic.add_argument("topic_id", help="topic ID from list-topics, for example topic:0")
    topic.add_argument("--children-page-size", type=int, default=1000, help="1-1000 (default 1000)")
    topic.add_argument("--children-cursor", help="children_next_cursor from the previous call")
    members = commands.add_parser("list-members", help="Source passages closest to a topic, most typical first")
    members.add_argument("topic_id", help="topic ID from list-topics, for example topic:0")
    members.add_argument("--page-size", type=int, help="1-1000 (default 100); at most 1000 members in total")
    members.add_argument("--cursor", help="next_cursor from the previous page (default: first page)")
    chunk = commands.add_parser("get-chunk", help="Full text of one source passage")
    chunk.add_argument("chunk_id", help="chunk_id from list-members")
    sitemap = commands.add_parser("sitemap", help="The named topic hierarchy as a table of contents with coverage")
    sitemap.add_argument("--topic", help="Start at this topic, for example topic:0 (default: every root topic)")
    sitemap.add_argument("--depth", type=int, help="Levels to include below the start (default: all)")
    sitemap.add_argument("--max-nodes", type=int, default=SITEMAP_DEFAULT_NODES,
                         help=f"1-{SITEMAP_MAX_NODES} topics at most (default {SITEMAP_DEFAULT_NODES}); larger trees are truncated")
    sitemap.add_argument("--format", choices=("json", "markdown"), default="json",
                         help="json (default) is the reader output; markdown is an indented outline")
    for sub in commands.choices.values():
        add_json_option(sub, subcommand=True)
    return result



def _name(row: dict[str, Any]) -> str:
    return row.get("label") or "(unnamed)"


def _more(result: dict[str, Any], command: str) -> str:
    return f"\nMore: run the same {command} with --cursor {result['next_cursor']}" if result.get("next_cursor") else ""


CHECKS = {
    "release_index_readback": "the topic hierarchy was read back and checked",
}


def summarize_status(result: dict[str, Any]) -> str:
    counts = result.get("topics_per_level") or {}
    levels = ", ".join(f"level {level}: {counts[level]}" for level in sorted(counts, key=int))
    check = CHECKS.get(result["verification_scope"], result["verification_scope"])
    return (f"Ready: {check}.\n"
            f"Topics per level (0 is broadest): {levels}.\n"
            f"Browsing starts at level {result['browse_level']}. Next: list-topics")


def summarize_topics(result: dict[str, Any]) -> str:
    rows = result["items"]
    lines = [f"{len(rows)} topics" + (f" at level {result['level']}" if "level" in result else "") + ":"]
    for row in sorted(rows, key=lambda r: -r["member_count"]):
        lines.append(f"  {_name(row)} - {row['member_count']} chunks  [{row['topic_id']}]")
    lines.append("Next: get-topic <id> or list-members <id>")
    return "\n".join(lines) + _more(result, "list-topics")


def summarize_topic(result: dict[str, Any]) -> str:
    children = result.get("children") or []
    return (f"{_name(result)}: {result['member_count']} chunks at level {result['level']}, "
            f"{len(children)} narrower topics.\nNext: list-members {result['topic_id']}")


def summarize_members(result: dict[str, Any]) -> str:
    lines = [f"{len(result['items'])} members:"] + [f"  {r.get('source_name') or r['source_id']}  [{r['chunk_id']}]"
                                                    for r in result["items"]]
    return "\n".join(lines + ["Next: get-chunk <chunk id>"]) + _more(result, "list-members")


def summarize_chunk(result: dict[str, Any]) -> str:
    text = " ".join(str(result.get("text", "")).split())
    return f"{result.get('source_name') or result.get('source_id')}\n{text[:600]}" + ("..." if len(text) > 600 else "")


def _percent(value: Any) -> str:
    return f"{value * 100:.0f}%" if isinstance(value, (int, float)) else "?"


def sitemap_markdown(result: dict[str, Any]) -> str:
    """Indented outline: each topic with its share of clustered passages and its description."""
    nodes = {node["topic_id"]: node for node in result["nodes"]}
    lines: list[str] = []

    def walk(topic_id: str, indent: int) -> None:
        node = nodes[topic_id]
        title = f"**{node['title']}**" if node.get("title") else f"(unnamed {node['topic_id']})"
        line = f"{'  ' * indent}- {title} ({_percent(node.get('coverage'))})"
        if node.get("description"):
            line += f" — {' '.join(str(node['description']).split())}"
        lines.append(line)
        for child in node.get("children") or []:
            if child in nodes:
                walk(child, indent + 1)

    tops = [node["topic_id"] for node in result["nodes"]
            if node["topic_id"] == result.get("root") or node.get("parent_id") not in nodes]
    for topic_id in tops:
        walk(topic_id, 0)
    graph = result.get("graph") or {}
    header = [f"# Sitemap: {graph.get('topic_count', len(nodes))} topics",
              "Coverage is each topic's share of clustered passages."]
    if graph.get("generated_at"):
        header.append(f"Generated {graph['generated_at']}.")
    footer = [f"\nTruncated at {len(nodes)} topics; use --topic or --depth to narrow it."] if result.get("truncated") else []
    return "\n".join(header + [""] + lines + footer)


def _emit_result(result: dict[str, Any], as_json: bool,
                 summary: Callable[[dict[str, Any]], str] | None) -> None:
    if as_json:
        print(json.dumps({"schema_version": JSON_SCHEMA_VERSION, "result": result},
                         sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(",", ":")))
    else:
        emit(result, False, summary, compact=False)


def _emit_error(exc: BaseException, as_json: bool, default_code: str = "QUERY_INVALID") -> int:
    body = error_body(exc, default_code)
    if as_json:
        print(json.dumps({"schema_version": JSON_SCHEMA_VERSION, **body},
                         sort_keys=True, ensure_ascii=False), file=sys.stderr)
    else:
        print(f"Blocked. {body['error_code']}: {body['error']}\nNext step: {body['next_step']}",
              file=sys.stderr)
    return 2


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        if args.command == "doctor":
            from .doctor import run_doctor

            report = run_doctor(resolve_config(args))
            if args.json:
                _emit_result(report, True, None)
                return 0
            return emit_doctor(report, False, "topic-graph-consume")
        service = make_service(args)
        if args.command == "status":
            result, summary = service.status(), summarize_status
        elif args.command == "list-topics":
            level = args.level if args.level is not None else service.browse_level()
            result = {**service.list_topics(level, args.page_size, args.cursor), "level": level}
            if args.cursor is None and result.get("next_cursor") is None:
                result["items"] = sorted(result["items"], key=lambda r: (-r["member_count"], r["topic_id"]))
            summary = summarize_topics
        elif args.command == "get-topic":
            result = service.get_topic(args.topic_id, args.children_page_size, args.children_cursor)
            summary = summarize_topic
        elif args.command == "list-members":
            page_size = args.page_size if args.page_size is not None else 100
            result = service.list_members(args.topic_id, page_size, args.cursor)
            summary = summarize_members
        elif args.command == "sitemap":
            result = service.sitemap(args.topic, args.depth, args.max_nodes)
            if args.format == "markdown" and not args.json:
                print(sitemap_markdown(result) + "\nNext: get-topic <id> for one topic, or list-members <id> "
                      "for its closest passages")
            else:
                _emit_result(result, True, None)
            return 0
        else:
            result, summary = service.get_chunk(args.chunk_id), summarize_chunk
        _emit_result(result, args.json, summary)
        return 0
    except (ContractError, ValueError, OSError, TypeError, ImportError) as exc:
        return _emit_error(exc, args.json)
    except Exception as exc:  # an SDK error the service answered: report what it said instead of a traceback
        if find(exc) is None:
            raise
        return _emit_error(exc, args.json, "SEARCH_REQUEST_FAILED")


if __name__ == "__main__":
    raise SystemExit(main())
