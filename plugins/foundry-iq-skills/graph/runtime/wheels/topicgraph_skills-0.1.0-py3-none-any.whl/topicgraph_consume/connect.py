"""Credential and store construction for TopicGraph Consume."""

from __future__ import annotations

import os
from typing import Any, Literal

from topicgraph_core.azure_auth import create_default_credential, resolve_tenant, validate_tenant
from topicgraph_core.contracts import ContractError, Descriptor

from .search_store import AzureSearchReadStore, QueryOnlyPolicy
from .endpoint import validate_search_endpoint


def build_store(
    descriptor: Descriptor,
    endpoint: str,
    auth: Literal["query-key", "entra"] = "entra",
    tenant_id: str | None = None,
    *,
    query_key: str | None = None,
    credential: Any | None = None,
) -> AzureSearchReadStore:
    descriptor.validate()
    endpoint = validate_search_endpoint(endpoint)
    from .config import descriptor_endpoint

    # Members are read from the source index with the same credential, so both indexes must share one service.
    if descriptor_endpoint(descriptor) != endpoint:
        raise ContractError("PLACEMENT_UNSUPPORTED", f"The topic index on {endpoint} and its source index "
                            f"{descriptor.source_index} on {descriptor.source_service} must be on the same "
                            "Search service")
    if auth == "query-key":
        key = query_key or os.environ.get("TOPICGRAPH_SEARCH_QUERY_KEY")
        if not key:
            raise ContractError("QUERY_INVALID", "query-key auth requires TOPICGRAPH_SEARCH_QUERY_KEY")
        from azure.core.credentials import AzureKeyCredential
        credential = AzureKeyCredential(key)
    elif auth == "entra":
        tenant = tenant_id or os.environ.get("TOPICGRAPH_TENANT_ID")
        if credential is None:
            credential = create_default_credential()
        validate_tenant(credential, resolve_tenant(credential, tenant))
    else:
        raise ContractError("QUERY_INVALID", "--auth must be query-key or entra")
    return AzureSearchReadStore(endpoint, credential,
                                policies=[QueryOnlyPolicy(descriptor.physical_index, auth, endpoint=endpoint,
                                                          source_index=descriptor.source_index)])
