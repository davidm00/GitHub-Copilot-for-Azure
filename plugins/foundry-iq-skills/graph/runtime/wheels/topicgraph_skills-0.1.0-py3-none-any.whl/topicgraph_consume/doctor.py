"""topic-graph-consume doctor: read-only checks of the machine, sign-in, descriptor and topic index."""

from __future__ import annotations

import json
import shutil
from dataclasses import replace
from pathlib import Path
from typing import Any, Callable

from topicgraph_core import doctor as d
from topicgraph_core.contracts import ContractError
from topicgraph_core.service_errors import from_exception, with_summary

from .config import ConsumeConfig, build_service

CLI = "topic-graph-consume"
CHECK = "topic_index"
SOURCE_CHECK = "source_reader"


def check_source_reader(config: ConsumeConfig, signed_in: bool, descriptor_ok: bool = True) -> d.Check:
    """Members and chunk text come from the source index, so a reader needs Search Index Data Reader there too."""
    if config.descriptor is None or not descriptor_ok:
        return d.skip(SOURCE_CHECK, "needs a readable descriptor")
    if config.documents:
        return d.skip(SOURCE_CHECK, "the --documents file holds the source chunks")
    if not config.endpoint:
        return d.skip(SOURCE_CHECK, "no --endpoint (or TOPICGRAPH_SEARCH_ENDPOINT)")
    if config.auth == "entra" and not signed_in:
        return d.skip(SOURCE_CHECK, "--auth entra needs a signed-in --tenant-id")
    service = build_service(config)
    index = service.descriptor.source_index
    try:
        count = service.store.source_count(service.descriptor)
    except ContractError as exc:
        if exc.code != "READ_ACCESS_DENIED" or config.auth == "query-key":
            raise
        info = exc.service_error
        return d.fail(SOURCE_CHECK, exc.code, with_summary(f"{index}: this identity can't read the source index", info),
                      f"ask the owner of the source index {index} to grant this identity Search Index Data Reader "
                      "on it (members and chunk text are read from there), then run doctor again.",
                      service_error=info)
    except Exception as exc:
        if type(exc).__name__ != "ResourceNotFoundError":
            raise
        info = from_exception(exc)
        return d.fail(SOURCE_CHECK, "INDEX_MISSING",
                      with_summary(f"source index {index} not found on {config.endpoint}", info),
                      "ask the builder whether the source index moved, then use a descriptor that names it.",
                      service_error=info)
    return d.ok(SOURCE_CHECK, f"{index}: {count:,} source chunks readable")


def check_topic_index(config: ConsumeConfig, signed_in: bool, descriptor_ok: bool = True) -> d.Check:
    if config.descriptor is None or not descriptor_ok:
        return d.skip(CHECK, "needs a readable descriptor")
    if not (config.documents or config.endpoint):
        return d.skip(CHECK, "no --endpoint (or TOPICGRAPH_SEARCH_ENDPOINT)")
    if config.endpoint and config.auth == "entra" and not signed_in:
        return d.skip(CHECK, "--auth entra needs a signed-in --tenant-id")
    status = build_service(config).status()
    counts = status.get("topics_per_level") or {}
    unnamed = f", {status['unnamed_topics']} without a title" if status.get("unnamed_topics") else ""
    return d.ok(CHECK, f"{status['physical_index']}: hierarchy checked, "
                       f"{sum(counts.values())} topics over {len(counts)} levels{unnamed}")


def run_doctor(config: ConsumeConfig, *, which: Callable[[str], str | None] = shutil.which,
               run: d.Runner = d._run) -> dict[str, Any]:
    seen: dict[str, d.Check] = {}

    def remember(name: str, check: Callable[[], d.Check]) -> Callable[[], d.Check]:
        def wrapped() -> d.Check:
            try:
                seen[name] = check()
            except Exception:
                seen[name] = {"status": d.FAIL}
                raise
            return seen[name]
        return wrapped

    def passed(name: str) -> bool:
        return seen.get(name, {}).get("status") == d.OK

    account = d.read_account(which, run)
    if not config.tenant_id and isinstance(account, dict) and account.get("tenantId"):
        # Default to the Azure CLI's current tenant when --tenant-id is absent.
        config = replace(config, tenant_id=account["tenantId"])
    result = d.run_checks([
        ("cli_version", lambda: d.check_cli_version(CLI)),
        ("python", d.check_python),
        ("azure_signin", remember("azure_signin", lambda: d.check_azure_signin(config.tenant_id, which=which, run=run,
                                                                           account=account))),
        ("descriptor", remember("descriptor", lambda: d.check_descriptor(config.descriptor))),
        (SOURCE_CHECK, lambda: check_source_reader(config, passed("azure_signin"),
                                                   config.descriptor is None or passed("descriptor"))),
        (CHECK, lambda: check_topic_index(config, passed("azure_signin"),
                                          config.descriptor is None or passed("descriptor"))),
    ], ok_next_step=f"run {CLI} status with the same connection flags.")
    return d.report(result, account=d.account_or_none(account), current=current_of(config))


def current_of(config: ConsumeConfig) -> dict[str, str] | None:
    """The build doctor would browse: an explicit descriptor, or the only published source's record."""
    if config.descriptor is None:
        return None
    if config.from_current:
        return d.current_build()
    try:
        generation = json.loads(Path(config.descriptor).read_text(encoding="utf-8")).get("generation_id")
    except (OSError, ValueError, AttributeError):
        generation = None
    return {"kind": "descriptor", "path": str(config.descriptor), "id": str(generation or "")}
