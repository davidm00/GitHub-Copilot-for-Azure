"""Run the installed Consume CLI with python -m topicgraph_consume."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
