"""Run the optional read-only TopicGraph MCP Apps adapter over the official SDK stdio transport."""

from __future__ import annotations

import argparse
import json
import sys
import traceback

from topicgraph_consume.config import add_connection_options, resolve_config
from topicgraph_core.cli_output import add_version_option, error_body
from topicgraph_core.contracts import ContractError
from topicgraph_core.service_errors import find


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(
        prog="topicgraph-mcp",
        description=(
            "Read-only TopicGraph MCP server. Descriptor, connection and offline fixture scope are bound "
            "at startup; tool calls cannot override them."
        ),
    )
    add_connection_options(result)
    result.add_argument("--query-key", help="Azure Search query key; prefer TOPICGRAPH_SEARCH_QUERY_KEY")
    add_version_option(result)
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        config = resolve_config(args)
        from .mcp import create_server

        server = create_server(config)
        # MCP stdio is UTF-8 JSON-RPC; Windows pipes otherwise default to the ANSI code page.
        sys.stdin.reconfigure(encoding="utf-8")
        sys.stdout.reconfigure(encoding="utf-8", newline="\n")
        server.run()
        return 0
    except ImportError as exc:
        if isinstance(exc, ModuleNotFoundError) and exc.name == "mcp":
            print(json.dumps({
                "error": f"ModuleNotFoundError: {exc}. Apps support is missing. Run the supplied distribution's "
                         '`python -I "<plugin-root>/graph/runtime/bootstrap.py" setup topicgraph`; '
                         "for source development, install the pinned Apps dependencies into your explicit local venv.",
                "error_code": "APPS_EXTRA_MISSING", "status": "blocked",
            }, sort_keys=True), file=sys.stderr)
            return 2
        traceback.print_exc(file=sys.stderr)
        print(json.dumps(error_body(exc, "MCP_DEPENDENCY_UNAVAILABLE"),
                         sort_keys=True, ensure_ascii=False), file=sys.stderr)
        return 2
    except (ContractError, ValueError, OSError, TypeError) as exc:
        print(json.dumps(error_body(exc, "CLI_ERROR"), sort_keys=True, ensure_ascii=False), file=sys.stderr)
        return 2
    except Exception as exc:  # an SDK error the service answered: report what it said instead of a traceback
        if find(exc) is None:
            raise
        print(json.dumps(error_body(exc, "SEARCH_REQUEST_FAILED"), sort_keys=True, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
