"""Read-only topicgraph-skills MCP server."""
