"""Run topicgraph-mcp with python -m topicgraph_mcp."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
