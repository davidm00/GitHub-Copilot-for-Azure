"""Short topic-graph-build summaries, plus the plan and descriptor files that let users skip copying IDs around."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from topicgraph_core.cli_output import mb
from topicgraph_core.contracts import ContractError
from topicgraph_core.state import State
from topicgraph_core.current import atomic_json

from topicgraph_build.live import service_endpoint


def _quote(arg: str) -> str:
    # Single quotes work the same way in PowerShell and POSIX shells.
    return arg if re.fullmatch(r"[\w@%+=:,./\\-]+", arg) else "'" + arg.replace("'", "''") + "'"


def command_prefix(argv: list[str], command: str) -> str:
    """The user's own global flags, so a printed next step can be pasted as is."""
    head = argv[:argv.index(command)] if command in argv else []
    return " ".join(["topic-graph-build", *(_quote(a) for a in head if a != "--json")])


# Plan output fields that are not part of the saved, digest-bound plan.
OUTPUT_ONLY = ("approval_card", "apply_command", "next_step")


def find_plan_state_dirs(state_dir: Path, plan_id: str) -> list[Path]:
    """State folders next to or inside ``state_dir`` that hold this saved plan."""
    root = Path(state_dir).resolve()
    hits = {path.parent.parent for base in (root.parent, root)
            for path in base.glob(f"*/plans/{plan_id}.json")}
    return sorted(hits - {root})


def apply_command(state_dir: Path, plan_id: str) -> str:
    """The exact apply command for a saved plan; the saved plan supplies every other setting."""
    return " ".join(["topic-graph-build", "--state-dir", _quote(str(Path(state_dir).resolve())),
                     "apply", "--plan-id", plan_id, "--confirm-writes"])


def plan_path(state_dir: Path, plan_id: str) -> Path:
    return state_dir / "plans" / f"{plan_id}.json"


def descriptor_path(state_dir: Path) -> Path:
    return state_dir / "descriptor.json"


def _write(path: Path, value: Any) -> None:
    atomic_json(path, value)


def latest_generation(state: State) -> str:
    built = [e["generation_id"] for e in state.events()
             if e.get("stage") == "apply" and e.get("state") == "verified" and e.get("generation_id")]
    if not built:
        raise ContractError("GENERATION_UNKNOWN", "No built generation in this state directory")
    return built[-1]


_SAVED_SETTINGS = ("tenant_id", "subscription_id", "resource_group", "search_service", "dataset")
_SAVED_FIELDS = {"key_field": "key", "text_field": "text", "vector_field": "vector",
                 "title_field": "title", "source_field": "source"}


def _saved_plan(args: argparse.Namespace) -> dict[str, Any] | None:
    """The plan this command acts on: its own --plan-file, or the plan that produced --generation-id."""
    if getattr(args, "plan_file", None) is not None:
        return json.loads(Path(args.plan_file).read_text(encoding="utf-8"))
    generation_id = getattr(args, "generation_id", None)
    if generation_id is None:
        return None
    record = State(args.state_dir / "operations").generation(generation_id)
    path = plan_path(args.state_dir, record["plan_id"])
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None


def _reuse_plan_settings(args: argparse.Namespace, saved: dict[str, Any]) -> None:
    """Fill flags the user left out from the saved plan; anything passed explicitly still has to match it."""
    def fill(name: str, value: Any) -> None:
        if hasattr(args, name) and not getattr(args, name) and value:
            setattr(args, name, value)

    for name in _SAVED_SETTINGS:
        fill(name, saved.get(name))
    naming = saved.get("run_naming") or (saved.get("binding") or {}).get("run_naming") or {}
    fill("run_prefix", naming.get("prefix"))
    source = saved.get("source") if isinstance(saved.get("source"), dict) else {}
    fill("source_index", saved.get("source_index") or source.get("index"))
    fill("embedding_model_id", source.get("embedding_model_id"))
    fields = saved.get("fields") if isinstance(saved.get("fields"), dict) else {}
    for name, role in _SAVED_FIELDS.items():
        fill(name, fields.get(role))


def fill_defaults(args: argparse.Namespace) -> None:
    """Let apply, reconcile and retire find the saved plan, and read-only verify find the latest build.

    Settings the user leaves out come from that saved plan, so follow-up commands need only the plan or
    generation ID. publish is a write, so it never picks its generation implicitly; a stale or aborted
    build could be cut over unnamed.
    """
    administrative = args.command in ("status", "generations", "plan-retire") and (
        getattr(args, "plan_id", None) is not None or getattr(args, "plan_file", None) is not None)
    if (args.command in ("apply", "reconcile", "retire", "configure-retrieval", "verify-retrieval") or administrative) and getattr(args, "plan_file", None) is None:
        if not getattr(args, "plan_id", None):
            raise ContractError("PLAN_NOT_FOUND", f"{args.command} needs --plan-id (or --plan-file)")
        args.plan_file = plan_path(args.state_dir, args.plan_id)
        if not args.plan_file.exists():
            error = ContractError("PLAN_NOT_FOUND", f"No saved plan {args.plan_id} in {args.state_dir}")
            found = find_plan_state_dirs(args.state_dir, args.plan_id)
            if len(found) == 1:
                error.next_step = (f"the plan is in {found[0]}; nothing was changed. Run: "
                                   + apply_command(found[0], args.plan_id))
            raise error
    if args.command == "publish" and getattr(args, "generation_id", None) is None:
        latest = latest_generation(State(args.state_dir / "operations"))
        error = ContractError("GENERATION_REQUIRED", "publish needs --generation-id naming the generation to select locally")
        error.next_step = f"pass --generation-id {latest} (the latest verified build) once local publication is approved."
        raise error
    if args.command == "verify" and getattr(args, "generation_id", None) is None:
        args.generation_id = latest_generation(State(args.state_dir / "operations"))
    saved = _saved_plan(args)
    if saved is not None:
        _reuse_plan_settings(args, saved)
    if hasattr(args, "embedding_model_id") and not args.embedding_model_id:
        args.embedding_model_id = _entity_embedding_model(args)


def _search_name(value: Any) -> str:
    text = str(value or "").strip().lower()
    host = text.split("://", 1)[-1].split("/", 1)[0]
    return host.split(".", 1)[0]


def _entity_embedding_model(args: argparse.Namespace) -> str | None:
    """The embedding model from an Entity Graph connect binding for this Search service.

    Only bindings whose target Search endpoint matches the source service count. Matching
    bindings that disagree are refused rather than resolved by file order.
    """
    service = _search_name(getattr(args, "search_service", None))
    if not service:
        return None
    search_dirs = [Path.cwd() / ".entity", Path.cwd()]
    if getattr(args, "state_dir", None):
        search_dirs.insert(0, Path(args.state_dir).parent)
    models: dict[str, list[str]] = {}
    for d in dict.fromkeys(search_dirs):
        for jf in sorted(d.glob("*.json")) if d.is_dir() else ():
            try:
                payload = json.loads(jf.read_text(encoding="utf-8"))
            except Exception:
                continue
            binding = payload.get("build_binding") if isinstance(payload, dict) else None
            if not isinstance(binding, dict):
                continue
            target = binding.get("target") if isinstance(binding.get("target"), dict) else {}
            model = binding.get("embedding_model")
            if (isinstance(model, str) and model
                    and _search_name(target.get("search_endpoint")) == service):
                models.setdefault(model, []).append(jf.name)
    if len(models) > 1:
        found = "; ".join(f"{m} ({', '.join(files)})" for m, files in sorted(models.items()))
        raise ContractError("SOURCE_IDENTITY_INVALID",
                            f"Entity Graph bindings for {service} name different embedding "
                            f"models: {found}. Pass --embedding-model-id.")
    return next(iter(models), None)


def generation_descriptor_path(state_dir: Path, generation_id: str) -> Path:
    return state_dir / "descriptors" / f"{generation_id}.json"


def retrieval_setup(args: argparse.Namespace, generation_id: str) -> dict[str, Any]:
    command = " ".join(["topic-graph-build", "--state-dir", _quote(str(args.state_dir.resolve())),
                        "--json", "plan-retrieval", "--generation-id", generation_id,
                        "--topic-diversity", "off"])
    return {
        "state": "not_checked", "live_queries": "not_run", "plan_command": command,
        "next_step": ("Building and publishing do not configure native Search/KB retrieval. "
                      "For retrieval, run plan_command; for KB use, append --knowledge-source and "
                      "--knowledge-base from the final Entity Graph descriptor for this content index. "
                      "After separate approval, configure-retrieval and verify-retrieval must succeed "
                      "before reporting retrieval setup complete. Keep live query validation separate."),
    }


def browse_settings(args: argparse.Namespace, result: dict[str, Any]) -> dict[str, Any]:
    """The environment a Copilot CLI session needs to browse the generation just published. Never a key or token."""
    env = {"TOPICGRAPH_DESCRIPTOR": str(generation_descriptor_path(args.state_dir, result["generation_id"]).resolve()),
           "TOPICGRAPH_SEARCH_ENDPOINT": service_endpoint(args.search_service),
           "TOPICGRAPH_SEARCH_AUTH": "entra",
           "TOPICGRAPH_TENANT_ID": args.tenant_id}
    return {"env": env,
            # Consume reads the endpoint from the descriptor and signs in as the current user.
            "command": " ".join(["topic-graph-consume", "--descriptor", _quote(env["TOPICGRAPH_DESCRIPTOR"]), "sitemap"]),
            "powershell": [f"$env:{name} = '{value}'" for name, value in env.items()],
            "note": "Set these in the shell, then start Copilot CLI from it so the TopicGraph MCP server inherits them."}


def save_artifacts(args: argparse.Namespace, result: dict[str, Any]) -> None:
    # The approval card is display-only; saved plans and descriptors must match their digests without it.
    result = {k: v for k, v in result.items() if k not in OUTPUT_ONLY}
    if args.command in ("plan", "plan-retire", "plan-retrieval") and "plan_id" in result:
        _write(plan_path(args.state_dir, result["plan_id"]), result)
    elif args.command == "apply" and "generation_id" in result:
        atomic_json(generation_descriptor_path(args.state_dir, result["generation_id"]), result, immutable=True)
        _write(descriptor_path(args.state_dir), result)


def _approve_line(result: dict[str, Any], prefix: str) -> str:
    if result.get("apply_command"):
        return f"For the agent, after the user approves, run exactly:\n  {result['apply_command']}"
    flags = f"--plan-id {result['plan_id']}"
    if result.get("backend") == "azure":
        flags += " --confirm-writes"
    return f"To run it after approval:\n  {prefix} apply {flags}"


def _card(result: dict[str, Any]) -> str | None:
    card = result.get("approval_card")
    return card["text"] if card else None


def summarize_plan(result: dict[str, Any], prefix: str) -> str:
    card = _card(result)
    if card:
        details = (result.get("approval_card") or {}).get("details") or []
        return "\n".join([card, *(result.get("warnings") or []), _approve_line(result, prefix),
                          *(["Details (show only if the user asks):", *(f"  - {d}" for d in details)]
                            if details else [])])
    source = result["source"]
    lines = [f"Plan {result['plan_id']}",
             f"  Reads {source['expected_count']:,} chunks in {source['index']} in place "
             f"({source['dimension']}-d, {source['embedding_model_id']}) and generates topics locally.",
             f"  While it builds, the build tool will "
             + "; ".join(result["source_temporary_changes"]["changes"])
             + f" on {result['source_temporary_changes']['index']} and remove it afterwards.",
             f"  Names topics with {result['model']['deployment']} ({result['model']['name']}): "
             f"at most {result['model_call_cap']:,} model calls.",
             f"  Creates one new index {result['target_index_prefix']}<release content ID> and uploads the "
             "topic documents.",
             "  Local default selection changes only after you approve publish; other readers require explicit rollout."]
    readers = result.get("reader_grants")
    if readers:
        lines.append(f"  Will {readers['approval']}.")
    lines += [f"  {w}" for w in result.get("warnings") or []]
    return "\n".join(lines + [_approve_line(result, prefix)])


def _publish_line(result: dict[str, Any], prefix: str) -> str:
    card = _card(result)
    return (card + "\n" if card else "") + f"To publish it after approval:\n  {prefix} publish --generation-id {result['generation_id']} --approve-publish"


def summarize_apply(result: dict[str, Any], state_dir: Path, prefix: str) -> str:
    return ("Built and verified a new generation. The local default is unchanged.\n"
            f"Descriptor for Consume: {descriptor_path(state_dir)}\n"
            f"Next, read it back; verify shows the publish approval:\n  {prefix} verify --generation-id {result['generation_id']}")


def _retrieval_line(result: dict[str, Any]) -> str:
    setup = result.get("retrieval_setup")
    if not setup:
        return ""
    return ("\nNative Search/KB retrieval is not checked. " + setup["next_step"]
            + f"\nRead-only setup plan (add the final KS/KB for KB use):\n  {setup['plan_command']}")


def summarize_verify(result: dict[str, Any], prefix: str) -> str:
    counts = result["counts"]
    text = ("Verified: every document read back. "
            + ", ".join(f"{counts[k]:,} {k}" for k in sorted(counts)) + ".")
    text += ("\n" + _publish_line(result, prefix) if result.get("generation_id") else "")
    return text + _retrieval_line(result)


def summarize_publish(result: dict[str, Any]) -> str:
    text = "Done: this computer now uses the new topics for browsing."
    browse = result.get("browse")
    if browse:
        text += f"\nTo show the topics, run exactly:\n  {browse['command']}"
    text += _retrieval_line(result)
    return "\n".join([text, *(f"Warning: {w}" for w in result.get("warnings") or [])])


def summarize_status(result: dict[str, Any]) -> str:
    serving = result.get("active_physical_index")
    incomplete = result.get("incomplete_generations") or []
    text = (f"Selected locally: {serving}." if serving
            else "Nothing is published yet.")
    if incomplete:
        text += f"\n{len(incomplete)} build(s) failed; run reconcile before retrying."
    return text


def summarize_generations(result: dict[str, Any]) -> str:
    lines = [f"  {row['role']:<13} {row['index']}  {row['document_count']:,} docs, {mb(row['storage_bytes'])}"
             for row in result["generations"]]
    candidates = result.get("retire_candidates") or []
    tail = f"Can be retired: {', '.join(candidates)}" if candidates else "Nothing to retire."
    return "\n".join(["Generations:"] + lines + [tail])


def summarize_retire_plan(result: dict[str, Any], prefix: str) -> str:
    card = _card(result)
    if card:
        return card + f"\nTo run it after approval:\n  {prefix} retire --plan-id {result['plan_id']} --confirm-writes"
    readers = result.get("reader_grants") or []
    return (f"Retire plan {result['plan_id']}\n"
            f"  Deletes {result['index']} ({result['document_count']:,} docs, {mb(result['storage_bytes'])}). "
            "The published generation and the source index are untouched."
            + (f"\n  Also removes {len(readers)} reader grant(s) on it." if readers else "")
            + f"\nTo run it after approval:\n  {prefix} retire --plan-id {result['plan_id']} --confirm-writes")


def summarize_retire(result: dict[str, Any]) -> str:
    revoked = result.get("reader_grants_revoked")
    return f"Retired {result['index']}; checked it's gone and the published generation didn't move." + (
        f" Removed {revoked} reader grant(s)." if revoked else "")


def summarize_inspect(result: dict[str, Any], prefix: str) -> str:
    stats = result.get("index_stats") or {}
    headroom = result.get("headroom") or {}
    lines = ["Source looks usable for a TopicGraph build."]
    if stats:
        lines.append(f"  {int(stats.get('documentCount') or 0):,} documents, {mb(stats.get('storageSize'))}.")
    if headroom:
        lines.append(f"  {headroom.get('free_index_slots')} free index slot(s) on the service.")
    lines += [f"  {w}" for w in result.get("warnings") or []]
    return "\n".join(lines + [f"Next:\n  {prefix} plan"])


def summarize_download_native(result: dict[str, Any], prefix: str) -> str:
    card = _card(result)
    if card:
        return (
            f"{card}\nTo download after approval:\n  "
            f"{prefix} download-native --plan-id {result['plan_id']} --approve-download"
        )
    verb = "Reused cached" if result.get("reused") else "Downloaded and verified"
    return (
        f"{verb} TopicGraph native binary {result.get('tag')} ({result.get('asset_name')}, "
        f"{result.get('asset_digest')}) at {result.get('binary_path')}."
    )


def summarize(args: argparse.Namespace, argv: list[str], result: Any) -> str | None:
    command = args.command
    prefix = command_prefix(argv, command)
    with_prefix = {"plan": summarize_plan, "plan-retire": summarize_retire_plan, "inspect": summarize_inspect,
                   "verify": summarize_verify, "download-native": summarize_download_native}
    plain = {"publish": summarize_publish, "status": summarize_status,
             "generations": summarize_generations, "retire": summarize_retire}
    if command == "apply":
        return summarize_apply(result, args.state_dir, prefix)
    if command == "plan-retrieval":
        return (_card(result) + f"\nTo run it after approval:\n  {prefix} configure-retrieval "
                f"--plan-id {result['plan_id']} --confirm-writes")
    if command in ("configure-retrieval", "verify-retrieval"):
        resources = "\n".join(f"  {row['resource']}: {row['state']}" for row in result["resources"])
        return (f"Native retrieval configuration: {result['state']} (default {result['default_kind']}).\n"
                f"{resources}\nLive queries were not run.\nNext: {result['next_step']}")
    if command in with_prefix:
        return with_prefix[command](result, prefix)
    return plain[command](result) if command in plain else None
