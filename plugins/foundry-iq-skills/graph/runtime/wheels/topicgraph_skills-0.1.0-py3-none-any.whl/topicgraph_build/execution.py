"""Approval-gated Build: run the TopicGraph build, then create, upload, verify and publish its release index."""

from __future__ import annotations
import re
import time
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from topicgraph_adapters.azure_publication import inventory_digest, same_document
from topicgraph_adapters.native_adapter import (
    SEARCH_API_VERSION,
    NativeBuildAdapter,
    build_native_config,
    error_line,
    native_error,
)
from topicgraph_adapters.native_runner import build_directory, validate_native_config
from topicgraph_build.planner import approve_plan, plan
from topicgraph_build.reader_grants import missing_readers
from topicgraph_build.release import Release
from topicgraph_core.adapters import BuildStore
from topicgraph_core.graph_contract import LEGACY_FORM, check_topic_graph, holds_legacy_rows
from topicgraph_core.contracts import (
    PUBLICATION_VERSION, BuildProfile, ContractError, Descriptor, Source, source_identity, digest, require_publication_version,
)
from topicgraph_core import service_errors
from topicgraph_core.current import (
    checked_current, commit_current, current_record, topicgraph_home, publication_context, publication_lock,
    scope_of,
)
from topicgraph_core.state import State

UPLOAD_BATCH_SIZE = 500
NATIVE_PHASE = "native-build"
REVERT_FAILED = "SOURCE_REVERT_FAILED"
BUDGET_EXHAUSTED = "MODEL_CALL_BUDGET_EXHAUSTED"
RESUME_REJECTED = "NATIVE_RESUME_REJECTED"
# The tool's documented refusals to continue from a saved build folder (see its "Safety and resume rules").
_RESUME_REJECTION = re.compile(
    r"current generation|--fresh|legacy|not owned by TopicGraph|cannot be resumed"
    r"|checkpoint\S*\s.*\b(incompatible|mismatch|corrupt|invalid|unsupported)",
    re.IGNORECASE)
# Plan keys that decide the build's output; approval-only keys such as the model call cap stay out, so a
# re-plan with a higher cap resumes the same build with its call counts. The native release is a build key,
# so a newer build tool never resumes checkpoints written by another release. Authentication is not a build key.
BUILD_KEYS = ("source", "source_binding", "fields", "profile", "model", "label_settings",
              "native_download", "pinned_dependencies", "target_service")


def _source_binding(store: BuildStore, inspected: dict[str, Any]) -> dict[str, Any] | None:
    binder = getattr(store, "source_binding", None)
    return binder(inspected) if callable(binder) else None


def _ambiguous_write(exc: BaseException) -> bool:
    """A timeout or 5xx may have landed server-side, so the journal must not call it failed."""
    current: BaseException | None = exc
    while current is not None:
        status = getattr(current, "status_code", getattr(getattr(current, "response", None), "status_code", None))
        if status == 408 or (isinstance(status, int) and status >= 500):
            return True
        name = type(current).__name__.lower()
        if "timeout" in name or "connection" in name:
            return True
        current = current.__cause__
    return False


def _journaled_write(state: State, plan_id: str, generation: str | None, stage: str, phase: str, target: str,
                     action: Callable[[], None], *, key_digest: str | None = None,
                     detail: dict[str, Any] | None = None) -> None:
    """Journal intent, run one write, then journal its outcome; never retry here."""
    state.record_write(plan_id, generation, stage, phase, target, key_digest=key_digest, detail=detail)
    try:
        action()
    except BaseException as exc:
        info = service_errors.find(exc)
        state.record_write(plan_id, generation, stage, phase, target, key_digest=key_digest,
                           status="ambiguous" if _ambiguous_write(exc) else "failed",
                           error_code=getattr(exc, "code", "WRITE_FAILED"),
                           detail={**(detail or {}), "service_error": info} if info else detail)
        raise
    state.record_write(plan_id, generation, stage, phase, target, key_digest=key_digest, status="confirmed", detail=detail)


def _check_upload(results: list[dict[str, Any]], expected: int, message: str) -> None:
    if len(results) != expected or any(not result.get("succeeded") for result in results):
        raise ContractError("UPLOAD_FAILED", message)


def _self_reverted(event: dict[str, Any]) -> bool:
    """A build the tool stopped itself has reverted its temporary source changes; rerunning apply resumes it."""
    return (event.get("phase") == NATIVE_PHASE and event.get("status") == "failed"
            and event.get("error_code") != REVERT_FAILED)


def _with_next_step(error: ContractError, next_step: str) -> ContractError:
    error.next_step = next_step
    return error


def build_failure(code: str, message: str, *, resumed_from: Path | None = None) -> ContractError:
    """The tool's own error, with the one next step that fits it. Never retried automatically."""
    if message.startswith("Could not revert"):
        return _with_next_step(ContractError(REVERT_FAILED, message),
                               "run reconcile with this plan to clean up the source index, then rerun apply with the "
                               "same plan and --resume-after-reconcile.")
    if message.startswith("Call budget for"):
        return _with_next_step(ContractError(BUDGET_EXHAUSTED, message),
                               "the approved model call cap was reached. Make a new plan with a higher "
                               "--model-call-cap, review and approve it, then apply it; the build resumes.")
    if resumed_from is not None and _RESUME_REJECTION.search(message):
        # Apply always resumes an existing build folder, so rerunning would fail the same way.
        return _with_next_step(
            ContractError(RESUME_REJECTED, f"The build tool could not resume the saved build in {resumed_from}: "
                                           f"{message}"),
            f"delete the folder {resumed_from} to start this build over, then rerun apply with the same plan. "
            "Rerunning without deleting it fails the same way.")
    return _with_next_step(ContractError(code, message),
                           "rerun apply with the same plan; the build resumes where it stopped.")


def document_counts(documents: list[dict[str, Any]]) -> dict[str, int]:
    form = check_topic_graph(documents)
    topics = {doc.get("subject_id") for doc in documents if str(doc.get("subject_id", "")).startswith(form.topic_prefix)}
    return {"documents": len(documents), "topics": len(topics)}


class BuildService:
    def __init__(self, store: BuildStore, state: State, workspace: Path, *,
                 native_adapter: NativeBuildAdapter | None = None,
                 output_root: Path | None = None):
        self.store, self.state, self.workspace = store, state, Path(workspace)
        self.native_adapter = native_adapter or NativeBuildAdapter()
        self.output_root = Path(output_root) if output_root else self.workspace / "topicgraph-output"
        self.workspace.mkdir(parents=True, exist_ok=True)

    def native_output_directory(self, planned: dict[str, Any]) -> Path:
        """Durable TopicGraph output directory for one build (kept for resume, cleanup and ontology)."""
        return self.output_root / digest({key: planned.get(key) for key in BUILD_KEYS})[:16]

    def inspect(self, source: Source) -> dict[str, Any]:
        source.validate()
        return self.store.inspect(source)

    def plan(self, source: Source, profile: BuildProfile, *, fields: dict[str, Any], model: dict[str, Any],
             dataset: str, model_call_cap: int | None = None) -> dict[str, Any]:
        inspected = self.inspect(source)
        return plan(source, profile, target_service=source.service, fields=fields, model=model, dataset=dataset,
                    publication=publication_context({"endpoint": source.service, "source_index": source.index,
                                                     "tenant_id": getattr(self.store, "tenant_id", "")}),
                    inspected=inspected, model_call_cap=model_call_cap)

    def _await_ids(self, index: str, expected_ids: set[str], timeout_seconds: float = 120) -> list[dict[str, Any]]:
        # Search indexing is near-real-time: uploaded keys, and the document count, can lag the upload.
        deadline = time.monotonic() + timeout_seconds
        delay = 0.25
        while True:
            try:
                observed = self.store.readback(index)
            except ContractError as exc:
                if exc.code != "READBACK_NOT_SETTLED" or time.monotonic() >= deadline:
                    raise
                observed = None
            if observed is not None and {d["id"] for d in observed} == expected_ids and len(observed) == len(expected_ids):
                return observed
            if time.monotonic() >= deadline:
                raise ContractError("READBACK_MISMATCH", "Physical index records not visible before timeout")
            time.sleep(min(delay, max(0, deadline - time.monotonic())))
            delay = min(delay * 2, 8)

    def apply(self, planned: dict[str, Any], plan_id: str, *, resume_after_reconcile: bool = False) -> Descriptor:
        approve_plan(planned, plan_id)
        source = source_identity(planned["source"])
        profile = BuildProfile(**planned["profile"])
        with self.state.publisher_lock():
            blocking = [event for event in self.state.unresolved_writes(plan_id) if not _self_reverted(event)]
            if blocking or (self.state.resume_required(plan_id) and not resume_after_reconcile):
                raise ContractError("RECONCILE_REQUIRED", "Reconcile every unresolved write, then explicitly approve resume with --resume-after-reconcile")
            if self.state.resume_required(plan_id):
                self.state.record_write(plan_id, None, "apply", "resume-approved", source.index, status="confirmed")
            before = self.inspect(source)
            self._check_source_matches_plan(planned, before)
            self.state.record(plan_id, None, "apply", "running", expected={"evidence": source.expected_count})
            timings: dict[str, int] = {}
            generation: str | None = None
            try:
                started = time.perf_counter()
                release = self._run_build(planned, plan_id, source, profile)
                timings["build"] = int((time.perf_counter() - started) * 1000)
                generation = release.content_id
                index = self.store.generation_index_name(generation)
                self._check_retained(generation, plan_id)
                self._check_target_index_free(index, plan_id)
                started = time.perf_counter()
                observed = self._upload_release(plan_id, release, index,
                                                (planned.get("reader_grants") or {}).get("grant", []),
                                                planned["publication"]["binding"])
                timings["upload_and_verify"] = int((time.perf_counter() - started) * 1000)
                return self._save_candidate(planned, plan_id, release, index, source, timings, observed)
            except (ContractError, ValueError, OSError) as exc:
                self.state.record(plan_id, generation, "apply", "failed", error_code=getattr(exc, "code", "BUILD_FAILED"))
                raise

    def _check_source_matches_plan(self, planned: dict[str, Any], inspected: dict[str, Any]) -> dict[str, Any] | None:
        binding = _source_binding(self.store, inspected)
        if binding is not None:
            if binding != planned.get("source_binding"):
                raise ContractError("SOURCE_CHANGED", "Source definition, count or vector binding changed since approved plan")
        elif digest(inspected) != planned["source_inspection_digest"]:
            raise ContractError("SOURCE_CHANGED", "Source schema or field mapping changed since approved plan")
        return binding

    def _check_target_index_free(self, index: str, plan_id: str) -> None:
        target_exists = getattr(self.store, "target_exists", None)
        if callable(target_exists) and target_exists(index) and not self.state.owns_index(plan_id, index):
            raise ContractError("INDEX_COLLISION", "The release's index already exists outside this journal")
        if self.state.retiring_index(index):
            raise ContractError("RETIRE_TARGET_PROTECTED", "A retired or retiring index cannot be reused")

    def _check_retained(self, generation: str, plan_id: str) -> None:
        try:
            retained = self.state.generation(generation)
        except ContractError as exc:
            if exc.code != "GENERATION_UNKNOWN":
                raise
            return
        require_publication_version(retained)
        if retained["plan_id"] != plan_id:
            raise ContractError("GENERATION_CHANGED", "This same-content release is already bound to another approval in this state directory. Select its retained physical descriptor explicitly; do not rebuild it here to refresh publication approval. No index or grant writes were made.")

    def native_config(self, planned: dict[str, Any], source: Source, profile: BuildProfile) -> dict[str, Any]:
        binding = planned.get("source_binding") or {}
        fields = planned["fields"]
        if binding and binding.get("vector_field") != fields["vector"]:
            raise ContractError("NATIVE_SOURCE_BINDING_INVALID", "The plan's vector field differs from its source binding")
        return build_native_config(
            endpoint=planned.get("endpoint") or getattr(self.store, "endpoint", f"https://{source.service}.search.windows.net"),
            source_index=source.index,
            vector_field=fields["vector"],
            text_field=fields["text"],
            title_field=fields.get("title"),
            doc_id_field=fields.get("source"),
            output_directory=self.native_output_directory(planned).resolve(),
            model=planned["model"],
            api_version=binding.get("search_api_version") or SEARCH_API_VERSION,
            auth_mode=planned["native_authentication"]["mode"],
            tenant_id=planned.get("tenant_id") or getattr(self.store, "tenant_id", None) or None,
            sampling_percentage=profile.sampling_percentage,
            minimum_sample_count=profile.minimum_sample_count,
            probe_seed=profile.probe_seed,
            max_leaf_size=profile.max_leaf_size,
            concurrency=profile.concurrency,
            requests_per_second=profile.requests_per_second,
            sitemap_options=planned.get("label_settings"),
        )

    def _run_build(self, planned: dict[str, Any], plan_id: str, source: Source, profile: BuildProfile) -> Release:
        """Run the build tool once, journaled as a source write: it adds a temporary scoring profile to the source index."""
        config = self.native_config(planned, source, profile)
        output = Path(config["outputDirectory"])
        resume = build_directory(output).exists()
        config_path = self.native_adapter.write_config(config)
        flags = ["--call-budget", f"Model={planned['model_call_cap']}"]
        detail = {"config_path": str(config_path), "output_directory": str(output), "resume": resume}
        self.state.record_write(plan_id, None, "apply", NATIVE_PHASE, source.index, detail=detail)
        try:
            _result, release = self.native_adapter.build_from_config(config_path, resume=resume, extra_flags=flags)
        except ContractError as exc:
            result = getattr(exc, "result", None)
            if result is not None:
                failure = build_failure(exc.code, error_line(result),
                                        resumed_from=build_directory(output) if resume else None)
                failure.service_error = getattr(exc, "service_error", None) or native_error(result)
                self.state.record_write(plan_id, None, "apply", NATIVE_PHASE, source.index, status="failed",
                                        error_code=failure.code,
                                        detail={**detail, "service_error": failure.service_error})
                raise failure from exc
            # The tool finished, but its release is unusable; its source changes are already reverted.
            finished = exc.code.startswith("RELEASE_")
            self.state.record_write(plan_id, None, "apply", NATIVE_PHASE, source.index,
                                    status="confirmed" if finished else "ambiguous", error_code=exc.code, detail=detail)
            if not finished:
                raise _with_next_step(exc, "run reconcile with this plan to clean up the source index.") from None
            raise
        except BaseException:
            self.state.record_write(plan_id, None, "apply", NATIVE_PHASE, source.index, status="ambiguous",
                                    error_code="NATIVE_INTERRUPTED", detail=detail)
            raise
        self.state.record_write(plan_id, None, "apply", NATIVE_PHASE, source.index, status="confirmed",
                                detail={**detail, "release_id": release.release_id, "content_id": release.content_id})
        return release

    def _upload_release(self, plan_id: str, release: Release, index: str,
                        readers: list[dict[str, Any]] = (), binding: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Create the index, grant planned readers, upload missing documents, then read every one back."""
        generation, documents = release.content_id, release.documents
        present = self._existing_or_new_index(plan_id, release, index, binding)
        self._grant_readers(plan_id, generation, index, readers)
        for start in range(0, len(documents), UPLOAD_BATCH_SIZE):
            batch = [d for d in documents[start:start + UPLOAD_BATCH_SIZE] if d["id"] not in present]
            if batch:
                _journaled_write(
                    self.state, plan_id, generation, "apply", "upload-batch", index,
                    lambda batch=batch: _check_upload(self.store.upload_batch(index, batch), len(batch),
                                                      "Unresolved partial document upload"),
                    key_digest=digest([d["id"] for d in batch]), detail={"count": len(batch)})
        self._await_ids(index, {d["id"] for d in documents})
        self.state.record_write(plan_id, generation, "apply", "retention-protect", index, status="confirmed")
        self.store.verify(index, documents)
        observed = self.store.readback(index)
        self._record_verified(plan_id, generation, index, document_counts(observed))
        return observed

    def _grant_readers(self, plan_id: str, generation: str, index: str, readers: list[dict[str, Any]]) -> None:
        """Each physical generation needs its own approved index-scoped grants."""
        if not readers:
            return
        grants = getattr(self.store, "reader_grants", None)
        if grants is None:
            raise ContractError("READER_GRANTS_UNSUPPORTED", "This backend can't grant readers; re-plan without readers")
        for wanted in readers:
            _journaled_write(self.state, plan_id, generation, "apply", "reader-grant", index,
                             lambda wanted=wanted: grants.grant(index, wanted),
                             key_digest=digest([wanted["principal_id"], wanted["role_definition_id"]]),
                             detail={"principal_id": wanted["principal_id"], "role": wanted["role"]})

    def _check_readers_follow(self, record: dict[str, Any], current: str | None, new_index: str) -> None:
        """Check both approved readers and readers added to the previous physical index."""
        grants = getattr(self.store, "reader_grants", None)
        wanted = (record.get("reader_grants") or {}).get("grant", [])
        if grants is None:
            if wanted:
                raise ContractError("READER_GRANTS_UNSUPPORTED", "Cannot verify approved reader assignments")
            return
        dropped = (record.get("reader_grants") or {}).get("dropped", [])
        carried = grants.list(current) if current and current != new_index else []
        missing = missing_readers([*carried, *wanted], grants.list(new_index), dropped)
        if missing:
            raise ContractError("READERS_MISSING", f"{len(missing)} reader(s) can't read {new_index} yet: "
                                f"{', '.join(missing)}. Next step: run apply again with the same plan, or re-plan "
                                "with --drop-reader for each one you mean to remove.")

    def source_reader_warnings(self, generation: str) -> list[str]:
        """Readers granted on the topic index who can't read the source index; a warning, never a block."""
        record = self.state.generation(generation)
        plan = record.get("reader_grants") or {}
        grants = getattr(self.store, "reader_grants", None)
        if grants is None or not plan.get("grant"):
            return []
        descriptor = Descriptor(**record["descriptor"])
        source = descriptor.source_index
        wanted = sorted({row["principal_id"] for row in plan["grant"]} - set(plan.get("dropped", [])))
        try:
            readers = grants.source_readers(source)
        except (ContractError, OSError, ValueError) as exc:
            status = getattr(exc, "code", type(exc).__name__)
            info = service_errors.find(exc)
            if info:
                status = f"{status}; service error: {service_errors.summary(info)}"
            return [f"Couldn't read role assignments on the source index {source} ({status}), so it's unknown "
                    f"whether the {len(wanted)} reader(s) can open member chunks. Check they have Search Index "
                    f"Data Reader on {source}."]
        lacking = [principal for principal in wanted if principal not in readers]
        if not lacking:
            return []
        return [f"{len(lacking)} reader(s) can browse topics but have no Search Index Data Reader role on the "
                f"source index {source}, so they can't open member chunks: {', '.join(lacking)}. Ask the source index "
                "owner to grant it; this build doesn't change access to source content. Access through a group "
                "isn't checked, so a reader who gets it from a group can show up here."]

    def _existing_or_new_index(self, plan_id: str, release: Release, index: str,
                               binding: dict[str, Any] | None = None) -> set[str]:
        """Resume only missing immutable keys; reject changed content or index-name collisions."""
        if self.state.retiring_index(index):
            raise ContractError("RETIRE_TARGET_PROTECTED", "A retired or retiring index cannot be reused")
        try:
            existing = self.store.readback(index)
        except ContractError as exc:
            if exc.code != "INDEX_MISSING":
                raise
            _journaled_write(self.state, plan_id, release.content_id, "apply", "create-index", index,
                             lambda: self.store.create_generation_index(index, release.schema),
                             detail={"publication_version": PUBLICATION_VERSION, "binding": binding,
                                     "release_id": release.release_id})
            return set()
        if holds_legacy_rows(existing):
            # Upload actions never delete rows: topic rows go only into a new physical index.
            raise ContractError(LEGACY_FORM, f"The index {index} holds community-form graph rows; topic-form rows "
                                "are published only to a new physical index, never added to a community-form one. "
                                "No documents were uploaded.")
        if not self.state.owns_index(plan_id, index):
            raise ContractError("INDEX_COLLISION", "Existing physical index is not owned by this journal")
        expected = {d["id"]: d for d in release.documents}
        if len({d["id"] for d in existing}) != len(existing):
            raise ContractError("READBACK_MISMATCH", "Duplicate keys in generation index")
        if any(d["id"] not in expected or not same_document(expected[d["id"]], d) for d in existing):
            raise ContractError("REPRODUCIBILITY_DEVIATION", "Existing generation output differs from the release")
        return {d["id"] for d in existing}

    def _record_verified(self, operation_id: str, generation: str, index: str, counts: dict[str, int],
                         started: float | None = None) -> None:
        self.state.record(operation_id, generation, "verify", "verified", expected=counts, observed=counts, evidence_ids=[index])
        timing = {"verify": int((time.perf_counter() - started) * 1000)} if started is not None else {}
        self.state.record_write(operation_id, generation, "verify", "readback", index, status="confirmed",
                                detail={"timings_ms": timing})

    def _save_candidate(self, planned: dict[str, Any], plan_id: str, release: Release, index: str,
                        source: Source, timings: dict[str, int],
                        observed: list[dict[str, Any]]) -> Descriptor:
        generation = release.content_id
        fields = planned["fields"]
        descriptor = Descriptor(index, generation, source.service, source.index,
                                source.embedding_model_id, source.dimension,
                                key_field=fields["key"], text_field=fields["text"], vector_field=fields["vector"],
                                title_field=fields.get("title"), source_field=fields.get("source"),
                                release_id=release.release_id, source_document_count=release.clustered_count,
                                source_names=planned.get("source_names") or None)
        descriptor.validate()
        counts = document_counts(observed)
        built_at = datetime.now(timezone.utc).isoformat()
        output = release.build_dir.parent
        candidate = {
            "descriptor": descriptor.to_dict(),
            "publication_version": PUBLICATION_VERSION, "publication": planned["publication"], "plan_id": plan_id,
            "status": "verified", "source": asdict(source), "source_binding": planned.get("source_binding"),
            "fields": fields, "model": planned["model"], "release": release.metadata(),
            "timings_ms": timings, "built_at": built_at, "counts": counts,
            "inventory_digest": inventory_digest(observed),
            "topicgraph_output": {"directory": str(output)},
        }
        if planned.get("reader_grants"):
            candidate["reader_grants"] = planned["reader_grants"]
        try:
            previous = self.state.generation(generation)
        except ContractError as exc:
            if exc.code != "GENERATION_UNKNOWN":
                raise
            self.state.save_generation(generation, candidate)
        else:
            if (previous["descriptor"] != candidate["descriptor"] or previous["plan_id"] != plan_id
                    or previous["source"] != candidate["source"]):
                raise ContractError("GENERATION_CHANGED", "Saved generation approval/identity differs")
        self.state.record(plan_id, generation, "apply", "verified", expected=counts, observed=counts, evidence_ids=[index])
        self.state.record_write(plan_id, generation, "apply", "built-at", index, status="confirmed", detail={"built_at": built_at})
        return descriptor

    def verify(self, generation: str, index: str, source: Source | None = None) -> dict[str, int]:
        """Read every document back and compare its inventory with the one verified at apply."""
        started = time.perf_counter()
        record = self.state.generation(generation)
        documents = self.store.readback(index)
        if inventory_digest(documents) != record.get("inventory_digest"):
            raise ContractError("PUBLICATION_VERIFY_FAILED", "Physical generation changed since apply verification")
        counts = document_counts(documents)
        self._record_verified(record.get("plan_id", generation), generation, index, counts, started)
        return counts

    def _verify_publication(self, generation: str, record: dict[str, Any]) -> Descriptor:
        descriptor = Descriptor(**record["descriptor"])
        self.verify(generation, descriptor.physical_index)
        previous = record["publication"].get("previous_descriptor")
        self._check_readers_follow(record, previous["physical_index"] if previous else None, descriptor.physical_index)
        return descriptor

    def publish(self, generation: str, *, approved: bool = False) -> Descriptor:
        if not approved:
            raise ContractError("PUBLISH_APPROVAL_REQUIRED", "Local descriptor publication requires separate approval")
        with publication_lock(), self.state.publisher_lock():
            record = self.state.generation(generation)
            require_publication_version(record)
            descriptor = Descriptor(**record["descriptor"])
            if not any(e.get("generation_id") == generation and e.get("stage") == "verify" and e.get("state") == "verified" for e in self.state.events()):
                raise ContractError("PUBLICATION_VERIFY_REQUIRED", "Verify must be journaled before publication")
            publication = record["publication"]
            if publication.get("home") != str(topicgraph_home().resolve()):
                error = ContractError("PUBLISH_BINDING_MISMATCH", "TOPICGRAPH_HOME differs from the approved plan")
                error.next_step = f"set TOPICGRAPH_HOME to {publication.get('home')} (the plan's home) and rerun publish."
                raise error
            current = checked_current(scope_of(descriptor.to_dict()))
            if any(e.get("phase") == "publish-current" for e in self.state.unresolved_writes(record["plan_id"])):
                raise ContractError("RECONCILE_REQUIRED", "Reconcile the uncertain local publication before retrying")
            if record.get("published_current") == current and record["status"] == "published":
                return self._verify_publication(generation, record)
            if digest(current) != publication["expected_current"]:
                raise ContractError("PUBLICATION_CHANGED", "Local selection changed since planning. Use the verified generation's existing descriptor explicitly; this stale approval cannot change the local default.")
            self._verify_publication(generation, record)
            pointer = current_record(
                descriptor.to_dict(), endpoint=publication["binding"]["endpoint"], auth="entra",
                tenant_id=publication["binding"].get("tenant_id", ""),
                publication={"publication_version": PUBLICATION_VERSION, "binding": publication["binding"],
                             "publication_revision": uuid.uuid4().hex})
            detail = {"expected_current": publication["expected_current"], "current": pointer,
                      "descriptor_digest": digest(descriptor.to_dict())}
            self.state.record_write(record["plan_id"], generation, "publish", "publish-current",
                                    descriptor.physical_index, detail=detail)
            try:
                commit_current(descriptor.to_dict(), pointer)
                record.update(status="published", published_current=pointer)
                self.state.save_generation(generation, record)
                self.state.record(record["plan_id"], generation, "publish", "published", evidence_ids=[descriptor.physical_index])
                self.state.record_write(record["plan_id"], generation, "publish", "publish-current",
                                        descriptor.physical_index, status="confirmed", detail=detail)
            except (OSError, ContractError) as exc:
                self.state.record_write(record["plan_id"], generation, "publish", "publish-current",
                                        descriptor.physical_index, status="ambiguous", detail=detail,
                                        error_code="PUBLICATION_UNCERTAIN")
                raise ContractError("PUBLICATION_UNCERTAIN", "Local publication needs reconciliation; no automatic retry or rollback") from exc
            return descriptor

    def status(self) -> dict[str, Any]:
        events = self.state.events()
        latest = {event["generation_id"]: event for event in events if event["generation_id"]}
        incomplete = [generation for generation, event in latest.items() if event["state"] == "failed"]
        scope = self._source_scope()
        current = checked_current(scope) if scope else None
        return {"local_current": current, "active_physical_index": current["physical_index"] if current else None,
                "incomplete_generations": incomplete, "events": events, "writes": self.state.write_events(),
                "recovery": "Rerun apply with the same approved plan: the build resumes and only missing documents upload. "
                            "Inspect failed indexes; never delete automatically"}

    def _source_scope(self) -> tuple[str, str] | None:
        """The source this state folder last planned or built, whose published pointer status reports."""
        for event in reversed(self.state.events()):
            if not event.get("generation_id"):
                continue
            try:
                binding = self.state.generation(event["generation_id"])["publication"]["binding"]
            except (ContractError, KeyError):
                continue
            return binding["endpoint"], binding["source_index"]
        return None

    def reconcile(self, planned: dict[str, Any]) -> dict[str, Any]:
        require_publication_version(planned)
        with publication_lock(), self.state.publisher_lock():
            return self._reconcile(planned)

    def _cleanup_source(self, event: dict[str, Any]) -> dict[str, Any]:
        """Revert the build's temporary source changes; the tool's cleanup is idempotent."""
        config_path = Path((event.get("detail") or {}).get("config_path", ""))
        if not config_path.is_file():
            raise ContractError("NATIVE_CONFIG_MISSING", f"The build configuration {config_path} is gone; cleanup needs it")
        config = validate_native_config(config_path)
        if config["authentication"]["mode"] == "token":
            error = ContractError(
                "NATIVE_AUTHENTICATION_UNSUPPORTED",
                f"The build configuration {config_path} predates refreshable Entra credentials, so cleanup "
                "cannot run with it")
            raise _with_next_step(error, "re-plan the build and apply the new plan, or remove the build's "
                                  "temporary scoring profile from the source index by hand.")
        result = self.native_adapter.runner.cleanup(config_path)
        if not result.succeeded:
            error = ContractError(result.error_code or "NATIVE_CLEANUP_FAILED", error_line(result))
            error.service_error = native_error(result)
            raise _with_next_step(error, "fix the reported problem, then run reconcile again with the same plan.")
        return {**(event.get("detail") or {}), "outcome": "cleaned-up"}

    def _reconcile(self, planned: dict[str, Any]) -> dict[str, Any]:
        plan_id = planned["plan_id"]
        if digest({k: v for k, v in planned.items() if k != "plan_id"}) != plan_id:
            raise ContractError("PLAN_CHANGED", "Reconcile needs the exact approved plan")
        if planned["publication"].get("home") != str(topicgraph_home().resolve()):
            error = ContractError("PUBLISH_BINDING_MISMATCH", "Reconcile must use the approved TOPICGRAPH_HOME")
            error.next_step = f"set TOPICGRAPH_HOME to {planned['publication'].get('home')} (the plan's home) and rerun reconcile."
            raise error
        pending = self.state.unresolved_writes(plan_id)
        for event in pending:
            if event["phase"] != "publish-current":
                continue
            record = self.state.generation(event["generation_id"])
            require_publication_version(record)
            detail = event["detail"]
            current = checked_current(scope_of(record["descriptor"]))
            if current == detail["current"]:
                if digest(record["descriptor"]) != detail["descriptor_digest"]:
                    raise ContractError("DESCRIPTOR_CHANGED", "Publication intent and generation descriptor differ")
                if record["plan_id"] != plan_id or record["descriptor"]["physical_index"] != event["target"]:
                    raise ContractError("PUBLISH_BINDING_MISMATCH", "Publication intent differs from the generation record")
                self._verify_publication(event["generation_id"], record)
                record.update(status="published", published_current=current)
                self.state.save_generation(event["generation_id"], record)
                self.state.record(plan_id, event["generation_id"], "publish", "published", evidence_ids=[event["target"]])
                outcome = "committed"
            elif digest(current) == detail["expected_current"]:
                outcome = "not-committed"
            else:
                raise ContractError("PUBLICATION_CHANGED", "A later local selection exists; reconciliation will not overwrite it")
            self.state.record_write(plan_id, event["generation_id"], "publish", "publish-current", event["target"],
                                    status="reconciled", detail={**detail, "outcome": outcome})
        cleanup = None
        for event in pending:
            if event["phase"] == NATIVE_PHASE:
                cleanup = self._cleanup_source(event)
                self.state.record_write(plan_id, None, event["operation"], NATIVE_PHASE, event["target"],
                                        key_digest=event.get("key_digest"), status="reconciled", detail=cleanup)
        created = [e["target"] for e in self.state.write_events()
                   if e.get("plan_id") == plan_id and e.get("phase") == "create-index"]
        target = created[-1] if created else None
        target_exists = False
        docs: list[dict[str, Any]] = []
        if target is not None:
            try:
                docs = self.store.readback(target)
                target_exists = True
            except ContractError as exc:
                if exc.code != "INDEX_MISSING":
                    raise
        present = sorted(doc.get("id") for doc in docs if isinstance(doc, dict) and doc.get("id"))
        intents = [e for e in self.state.write_events() if e.get("plan_id") == plan_id and e.get("status") == "intent"
                   and e.get("phase") == "upload-batch"]
        intended_count = sum(int((e.get("detail") or {}).get("count", 1)) for e in intents)
        summary = {"target_index": target, "target_exists": target_exists,
                   "intended_count": intended_count, "present_count": len(present),
                   "missing_count": max(intended_count - len(present), 0),
                   "present_digest": digest(present), "source_cleanup": cleanup,
                   "unresolved": self.state.unresolved_writes(plan_id)}
        anchor = target or planned["source"]["index"]
        self.state.record_write(plan_id, None, "reconcile", "readback", anchor, status="reconciled", detail=summary)
        resumable_phases = {"create-index", "upload-batch", "reader-grant", NATIVE_PHASE}
        if any(event["phase"] in resumable_phases for event in pending):
            self.state.record_write(plan_id, None, "reconcile", "resume-required", anchor, status="confirmed")
        for event in pending:
            if event["phase"] in resumable_phases - {NATIVE_PHASE}:
                detail = {"readback_digest": summary["present_digest"]}
                self.state.record_write(plan_id, event.get("generation_id"), event["operation"], event["phase"],
                                        event["target"], key_digest=event.get("key_digest"), status="reconciled",
                                        detail=detail)
        return summary
