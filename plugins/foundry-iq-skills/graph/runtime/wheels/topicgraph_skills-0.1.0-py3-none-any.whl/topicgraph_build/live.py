"""Live Azure Build wiring with injectable boundaries for offline tests."""

from __future__ import annotations

from typing import Any, Callable
from urllib.parse import quote

from topicgraph_adapters.azure_build import AzureBuildStore
from topicgraph_adapters.azure_publication import PublicationApproval
from topicgraph_adapters.azure_source import SourceExportApproval, SourceFields, enum_value, get_field
from topicgraph_build.reader_grants import ArmRequest, ReaderGrants, default_arm_request
from topicgraph_core import skill_user_agent
from topicgraph_core.azure_auth import MANAGEMENT_SCOPE, create_default_credential, get_token, validate_tenant
from topicgraph_core.contracts import ContractError, Source, SourceIdentity, digest
from topicgraph_core.service_errors import from_exception, from_response


API_VERSION = "2026-04-01"
NOVEMBER_API_VERSION = "2026-11-01-preview"
SERVERLESS_API_VERSION = NOVEMBER_API_VERSION
SUPPORTED_SEARCH_API_VERSIONS = (NOVEMBER_API_VERSION,)
ARM_VERSION = "2023-11-01"


def _is_unsupported_api_version_error(exc: BaseException) -> bool:
    status = get_field(exc, "status_code", get_field(get_field(exc, "response"), "status_code"))
    if status == 400:
        return True
    msg = str(exc).lower()
    return "api-version" in msg or "invalidapiversion" in msg or "unsupported api version" in msg


def detect_search_api_version(
    endpoint: str,
    credential: Any,
    index_factory: Any,
    *,
    preferred_versions: tuple[str, ...] = SUPPORTED_SEARCH_API_VERSIONS,
    extra_options: dict[str, Any] | None = None,
) -> tuple[str, Any, Any]:
    """Probe the Search resource read-only for each supported API version in order."""
    options = {
        "credential": credential,
        "audience": "https://search.azure.com",
        "permit_redirects": False,
        **(extra_options or {}),
    }
    last_exc: Exception | None = None
    for idx, candidate in enumerate(preferred_versions):
        client = index_factory(endpoint=endpoint, api_version=candidate, **options)
        try:
            stats = client.get_service_statistics()
            return candidate, client, stats
        except Exception as exc:
            last_exc = exc
            if idx + 1 < len(preferred_versions) and _is_unsupported_api_version_error(exc):
                continue
            raise ContractError("SEARCH_REQUEST_FAILED", "Cannot read Search service statistics",
                                service_error=from_exception(exc)) from exc
    raise ContractError("SEARCH_REQUEST_FAILED", "Cannot read Search service statistics",
                        service_error=from_exception(last_exc)) from last_exc


def service_endpoint(service: str) -> str:
    if not service or any(c in service for c in "/: "):
        raise ContractError("SEARCH_SERVICE_INVALID", "--search-service must be a Search service name")
    return f"https://{service}.search.windows.net"


def publication_binding(args: Any, endpoint: str) -> dict[str, Any]:
    from topicgraph_core.run_naming import context
    return {"tenant_id": args.tenant_id, "subscription_id": args.subscription_id,
            "resource_group": args.resource_group, "endpoint": endpoint, "dataset": args.dataset,
            "source_index": args.source_index, "vector_field": args.vector_field,
            **({"run_naming": context(args.run_prefix)} if getattr(args, "run_prefix", None) else {})}


def corpus_warnings(document_count: int) -> list[str]:
    return ["below recommended 2,000 chunks for clustering quality"] if document_count < 2000 else []


def validate_dataset(dataset: str) -> None:
    if not dataset or dataset != dataset.lower() or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in dataset):
        raise ContractError("DATASET_INVALID", "--dataset must be a lowercase Search-safe slug")


def _field_defs(index: Any) -> dict[str, Any]:
    return {get_field(field, "name"): field for field in get_field(index, "fields", [])}


def vector_metadata(index: Any, vector_field: str) -> dict[str, Any]:
    fields = _field_defs(index)
    field = fields.get(vector_field)
    if field is None:
        raise ContractError("SOURCE_FIELDS_INVALID", "Mapped vector field is absent")
    profile_name = get_field(field, "vector_search_profile_name", get_field(field, "vectorSearchProfile"))
    search = get_field(index, "vector_search", get_field(index, "vectorSearch"))
    profile = next((row for row in (get_field(search, "profiles", []) or [])
                    if get_field(row, "name") == profile_name), None)
    algorithm_name = get_field(profile, "algorithm_configuration_name", get_field(profile, "algorithm"))
    algorithm = next((row for row in (get_field(search, "algorithms", []) or [])
                      if get_field(row, "name") == algorithm_name), None)
    parameters = get_field(algorithm, "parameters", get_field(algorithm, "hnswParameters"))
    return {
        "name": vector_field,
        "dimension": get_field(field, "vector_search_dimensions", get_field(field, "vectorSearchDimensions", get_field(field, "dimensions"))),
        "profile": profile_name,
        "algorithm": _algorithm_for_profile(index, profile_name),
        "metric": enum_value(get_field(parameters, "metric")),
        "compression": get_field(profile, "compression_name", get_field(profile, "compression")),
        "stored": get_field(field, "stored", True),
        "retrievable": get_field(field, "retrievable", True) is not False and not get_field(field, "hidden", False),
    }


NATIVE_SOURCE_POLICY = "stored-retrievable-float32-cosine-or-dotproduct-hnsw-v3"
NATIVE_METRICS = ("cosine", "dotProduct")


def native_source_preflight(vector: dict[str, Any]) -> dict[str, Any]:
    """Schema-only admission. Scalar or binary quantization is fine when the original float32 vectors are kept."""
    if vector.get("stored") is not True or vector.get("retrievable") is not True:
        raise ContractError(
            "SOURCE_VECTORS_NOT_RETRIEVABLE",
            f"Source vector {vector.get('name')!r} has stored={vector.get('stored')!r}, "
            f"retrievable={vector.get('retrievable')!r}: the original vectors were discarded or are not retrievable. "
            "TopicGraph reads stored float32 vectors in place; ask the source owner for a retrievable vector field.")
    if not vector["profile"] or vector["algorithm"] != "hnsw" or vector["metric"] not in NATIVE_METRICS:
        raise ContractError(
            "NATIVE_SOURCE_INCOMPATIBLE",
            f"Source vector {vector['name']!r}: algorithm={vector['algorithm']!r}, "
            f"metric={vector['metric']!r}, compression={vector['compression']!r}. "
            "The build needs an HNSW profile using cosine or dotProduct (euclidean isn't supported); "
            "compressed and uncompressed profiles both work. "
            "Ask the source owner for a compatible source; do not edit or copy a managed index automatically.")
    return {"status": "admitted", "policy": NATIVE_SOURCE_POLICY, "evidence": "source_schema_only"}


def _algorithm_for_profile(index: Any, profile_name: str | None) -> str | None:
    search = get_field(index, "vector_search", get_field(index, "vectorSearch"))
    profiles = get_field(search, "profiles", []) if search is not None else []
    algorithms = get_field(search, "algorithms", []) if search is not None else []
    algorithm_name = None
    for profile in profiles:
        if get_field(profile, "name") == profile_name:
            algorithm_name = get_field(profile, "algorithm_configuration_name", get_field(profile, "algorithm"))
            break
    for algorithm in algorithms:
        if get_field(algorithm, "name") == algorithm_name:
            return enum_value(get_field(algorithm, "kind"))
    return algorithm_name


def definition_fingerprint(index: Any, mapped_fields: SourceFields) -> str:
    fields = _field_defs(index)
    names = sorted({name for name in (mapped_fields.key, mapped_fields.text, mapped_fields.source, mapped_fields.title,
                                      mapped_fields.vector)
                    if name})
    return digest({
        "name": get_field(index, "name"),
        "fields": [{
            "name": name, "type": enum_value(get_field(fields[name], "type")),
            "key": get_field(fields[name], "key"), "sortable": get_field(fields[name], "sortable"),
            "filterable": get_field(fields[name], "filterable"), "hidden": get_field(fields[name], "hidden"),
            "stored": get_field(fields[name], "stored"),
            "dimensions": get_field(fields[name], "vector_search_dimensions", get_field(fields[name], "vectorSearchDimensions", get_field(fields[name], "dimensions"))),
            "profile": get_field(fields[name], "vector_search_profile_name", get_field(fields[name], "vectorSearchProfile")),
        } for name in names if name in fields],
        "vector_algorithm": vector_metadata(index, mapped_fields.vector).get("algorithm"),
    })


def default_arm_get(url: str, bearer_token: str) -> dict[str, Any]:
    import uuid
    import requests
    from topicgraph_core import skill_user_agent

    response = requests.get(
        url,
        headers={
            "Authorization": f"Bearer {bearer_token}",
            "User-Agent": skill_user_agent(),
            "x-ms-client-request-id": str(uuid.uuid4()),
        },
        timeout=30,
    )
    if response.status_code == 404:
        raise ContractError("SEARCH_SERVICE_NOT_FOUND", "Search service resource was not found in the named subscription/RG",
                            service_error=from_response(response))
    if response.status_code >= 400:
        raise ContractError("ARM_REQUEST_FAILED", f"ARM GET failed with status {response.status_code}",
                            service_error=from_response(response))
    from topicgraph_core.service_errors import response_json
    return response_json(response, "ARM GET")


class LiveAzureBuildStore(AzureBuildStore):
    def __init__(self, *args: Any, arm: dict[str, Any], service_stats: dict[str, Any],
                 index_client: Any, endpoint: str, fields: SourceFields, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self.reader_grants: ReaderGrants | None = None
        self.arm = arm
        self.service_stats = service_stats
        self.index_client = index_client
        self.endpoint = endpoint
        self.fields = fields

    def inspect(self, identity: Source) -> dict[str, Any]:
        base = self.source.inspect(identity)
        index = self.index_client.get_index(identity.index)
        index_stats = self.index_stats(identity.index)
        headroom = headroom_snapshot(self.arm, self.service_stats, index_stats, base.get("source", identity.__dict__))
        vector = vector_metadata(index, self.fields.vector)
        native_admission = native_source_preflight(vector)
        return {
            **base,
            "warnings": corpus_warnings(identity.expected_count),
            "arm": safe_arm_snapshot(self.arm),
            "index_stats": index_stats,
            "document_count": identity.expected_count,
            "vector": vector,
            "native_source_preflight": native_admission,
            "definition_fingerprint": definition_fingerprint(index, self.fields),
            "headroom": headroom,
        }

    def index_stats(self, index: str) -> dict[str, int]:
        try:
            observed = self.index_client.get_index_statistics(index)
        except Exception as exc:
            raise ContractError("SEARCH_REQUEST_FAILED", "Cannot read Search index statistics",
                                service_error=from_exception(exc)) from exc
        return {name: _stat_counter(observed, name)
                for name in ("documentCount", "storageSize", "vectorIndexSize")}

    def source_binding(self, inspected: dict[str, Any]) -> dict[str, Any]:
        binding = {
            "source_index": inspected["source"]["index"],
            "definition_fingerprint": inspected["definition_fingerprint"],
            "document_count": inspected["document_count"],
            "vector_field": inspected["vector"]["name"],
            "dimension": inspected["vector"]["dimension"],
            "native_source_policy": NATIVE_SOURCE_POLICY,
        }
        if "search_api_version" in inspected["arm"]:
            binding["search_api_version"] = inspected["arm"]["search_api_version"]
            binding["search_sku"] = inspected["arm"]["sku"]
        return binding

    def target_exists(self, index: str) -> bool:
        try:
            self.index_client.get_index(index)
            return True
        except Exception as exc:
            status = get_field(exc, "status_code", get_field(get_field(exc, "response"), "status_code"))
            if status == 404:
                return False
            raise


def safe_arm_snapshot(resource: dict[str, Any]) -> dict[str, Any]:
    sku = resource.get("sku") or {}
    props = resource.get("properties") or {}
    snapshot = {
        "id": resource.get("id"), "name": resource.get("name"), "location": resource.get("location"),
        "sku": sku.get("name") if isinstance(sku, dict) else sku,
        "replicaCount": props.get("replicaCount"), "partitionCount": props.get("partitionCount"),
        "disableLocalAuth": props.get("disableLocalAuth"),
    }
    if isinstance(resource.get("search_api_version"), str) and resource["search_api_version"]:
        snapshot["search_api_version"] = resource["search_api_version"]
    elif isinstance(snapshot["sku"], str) and snapshot["sku"].casefold() == "serverless":
        snapshot["search_api_version"] = SERVERLESS_API_VERSION
    return snapshot


def _quota_counter(counters: Any, name: str) -> tuple[int | None, int | None]:
    value = get_field(counters, name)
    if value is None:
        return None, None
    usage, quota = get_field(value, "usage"), get_field(value, "quota")
    return (usage if type(usage) is int and usage >= 0 else None,
            quota if type(quota) is int and quota >= 0 else None)


def _stat_counter(data: Any, name: str) -> int:
    sdk_names = {"documentCount": "document_count", "storageSize": "storage_size",
                 "vectorIndexSize": "vector_index_size"}
    value = get_field(data, name, get_field(data, sdk_names.get(name, name)))
    if value is not None and type(value) is not int:
        value = get_field(value, "usage", get_field(value, "value"))
    if type(value) is not int or value < 0:
        raise ContractError("SEARCH_STATISTICS_INVALID",
                            f"Search index statistic {name} must be a known nonnegative integer")
    return value


def headroom_snapshot(arm: dict[str, Any], service_stats: dict[str, Any], index_stats: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    counters = get_field(service_stats, "counters")
    limits = get_field(service_stats, "limits")
    if counters is None:
        raise ContractError("SEARCH_HEADROOM_INSUFFICIENT", "Search service stats counters are unavailable")
    index_count, index_quota = _quota_counter(counters, "indexesCount")
    storage_used, storage_quota = _quota_counter(counters, "storageSize")
    vector_used, vector_quota = _quota_counter(counters, "vectorIndexSize")
    max_storage_per_index = get_field(limits, "maxStoragePerIndex",
                                      get_field(limits, "max_storage_per_index"))
    max_vector_per_index = get_field(limits, "maxVectorIndexSizePerIndexInBytes",
                                    get_field(limits, "max_vector_index_size_per_index_in_bytes"))
    sku = safe_arm_snapshot(arm)["sku"]
    serverless_per_index = (
        isinstance(sku, str) and sku.casefold() == "serverless"
        and get_field(get_field(counters, "storageSize"), "quota") is None
        and get_field(get_field(counters, "vectorIndexSize"), "quota") is None
    )
    required = (index_count, index_quota, storage_used, vector_used, max_storage_per_index)
    required += (max_vector_per_index,) if serverless_per_index else (storage_quota, vector_quota)
    if any(type(value) is not int or value < 0 for value in required):
        raise ContractError("SEARCH_HEADROOM_INSUFFICIENT", "Search index/storage/vector quotas must be known")
    source_storage = _stat_counter(index_stats, "storageSize")
    source_vector = _stat_counter(index_stats, "vectorIndexSize")
    dimension = int(source.get("dimension") or 1)
    count = int(source.get("expected_count") or 1)
    estimate = max(source_storage, count * (dimension * 4 + 1024) * 5)
    vector_estimate = max(source_vector, count * dimension * 4)
    free_indexes = max(index_quota - index_count, 0)
    free_storage = None if serverless_per_index else max(storage_quota - storage_used, 0)
    free_vector = None if serverless_per_index else max(vector_quota - vector_used, 0)
    if serverless_per_index:
        ok = (free_indexes >= 1 and 2 * estimate <= max_storage_per_index
              and 2 * vector_estimate <= max_vector_per_index)
    else:
        ok = (free_indexes >= 1 and free_storage >= 2 * estimate and free_vector >= 2 * vector_estimate
              and estimate <= max_storage_per_index)
    snapshot = {
        "index_count": index_count, "index_quota": index_quota, "free_index_slots": free_indexes,
        "storage_used": storage_used, "storage_quota": storage_quota, "free_storage": free_storage,
        "vector_used": vector_used, "vector_quota": vector_quota, "free_vectorIndexSize": free_vector,
        "max_storage_per_index": max_storage_per_index,
        "estimated_bytes": estimate, "estimated_vector_bytes": vector_estimate,
        "sufficient": ok,
    }
    if serverless_per_index:
        snapshot.update({
            "capacity_basis": "serverless_per_index_limits",
            "max_vector_index_size_per_index": max_vector_per_index,
            "aggregate_storage_vector_quotas": "not reported; not assumed unlimited",
        })
    if not ok:
        raise ContractError("SEARCH_HEADROOM_INSUFFICIENT", "Search service lacks index, storage, vector or per-index headroom for the plan")
    return snapshot


def publication_approval(args: Any, endpoint: str, arm: dict[str, Any], service_stats: dict[str, Any],
                         index_client: Any, count: int, dimension: int) -> PublicationApproval:
    """Derive write attestations from this command's real inputs; read-only commands get none, so writes fail closed."""
    command = getattr(args, "command", None)
    writes = command == "apply" and bool(getattr(args, "confirm_writes", False))
    headroom = write = ""
    if writes:
        try:
            index_stats = index_client.get_index_statistics(args.source_index)
        except Exception as exc:
            raise ContractError("SEARCH_REQUEST_FAILED", "Cannot read source index statistics for publication approval",
                                service_error=from_exception(exc)) from exc
        snapshot = headroom_snapshot(arm, service_stats, index_stats, {"dimension": dimension, "expected_count": count})
        if snapshot.get("capacity_basis") == "serverless_per_index_limits":
            headroom = (
                f"headroom:serverless_per_index_limits;free_index_slots={snapshot['free_index_slots']};"
                f"storage_limit={snapshot['max_storage_per_index']};"
                f"vector_limit={snapshot['max_vector_index_size_per_index']}")
        else:
            headroom = f"headroom:free_storage={snapshot['free_storage']}"
        write = "confirm-writes"
    return PublicationApproval(args.tenant_id, endpoint, args.dataset, headroom, write,
                               getattr(args, "run_prefix", None))


def display_names(arm_get: Callable[[str, str], dict[str, Any]], management: str,
                  tenant_id: str, subscription_id: str) -> dict[str, str | None]:
    """Tenant and subscription display names for approval cards. Best effort: a failed lookup shows the ID prefix."""
    names: dict[str, str | None] = {"tenant_name": None, "subscription_name": None}
    try:
        sub = arm_get(f"https://management.azure.com/subscriptions/{quote(subscription_id, safe='')}?api-version=2022-12-01", management)
        if isinstance(sub.get("displayName"), str):
            names["subscription_name"] = sub["displayName"]
    except Exception:
        pass
    try:
        tenants = arm_get("https://management.azure.com/tenants?api-version=2022-12-01", management)
        match = next((t for t in tenants.get("value") or [] if t.get("tenantId") == tenant_id), None)
        if match and isinstance(match.get("displayName"), str):
            names["tenant_name"] = match["displayName"]
    except Exception:
        pass
    return names


def create_live_store(args: Any, *, credential: Any | None = None,
                      arm_get: Callable[[str, str], dict[str, Any]] = default_arm_get,
                      index_client_factory: Any | None = None, search_client_factory: Any | None = None,
                      arm_request: ArmRequest = default_arm_request) -> tuple[LiveAzureBuildStore, Source, dict[str, Any]]:
    validate_dataset(args.dataset)
    endpoint = service_endpoint(args.search_service)
    credential = credential or create_default_credential()
    tenant = validate_tenant(credential, args.tenant_id)
    management = get_token(credential, MANAGEMENT_SCOPE, args.tenant_id)
    arm_url = (f"https://management.azure.com/subscriptions/{quote(args.subscription_id, safe='')}/resourceGroups/"
               f"{quote(args.resource_group, safe='')}/providers/Microsoft.Search/searchServices/"
               f"{quote(args.search_service, safe='')}?api-version={ARM_VERSION}")
    arm = arm_get(arm_url, management)
    props = arm.get("properties") or {}
    if arm.get("name") and arm.get("name") != args.search_service:
        raise ContractError("SEARCH_SERVICE_MISMATCH", "ARM returned a different Search service")
    arm_ep = (props.get("endpoint") or "").rstrip("/")
    if arm_ep and arm_ep != endpoint:
        raise ContractError("SEARCH_SERVICE_MISMATCH", "ARM endpoint does not match --search-service")
    if index_client_factory is None or search_client_factory is None:
        try:
            from azure.search.documents import SearchClient
            from azure.search.documents.indexes import SearchIndexClient
        except ImportError as exc:  # pragma: no cover
            raise ContractError("AZURE_DEPENDENCY_MISSING", "azure-search-documents is required for --backend azure") from exc
        index_client_factory = index_client_factory or SearchIndexClient
        search_client_factory = search_client_factory or SearchClient
    index_factory = index_client_factory
    search_factory = search_client_factory
    extra_options: dict[str, Any] = {"user_agent": skill_user_agent()}
    if getattr(args, "detect_api_version", False) or arm.get("search_api_version") == "auto":
        detected_version, index_client, service_stats = detect_search_api_version(
            endpoint, credential, index_factory, extra_options=extra_options,
        )
        arm = {**arm, "search_api_version": detected_version}
        client_options = {"credential": credential, "audience": "https://search.azure.com",
                          "api_version": detected_version, "permit_redirects": False, **extra_options}
    else:
        initial_version = safe_arm_snapshot(arm).get("search_api_version", API_VERSION)
        client_options = {"credential": credential, "audience": "https://search.azure.com",
                          "api_version": initial_version, "permit_redirects": False, **extra_options}
        index_client = index_factory(endpoint=endpoint, **client_options)
        try:
            service_stats = index_client.get_service_statistics()
        except Exception as exc:
            raise ContractError("SEARCH_REQUEST_FAILED", "Cannot read Search service statistics",
                                service_error=from_exception(exc)) from exc
    source_client = search_factory(endpoint=endpoint, index_name=args.source_index, **client_options)
    fields = SourceFields(args.key_field, args.text_field, getattr(args, "source_field", None) or None, args.vector_field,
                          title=getattr(args, "title_field", None) or None)
    source_index_def = index_client.get_index(args.source_index)
    vector = vector_metadata(source_index_def, args.vector_field)
    try:
        count = source_client.get_document_count()
    except Exception as exc:
        raise ContractError("SOURCE_COUNT_UNAVAILABLE", "Cannot read source document count",
                            service_error=from_exception(exc)) from exc
    if not isinstance(vector.get("dimension"), int) or vector["dimension"] < 1 or type(count) is not int or count < 1:
        raise ContractError("SOURCE_IDENTITY_INVALID", "Live source dimension/count could not be inferred")
    source_id = SourceIdentity(endpoint, args.source_index, args.embedding_model_id,
                               vector["dimension"], count)
    from topicgraph_adapters import AzurePublicationAdapter, AzureSourceAdapter
    source = AzureSourceAdapter(source_client, index_client, fields, approval=SourceExportApproval(
        args.tenant_id, endpoint, args.source_index))
    publisher = AzurePublicationAdapter(index_client, lambda index: search_factory(
        endpoint=endpoint, index_name=index, **client_options),
        approval=publication_approval(args, endpoint, arm, service_stats, index_client, count, vector["dimension"]),
)
    store = LiveAzureBuildStore(source, publisher, arm=arm, service_stats=service_stats,
                                index_client=index_client, endpoint=endpoint, fields=fields)
    store.reader_grants = ReaderGrants(arm.get("id") or arm_url.split("?", 1)[0].removeprefix("https://management.azure.com"),
                                       management, arm_request)
    return store, source_id, {"tenant_tokens": tenant, "endpoint": endpoint, "arm": safe_arm_snapshot(arm),
                              "source_definition_fingerprint": definition_fingerprint(source_index_def, fields),
                              "credential": credential,
                              "names": lambda: display_names(arm_get, management, args.tenant_id, args.subscription_id)}
