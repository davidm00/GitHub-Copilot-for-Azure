"""Run the installed Build CLI with python -m topicgraph_build."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
