"""Separately approved, service-wide activation of a verified topic generation."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

from topicgraph_adapters.azure_retrieval import API_VERSION
from topicgraph_build.live import native_source_preflight, publication_binding, vector_metadata
from topicgraph_core.contracts import PUBLICATION_VERSION, ContractError, digest, require_publication_version

VERSION = "topicgraph-retrieval-v1"


def _definition(value: Any) -> Any:
    if isinstance(value, dict):
        # @odata.type selects concrete Search types and belongs in PUTs and drift digests.
        result = {key: _definition(item) for key, item in value.items()
                  if key not in {"@odata.context", "@odata.etag", "createdResources"} and item is not None}
        if result.get("kind") == "azureBlob":
            parameters = result.get("azureBlobParameters") or {}
            cache = (parameters.get("ingestionParameters") or {}).get("cache")
            if isinstance(cache, dict):
                # Cache secrets are write-only. Preserve the same stored value in PUTs and readback digests.
                cache["storageConnectionString"] = "<unchanged>"
        return result
    if isinstance(value, list):
        return [_definition(item) for item in value]
    return value


def _index_update(body: dict[str, Any], vector: str, index: str, kind: str,
                  run_prefix: str | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    result = deepcopy(body)
    fields = result.get("fields") or []
    field = next((f for f in fields if f.get("name") == vector), None)
    if not field or field.get("type") != "Collection(Edm.Single)" or not field.get("vectorSearchProfile"):
        raise ContractError("RETRIEVAL_VECTOR_INVALID", "The source must have the verified float32 vector field")
    search = result.setdefault("vectorSearch", {})
    profiles = search.get("topicGraphProfiles") or []
    if len(profiles) > 1:
        raise ContractError("RETRIEVAL_PROFILE_CONFLICT", "The November contract permits only one topic graph profile")
    previous = {"profiles": deepcopy(profiles), "field_binding": field.get("topicGraphProfile")}
    if profiles:
        name = profiles[0]["name"]
        if field.get("topicGraphProfile") != name:
            raise ContractError("RETRIEVAL_PROFILE_CONFLICT", "An existing profile belongs to another vector field")
    else:
        if field.get("topicGraphProfile"):
            raise ContractError("RETRIEVAL_PROFILE_CONFLICT", "The vector field references a missing topic profile")
        if run_prefix:
            from topicgraph_core.run_naming import context
            context(run_prefix)
        name = f"{run_prefix + '-retrieval' if run_prefix else 'topicgraph'}-{digest(vector)[:12]}"
    if any(f is not field and f.get("topicGraphProfile") == name for f in fields):
        raise ContractError("RETRIEVAL_PROFILE_CONFLICT", "The topic profile is shared with another vector field")
    profile = deepcopy(profiles[0]) if profiles else {}
    profile.pop("defaultDiversityFactor", None)
    profile.pop("defaultMinDiversityPoolSize", None)
    profile.update(name=name, indexName=index, defaultKind=kind)
    if kind == "balanced":
        profile["defaultMinDiversityPoolSize"] = 1000
    search["topicGraphProfiles"] = [profile]
    field["topicGraphProfile"] = name
    return _definition(result), previous


def _ks_parameters(body: dict[str, Any], source_index: str) -> dict[str, Any]:
    kind = body.get("kind")
    if kind == "searchIndex":
        parameters = body.get("searchIndexParameters") or {}
        index = parameters.get("searchIndexName")
    elif kind == "azureBlob":
        parameters = body.get("azureBlobParameters") or {}
        resources = parameters.get("createdResources") or {}
        index = resources.get("index")
        connection = parameters.get("connectionString")
        # Same-source PUT carries the exact redaction sentinel forward server-side.
        if not isinstance(connection, str) or not (
                connection.lower().startswith("resourceid=") or connection == "<redacted>"):
            raise ContractError("RETRIEVAL_KS_AUTH_UNSUPPORTED",
                                "The existing Blob connection cannot be preserved from this representation")
    else:
        raise ContractError("RETRIEVAL_KS_UNSUPPORTED", "Only searchIndex and azureBlob sources support topicGraph")
    if index != source_index:
        raise ContractError("RETRIEVAL_KS_MISMATCH", "The knowledge source does not target the verified content index")
    return parameters


def _desired(body: dict[str, Any], plan: dict[str, Any], resource: str) -> tuple[dict[str, Any], dict[str, Any]]:
    if resource.startswith("indexes/"):
        vector = vector_metadata(body, plan["fields"]["vector"])
        native_source_preflight(vector)
        if vector["dimension"] != plan["source"]["dimension"]:
            raise ContractError("SOURCE_CHANGED", "The source vector dimension differs from the verified topic generation")
        return _index_update(body, plan["fields"]["vector"], plan["topic_index"], plan["default_kind"],
                             ((plan.get("binding") or {}).get("run_naming") or {}).get("prefix"))
    result = deepcopy(body)
    parameters = _ks_parameters(result, plan["source"]["index"])
    previous = {"topicGraph": deepcopy(parameters.get("topicGraph"))}
    parameters["topicGraph"] = {"kind": plan["default_kind"]}
    return _definition(result), previous


def _check_kb(client: Any, plan: dict[str, Any]) -> None:
    if plan.get("knowledge_base"):
        body, _ = client.read(f"knowledgebases/{plan['knowledge_base']}")
        if not any(row.get("name") == plan["knowledge_source"] for row in body.get("knowledgeSources", [])):
            raise ContractError("RETRIEVAL_KB_MISMATCH", "The KB does not reference the selected knowledge source")


def _check_generation(service: Any, state: Any, plan: dict[str, Any]) -> None:
    record = state.generation(plan["generation_id"])
    require_publication_version(record)
    if (record["descriptor"]["physical_index"] != plan["topic_index"]
            or record["source"] != plan["source"]
            or record["source_binding"] != plan["source_binding"]
            or record["fields"] != plan["fields"]
            or record["publication"]["binding"] != plan["binding"]):
        raise ContractError("RETRIEVAL_BINDING_MISMATCH", "The verified generation or source binding changed")
    service.verify(plan["generation_id"], plan["topic_index"])


def plan_retrieval(client: Any, service: Any, state: Any, args: Any) -> dict[str, Any]:
    record = state.generation(args.generation_id)
    require_publication_version(record)
    binding = publication_binding(args, client.endpoint)
    if record["publication"]["binding"] != binding:
        raise ContractError("RETRIEVAL_BINDING_MISMATCH", "Use the generation's exact resource, corpus and vector field")
    if args.knowledge_base and not args.knowledge_source:
        raise ContractError("RETRIEVAL_KS_REQUIRED", "Name the existing knowledge source used by the KB")
    data = {
        "version": VERSION, "publication_version": PUBLICATION_VERSION, "api_version": API_VERSION,
        **{key: getattr(args, key) for key in
           ("tenant_id", "subscription_id", "resource_group", "search_service", "dataset")},
        "binding": binding, "source": record["source"], "source_binding": record["source_binding"],
        "fields": record["fields"],
        "generation_id": args.generation_id, "topic_index": record["descriptor"]["physical_index"],
        "default_kind": "balanced" if args.topic_diversity == "on" else "none",
        "knowledge_source": args.knowledge_source, "knowledge_base": args.knowledge_base,
    }
    _check_generation(service, state, data)
    _check_kb(client, data)
    resources = [f"indexes/{record['source']['index']}"]
    if args.knowledge_source:
        resources.append(f"knowledgesources/{args.knowledge_source}")
    operations = []
    for resource in resources:
        before, etag = client.read(resource)
        if not etag or etag.strip() == "*":
            raise ContractError("RETRIEVAL_ETAG_REQUIRED", f"{resource} has no concurrency token")
        after, previous = _desired(before, data, resource)
        operations.append({"resource": resource, "etag": etag, "before_digest": digest(_definition(before)),
                           "after_digest": digest(after), "previous": previous})
    data["operations"] = operations
    planned = {"plan_id": digest(data), **data}
    state.record(planned["plan_id"], args.generation_id, "retrieval-plan", "planned")
    return planned


def _check_plan(plan: dict[str, Any], args: Any, endpoint: str) -> None:
    body = {key: value for key, value in plan.items() if key != "plan_id"}
    if (plan.get("version") != VERSION or plan.get("api_version") != API_VERSION
            or plan.get("plan_id") != args.plan_id or digest(body) != args.plan_id):
        raise ContractError("PLAN_ID_MISMATCH", "Retrieval activation needs the exact reviewed plan")
    if plan["binding"] != publication_binding(args, endpoint):
        raise ContractError("RETRIEVAL_BINDING_MISMATCH", "Retrieval approval belongs to another resource or corpus")


def verify_retrieval(client: Any, service: Any, state: Any, args: Any, plan: dict[str, Any],
                     *, reconcile: bool = False) -> dict[str, Any]:
    _check_plan(plan, args, client.endpoint)
    _check_generation(service, state, plan)
    _check_kb(client, plan)
    observations = []
    for operation in plan["operations"]:
        resource = operation["resource"]
        body, _ = client.read(resource)
        observed = digest(_definition(body))
        outcome = ("configured" if observed == operation["after_digest"] else
                   "unchanged" if observed == operation["before_digest"] else "conflict")
        observations.append({"resource": resource, "state": outcome})
        if reconcile:
            state.record_write(plan["plan_id"], plan["generation_id"], "reconcile", "retrieval-update",
                               resource, status="reconciled", detail={"outcome": outcome})
    configured = all(row["state"] == "configured" for row in observations)
    return {"state": "configured" if configured else "not_ready", "plan_id": plan["plan_id"],
            "generation_id": plan["generation_id"], "topic_index": plan["topic_index"],
            "default_kind": plan["default_kind"], "resources": observations,
            "verification": {"configuration": configured, "live_queries": "not_run"},
            "requests": list(getattr(client, "receipts", [])),
            "next_step": ("Use Why Graph On/Off, or entity-graph-consume with --topic-diversity on/off, "
                          "to verify actual Search and KB retrieval. No query or model calls ran during configuration."
                          if configured else
                          "Inspect the readback; re-plan conflicts. An unchanged resource may resume under the "
                          "same approved plan after this explicit reconciliation. No writes or rollback ran.")}


def configure_retrieval(client: Any, service: Any, state: Any, args: Any, plan: dict[str, Any]) -> dict[str, Any]:
    if not args.confirm_writes:
        raise ContractError("WRITE_CONFIRMATION_REQUIRED", "Retrieval activation requires --confirm-writes")
    _check_plan(plan, args, client.endpoint)
    with state.publisher_lock():
        if state.unresolved_writes(plan["plan_id"]):
            raise ContractError("RETRIEVAL_RECONCILE_REQUIRED", "Run verify-retrieval before retrying uncertain activation")
        _check_generation(service, state, plan)
        _check_kb(client, plan)
        updates = []
        for operation in plan["operations"]:
            before, etag = client.read(operation["resource"])
            observed = digest(_definition(before))
            if observed == operation["after_digest"]:
                continue
            if observed != operation["before_digest"]:
                raise ContractError("RETRIEVAL_PLAN_STALE", "Configuration changed since planning; re-plan before writing")
            after, _ = _desired(before, plan, operation["resource"])
            if digest(after) != operation["after_digest"] or not etag or etag.strip() == "*":
                raise ContractError("RETRIEVAL_PLAN_STALE", "The approved delta or concurrency token changed")
            updates.append((operation["resource"], after, etag))
        for resource, after, etag in updates:
            state.record_write(plan["plan_id"], plan["generation_id"], "configure-retrieval",
                               "retrieval-update", resource)
            try:
                client.update(resource, after, etag)
                observed, _ = client.read(resource)
                if digest(_definition(observed)) != digest(after):
                    raise ContractError("RETRIEVAL_READBACK_FAILED", "Configuration readback differs from approval")
            except Exception:
                state.record_write(plan["plan_id"], plan["generation_id"], "configure-retrieval",
                                   "retrieval-update", resource, status="ambiguous",
                                   error_code="RETRIEVAL_UPDATE_UNCERTAIN")
                raise
            state.record_write(plan["plan_id"], plan["generation_id"], "configure-retrieval",
                               "retrieval-update", resource, status="confirmed")
        return verify_retrieval(client, service, state, args, plan)
