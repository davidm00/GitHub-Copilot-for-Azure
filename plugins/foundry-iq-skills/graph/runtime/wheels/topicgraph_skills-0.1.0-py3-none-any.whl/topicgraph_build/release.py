"""Load and check the latest exported release named by the build tool's run-manifest.json.

Release files are written with a UTF-8 byte order mark, so every read uses ``utf-8-sig``. Paths in the
manifest are relative to the ``topicGraph`` build directory.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from topicgraph_adapters.native_runner import RUN_MANIFEST, build_directory
from topicgraph_core.contracts import ContractError
from topicgraph_core.graph_contract import (LEGACY_DETAIL, LEGACY_FORM, RUN_MANIFEST_TOPICS, RUN_MANIFEST_VERSION,
                                           TOPIC_FORM, check_semantic_configuration, check_topic_graph)

VECTOR_FIELD = "object_vector"
RELEASE_KEY = "id"


@dataclass(frozen=True)
class Release:
    release_id: str
    content_id: str
    structure_id: str
    label_variant_id: str
    schema: dict[str, Any]
    documents: list[dict[str, Any]]
    ontology_file: Path | None
    ontology_version: str | None
    graph_document_count: int
    clustered_count: int
    topic_count: int
    coverage: float | None
    labeling: dict[str, Any]
    build_dir: Path

    def metadata(self) -> dict[str, Any]:
        """JSON-safe identity of the release, without the documents or schema."""
        return {"release_id": self.release_id, "content_id": self.content_id, "structure_id": self.structure_id,
                "label_variant_id": self.label_variant_id, "ontology_version": self.ontology_version,
                "ontology_file": str(self.ontology_file) if self.ontology_file else None,
                "graph_document_count": self.graph_document_count,
                "clustered_count": self.clustered_count, "topic_count": self.topic_count, "coverage": self.coverage,
                "labeling": self.labeling}


def _invalid(detail: str) -> ContractError:
    return ContractError("RELEASE_INVALID", detail)


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        raise _invalid(f"Cannot read {path.name}: {exc}") from exc


def _release_path(build_dir: Path, value: Any, name: str, *, required: bool = True) -> Path | None:
    if value is None and not required:
        return None
    if not isinstance(value, str) or not value.strip():
        raise _invalid(f"Release {name} is missing")
    relative = PurePosixPath(value.replace("\\", "/"))
    if relative.is_absolute() or ".." in relative.parts or Path(value).is_absolute():
        raise _invalid(f"Release {name} must stay inside the build directory")
    path = build_dir.joinpath(*relative.parts)
    if not path.is_file():
        raise ContractError("RELEASE_MISSING", f"Release {name} {value} does not exist")
    return path


def _documents(path: Path) -> list[dict[str, Any]]:
    documents = []
    try:
        lines = path.read_text(encoding="utf-8-sig").splitlines()
    except OSError as exc:
        raise _invalid(f"Cannot read {path.name}: {exc}") from exc
    for number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            doc = json.loads(line)
        except json.JSONDecodeError as exc:
            raise _invalid(f"{path.name} line {number} is not JSON") from exc
        if not isinstance(doc, dict) or not isinstance(doc.get(RELEASE_KEY), str) or not doc[RELEASE_KEY]:
            raise _invalid(f"{path.name} line {number} has no document id")
        documents.append(doc)
    return documents


def check_schema(schema: Any) -> dict[str, Any]:
    if not isinstance(schema, dict) or not isinstance(schema.get("fields"), list):
        raise _invalid("Release schema must be an index definition with fields")
    if "name" in schema:
        raise _invalid("Release schema must not name its index")
    names = {field.get("name") for field in schema["fields"] if isinstance(field, dict)}
    if RELEASE_KEY not in names or VECTOR_FIELD not in names:
        raise _invalid(f"Release schema needs the {RELEASE_KEY} and {VECTOR_FIELD} fields")
    return schema


def load_release(output_directory: Path) -> Release:
    """The latest exported release, with its schema and documents checked against the manifest."""
    build_dir = build_directory(Path(output_directory))
    manifest_path = build_dir / RUN_MANIFEST
    if not manifest_path.is_file():
        raise ContractError("RELEASE_MISSING", f"No {RUN_MANIFEST} in {build_dir}")
    manifest = _read_json(manifest_path)
    version = manifest.get("version") if isinstance(manifest, dict) else None
    if version == 1:
        raise ContractError(LEGACY_FORM, f"{RUN_MANIFEST} version 1. {LEGACY_DETAIL}")
    if type(version) is not int or version != RUN_MANIFEST_VERSION:
        raise ContractError("NATIVE_SCHEMA_VERSION_UNSUPPORTED",
                            f"{RUN_MANIFEST} version {version!r} is not supported (supported: {RUN_MANIFEST_VERSION})")
    latest = manifest.get("latestRelease") if isinstance(manifest, dict) else None
    entries = [r for r in (manifest.get("releases") or []) if isinstance(r, dict) and r.get("id") == latest] \
        if isinstance(manifest, dict) and latest else []
    if len(entries) != 1:
        raise ContractError("RELEASE_MISSING", "The build did not record exactly one latest release")
    entry = entries[0]
    if entry.get("state") != "exported":
        raise _invalid(f"Release {latest} is {entry.get('state')!r}, not exported")
    for key in ("contentId", "structureId", "labelVariantId"):
        if not isinstance(entry.get(key), str) or not entry[key]:
            raise _invalid(f"Release {latest} has no {key}")
    content_id = entry["contentId"]
    if not 12 <= len(content_id) <= 64 or any(c not in "0123456789abcdef" for c in content_id):
        raise _invalid(f"Release content identity {content_id!r} is not lowercase hex")
    count = entry.get("graphDocumentCount")
    if type(count) is not int or count < 1:
        raise _invalid(f"Release {latest} has no document count")
    structures = [s for s in (manifest.get("structures") or [])
                  if isinstance(s, dict) and s.get("id") == entry["structureId"]]
    structure = structures[0] if len(structures) == 1 else {}
    clustered, topics = structure.get("clustered"), structure.get(RUN_MANIFEST_TOPICS)
    if type(clustered) is not int or clustered < 1:
        raise _invalid(f"Release {latest} has no clustered chunk count for structure {entry['structureId']}")
    if type(topics) is not int or topics < 1 or "communities" in structure:
        raise _invalid(f"{RUN_MANIFEST} version {version} needs a {RUN_MANIFEST_TOPICS} count, and no communities "
                       f"count, for structure {entry['structureId']}")
    schema = check_schema(_read_json(_release_path(build_dir, entry.get("schemaFile"), "schema file")))
    check_semantic_configuration(schema)
    documents = _documents(_release_path(build_dir, entry.get("documentsFile"), "documents file"))
    if len(documents) != count:
        raise _invalid(f"Release {latest} has {len(documents)} documents; the manifest says {count}")
    ids = [doc[RELEASE_KEY] for doc in documents]
    if len(set(ids)) != len(ids):
        raise _invalid(f"Release {latest} repeats document ids")
    check_topic_graph(documents)
    if entry.get("ontologyVersion") != TOPIC_FORM.ontology_version:
        raise _invalid(f"Release {latest} has ontology {entry.get('ontologyVersion')!r}, not the "
                       f"{TOPIC_FORM.ontology_version} that {RUN_MANIFEST} version {version} writes")
    ontology = _release_path(build_dir, entry.get("ontologyFile"), "ontology file", required=False)
    labeling = entry.get("labeling") if isinstance(entry.get("labeling"), dict) else {}
    coverage = entry.get("coverage")
    return Release(release_id=latest, content_id=content_id, structure_id=entry["structureId"],
                   label_variant_id=entry["labelVariantId"], schema=schema, documents=documents,
                   ontology_file=ontology, ontology_version=entry.get("ontologyVersion"), graph_document_count=count,
                   clustered_count=clustered, topic_count=topics, coverage=float(coverage) if isinstance(coverage, (int, float)) else None, labeling=labeling,
                   build_dir=build_dir)
