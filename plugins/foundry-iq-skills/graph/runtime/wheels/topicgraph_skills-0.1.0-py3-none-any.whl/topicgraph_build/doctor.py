"""topic-graph-build doctor: read-only checks of the operator's machine, sign-in, state and reader access."""

from __future__ import annotations

import argparse
import shutil
from typing import Any, Callable

from topicgraph_core import doctor as d
from topicgraph_core.azure_auth import MANAGEMENT_SCOPE, SEARCH_SCOPE

CLI = "topic-graph-build"


def run_doctor(args: argparse.Namespace, *, credential: Any | None = None, get: d.HttpGet = d.http_get,
               which: Callable[[str], str | None] = shutil.which, run: d.Runner = d._run) -> dict[str, Any]:
    account = d.read_account(which, run)
    # Default to the Azure CLI's current tenant when --tenant-id is absent.
    tenant = getattr(args, "tenant_id", None) or (
        account.get("tenantId") if isinstance(account, dict) else None)
    signin: dict[str, Any] = {}
    auth: dict[str, Any] = {}

    def azure_signin() -> d.Check:
        signin["check"] = d.check_azure_signin(tenant, which=which, run=run, account=account)
        return signin["check"]

    def headers(scope: str) -> dict[str, str]:
        if "credential" not in auth:
            from topicgraph_core.azure_auth import create_default_credential, validate_tenant

            auth["credential"] = credential or create_default_credential()
            validate_tenant(auth["credential"], tenant)
        return d.bearer(auth["credential"], scope, tenant)

    def live() -> bool:
        return signin.get("check", {}).get("status") == d.OK

    def endpoint() -> str:
        from topicgraph_build.live import service_endpoint

        return service_endpoint(args.search_service)

    def source_reader() -> d.Check:
        if not (args.search_service and args.source_index):
            return d.skip("source_reader", "no --search-service and --source-index")
        if not live():
            return d.skip("source_reader", "needs a signed-in --tenant-id")
        return d.check_search_reader("source_reader", endpoint(), args.source_index, headers(SEARCH_SCOPE), get=get)

    def topic_index_reader() -> d.Check:
        from topicgraph_core.current import checked_current

        source_index = getattr(args, "source_index", None)
        current = checked_current((endpoint(), source_index)) if args.search_service and source_index else None
        if not current or current["endpoint"].rstrip("/") != endpoint():
            return d.skip("topic_index_reader", "no matching local physical descriptor")
        if not live():
            return d.skip("topic_index_reader", "needs a signed-in --tenant-id")
        return d.check_search_reader("topic_index_reader", endpoint(), current["physical_index"], headers(SEARCH_SCOPE), get=get)

    def model_data_plane() -> d.Check:
        hdrs = (lambda: headers(d.COGNITIVE_SCOPE)) if live() else None
        return d.check_model_data_plane(getattr(args, "model_endpoint", None),
                                        getattr(args, "model_deployment", None), hdrs, get=get)

    model: dict[str, Any] = {}

    def model_scope() -> tuple[Any, ...]:
        hdrs = (lambda: headers(MANAGEMENT_SCOPE)) if live() else None
        return (getattr(args, "model_endpoint", None), getattr(args, "model_deployment", None),
                getattr(args, "model_subscription_id", None) or args.subscription_id,
                getattr(args, "model_resource_group", None) or args.resource_group, hdrs)

    def model_deployment() -> d.Check:
        model["deployment"] = d.check_model_deployment(*model_scope(), get=get)
        return model["deployment"]

    def model_lifecycle() -> d.Check:
        deployed = model.get("deployment") or {}
        return d.check_model_lifecycle(
            *model_scope(), model=(deployed.get("model_name"), deployed.get("model_version")),
            label=getattr(args, "model_name", None), get=get)

    result = d.run_checks([
        ("cli_version", lambda: d.check_cli_version(CLI)),
        ("python", d.check_python),
        ("azure_signin", azure_signin),
        ("state_dir", lambda: d.check_state_dir(args.state_dir)),
        ("journal", lambda: d.check_journal(args.state_dir, CLI)),
        ("source_reader", source_reader),
        ("topic_index_reader", topic_index_reader),
        ("model_data_plane", model_data_plane),
        ("model_deployment", model_deployment),
        ("model_lifecycle", model_lifecycle),
    ], ok_next_step=f"run {CLI} inspect with your source flags, then plan.")
    return d.report(result, account=d.account_or_none(account), current=d.current_build())
