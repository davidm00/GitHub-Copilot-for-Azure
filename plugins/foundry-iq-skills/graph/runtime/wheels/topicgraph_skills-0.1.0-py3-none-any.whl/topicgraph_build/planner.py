"""Read-only plan and its immutable approval identity."""

from __future__ import annotations

import math
from dataclasses import asdict
from typing import Any

from topicgraph_core.contracts import PINNED_DEPENDENCIES, PUBLICATION_VERSION, BuildProfile, ContractError, Source, digest, require_publication_version
from topicgraph_core.run_naming import context, index_prefix

MIN_MODEL_CALL_CAP = 50
MODEL_CALLS_PER_LEAF = 10
DEFAULT_MODEL_API_VERSION = "2024-12-01-preview"
NATIVE_AUTHENTICATION = {"mode": "defaultAzureCredential", "allowInteractiveBrowser": False}
# label_max_completion_tokens: the tool's default (1300) is too small for reasoning models such
# as gpt-5-mini, whose reasoning tokens count against it; labels then end mid-JSON and block.
LABEL_SETTINGS = {"label_title_words": 8, "label_description_words": 60, "label_representatives": 4,
                  "label_max_completion_tokens": 4096}
SOURCE_TEMPORARY_CHANGES = [
    "add a temporary scoring profile to the source index (no documents or fields change)",
]
FIELD_ROLES = ("key", "text", "vector", "title", "source")


def default_model_call_cap(chunks: int, max_leaf_size: int) -> int:
    """Labeling calls allowed: about ten per expected leaf topic, never fewer than 50."""
    return max(MIN_MODEL_CALL_CAP, math.ceil(MODEL_CALLS_PER_LEAF * chunks / max_leaf_size))


def validate_model(model: dict[str, Any]) -> dict[str, str]:
    keys = ("endpoint", "deployment", "name", "api_version")
    if set(model) != set(keys) or not all(isinstance(model[k], str) and model[k].strip() for k in keys):
        raise ContractError("MODEL_SETTINGS_INVALID", "Model endpoint, deployment, name and API version are required")
    if not model["endpoint"].startswith("https://"):
        raise ContractError("MODEL_SETTINGS_INVALID", "The model endpoint must be an https URL")
    return {k: model[k].strip().rstrip("/") if k == "endpoint" else model[k].strip() for k in keys}


def validate_fields(fields: dict[str, Any]) -> dict[str, Any]:
    if set(fields) - set(FIELD_ROLES) or not all(isinstance(fields.get(k), str) and fields[k] for k in ("key", "text", "vector")):
        raise ContractError("SOURCE_FIELDS_INVALID", "Key, text and vector fields are required")
    if any(fields.get(k) is not None and (not isinstance(fields[k], str) or not fields[k]) for k in ("title", "source")):
        raise ContractError("SOURCE_FIELDS_INVALID", "Optional title and source fields must be names when given")
    return {k: fields.get(k) for k in FIELD_ROLES}


def plan(source: Source, profile: BuildProfile, *, target_service: str, fields: dict[str, Any],
         model: dict[str, Any], dataset: str, publication: dict[str, Any] | None = None,
         inspected: dict[str, Any] | None = None, model_call_cap: int | None = None,
         run_prefix: str | None = None) -> dict[str, Any]:
    source.validate()
    profile.validate()
    if target_service != source.service:
        raise ContractError("PLACEMENT_UNSUPPORTED", "Cross-service placement requires product validation")
    cap = model_call_cap if model_call_cap is not None else default_model_call_cap(source.expected_count, profile.max_leaf_size)
    if type(cap) is not int or cap < 1:
        raise ContractError("MODEL_CALL_CAP_INVALID", "The model call cap must be a positive whole number")
    prefix = index_prefix(dataset, run_prefix)
    action = {
        "source": asdict(source),
        "source_inspection_digest": digest(inspected if inspected is not None else asdict(source)),
        "fields": validate_fields(fields),
        "profile": asdict(profile),
        "pinned_dependencies": PINNED_DEPENDENCIES,
        "target_service": target_service,
        "publication_version": PUBLICATION_VERSION,
        "publication": publication or {"binding": {"endpoint": target_service, "source_index": source.index},
                                       "expected_current": digest(None), "previous_descriptor": None},
        "model": validate_model(model),
        "native_authentication": dict(NATIVE_AUTHENTICATION),
        "label_settings": dict(LABEL_SETTINGS),
        "model_call_cap": cap,
        "source_temporary_changes": {
            "index": source.index, "changes": list(SOURCE_TEMPORARY_CHANGES),
            "revert": "the build removes it; if it reports it could not, run reconcile to clean up",
        },
        "target_index_prefix": prefix,
        **({"run_naming": context(run_prefix)} if run_prefix else {}),
        "index_writes": [f"create a new index {prefix}<release content ID>", "upload the release's topic documents"],
        "publish_write": "select the verified physical descriptor on this machine; other consumers require explicit rollout",
    }
    return {"plan_id": digest(action), **action}


def approve_plan(planned: dict[str, Any], plan_id: str) -> None:
    require_publication_version(planned)
    if planned.get("pinned_dependencies") != PINNED_DEPENDENCIES:
        raise ContractError("PLAN_CHANGED", "Runtime pipeline changed; create and approve a new plan")
    if planned.get("native_authentication") != NATIVE_AUTHENTICATION:
        raise ContractError("PLAN_CHANGED", "Native Search authentication changed; create and approve a new plan")
    if planned["plan_id"] != plan_id or digest({k: v for k, v in planned.items() if k != "plan_id"}) != plan_id:
        raise ContractError("PLAN_CHANGED", "Approval must match exact immutable plan")
