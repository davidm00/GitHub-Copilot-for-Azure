"""Read-only inspection of a Search source index."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any

from topicgraph_core.contracts import ContractError, Source, digest
from topicgraph_core.service_errors import from_exception


def get_field(value: Any, name: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(name, default)
    if isinstance(value, Mapping):
        default = value.get(name, default)
    return getattr(value, name, default)


def enum_value(value: Any) -> Any:
    return value.value if isinstance(value, Enum) else value


def _fail(code: str, detail: str) -> None:
    raise ContractError(code, detail)


@dataclass(frozen=True)
class SourceFields:
    key: str
    text: str
    source: str | None
    vector: str
    title: str | None = None


@dataclass(frozen=True)
class SourceExportApproval:
    tenant: str
    resource: str
    dataset: str


class AzureSourceAdapter:
    """Requires query and index-read clients for the named *physical* source index.

    The build tool reads the source itself; this adapter only checks the field contract and document count.
    """

    def __init__(
        self, search_client: Any, index_client: Any, fields: SourceFields,
        *, approval: SourceExportApproval,
    ):
        self.search_client = search_client
        self.index_client = index_client
        self.fields = fields
        self.approval = approval

    def _preflight(self, source: Source) -> tuple[str, list[str]]:
        source.validate()
        approval = self.approval
        if not all((approval.tenant, approval.resource, approval.dataset)):
            _fail("SOURCE_IDENTITY_INVALID", "Named tenant/resource/dataset required")
        if source.service != approval.resource or source.index != approval.dataset:
            _fail("SOURCE_TARGET_MISMATCH", "Approval must identify the physical source service and index")
        bound = get_field(self.search_client, "index_name")
        if bound is not None and bound != source.index:
            _fail("SOURCE_TARGET_MISMATCH", "Search client is bound to a different physical index")
        if len({self.fields.key, self.fields.text, self.fields.vector}) != 3:
            _fail("SOURCE_FIELDS_INVALID", "Key, text and vector fields must be distinct")
        try:
            index = self.index_client.get_index(source.index)
        except Exception as exc:
            raise ContractError("SOURCE_INSPECT_FAILED", "Cannot inspect the named physical source index",
                                service_error=from_exception(exc)) from exc
        if get_field(index, "name") != source.index:
            _fail("SOURCE_TARGET_MISMATCH", "Index definition does not match physical source index")
        definitions = {get_field(f, "name"): f for f in get_field(index, "fields", [])}
        optional = [name for name in (self.fields.source, self.fields.title) if name]
        requested = [self.fields.key, self.fields.text, self.fields.vector, *optional]
        if any(not name or name not in definitions for name in requested):
            _fail("SOURCE_FIELDS_INVALID", "Every mapped field must exist in the source index")
        if not get_field(definitions[self.fields.key], "key", False):
            _fail("SOURCE_KEY_INVALID", "Mapped document ID must be the physical index key")
        for name in [n for n in requested if n != self.fields.vector]:
            field = definitions[name]
            if get_field(field, "hidden", False) or get_field(field, "retrievable", True) is False:
                _fail("SOURCE_FIELDS_INVALID", f"Field {name!r} is not retrievable")
        vector = definitions[self.fields.vector]
        if get_field(vector, "stored", True) is False:
            _fail("SOURCE_VECTORS_NOT_STORED", f"Field {self.fields.vector!r} is not stored, so its vectors can't be read")
        if get_field(vector, "hidden", False) or get_field(vector, "retrievable", True) is False:
            _fail("SOURCE_VECTORS_NOT_RETRIEVABLE", f"Field {self.fields.vector!r} is not retrievable, so its "
                  "vectors can't be read in place; ask the source owner to make it retrievable")
        if enum_value(get_field(vector, "type")) != "Collection(Edm.Single)" or get_field(vector, "vector_search_dimensions", get_field(vector, "dimensions")) != source.dimension:
            _fail("SOURCE_VECTOR_INVALID", "Stored vector type or dimension differs from the owner-provided model identity")
        for name in (self.fields.key, self.fields.text, *optional):
            if enum_value(get_field(definitions[name], "type")) != "Edm.String":
                _fail("SOURCE_FIELDS_INVALID", f"Field {name!r} must be a string")
        return digest([{"name": name, "type": get_field(f, "type"), "key": get_field(f, "key"),
                        "sortable": get_field(f, "sortable"), "filterable": get_field(f, "filterable"),
                        "hidden": get_field(f, "hidden"), "stored": get_field(f, "stored"),
                        "dimensions": get_field(f, "vector_search_dimensions", get_field(f, "dimensions"))}
                       for name, f in sorted(definitions.items())]), requested

    def _count(self, expected: int) -> None:
        try:
            actual = self.search_client.get_document_count()
        except Exception as exc:
            raise ContractError("SOURCE_COUNT_UNAVAILABLE", "Cannot verify full source count",
                                service_error=from_exception(exc)) from exc
        if actual != expected:
            _fail("SOURCE_CHANGED", f"Expected {expected} source rows; observed {actual}")

    def inspect(self, source: Source) -> dict[str, Any]:
        schema_fingerprint, selected = self._preflight(source)
        self._count(source.expected_count)
        return {"source": asdict(source), "fields": asdict(self.fields),
                "schema_fingerprint": schema_fingerprint, "selected_fields": selected,
                "snapshot_isolation": False}
