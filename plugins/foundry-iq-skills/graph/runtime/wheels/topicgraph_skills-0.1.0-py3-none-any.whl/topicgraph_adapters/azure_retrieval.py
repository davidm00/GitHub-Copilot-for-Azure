"""Raw November definitions: SDK round trips can discard preview configuration."""

from __future__ import annotations

import uuid
from typing import Any
from urllib.parse import quote

from topicgraph_core import skill_user_agent
from topicgraph_core.azure_auth import SEARCH_SCOPE, get_token
from topicgraph_core.contracts import ContractError
from topicgraph_core.service_errors import from_exception, from_response, response_json

API_VERSION = "2026-11-01-preview"


class RetrievalConfigurationClient:
    def __init__(self, endpoint: str, credential: Any, tenant_id: str, *, request: Any = None):
        import requests

        self.endpoint = endpoint.rstrip("/")
        self.credential, self.tenant_id = credential, tenant_id
        self.request = request or requests.request
        self.user_agent = f"{requests.utils.default_user_agent()} {skill_user_agent()}"
        self.receipts: list[dict[str, Any]] = []

    def _send(self, method: str, resource: str, body: dict[str, Any] | None = None,
              etag: str | None = None) -> tuple[dict[str, Any], str | None]:
        collection, name = resource.split("/", 1)
        if collection not in {"indexes", "knowledgesources", "knowledgebases"} or not name:
            raise ContractError("RETRIEVAL_RESOURCE_INVALID", "Unsupported configuration resource")
        if method == "PUT" and (not etag or etag.strip() == "*"):
            raise ContractError("RETRIEVAL_ETAG_REQUIRED", "An observed ETag is required before updating configuration")
        headers = {
            "Authorization": f"Bearer {get_token(self.credential, SEARCH_SCOPE, self.tenant_id)}",
            "Content-Type": "application/json", "User-Agent": self.user_agent,
            "x-ms-client-request-id": str(uuid.uuid4()),
        }
        if etag:
            headers["If-Match"] = etag
        url = f"{self.endpoint}/{collection}/{quote(name, safe='')}?api-version={API_VERSION}"
        try:
            response = self.request(method, url, headers=headers, json=body, timeout=60, allow_redirects=False)
        except Exception as exc:
            raise ContractError("RETRIEVAL_REQUEST_FAILED", f"{method} {resource} failed; inspect before retrying",
                                service_error=from_exception(exc)) from exc
        self.receipts.append({"resource": resource, "method": method, "status": response.status_code,
                              "request_id": response.headers.get("request-id"),
                              "client_request_id": headers["x-ms-client-request-id"]})
        if not 200 <= response.status_code < 300:
            raise ContractError("RETRIEVAL_REQUEST_FAILED", f"{method} {resource} returned {response.status_code}",
                                service_error=from_response(response))
        value = response_json(response, f"{method} {resource}", empty_ok=method != "GET")
        if not isinstance(value, dict):
            raise ContractError("RETRIEVAL_RESPONSE_INVALID", f"{resource} did not return a definition")
        return value, response.headers.get("ETag") or value.get("@odata.etag")

    def read(self, resource: str) -> tuple[dict[str, Any], str | None]:
        return self._send("GET", resource)

    def update(self, resource: str, body: dict[str, Any], etag: str) -> None:
        # Search may answer a write with an empty body (204); the caller's readback confirms it.
        self._send("PUT", resource, body, etag)
