"""Orchestration adapter around the TopicGraph build tool.

The tool writes its build under ``<outputDirectory>/topicGraph``; ``run-manifest.json`` names the
exported release, which :func:`topicgraph_build.release.load_release` verifies and loads.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from topicgraph_build.release import Release, load_release
from topicgraph_core.contracts import ContractError
from topicgraph_core.service_errors import MAX_DETAIL_MESSAGE, MAX_DETAILS, MAX_MESSAGE, redact

from .native_runner import (
    NativeCliResult,
    NativeRunner,
    config_output_directory,
    validate_native_config,
)

SEARCH_API_VERSION = "2026-11-01-preview"


def build_native_config(
    *,
    endpoint: str,
    source_index: str,
    vector_field: str,
    text_field: str,
    output_directory: str | Path,
    model: dict[str, str],
    api_version: str = SEARCH_API_VERSION,
    auth_mode: str = "defaultAzureCredential",
    tenant_id: str | None = None,
    title_field: str | None = None,
    doc_id_field: str | None = None,
    sampling_percentage: int = 4,
    minimum_sample_count: int = 30000,
    probe_seed: int = 1234,
    max_leaf_size: int = 100,
    concurrency: int = 8,
    requests_per_second: int = 25,
    sitemap_options: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Construct a validated nested TopicGraph configuration with topic labelling on.

    ``model`` holds ``endpoint``, ``deployment``, ``name`` and ``api_version`` of one Azure OpenAI chat
    deployment. ``readOnly`` is false because the build adds a temporary scoring profile to the source index and removes it.
    """
    search: dict[str, Any] = {
        "endpoint": endpoint,
        "apiVersion": api_version,
        "sourceIndex": source_index,
        "vectorField": vector_field,
        "textField": text_field,
    }
    if title_field:
        search["titleField"] = title_field
    if doc_id_field:
        search["docIdField"] = doc_id_field
    authentication: dict[str, Any] = {"mode": auth_mode}
    if auth_mode == "defaultAzureCredential":
        authentication["allowInteractiveBrowser"] = False
    if tenant_id:
        authentication["tenantId"] = tenant_id
    config: dict[str, Any] = {
        "search": search,
        "authentication": authentication,
        "models": [{
            "kind": "azureOpenAI",
            "azureOpenAIParameters": {
                "resourceUri": model.get("endpoint"),
                "deploymentId": model.get("deployment"),
                "modelName": model.get("name"),
                "modelApiVersion": model.get("api_version"),
            },
        }],
        "execution": {
            "topicGraph": {
                "samplingPercentage": sampling_percentage,
                "minimumSampleCount": minimum_sample_count,
                "probeSeed": probe_seed,
                "maxLeafSize": max_leaf_size,
                "concurrency": concurrency,
                "requestsPerSecond": requests_per_second,
                "readOnly": False,
            },
            "sitemap": {"enabled": True, **(sitemap_options or {})},
        },
        "outputDirectory": str(output_directory),
    }
    validate_native_config(config)
    return config


CONFIG_FILE_NAME = "topicgraph-config.json"


def _capped(text: str, limit: int) -> str:
    text = redact(text)
    return text if len(text) <= limit else text[: limit - 1] + "\u2026"


def _output_lines(result: NativeCliResult) -> list[str]:
    text = result.error or result.stderr or ""
    return [line.strip() for line in text.splitlines() if line.strip()]


def error_line(result: NativeCliResult) -> str:
    """The tool's one-line ``ERROR:`` message, without the prefix; secrets redacted, length capped."""
    lines = _output_lines(result)
    marked = [line for line in lines if line.startswith("ERROR:")]
    line = (marked or lines or [f"TopicGraph build exited with code {result.exit_code}"])[-1]
    return _capped(line.removeprefix("ERROR:").strip(), MAX_MESSAGE)


def native_error(result: NativeCliResult) -> dict[str, Any]:
    """What the build tool itself reported, in the ``service_error`` shape (no HTTP status): its error line,
    exit code and the last lines of its error output, redacted and capped. Never the full output."""
    info: dict[str, Any] = {"status": None, "source": "topicgraph build tool", "exit_code": result.exit_code,
                            "message": error_line(result)}
    tail = [{"message": _capped(line, MAX_DETAIL_MESSAGE)} for line in _output_lines(result)[-MAX_DETAILS:]]
    if tail:
        info["details"] = tail
    if result.support_log_path:
        info["support_log"] = str(result.support_log_path)
    return info


class NativeBuildAdapter:
    """Adapter running a TopicGraph build and loading the release it exports."""

    def __init__(self, runner: NativeRunner | None = None):
        self.runner = runner or NativeRunner()

    @staticmethod
    def write_config(config: dict[str, Any]) -> Path:
        """Write ``<outputDirectory>/topicgraph-config.json`` so the same file can resume the build or run cleanup."""
        cfg_data = dict(config)
        out_dir = Path(cfg_data["outputDirectory"]).resolve()
        cfg_data["outputDirectory"] = str(out_dir)
        validate_native_config(cfg_data)
        out_dir.mkdir(parents=True, exist_ok=True)
        cfg_path = out_dir / CONFIG_FILE_NAME
        cfg_path.write_text(json.dumps(cfg_data, indent=2), encoding="utf-8")
        return cfg_path

    def build_from_config(
        self,
        config: dict[str, Any] | Path,
        *,
        resume: bool = False,
        extra_flags: list[str] | None = None,
        env: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> tuple[NativeCliResult, Release]:
        """Run ``build --fresh`` (or ``--resume``) and load the latest exported release.

        A failed run raises ContractError carrying the tool's one-line error and the run result as ``result``.
        """
        cfg_path = self.write_config(config) if isinstance(config, dict) else Path(config)
        out_dir = config_output_directory(cfg_path)
        if out_dir is None:
            raise ContractError("CONFIG_INVALID", "Configuration missing top-level 'outputDirectory'")
        validate_native_config(cfg_path)
        result = self.runner.build(cfg_path, resume=resume, extra_flags=extra_flags, env=env, timeout=timeout)
        if not result.succeeded:
            error = ContractError(result.error_code or "NATIVE_EXECUTION_FAILED", error_line(result))
            error.result = result
            error.service_error = native_error(result)
            raise error
        return result, load_release(out_dir)
