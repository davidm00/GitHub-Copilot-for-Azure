"""Read a Topic Graph build output folder; passage text comes from the *current* source index.

The topic structure and topic labels are read from the ``ontology`` folder the
Topic Graph build keeps inside its output directory. No published Topic Graph index is
consulted. Construction, manifest, representatives and members are offline. Only
validate_source/evidence/hydrate perform HTTP, read-only and Entra-authenticated, through
exact per-call egress scopes. Callers must register ERROR_CODES in ontology_core.errors.CODES.
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import struct
import time
from collections import deque
from datetime import date
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlencode, urlsplit

from ontology_core import azure_auth, http, service_errors
from ontology_core.errors import Blocked
from ontology_core.http import EgressPolicy
from ontology_core.state import OUTDATED_STATE as _OUTDATED_STATE

from ontology_build.reader import EvidenceText, Manifest, Membership, Representative


ERROR_CODES = {
    "SOURCE_CURRENT_READ_REQUIRED": "explicitly acknowledge reading current source values, not the original snapshot",
    "TOPICGRAPH_OUTPUT_INVALID": "pass the Topic Graph build output folder (it contains an `ontology` folder); "
                                 "add --structure-id or --labels-id when it holds more than one",
    "TOPICGRAPH_STRUCTURE_INVALID": "restore an intact topic structure from the Topic Graph build output folder",
    "TOPICGRAPH_LEGACY_FORM": "rebuild the topic graph with the pinned Topic Graph build tool, then reconnect "
                              "and rebuild the ontology",
    "TOPICGRAPH_LABELS_INVALID": "restore one intact topic labels file for the chosen topic structure",
    "TOPICGRAPH_DESCRIPTOR_INVALID": "rerun ontology-build connect --topic-graph-output <dir>",
    "TOPICGRAPH_PIN_MISMATCH": "restore the connected Topic Graph output or reconnect and re-plan",
    "SOURCE_INDEX_CONFIG": "check the source endpoint, index, field mappings and API version recorded by the Topic Graph build",
    "SOURCE_INDEX_SCHEMA": "restore the expected source schema or reconnect and re-plan",
    "SOURCE_INDEX_AUTH": "sign in with az login to the target tenant",
    "SOURCE_INDEX_REQUEST": "check read access to the configured source index and retry",
    "SOURCE_INDEX_ROWS": "restore the selected source rows; keys and nonempty text must match exactly",
    "SOURCE_INDEX_FILTER": "use a filterable source key to preserve the recorded source scope",
}
# Folder and file names written by the Topic Graph build tool 1.0.10; read as-is. Its
# `ontology` hand-off folder holds `step-06-structures` and `labels` (the `step-07-labels`
# folder under `topicGraph` is the tool's own working copy).
ONTOLOGY_FOLDER = "ontology"
_STRUCTURES = "step-06-structures"
_LABELS = "labels"
_RUN_MANIFEST = ("topicGraph", "run-manifest.json")
# The pinned Topic Graph build tool writes sealed structure v3 with `topics` in hierarchy.json and
# statistics.json. v2 (`communities`, build tool 1.0.7 and earlier) is a different contract: rejected, not read.
_STRUCTURE_VERSION = 3
_TOPICS, _LEGACY_TOPICS = "topics", "communities"
_LEGACY_STRUCTURE = ("This Topic Graph output is the community-form structure (version 2) written by build tool "
                     "1.0.7 or earlier; this version reads only structure version 3. Rebuild it with the pinned "
                     "build tool.")
_LABEL_STATUSES = {"ok", "skipped", "blocked"}
_SHA = re.compile(r"[0-9a-f]{64}\Z")
_FIELD = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,127}\Z")
_INDEX = re.compile(r"[a-z0-9][a-z0-9_-]{0,127}\Z")
_HOST = re.compile(
    r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?"
    r"\.search\.windows\.net\Z"
)
_CONFIG = (
    "endpoint", "index", "key_field", "text_field", "source_id_field", "title_field",
    "vector_field", "dimensions", "api_version", "filter",
)
_REQUIRED = {
    "hierarchy.json", "chunks.json", "leaf-members.bin", "statistics.json",
    "centroids.f32", "context.json",
}


def _fail(code: str, message: str) -> None:
    raise Blocked(code, message) from None


def _service_fail(code: str, message: str, info: dict | None) -> None:
    """`_fail` for a failed service call: append the parsed, redacted service error and attach it."""
    if info:
        message = f"{message} {service_errors.summary(info)}"
    raise Blocked(code, message, service_error=info) from None


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def _object(data: bytes, code: str) -> dict:
    def pairs(items: list[tuple[str, Any]]) -> dict:
        result: dict = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate property")
            result[key] = value
        return result

    try:
        obj = json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs,
                         parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (ValueError, UnicodeError, RecursionError):
        _fail(code, "Invalid JSON object.")
    if not isinstance(obj, dict):
        _fail(code, "Expected a JSON object.")
    return obj


def _bytes(path: Path, code: str) -> bytes:
    try:
        return path.read_bytes()
    except (OSError, ValueError):
        _fail(code, "A required local artifact cannot be read.")


def _integer(value: Any, minimum: int = 0) -> bool:
    return type(value) is int and value >= minimum


def _resolved(path: Any, code: str) -> Path:
    try:
        return Path(path).resolve(strict=True)
    except (OSError, ValueError, TypeError, RuntimeError):
        _fail(code, "A required local path cannot be resolved.")


def _structure(directory: Path) -> dict:
    code = "TOPICGRAPH_STRUCTURE_INVALID"
    root = _resolved(directory, code)
    manifest_path = _resolved(root / "manifest.json", code)
    if manifest_path.parent != root or manifest_path.name != "manifest.json":
        _fail(code, "Structure manifest escapes its directory.")
    raw = _bytes(manifest_path, code)
    manifest = _object(raw, code)
    sid, version = manifest.get("structureId"), manifest.get("version")
    if version == 2:
        _fail("TOPICGRAPH_LEGACY_FORM", _LEGACY_STRUCTURE)
    if (type(version) is not int or version != _STRUCTURE_VERSION
            or not isinstance(sid, str) or not _SHA.fullmatch(sid) or root.name != sid):
        _fail(code, "Structure manifest version or directory identity does not match.")
    entries = manifest.get("files")
    if not isinstance(entries, list):
        _fail(code, "Structure manifest must list its files.")
    names: set[str] = set()
    exact_names: set[str] = set()
    data: dict[str, bytes] = {}
    needed = {"hierarchy.json", "chunks.json", "leaf-members.bin", "context.json", "statistics.json"}
    for entry in entries:
        if not isinstance(entry, dict):
            _fail(code, "Invalid structure file entry.")
        name, size, digest = (entry.get(k) for k in ("name", "bytes", "sha256"))
        if (not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_-][A-Za-z0-9_.-]*", name)
                or name.casefold() in names or name.casefold() == "manifest.json"
                or not _integer(size) or not isinstance(digest, str) or not _SHA.fullmatch(digest)):
            _fail(code, "Invalid, duplicate or unsafe structure file entry.")
        names.add(name.casefold())
        exact_names.add(name)
        path = _resolved(root / name, code)
        if path.parent != root or path.name != name:
            _fail(code, "A structure file escapes its structure directory.")
        try:
            hasher = hashlib.sha256()
            length = 0
            parts = []
            with path.open("rb") as stream:
                while block := stream.read(1024 * 1024):
                    hasher.update(block)
                    length += len(block)
                    if name in needed:
                        parts.append(block)
        except OSError:
            _fail(code, "A structure file cannot be read.")
        if length != size or hasher.hexdigest() != digest:
            _fail(code, "A structure file size or SHA256 does not match the manifest.")
        if name in needed:
            data[name] = b"".join(parts)
    if (not _REQUIRED <= exact_names
            or not any(n.startswith("representatives-") and n.endswith(".json") for n in names)
            or not any(n.startswith("selection-") and n.endswith(".json") for n in names)):
        _fail(code, "Structure manifest omits required files.")
    try:
        if any(p.name.casefold() not in names | {"manifest.json"} for p in root.iterdir()):
            _fail(code, "Structure directory contains an unlisted artifact.")
    except OSError:
        _fail(code, "Structure directory cannot be enumerated.")
    hierarchy = _object(data["hierarchy.json"], code)
    if (type(hierarchy.get("version")) is not int or hierarchy["version"] != version
            or hierarchy.get("structureId") != sid or _LEGACY_TOPICS in hierarchy):
        _fail(code, "Hierarchy identity or version differs from the structure manifest.")
    context = _object(data["context.json"], code)
    if type(context.get("version")) is not int or context["version"] != version:
        _fail(code, "Context version differs from the structure manifest.")
    chunks = _object(data["chunks.json"], code)
    ordinals, keys = chunks.get("ordinals"), chunks.get("keys")
    if (not isinstance(ordinals, list) or not isinstance(keys, list) or not keys
            or len(keys) != len(ordinals) or any(not _integer(o) for o in ordinals)
            or any(not isinstance(k, str) or not k.strip() for k in keys)
            or len(set(ordinals)) != len(ordinals) or len(set(keys)) != len(keys)):
        _fail(code, "Chunk keys and graph ordinals must be nonempty, unique and paired.")
    by_ordinal = dict(zip(ordinals, keys))
    topics = hierarchy.get(_TOPICS)
    if not isinstance(topics, list) or not topics:
        _fail(code, "Hierarchy has no topics.")
    nodes: dict[int, dict] = {}
    for node in topics:
        if (not isinstance(node, dict) or not _integer(node.get("id"))
                or node["id"] in nodes or not _integer(node.get("memberCount"), 1)
                or not _integer(node.get("level"))
                or type(node.get("isLeaf")) is not bool
                or "parent" not in node
                or (node["parent"] is not None and not _integer(node["parent"]))):
            _fail(code, "Topic identifiers, parents, levels, counts or leaf markers are invalid.")
        nodes[node["id"]] = node
    children: dict[int, list[int]] = {i: [] for i in nodes}
    for i, node in nodes.items():
        parent = node["parent"]
        if parent is not None:
            if parent not in nodes or parent == i:
                _fail(code, "Hierarchy has an unknown or self parent.")
            children[parent].append(i)
    leaves = {i for i in nodes if not children[i]}
    if any(nodes[i]["isLeaf"] != (i in leaves) for i in nodes):
        _fail(code, "Hierarchy leaf markers do not match its children.")
    statistics = _object(data["statistics.json"], code)
    row_ids, rows = statistics.get("rowIds"), statistics.get(_TOPICS)
    if (type(statistics.get("version")) is not int or statistics["version"] != version
            or _LEGACY_TOPICS in statistics or not isinstance(row_ids, list) or not isinstance(rows, list)
            or any(not _integer(r) for r in row_ids) or len(set(row_ids)) != len(row_ids)
            or set(row_ids) != set(nodes)
            or [row.get("id") if isinstance(row, dict) else None for row in rows] != row_ids):
        _fail(code, "Statistics version, topics or row order differs from the hierarchy (topic IDs must equal rowIds).")
    binary = data["leaf-members.bin"]
    offset = 4

    def number() -> int:
        nonlocal offset
        if offset + 4 > len(binary):
            _fail(code, "Leaf membership binary is truncated.")
        value = struct.unpack_from("<i", binary, offset)[0]
        offset += 4
        return value

    if binary[:4] != b"TGLM" or number() != version or number() != len(leaves):
        _fail(code, "Leaf membership header is not the supported Topic Graph format.")
    membership: dict[int, set[str]] = {}
    covered: set[int] = set()
    for _ in leaves:
        i, count = number(), number()
        if i not in leaves or i in membership or count != nodes[i]["memberCount"]:
            _fail(code, "Leaf membership identifiers or counts differ from the hierarchy.")
        if count > (len(binary) - offset) // 4:
            _fail(code, "Leaf membership binary is truncated.")
        local: set[str] = set()
        for _ in range(count):
            ordinal = number()
            if ordinal not in by_ordinal or ordinal in covered:
                _fail(code, "Leaf membership has unknown or duplicate graph ordinals.")
            covered.add(ordinal)
            local.add(by_ordinal[ordinal])
        membership[i] = local
    if offset != len(binary) or covered != set(ordinals):
        _fail(code, "Leaf membership has trailing bytes or incomplete chunk coverage.")
    merged: set[int] = set()
    remaining = {i: len(children[i]) for i in nodes}
    queue = deque(sorted(leaves))
    while queue:
        i = queue.popleft()
        merged.add(i)
        if children[i]:
            membership[i] = set().union(*(membership[c] for c in children[i]))
        if len(membership[i]) != nodes[i]["memberCount"]:
            _fail(code, "A topic memberCount differs from its descendant union.")
        parent = nodes[i]["parent"]
        if parent is not None:
            remaining[parent] -= 1
            if not remaining[parent]:
                queue.append(parent)
    if len(merged) != len(nodes):
        _fail(code, "Hierarchy contains a parent cycle.")
    # Topic Graph numbers levels from the roots (0 = broadest); keep its numbers and check them.
    depth = {i: 0 for i in nodes if nodes[i]["parent"] is None}
    walk = deque(sorted(depth))
    while walk:
        i = walk.popleft()
        for c in children[i]:
            depth[c] = depth[i] + 1
            walk.append(c)
    if any(nodes[i]["level"] != depth[i] for i in nodes):
        _fail(code, "Topic levels do not match the hierarchy (roots are level 0).")
    levels = {i: nodes[i]["level"] for i in nodes}
    if (hierarchy.get("clustered") != len(keys)
            or not _integer(hierarchy.get("sourceNodes"), len(keys))):
        _fail(code, "Hierarchy clustered/source counts do not match the chunk coverage.")
    return {
        "root": root, "structure_id": sid, "manifest_sha256": _sha(raw),
        "context": context, "nodes": nodes,
        "membership": membership, "levels": levels, "keys": set(keys),
    }


def read_structure(structure_dir: Path) -> dict:
    """Offline integrity/coverage summary; contains neither labels nor passage text."""
    data = _structure(structure_dir)
    return {
        "structure_id": data["structure_id"], "manifest_sha256": data["manifest_sha256"],
        "counts": {"representative": len(data["nodes"]),
                   "membership": sum(map(len, data["membership"].values())),
                   "chunks": len(data["keys"])},
        "levels": sorted(set(data["levels"].values())),
    }


def _labels(path: Path | None, sid: str, ids: set[int]) -> tuple[Path | None, str | None, dict]:
    if path is None:
        return None, None, {}
    code = "TOPICGRAPH_LABELS_INVALID"
    resolved = _resolved(path, code)
    if resolved.is_dir():
        try:
            candidates = []
            for candidate in sorted(resolved.rglob("*.json")):
                obj = _object(_bytes(candidate, code), code)
                if obj.get("structureId") == sid and "labels" in obj:
                    candidates.append(candidate)
        except OSError:
            _fail(code, "Labels directory cannot be enumerated.")
        if len(candidates) != 1:
            _fail("TOPICGRAPH_LABELS_INVALID", "Choose an explicit labels file: directory must have exactly one matching structure.")
        resolved = _resolved(candidates[0], code)
    raw = _bytes(resolved, code)
    obj = _object(raw, code)
    if (type(obj.get("version")) is not int or obj["version"] != 2
            or obj.get("structureId") != sid or not isinstance(obj.get("labels"), dict)):
        _fail(code, "Labels version, structure identity or label map is invalid.")
    labels = obj["labels"]
    known_ids = {str(n) for n in ids}
    for i, label in labels.items():
        omitted = label.get("omittedChildren", []) if isinstance(label, dict) else None
        if (i not in known_ids or not isinstance(label, dict)
                or label.get("status") not in _LABEL_STATUSES
                or any(k in label and label[k] is not None and not isinstance(label[k], str)
                       for k in ("title", "description"))
                # A parent labeled only from its children's summaries; the label is still the topic's own.
                or label.get("evidence", "children_only") != "children_only"
                or not isinstance(omitted, list)
                or any(not _integer(c) or str(c) not in known_ids for c in omitted)):
            _fail(code, "Labels contain an unknown topic, status or mistyped field.")
        if label["status"] == "ok" and (
                not isinstance(label.get("title"), str) or not label["title"].strip()
                or not isinstance(label.get("description"), str)):
            _fail(code, "Successful labels require a nonempty title and a string description.")
        # A skipped label (the model's content filter kept rejecting the topic) publishes the topic untitled.
        if label["status"] == "skipped" and (label.get("title") is not None or label.get("description") is not None):
            _fail(code, "Skipped labels must have no title or description.")
    return resolved, _sha(raw), labels


def _endpoint(value: Any) -> str:
    if not isinstance(value, str):
        _fail("SOURCE_INDEX_CONFIG", "Source endpoint must be an HTTPS Azure Search origin.")
    try:
        parts = urlsplit(value)
        if (parts.scheme != "https" or not parts.hostname or not _HOST.fullmatch(parts.hostname)
                or parts.netloc != parts.hostname or parts.path not in ("", "/")
                or parts.query or parts.fragment):
            raise ValueError()
    except ValueError:
        _fail("SOURCE_INDEX_CONFIG", "Source endpoint must be an HTTPS Azure Search origin without credentials or port.")
    return f"https://{parts.hostname}"


def _source(context: dict) -> dict:
    """The source index reference the Topic Graph build recorded in context.json."""
    code = "SOURCE_INDEX_CONFIG"
    source = context.get("source")
    if not isinstance(source, dict):
        _fail(code, "The topic structure does not record its source index.")
    if type(source.get("version")) is not int or source["version"] != 1:
        _fail(code, "Recorded source reference version is unsupported.")
    index = source.get("indexName")
    if not isinstance(index, str) or not _INDEX.fullmatch(index):
        _fail(code, "Source index identifier is invalid.")
    result = {"endpoint": _endpoint(source.get("endpoint")), "index": index}
    for name, property_name, required in (
            ("key_field", "keyField", True), ("text_field", "textField", True),
            ("source_id_field", "docIdField", False), ("title_field", "titleField", False),
            ("vector_field", "vectorField", True)):
        value = source.get(property_name)
        if value is None and not required:
            result[name] = None
            continue
        if not isinstance(value, str) or not _FIELD.fullmatch(value):
            _fail(code, "A required recorded source field identifier is invalid.")
        result[name] = value
    dimensions = source.get("dimensions")
    api_version = source.get("apiVersion")
    if not _integer(dimensions, 1):
        _fail(code, "Recorded vector dimensions must be a positive integer.")
    if not isinstance(api_version, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:-preview)?", api_version):
        _fail(code, "Recorded source API version is invalid.")
    try:
        date.fromisoformat(api_version[:10])
    except ValueError:
        _fail(code, "Recorded source API version is invalid.")
    scope = source.get("filter", context.get("filter"))
    if scope is not None and (not isinstance(scope, str) or not scope.strip()):
        _fail(code, "Recorded source filter must be null or a nonempty string.")
    result.update(dimensions=dimensions, api_version=api_version, filter=scope)
    return result


def _ontology_folder(output: Any) -> Path:
    code = "TOPICGRAPH_OUTPUT_INVALID"
    root = _resolved(output, code)
    for candidate in (root / ONTOLOGY_FOLDER, root):
        if (candidate / _STRUCTURES).is_dir():
            return candidate
    _fail(code, "The folder is not a Topic Graph build output folder; it has no `ontology` folder.")


def _run_manifest(ontology: Path) -> dict:
    """Build bookkeeping used only to break ties between several structures or label sets."""
    path = ontology.parent.joinpath(*_RUN_MANIFEST)
    if not path.is_file():
        return {}
    try:
        return _object(_bytes(path, "TOPICGRAPH_OUTPUT_INVALID"), "TOPICGRAPH_OUTPUT_INVALID")
    except Blocked:
        return {}


def _identifier(value: Any, flag: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not _SHA.fullmatch(value.strip().lower()):
        _fail("TOPICGRAPH_OUTPUT_INVALID", f"{flag} must be a 64-character hexadecimal identifier.")
    return value.strip().lower()


def resolve_output(output: Any, *, structure_id: str | None = None,
                   labels_id: str | None = None) -> tuple[Path, Path | None]:
    """Pick one topic structure and its topic labels from a Topic Graph output folder.

    ``output`` is the build output directory or its ``ontology`` folder. With one
    structure (or one matching labels file) no choice is needed; otherwise the build's
    latest structure and release are preferred, then the explicit IDs are required.
    No labels file means an unlabeled run.
    """
    code = "TOPICGRAPH_OUTPUT_INVALID"
    structure_id = _identifier(structure_id, "--structure-id")
    labels_id = _identifier(labels_id, "--labels-id")
    ontology = _ontology_folder(output)
    labels_dir = ontology / _LABELS
    try:
        structures = sorted(p.name for p in (ontology / _STRUCTURES).iterdir()
                            if p.is_dir() and _SHA.fullmatch(p.name))
        label_ids = sorted(p.stem for p in labels_dir.iterdir()
                           if p.is_file() and p.suffix == ".json" and _SHA.fullmatch(p.stem)) \
            if labels_dir.is_dir() else []
    except OSError:
        _fail(code, "The Topic Graph output folder cannot be listed.")
    hints = _run_manifest(ontology)
    if not structures:
        _fail(code, "The Topic Graph output folder has no topic structure.")
    if structure_id is not None:
        if structure_id not in structures:
            _fail(code, "--structure-id does not name a topic structure in this output folder.")
        sid = structure_id
    elif len(structures) == 1:
        sid = structures[0]
    elif hints.get("latest") in structures:
        sid = hints["latest"]
    else:
        _fail(code, "The output folder holds several topic structures; pass --structure-id.")
    structure_dir = ontology / _STRUCTURES / sid
    if labels_id is not None:
        if labels_id not in label_ids:
            _fail(code, "--labels-id does not name a topic labels file in this output folder.")
        return structure_dir, labels_dir / f"{labels_id}.json"
    matching = [i for i in label_ids
                if _object(_bytes(labels_dir / f"{i}.json", "TOPICGRAPH_LABELS_INVALID"),
                           "TOPICGRAPH_LABELS_INVALID").get("structureId") == sid]
    if len(matching) <= 1:
        return structure_dir, labels_dir / f"{matching[0]}.json" if matching else None
    releases = [r for r in hints.get("releases") or [] if isinstance(r, dict) and r.get("structureId") == sid]
    latest = [r for r in releases if r.get("id") == hints.get("latestRelease")]
    for candidates in (latest, releases):
        preferred = {r.get("labelVariantId") for r in candidates} & set(matching)
        if len(preferred) == 1:
            return structure_dir, labels_dir / f"{preferred.pop()}.json"
    _fail(code, "Several topic labels files match the topic structure; pass --labels-id.")


def create_descriptor(structure_dir: Path, labels: Path | None = None, *,
                      accept_current_source: bool = False) -> dict:
    """Pin the local structure, labels and recorded source; the acknowledgment is mandatory.

    The source reference comes only from the structure's context.json. No original
    request ID, model identity, credentials or source snapshot is invented.
    """
    if accept_current_source is not True:
        _fail("SOURCE_CURRENT_READ_REQUIRED",
              "Passage text is read from the source index as it is now, not as it was at build time.")
    data = _structure(structure_dir)
    label_file, label_sha, _ = _labels(labels, data["structure_id"], set(data["nodes"]))
    return {
        "version": "topicgraph-output-v1", "accept_current_source": True,
        "structure_id": data["structure_id"], "structure_dir": str(data["root"]),
        "manifest_sha256": data["manifest_sha256"],
        "labels_file": str(label_file) if label_file else None, "labels_sha256": label_sha,
        **_source(data["context"]),
    }


class TopicGraphReader:
    """Offline topic hierarchy plus selected-row current-source hydration.

    Each outbound request uses a policy narrowed to just its exact source method/path.
    """

    def __init__(self, descriptor: dict, tenant_id: str):
        if not isinstance(descriptor, dict):
            _fail("TOPICGRAPH_DESCRIPTOR_INVALID", "The saved Topic Graph input must be an object.")
        obj = copy.deepcopy(descriptor)
        if obj.get("version") != "topicgraph-output-v1" or obj.get("accept_current_source") is not True:
            _fail("TOPICGRAPH_DESCRIPTOR_INVALID", "Unsupported saved input or missing current-source acknowledgment.")
        try:
            expected = create_descriptor(obj.get("structure_dir"), obj.get("labels_file"), accept_current_source=True)
        except Blocked as exc:
            if exc.code != "TOPICGRAPH_LEGACY_FORM":
                raise
            # A saved connection pinned to a community-form structure is outdated state, not a new input.
            raise Blocked("ONTOLOGY_STATE_OUTDATED", _OUTDATED_STATE) from None
        if set(obj) - set(expected) - {"source_schema_sha256"}:
            _fail("TOPICGRAPH_DESCRIPTOR_INVALID", "Unexpected saved input fields.")
        for name, value in expected.items():
            if name not in obj or type(obj[name]) is not type(value) or obj[name] != value:
                _fail("TOPICGRAPH_PIN_MISMATCH", "Connected inputs or the recorded source configuration have changed.")
        pin = obj.get("source_schema_sha256")
        if pin is not None and (not isinstance(pin, str) or not _SHA.fullmatch(pin)):
            _fail("TOPICGRAPH_DESCRIPTOR_INVALID", "Source schema pin must be a SHA256 digest.")
        if not isinstance(tenant_id, str) or not tenant_id.strip():
            _fail("SOURCE_INDEX_AUTH", "A target tenant ID is required.")
        self._descriptor = obj
        self._tenant_id = tenant_id
        self._data = _structure(Path(obj["structure_dir"]))
        _, labels_sha, self._labels = _labels(
            Path(obj["labels_file"]) if obj["labels_file"] else None,
            obj["structure_id"], set(self._data["nodes"]),
        )
        if self._data["manifest_sha256"] != obj["manifest_sha256"]:
            _fail("TOPICGRAPH_PIN_MISMATCH", "The topic structure changed while it was being opened.")
        # Recheck labels after loading rather than trusting a previous directory scan.
        if labels_sha != obj["labels_sha256"]:
            _fail("TOPICGRAPH_PIN_MISMATCH", "The topic labels changed while they were being opened.")

    @property
    def descriptor(self) -> dict:
        return copy.deepcopy(self._descriptor)

    def manifest(self) -> Manifest:
        payload = {
            "health": "verified", "structure_id": self._descriptor["structure_id"],
            "manifest_sha256": self._descriptor["manifest_sha256"],
            "labels_sha256": self._descriptor["labels_sha256"],
            "source": {k: self._descriptor[k] for k in _CONFIG},
            "source_schema_sha256": self._descriptor.get("source_schema_sha256"),
            "evidence_mode": "current-source-read",
            "counts": {"representative": len(self._data["nodes"]),
                       "membership": sum(map(len, self._data["membership"].values())),
                       "evidence": len(self._data["keys"])},
        }
        return Manifest(payload=payload, digest=_sha(_canonical(payload)))

    def representatives(self) -> list[Representative]:
        result = []
        for i, node in sorted(self._data["nodes"].items()):
            label = self._labels.get(str(i), {})
            named = label.get("status") == "ok"
            result.append(Representative(
                topic_id=str(i), parent_id=str(node["parent"]) if node["parent"] is not None else None,
                level=self._data["levels"][i], member_count=node["memberCount"],
                label=label["title"] if named else None,
                label_status="named" if named else None,
                summary=label["description"] if named else None,
            ))
        return result

    def members(self, level: int | None = None) -> list[Membership]:
        if level is not None and not _integer(level):
            _fail("TOPICGRAPH_STRUCTURE_INVALID", "Membership level must be a nonnegative integer.")
        return [
            Membership(str(i), key, self._data["levels"][i])
            for i, keys in sorted(self._data["membership"].items())
            if level is None or level == self._data["levels"][i]
            for key in sorted(keys)
        ]

    def _headers(self) -> dict[str, str]:
        try:
            azure_auth.require_tenant(self._tenant_id)
            return {"Authorization": "Bearer " + azure_auth.token(self._tenant_id, "search")}
        except Blocked as exc:
            message = "Could not obtain an Azure CLI Search token for the target tenant."
            raise Blocked("SOURCE_INDEX_AUTH", f"{message} {exc.error}",
                          service_error=exc.service_error) from None
        except Exception as exc:
            _service_fail("SOURCE_INDEX_AUTH", "Could not obtain an Azure CLI Search token for the target tenant.",
                          service_errors.from_exception(exc))

    def _request(self, method: str, path: str, *, body: dict | None = None,
                 query: dict | None = None) -> dict:
        d = self._descriptor
        url = d["endpoint"] + f"/indexes/{d['index']}" + path
        params = {"api-version": d["api_version"], **(query or {})}
        url += "?" + urlencode(params)
        exact = EgressPolicy(extra=(f"{method} {url}",))
        headers = self._headers()
        for attempt in range(3):
            try:
                response = http.request(exact, method, url, headers=headers, json_body=body)
            except (http.EgressNotSent, http.EgressUnknownOutcome):
                if attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                _fail("SOURCE_INDEX_REQUEST", "Source read failed after bounded retries.")
            except Exception:
                _fail("SOURCE_INDEX_REQUEST", "Source read could not be completed.")
            if response.status in (408, 429) or 500 <= response.status <= 599:
                if attempt < 2:
                    time.sleep(http.retry_after_seconds(response.headers, 2 ** attempt))
                    continue
            if response.status != 200:
                _service_fail("SOURCE_INDEX_REQUEST", "Source read returned an unsuccessful HTTP status.",
                              response.service_error())
            return _object(response.body, "SOURCE_INDEX_REQUEST")
        _fail("SOURCE_INDEX_REQUEST", "Source read failed after bounded retries.")

    def validate_source(self, *, include_vectors: bool = False) -> dict:
        """Return full source schema JSON; canonical pins include any @odata.etag.

        Vector retrievability/dimensions are required only for vector hydration.
        No volatile metadata is removed from either returned JSON or its pin.
        """
        schema = self._request("GET", "")
        d = self._descriptor
        if schema.get("name") != d["index"] or not isinstance(schema.get("fields"), list):
            _fail("SOURCE_INDEX_SCHEMA", "Source schema does not identify the configured index.")
        fields = {}
        for field in schema["fields"]:
            if (not isinstance(field, dict) or not isinstance(field.get("name"), str)
                    or field["name"] in fields):
                _fail("SOURCE_INDEX_SCHEMA", "Source schema has invalid or duplicate fields.")
            fields[field["name"]] = field
        for mapping in ("key_field", "text_field", "source_id_field", "title_field", "vector_field"):
            name = d[mapping]
            if name is None:
                continue
            field = fields.get(name, {})
            expected_type = "Collection(Edm.Single)" if mapping == "vector_field" else "Edm.String"
            needs_retrieval = mapping != "vector_field" or include_vectors
            if (field.get("type") != expected_type
                    or (needs_retrieval and field.get("retrievable", True) is not True)):
                _fail("SOURCE_INDEX_SCHEMA", "A mapped source field has an incompatible type or is not retrievable.")
            if mapping == "vector_field" and include_vectors and (
                    type(field.get("dimensions")) is not int or field["dimensions"] != d["dimensions"]):
                _fail("SOURCE_INDEX_SCHEMA", "Source vector dimensions differ from the recorded mapping.")
        if fields[d["key_field"]].get("key") is not True:
            _fail("SOURCE_INDEX_SCHEMA", "The configured source key is not the index key.")
        digest = _sha(_canonical(schema))
        if d.get("source_schema_sha256") is not None and d["source_schema_sha256"] != digest:
            _fail("SOURCE_INDEX_SCHEMA", "Source schema differs from the pinned schema.")
        return schema

    def evidence(self, chunk_ids: list[str]) -> dict[str, EvidenceText]:
        """The `OntologyReader` evidence read: selected scalar values, never vectors."""
        return {
            key: EvidenceText(key, row["source_id"], row["text"])
            for key, row in self.hydrate(chunk_ids).items()
        }

    def hydrate(self, chunk_ids: list[str], *, include_vectors: bool = False) -> dict[str, dict[str, Any]]:
        """Ordered current-source rows: chunk_id/text/source_id/title, optionally embedding.

        A source title may be null; an unmapped title is explicitly None. An unmapped
        document ID falls back to the chunk key. Vectors are
        selected/validated only on opt-in. Pre/post schema checks do not freeze values.
        """
        if type(include_vectors) is not bool:
            _fail("SOURCE_INDEX_CONFIG", "include_vectors must be an explicit boolean.")
        if not isinstance(chunk_ids, list) or any(
                not isinstance(k, str) or k not in self._data["keys"] for k in chunk_ids):
            _fail("SOURCE_INDEX_ROWS", "Requested chunks must belong to the Topic Graph structure.")
        wanted = list(dict.fromkeys(chunk_ids))
        if not wanted:
            return {}
        schema = self.validate_source(include_vectors=include_vectors)
        d = self._descriptor
        key_field = next(f for f in schema["fields"] if f["name"] == d["key_field"])
        filterable = key_field.get("filterable") is True
        if not filterable and d["filter"] is not None:
            _fail("SOURCE_INDEX_FILTER", "Keyed GET cannot safely reapply the recorded source filter.")
        mappings = ["key_field", "source_id_field", "text_field", "title_field"]
        if include_vectors:
            mappings.append("vector_field")
        select = list(dict.fromkeys(d[k] for k in mappings if d[k] is not None))
        found: dict[str, dict[str, Any]] = {}

        def add(rows: Any, expected: set[str]) -> None:
            if not isinstance(rows, list):
                _fail("SOURCE_INDEX_ROWS", "Source response is not a document list.")
            local = set()
            for row in rows:
                if not isinstance(row, dict):
                    _fail("SOURCE_INDEX_ROWS", "Source response contains an invalid document.")
                key, text = row.get(d["key_field"]), row.get(d["text_field"])
                # Without a recorded document-ID field, each chunk is its own source document.
                source_id = row.get(d["source_id_field"]) if d["source_id_field"] is not None else key
                if (not isinstance(key, str) or key not in expected or key in local or key in found
                        or not isinstance(source_id, str) or not source_id.strip()
                        or not isinstance(text, str) or not text.strip()):
                    _fail("SOURCE_INDEX_ROWS", "Source rows have duplicate/unexpected keys or invalid source ID/text.")
                title = None
                if d["title_field"] is not None:
                    if d["title_field"] not in row:
                        _fail("SOURCE_INDEX_ROWS", "Source row omits its selected title field.")
                    title = row[d["title_field"]]
                    if title is not None and not isinstance(title, str):
                        _fail("SOURCE_INDEX_ROWS", "Source title must be a string or null.")
                hydrated = {"chunk_id": key, "text": text, "source_id": source_id, "title": title}
                if include_vectors:
                    vector = row.get(d["vector_field"])
                    if not isinstance(vector, list) or len(vector) != d["dimensions"]:
                        _fail("SOURCE_INDEX_ROWS", "Source embedding must match the recorded dimensions.")
                    try:
                        if any(type(value) not in (int, float) or not math.isfinite(value) for value in vector):
                            raise ValueError()
                        hydrated["embedding"] = [float(value) for value in vector]
                    except (ValueError, OverflowError):
                        _fail("SOURCE_INDEX_ROWS", "Source embedding must contain only finite numbers.")
                local.add(key)
                found[key] = hydrated
            if local != expected:
                _fail("SOURCE_INDEX_ROWS", "Source response is missing selected chunks.")

        if filterable:
            for start in range(0, len(wanted), 100):
                batch = wanted[start:start + 100]
                delimiter = next((c for c in "|,~^;" if all(c not in k for k in batch)), None)
                if delimiter is None:
                    _fail("SOURCE_INDEX_ROWS", "Selected keys cannot be encoded safely for search.in.")
                escaped = delimiter.join(batch).replace("'", "''")
                scope = f"search.in({d['key_field']}, '{escaped}', '{delimiter}')"
                if d["filter"] is not None:
                    scope = f"({d['filter']}) and ({scope})"
                result = self._request("POST", "/docs/search", body={
                    "search": "*", "filter": scope, "select": ",".join(select), "top": len(batch),
                })
                if any(result.get(k) for k in ("@odata.nextLink", "@search.nextPageParameters")):
                    _fail("SOURCE_INDEX_ROWS", "Unexpected source continuation; no continuation URL will be followed.")
                add(result.get("value"), set(batch))
        else:
            for key in wanted:
                result = self._request("GET", "/docs/" + quote(key, safe=""),
                                       query={"$select": ",".join(select)})
                add([result], {key})
        after = self.validate_source(include_vectors=include_vectors)
        if _canonical(after) != _canonical(schema):
            _fail("SOURCE_INDEX_SCHEMA", "Source schema changed during hydration; selected evidence was discarded.")
        return {key: found[key] for key in wanted}
