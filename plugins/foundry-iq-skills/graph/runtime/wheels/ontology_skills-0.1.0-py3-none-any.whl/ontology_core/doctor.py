"""`doctor` checks.

Output is one line per check (`ok`/`FAIL`/`skip`, name, detail), then `Next step: ...`. All checks
run; the first FAIL sets `status:"blocked"` and `error_code:"DOCTOR_<CHECK>"` in `result()`, which blocks
`connect`. The `doctor` verb itself always exits 0 and, with `--json`, prints `report()`, the shape every
plugin shares. A skip never blocks. Doctor never sends a completion.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal
from urllib.parse import quote, urlparse

from ontology_core import errors, service_errors
from ontology_core.errors import Blocked
from ontology_core.model import Config

CheckStatus = Literal["ok", "FAIL", "skip"]

CHECKS: tuple[str, ...] = (
    "cli_version", "python", "azure_signin", "state_dir", "journal", "topicgraph_output",
    "source_index", "topicgraph_topics", "model_data_plane", "model_deployment",
)
"""`ontology-build doctor` checks, in output order. Each FAIL maps to error code `DOCTOR_<NAME.upper()>`."""

CONSUME_CHECKS: tuple[str, ...] = ("cli_version", "python", "state_dir", "journal")
"""`ontology-consume doctor` checks (no Azure)."""

MIN_PYTHON = (3, 12)
PACKAGE = "ontology-skills"
COGNITIVE_ARM_API_VERSION = "2024-10-01"
ARM = "https://management.azure.com"


def code_for(check: str) -> str:
    """`DOCTOR_<CHECK>` for a name in `CHECKS`."""
    return f"DOCTOR_{check.upper()}"


@dataclass
class Check:
    name: str
    status: CheckStatus
    detail: str = ""
    next_step: str | None = None
    """Rendered `next_step` for a FAIL (defaults to the `DOCTOR_<CHECK>` template)."""
    data: dict[str, Any] = field(default_factory=dict)
    """Structured facts, e.g. `{"model_name": ..., "model_version": ...}` from `model_deployment`."""
    service_error: dict[str, Any] | None = None
    """Parsed service error (`service_errors.describe`) for a FAIL caused by a failed service call."""

    def to_dict(self) -> dict[str, Any]:
        body: dict[str, Any] = {"name": self.name, "status": self.status, "detail": self.detail}
        if self.status == "FAIL":
            body["error_code"] = code_for(self.name)
            body["next_step"] = self.next_step or errors.render_next_step(code_for(self.name))
        if self.data:
            body["data"] = self.data
        if self.service_error:
            body["service_error"] = self.service_error
        return body


@dataclass
class DoctorContext:
    """Inputs resolved from flags first, then `config.json`. Any may be None (the check is skipped)."""

    state_dir: Path
    config: Config | None = None
    tenant_id: str | None = None
    tenant_name: str | None = None
    topicgraph_input_path: Path | None = None
    model_endpoint: str | None = None
    model_deployment: str | None = None
    subscription_id: str | None = None
    model_resource_group: str | None = None
    plugin_root: Path | None = None
    """Explicit package root or a package discovered from this runtime's source location."""
    cache: dict[str, Any] = field(default_factory=dict, repr=False)
    """Objects shared between checks within one run (descriptor, reader, signed-in account)."""


CheckFn = Callable[[DoctorContext, dict[str, Check]], Check]
"""A check receives the context and earlier results for dependent skips."""


def _ok(name: str, detail: str, **data: Any) -> Check:
    return Check(name, "ok", detail, data={k: v for k, v in data.items() if v is not None})


def _skip(name: str, detail: str) -> Check:
    return Check(name, "skip", detail)


def _passed(earlier: dict[str, Check], name: str) -> bool:
    return name in earlier and earlier[name].status == "ok"


def _tenant_label(ctx: DoctorContext) -> str:
    return f"tenant {ctx.tenant_id}" + (f" ({ctx.tenant_name})" if ctx.tenant_name else "")


# --------------------------------------------------------------------------- machine


def installed_version() -> str | None:
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version(PACKAGE)
    except PackageNotFoundError:
        return None


def check_cli_version(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    from ontology_core import __version__

    installed = installed_version() or __version__
    root = ctx.plugin_root or plugin_root_from(None) or installed_plugin_root()
    if root is None:
        return _skip("cli_version", f"ontology-skills {installed}; package source version not compared; "
                     "pass --plugin-root or set PLUGIN_ROOT to the installed or extracted package")
    runtime_manifest = Path(root) / "graph" / "runtime" / "manifest.json"
    if runtime_manifest.is_file():
        try:
            metadata = json.loads(runtime_manifest.read_text(encoding="utf-8"))
            if type(metadata["schema_version"]) is not int or metadata["schema_version"] != 2:
                raise ValueError("runtime manifest requires schema_version 2")
            wheel = metadata["runtimes"]["ontology"]["wheel"]
            if wheel["name"] != PACKAGE:
                raise ValueError(f"expected the {PACKAGE} runtime wheel")
            plugin = wheel["version"]
            if not isinstance(plugin, str) or not plugin.strip():
                raise ValueError("ontology wheel version must be a non-empty string")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise Blocked(
                "DOCTOR_CLI_VERSION", f"cannot read {runtime_manifest}: {exc}",
                next_step="Reinstall a complete compatible plugin package, then rerun ontology-build doctor. "
                          "Runtime setup cannot repair invalid or unsupported package metadata.",
            ) from exc
        if plugin != installed:
            raise Blocked("DOCTOR_CLI_VERSION", f"CLI {installed} does not match ontology wheel {plugin} ({runtime_manifest})")
        return _ok("cli_version", f"ontology-skills {installed} (wheel {plugin})", version=installed)
    manifest = next((Path(root) / directory / "plugin.json"
                     for directory in (".plugin", "", ".claude-plugin", ".cursor-plugin")
                     if (Path(root) / directory / "plugin.json").is_file()), Path(root) / "plugin.json")
    if not manifest.is_file():
        return _skip("cli_version", f"ontology-skills {installed}; no runtime manifest or source metadata at {root}")
    try:
        metadata = json.loads(manifest.read_text(encoding="utf-8"))
        if not isinstance(metadata, dict):
            raise ValueError("manifest must be an object")
        plugin = metadata.get("version")
        if metadata.get("name") == "foundry-iq-skills":
            import tomllib

            project_path = Path(root) / "graph" / "runtime" / PACKAGE / "pyproject.toml"
            if not project_path.is_file():
                return _skip("cli_version", f"ontology-skills {installed}; no runtime manifest or source metadata at {root}")
            project = tomllib.loads(project_path.read_text(encoding="utf-8"))["project"]
            if project["name"] != PACKAGE:
                raise ValueError(f"expected the {PACKAGE} runtime project")
            plugin = project["version"]
        if not isinstance(plugin, str) or not plugin:
            raise ValueError("source version is missing")
    except (OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        raise Blocked("DOCTOR_CLI_VERSION", f"cannot read {manifest}: {exc}") from exc
    if plugin != installed:
        raise Blocked("DOCTOR_CLI_VERSION", f"CLI {installed} does not match plugin {plugin} ({manifest})",
                      next_step=errors.CODES["DOCTOR_CLI_VERSION"])
    return _ok("cli_version", f"ontology-skills {installed} (plugin {plugin})", version=installed)


def check_python(ctx: DoctorContext, earlier: dict[str, Check], *,
                 version: tuple[int, ...] | None = None) -> Check:
    current = tuple(version or sys.version_info[:3])
    shown = ".".join(map(str, current))
    if current[:2] < MIN_PYTHON:
        raise Blocked("DOCTOR_PYTHON", f"Python {shown} is older than 3.12")
    return _ok("python", f"Python {shown}")


# --------------------------------------------------------------------------- Azure sign-in


def check_azure_signin(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    """Reads `az account show` through azure_auth; never signs in. The tenant is named first."""
    if not ctx.tenant_id:
        return _skip("azure_signin", "no tenant yet (--tenant-id); Azure checks skipped")
    from ontology_core import azure_auth

    try:
        account = azure_auth.require_tenant(ctx.tenant_id, ctx.tenant_name)
    except Blocked as exc:
        raise Blocked("DOCTOR_AZURE_SIGNIN", f"{_tenant_label(ctx)}: {exc.error}", next_step=exc.next_step,
                      details={"cause": exc.code}, service_error=exc.service_error) from exc
    ctx.cache["account"] = account
    if not ctx.tenant_name and account.tenant_name:
        ctx.tenant_name = account.tenant_name
    who = f" as {account.user}" if account.user else ""
    return _ok("azure_signin", f"{_tenant_label(ctx)}: signed in{who}", tenant_id=ctx.tenant_id,
               tenant_name=ctx.tenant_name, account=account.user or None)


# --------------------------------------------------------------------------- state


def check_state_dir(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    """Exists or can be created, writable, user-only. Never creates anything."""
    from ontology_core import state

    root = Path(ctx.state_dir)
    existing = root
    while not existing.exists() and existing.parent != existing:
        existing = existing.parent
    if not existing.is_dir():
        raise Blocked("DOCTOR_STATE_DIR", f"{existing} is not a directory")
    try:
        with tempfile.TemporaryFile(dir=existing):
            pass
    except OSError as exc:
        raise Blocked("DOCTOR_STATE_DIR", f"{existing} is not writable: {exc.strerror or exc}") from exc
    if existing != root:
        return _ok("state_dir", f"{root} will be created (user-only)")
    if not state.is_user_only(root):
        raise Blocked("DOCTOR_STATE_DIR", f"{root} is readable by other users")
    paths = state.paths_for(root)
    if paths.config.is_file():
        try:
            state.load_config(paths)
        except Blocked as exc:
            raise Blocked("DOCTOR_STATE_DIR", f"config.json: {exc.error}", next_step=exc.next_step) from exc
    try:
        state.require_current_contract(paths)
    except Blocked as exc:
        raise Blocked("DOCTOR_STATE_DIR", exc.error, next_step=exc.next_step,
                      details={"cause": exc.code, **exc.details}) from exc
    return _ok("state_dir", f"{root} writable, user-only")


def check_journal(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    from ontology_build import reconcile
    from ontology_core import journal as journal_mod
    from ontology_core import state

    paths = state.paths_for(ctx.state_dir)
    if not paths.journal.is_file():
        return _skip("journal", "no journal yet")
    try:
        entries = journal_mod.Journal(paths).read()
    except Blocked as exc:
        raise Blocked("DOCTOR_JOURNAL", exc.error) from exc
    lock = journal_mod.read_lock(paths)
    if lock is not None:
        stale = lock.host != journal_mod.this_host() or not journal_mod.pid_alive(lock.pid)
        if stale:
            raise Blocked("DOCTOR_JOURNAL", f"stale lock from {lock.verb} (pid {lock.pid} on {lock.host})")
    report = reconcile.check(paths)
    if report.drift:
        raise Blocked("DOCTOR_JOURNAL", f"{len(report.drift)} file(s) differ from the journal: "
                      + ", ".join(report.drift[:3]))
    detail = f"{len(entries)} entries, no drift"
    if lock is not None:
        detail += f"; {lock.verb} is running (pid {lock.pid})"
    if report.open_runs:
        detail += f"; {len(report.open_runs)} unfinished run(s), rerun propose to resume"
    return _ok("journal", detail)


def _you(ctx: DoctorContext) -> str:
    account = ctx.cache.get("account")
    return getattr(account, "user", None) or "<your sign-in>"


def check_topicgraph_output(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    from ontology_build import connection
    from ontology_build.topicgraph_reader import TopicGraphReader
    from ontology_core.hashing import sha256_bytes

    descriptor = ctx.cache.get("topicgraph_input")
    if descriptor is None and ctx.topicgraph_input_path is not None:
        descriptor = connection.local_descriptor(ctx.topicgraph_input_path)
        if ctx.config and sha256_bytes(ctx.topicgraph_input_path.read_bytes()) != ctx.config.topicgraph.descriptor_sha256:
            raise Blocked("TOPICGRAPH_INPUT_CHANGED", "saved Topic Graph input differs from the connected binding")
    if descriptor is None:
        if ctx.config is not None:
            raise Blocked("DOCTOR_TOPICGRAPH_OUTPUT", "The connected Topic Graph input is missing.")
        return _skip("topicgraph_output", "no Topic Graph output connected yet; run connect --topic-graph-output")
    try:
        reader = TopicGraphReader(descriptor, ctx.tenant_id or "")
    except Blocked as exc:
        raise Blocked("DOCTOR_TOPICGRAPH_OUTPUT", exc.error, next_step=exc.next_step,
                      details={"cause": exc.code}, service_error=exc.service_error) from exc
    ctx.cache["topicgraph_input"] = descriptor
    ctx.cache["reader"] = reader
    return _ok("topicgraph_output", f"topic structure {descriptor['structure_id']} (no published Topic Graph index)")


def check_source_index(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    if not _passed(earlier, "topicgraph_output"):
        return _skip("source_index", "needs a valid Topic Graph output")
    if not _passed(earlier, "azure_signin"):
        return _skip("source_index", "needs a signed-in tenant")
    try:
        ctx.cache["source_schema"] = ctx.cache["reader"].validate_source()
    except Blocked as exc:
        raise Blocked("DOCTOR_SOURCE_INDEX", exc.error, next_step=exc.next_step,
                      details={"cause": exc.code}, service_error=exc.service_error) from exc
    descriptor = ctx.cache["topicgraph_input"]
    return _ok("source_index", f"{descriptor['index']}: read-only source schema verified; "
               "passage text is read as it is now, not as it was at build time")


def check_topicgraph_topics(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    if not _passed(earlier, "topicgraph_output"):
        return _skip("topicgraph_topics", "needs a valid Topic Graph output")
    from ontology_build.reader import check_manifest

    reader = ctx.cache["reader"]
    manifest, representatives, members = reader.manifest(), reader.representatives(), reader.members(None)
    try:
        check_manifest(manifest, representatives, members)
    except Blocked as exc:
        raise Blocked("DOCTOR_TOPICGRAPH_TOPICS", exc.error, next_step=exc.next_step,
                      details={"cause": exc.code}, service_error=exc.service_error) from exc
    return _ok("topicgraph_topics", f"{len(representatives)} topics, {len(members)} memberships; "
               "level 0 is the broadest, same numbering as Topic Graph", manifest_digest=manifest.digest)


# --------------------------------------------------------------------------- model (metadata only)


def account_name(endpoint: str) -> str:
    return (urlparse(endpoint).hostname or "").split(".", 1)[0]


def check_model_data_plane(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    """Checks catalog access only without a selected deployment. Never sends a completion."""
    if not ctx.model_endpoint:
        return _skip("model_data_plane", "no model endpoint yet (--model-endpoint)")
    if not _passed(earlier, "azure_signin"):
        return _skip("model_data_plane", "needs a signed-in tenant")
    if ctx.model_deployment:
        return _skip("model_data_plane",
                     f"{ctx.model_deployment}: selected deployment; model catalog discovery not required; "
                     "chat access and compatibility unverified until the first approved model call")
    from ontology_build.model_client import ModelClient
    from ontology_core.http import EgressPolicy

    endpoint = ctx.model_endpoint.rstrip("/")
    policy = EgressPolicy(model_endpoint=endpoint, model_deployment=ctx.model_deployment)
    client = ModelClient(endpoint=endpoint, deployment=ctx.model_deployment or "", tenant_id=str(ctx.tenant_id),
                         policy=policy)
    status = client.list_models()
    if status == 200:
        return _ok("model_data_plane", f"{endpoint}: models readable (metadata only, no completion; "
                   "chat access and compatibility unverified)")
    last = getattr(client, "last_models_response", None)
    info = last.service_error() if last is not None else service_errors.describe(status, None)
    if status in (401, 403):
        raise Blocked("DOCTOR_MODEL_DATA_PLANE", f"{endpoint}: {service_errors.summary(info)}", you=_you(ctx),
                      account=f"<resource ID of {account_name(endpoint)}>", service_error=info)
    if status in (408, 429) or 500 <= status < 600:
        next_step = ("model catalog discovery is temporarily unavailable; retry doctor later, or supply an "
                     "explicitly selected `--model-deployment` to skip catalog discovery; chat access and "
                     "compatibility remain unverified until an approved model call")
    else:
        next_step = ("verify `--model-endpoint` and model catalog route/API-version support, or supply an "
                     "explicitly selected `--model-deployment`; catalog discovery does not verify chat inference")
    raise Blocked("DOCTOR_MODEL_DATA_PLANE", f"{endpoint}: {service_errors.summary(info)}",
                  next_step=next_step, service_error=info)


def check_model_deployment(ctx: DoctorContext, earlier: dict[str, Check]) -> Check:
    """Read-only ARM GET of Microsoft.CognitiveServices/accounts/deployments; records model name and version."""
    if not (ctx.model_endpoint and ctx.model_deployment):
        return _skip("model_deployment", "no model endpoint and deployment yet")
    if not (ctx.subscription_id and ctx.model_resource_group):
        return _skip("model_deployment", "no --subscription-id and --model-resource-group")
    if not _passed(earlier, "azure_signin"):
        return _skip("model_deployment", "needs a signed-in tenant")
    from ontology_core import azure_auth, http

    account = account_name(ctx.model_endpoint)
    url = (f"{ARM}/subscriptions/{quote(ctx.subscription_id, safe='')}/resourceGroups/"
           f"{quote(ctx.model_resource_group, safe='')}/providers/Microsoft.CognitiveServices/accounts/"
           f"{quote(account, safe='')}/deployments/{quote(ctx.model_deployment, safe='')}"
           f"?api-version={COGNITIVE_ARM_API_VERSION}")
    policy = http.EgressPolicy(model_endpoint=ctx.model_endpoint.rstrip("/"), model_deployment=ctx.model_deployment,
                               subscription_id=ctx.subscription_id, resource_group=ctx.model_resource_group,
                               account_name=account)
    headers = {"Authorization": "Bearer " + azure_auth.token(str(ctx.tenant_id), "arm")}
    response = http.request(policy, "GET", url, headers=headers)
    where = f"{account}/{ctx.model_deployment}"
    if response.status == 200:
        try:
            props = json.loads(response.body or b"{}").get("properties") or {}
        except ValueError:
            props = {}
        model = props.get("model") or {}
        name, version = model.get("name"), model.get("version")
        state = props.get("provisioningState")
        if state and state != "Succeeded":
            raise Blocked("DOCTOR_MODEL_DEPLOYMENT", f"{where}: provisioningState {state}",
                          next_step="wait for the deployment to finish provisioning, then rerun doctor")
        detail = f"{where}: {name or '?'} {version or ''}".rstrip()
        # ARM deployment `capabilities` (string flags) say whether it serves Chat Completions:
        # https://learn.microsoft.com/rest/api/aiservices/accountmanagement/deployments/get
        capabilities = props.get("capabilities") if isinstance(props.get("capabilities"), dict) else {}
        flags = sorted(key for key, value in capabilities.items() if str(value).lower() == "true")
        if capabilities and "chatCompletion" not in flags:
            raise Blocked("DOCTOR_MODEL_DEPLOYMENT",
                          f"{where}: capabilities {', '.join(flags) or 'none'}, not chatCompletion",
                          next_step="ask the user to pick a deployment that reports chatCompletion from "
                                    "`entity-graph-provision discover`, then rerun doctor")
        if not capabilities:
            detail += " (capabilities unreported; the first model call confirms chat support)"
        return _ok("model_deployment", detail, model_name=name, model_version=version,
                   capabilities=flags or None)
    info = response.service_error()
    detail = service_errors.summary(info)
    if response.status == 404:
        raise Blocked("DOCTOR_MODEL_DEPLOYMENT", f"{where}: not found ({detail})", service_error=info)
    if response.status in (401, 403):
        raise Blocked("DOCTOR_MODEL_DEPLOYMENT", f"{where}: {detail} reading the deployment",
                      next_step="ask an owner for Reader on the model resource group, or drop "
                                "`--subscription-id/--model-resource-group` to skip this check",
                      service_error=info)
    raise Blocked("DOCTOR_MODEL_DEPLOYMENT", f"{where}: {detail}", service_error=info)


CHECK_FUNCTIONS: dict[str, CheckFn] = {
    "cli_version": check_cli_version,
    "python": check_python,
    "azure_signin": check_azure_signin,
    "state_dir": check_state_dir,
    "journal": check_journal,
    "topicgraph_output": check_topicgraph_output,
    "source_index": check_source_index,
    "topicgraph_topics": check_topicgraph_topics,
    "model_data_plane": check_model_data_plane,
    "model_deployment": check_model_deployment,
}


def run(ctx: DoctorContext, *, checks: tuple[str, ...] = CHECKS) -> list[Check]:
    """Run every named check in order, catching `Blocked` inside each check into a FAIL. Never raises."""
    results: dict[str, Check] = {}
    for name in checks:
        try:
            check = CHECK_FUNCTIONS[name](ctx, dict(results))
        except Blocked as exc:
            data = dict(exc.details) if exc.details else {}
            check = Check(name, "FAIL", exc.error, next_step=exc.next_step, data=data,
                          service_error=exc.service_error)
        except Exception as exc:  # a broken probe must not hide the other checks
            hint = errors.render_next_step(code_for(name), tenant_id=ctx.tenant_id,
                                           tenant_name=ctx.tenant_name or "the tenant that owns the source index")
            info = service_errors.from_exception(exc)
            message = f"{type(exc).__name__}: {exc}"
            if info and info.get("message") and str(info["message"]) not in message:
                message += f" ({service_errors.summary(info)})"
            check = Check(name, "FAIL", message, next_step=hint, service_error=info)
        results[name] = check
    return list(results.values())


def result(checks: list[Check], *, next_step_if_ok: str) -> dict[str, Any]:
    """The verb result: `{status:"ok", checks:[...], next_step}` or the blocked envelope of the first FAIL
    (`error_code` `DOCTOR_<CHECK>`) plus `checks`."""
    rows = [c.to_dict() for c in checks]
    first = next((c for c in checks if c.status == "FAIL"), None)
    if first is None:
        return {"status": "ok", "checks": rows, "next_step": next_step_if_ok}
    failed = first.to_dict()
    body = errors.envelope(failed["error_code"], f"{first.name}: {first.detail}", failed["next_step"],
                           service_error=first.service_error)
    body["checks"] = rows
    return body


_REPORT_STATUS = {"ok": "pass", "skip": "warn", "FAIL": "fail"}


def report(result_body: dict[str, Any]) -> dict[str, Any]:
    """The cross-plugin `doctor --json` shape, built from `result()`:
    `{plugin, version, ready, signed_in:{tenant_id, account}, current:{kind, path, id}|null,
    checks:[{name, status: pass|warn|fail, detail[, service_error]}], next_step}`. Read-only."""
    from ontology_core import current as current_mod

    rows = result_body.get("checks", [])
    signin = next((r.get("data", {}) for r in rows if r["name"] == "azure_signin" and r["status"] == "ok"), {})
    checks = [{"name": r["name"], "status": _REPORT_STATUS.get(r["status"], "warn"), "detail": r.get("detail", ""),
               **({"service_error": r["service_error"]} if r.get("service_error") else {})}
              for r in rows]
    pointer_ref = None
    try:
        pointer = current_mod.load(required=False)
    except Blocked as exc:
        checks.append({"name": "current", "status": "warn", "detail": exc.error})
    else:
        if pointer is None:
            checks.append({"name": "current", "status": "warn", "detail": "no approved ontology recorded yet"})
        else:
            pointer_ref = {"kind": current_mod.KIND, "path": pointer["path"], "id": pointer["schema_id"]}
            checks.append({"name": "current", "status": "pass",
                           "detail": f"v{pointer['version']} {pointer['schema_id']} at {pointer['path']}"})
    return {
        "plugin": PACKAGE,
        "version": installed_version() or "unknown",
        "ready": result_body.get("status") == "ok",
        "signed_in": {"tenant_id": signin.get("tenant_id"), "account": signin.get("account")},
        "current": pointer_ref,
        "checks": checks,
        "next_step": str(result_body.get("next_step") or ""),
    }


def render(checks: list[Check], next_step: str) -> str:
    """Summary text: `ok    name  detail` lines, then `Next step: ...`."""
    width = max((len(c.name) for c in checks), default=0)
    lines = [f"{c.status:<4}  {c.name:<{width}}  {c.detail}".rstrip() for c in checks]
    lines.append(f"Next step: {next_step}")
    return "\n".join(lines)


def plugin_root_from(flag: str | None) -> Path | None:
    value = (flag or os.environ.get("ONTOLOGY_PLUGIN_ROOT") or os.environ.get("PLUGIN_ROOT")
             or os.environ.get("CLAUDE_PLUGIN_ROOT"))
    return Path(value).expanduser() if value else None


def installed_plugin_root() -> Path | None:
    """Resolve explicit or source-local package metadata without querying a harness."""
    explicit = plugin_root_from(None)
    if explicit is not None:
        return explicit
    for root in Path(__file__).resolve().parents:
        if any((root / directory / "plugin.json").is_file()
               for directory in (".plugin", "", ".claude-plugin", ".cursor-plugin")):
            return root
    return None
