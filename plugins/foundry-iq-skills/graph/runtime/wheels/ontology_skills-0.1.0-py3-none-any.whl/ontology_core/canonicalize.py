"""Deterministic ontology canonicalization and extraction guidance (ported from an earlier ontology toolkit).

Runs before and after the coverage audit in `propose`, and can also be called directly on raw dicts or
`Ontology` instances:
1. Qualify property name collisions that differ only by case or endpoints deterministically.
2. Fold redundant range-suffixed properties (`managesProject` -> `manages`) and passive `...By` properties
   (`managedBy` on `Project -> Person` -> `manages` on `Person -> Project`) into the canonical active
   property, preserving their evidence and recording the folded name in `aliases`.
3. Collapse empty wrapper entities (one incoming object property, one `String` `name`/`value` datatype
   property, no other properties) into a `String` datatype property on the owner class when evidenced by
   table headers.
4. Add evidenced role properties (`primaryX` from `"Primary X"` table columns when the owner class in the
   same delimited header line is unambiguous).
5. Add evidenced identity properties (`<x>Id` as a `String` datatype property on class `X` for `"X ID"` /
   `"X identifier"` fields in the evidence).
6. Append extraction guidance to property `rdfs:comment` descriptions for the server's extraction LLM and
   NL->GQL planner:
   - Object properties: `"The subject is <Domain>; the object is <Range>; never reverse."`
   - `Double` datatype properties: `"Extract only the numeric value."`
   - Identity properties: `"Copy the identifier verbatim; use it as the entity label."`
   - Object properties whose range is an event (a call, meeting, hearing...): when the passage doesn't name
     the event, use the one the whole document records, since a transcript rarely repeats its own title.
"""

from __future__ import annotations

import copy
import re
import unicodedata
from typing import Any

from ontology_core import hygiene, names
from ontology_core.model import ClassDef, Ontology, Passage, PropertyDef


def _type_words(name: str) -> list[str]:
    value = unicodedata.normalize("NFKC", name or "")
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", value)
    value = re.sub(r"(?<=[A-Z])(?=[A-Z][a-z])", " ", value)
    value = re.sub(r"[_-]+", " ", value)
    return [w for w in value.split() if any(ch.isalnum() for ch in w)]


def _type_key(name: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKC", name or "").casefold() if ch.isalnum())


def _pascal(name: str) -> str:
    words = _type_words(name)
    return "".join(w[:1].upper() + w[1:] for w in words) if words else ""


def _camel(name: str) -> str:
    words = _type_words(name)
    if not words:
        return ""
    first = words[0].lower()
    rest = "".join(w[:1].upper() + w[1:].lower() for w in words[1:])
    return first + rest


def _header_phrase(value: str) -> str:
    value = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", value)
    return re.sub(r"[_-]+", " ", value).strip()


def _delimited_fields(line: str) -> list[str]:
    if "|" in line:
        raw = line.strip().strip("|").split("|")
    elif "\t" in line:
        raw = line.split("\t")
    elif "," in line and line.count(",") >= 2:
        raw = line.split(",")
    else:
        return []
    return [_header_phrase(f.strip()) for f in raw if f.strip()]


def _iter_passages(evidence_input: list[Passage] | str | None) -> list[tuple[str | None, str]]:
    if evidence_input is None:
        return []
    if isinstance(evidence_input, str):
        return [(None, evidence_input)]
    out: list[tuple[str | None, str]] = []
    for p in evidence_input:
        if isinstance(p, Passage) and p.excerpt:
            out.append((p.evidence_id, p.excerpt))
        elif isinstance(p, dict) and p.get("excerpt"):
            out.append((p.get("evidence_id"), str(p["excerpt"])))
    return out


def evidenced_identifier_keys(evidence_input: list[Passage] | str | None) -> dict[str, list[str]]:
    """Map normalized class key -> sorted list of evidence IDs where '<Class> ID' or '<Class> identifier' appears."""
    found: dict[str, set[str]] = {}
    pattern = re.compile(r"^([A-Za-z][A-Za-z0-9]*(?:\s+[A-Za-z][A-Za-z0-9]*){0,3})\s+(?:ID|identifier)$", flags=re.IGNORECASE)
    for eid, text in _iter_passages(evidence_input):
        for line in text.splitlines():
            fields = _delimited_fields(line) or ([_header_phrase(line.strip().rstrip(":"))] if ":" in line or len(line.split()) <= 5 else [])
            for field in fields:
                match = pattern.match(field.strip())
                if match is None:
                    continue
                words = [w for w in match.group(1).split() if w.casefold() not in {"a", "an", "the"}]
                if words:
                    key = _type_key(" ".join(words))
                    found.setdefault(key, set()).update([eid] if eid else [])
                    if words[0].casefold() == "primary" and len(words) > 1:
                        sub_key = _type_key(" ".join(words[1:]))
                        found.setdefault(sub_key, set()).update([eid] if eid else [])
    return {k: sorted(v) for k, v in found.items()}


def evidenced_scalar_keys(evidence_input: list[Passage] | str | None) -> set[str]:
    keys: set[str] = set()
    for _, text in _iter_passages(evidence_input):
        for line in text.splitlines():
            for field in _delimited_fields(line):
                words = field.split()
                if not words or words[-1].casefold() in {"id", "identifier"}:
                    continue
                while words and words[0].casefold() in {"a", "an", "the", "primary"}:
                    words.pop(0)
                if words:
                    keys.add(_type_key(" ".join(words)))
    return keys


def _lexical_root(name: str) -> str:
    words = [w.lower() for w in _type_words(name)]
    if words and words[-1] == "by":
        words = words[:-1]
    token = "".join(words)
    for suffix in ("ed", "es", "s"):
        if token.endswith(suffix) and len(token) > len(suffix) + 2:
            token = token[:-len(suffix)]
            break
    return token


def _unique_prop_name(desired: str, domain: str, range_: str, used: set[str]) -> str:
    d_camel = names.to_lower_camel(domain) or "entity"
    r_pascal = _pascal(range_) or "Value"
    p_tail = desired[:1].upper() + desired[1:]
    candidates = [
        desired,
        f"{d_camel}{p_tail}",
        f"{d_camel}{p_tail}{r_pascal}",
    ]
    for cand in candidates:
        if cand.casefold() not in used:
            return cand
    suffix = 2
    while f"{candidates[-1]}{suffix}".casefold() in used:
        suffix += 1
    return f"{candidates[-1]}{suffix}"


def _clean_aliases(raw_aliases: Any, own_name: str, forbidden: set[str]) -> list[str]:
    if not isinstance(raw_aliases, list):
        return []
    out: list[str] = []
    seen: set[str] = {own_name.casefold()}
    for item in raw_aliases:
        if not isinstance(item, str):
            continue
        val = item.strip()
        if not val or len(val.encode("utf-8")) > 1024:
            continue
        key = val.casefold()
        if key in seen or key in forbidden:
            continue
        seen.add(key)
        out.append(val)
        if len(out) >= 64:
            break
    return out


_EVENT_WORDS = frozenset({
    "call", "meeting", "conference", "event", "session", "hearing", "interview", "webinar", "webcast",
    "briefing", "presentation", "keynote", "panel", "summit", "workshop", "lecture", "deposition",
})


def is_event_class(name: str) -> bool:
    return any(word.casefold() in _EVENT_WORDS for word in _type_words(name))


def append_extraction_guidance(prop_name: str, kind: str, domain: str, range_: str, description: str) -> str:
    """Append deterministic extraction guidance for object, Double, and identifier properties."""
    desc = (description or "").strip()

    def add(guidance: str) -> None:
        nonlocal desc
        joined = f"{desc} {guidance}".strip()
        if guidance.casefold() not in desc.casefold() and len(joined.encode("utf-8")) <= 1024:
            desc = joined

    if kind == "object":
        guidance = f"The subject is {domain}; the object is {range_}; never reverse."
        if guidance.casefold() not in desc.casefold():
            desc = f"{desc} {guidance}".strip()
        if is_event_class(range_) and not is_event_class(domain):
            # Links an utterance, question or answer to its event: a transcript chunk rarely names it.
            add(f"When the passage doesn't name the {range_}, use the {range_} the whole document "
                "records (a transcript's own call or meeting), named as the document names it.")
    elif kind == "datatype" and range_ == "Double":
        guidance = "Extract only the numeric value."
        if guidance.casefold() not in desc.casefold():
            desc = f"{desc} {guidance}".strip()
    elif kind == "datatype" and range_ == "String":
        expected_id = f"{names.to_lower_camel(domain)}Id".casefold()
        if prop_name.casefold() == expected_id or prop_name.endswith("Id"):
            guidance = "Copy the identifier verbatim; use it as the entity label."
            if guidance.casefold() not in desc.casefold():
                desc = f"{desc} {guidance}".strip()
    return desc


def canonicalize_raw(
    raw: dict[str, Any],
    evidence_input: list[Passage] | str | None = None,
    *,
    add_evidenced: bool = False,
    append_guidance: bool = False,
) -> dict[str, Any]:
    """Canonicalize raw `{"classes": [...], "properties": [...]}` dict."""
    if not isinstance(raw, dict):
        return {"classes": [], "properties": []}
    raw_classes = [copy.deepcopy(c) for c in (raw.get("classes") or []) if isinstance(c, dict)]
    raw_props = [copy.deepcopy(p) for p in (raw.get("properties") or []) if isinstance(p, dict)]

    # 1. Normalize and merge classes case-insensitively.
    class_groups: dict[str, dict[str, Any]] = {}
    for c in raw_classes:
        cname = names.normalize_class(str(c.get("name") or ""))
        if not cname:
            continue
        key = cname.casefold()
        ev = [e for e in (c.get("evidence") or []) if isinstance(e, str)]
        al = [a for a in (c.get("aliases") or []) if isinstance(a, str)]
        if key not in class_groups:
            class_groups[key] = {
                **c,
                "name": cname,
                "description": str(c.get("description") or "").strip(),
                "evidence": list(dict.fromkeys(ev)),
                "aliases": list(dict.fromkeys(al)),
            }
        else:
            cur = class_groups[key]
            cur["evidence"] = list(dict.fromkeys([*cur["evidence"], *ev]))
            cur["aliases"] = list(dict.fromkeys([*cur["aliases"], *al]))
            if not cur["description"] and c.get("description"):
                cur["description"] = str(c.get("description")).strip()

    class_by_key = {k: v["name"] for k, v in class_groups.items()}

    # 2. Group properties by case-insensitive name & shape; qualify distinct endpoint collisions.
    prop_groups: dict[str, dict[tuple[str, str, str], dict[str, Any]]] = {}
    for p in raw_props:
        pname = names.normalize_property(str(p.get("name") or ""))
        if not pname:
            continue
        raw_range = str(p.get("range") or "").strip()
        dt = hygiene.map_datatype(raw_range)
        kind_raw = str(p.get("kind") or "").strip().lower()
        kind = "datatype" if (kind_raw.startswith(("data", "attr", "lit")) or dt is not None) else "object"
        d_norm = names.normalize_class(str(p.get("domain") or ""))
        domain = class_by_key.get(d_norm.casefold(), d_norm)
        if kind == "datatype":
            range_ = dt or raw_range
        else:
            r_norm = names.normalize_class(raw_range)
            range_ = class_by_key.get(r_norm.casefold(), r_norm)
        if not domain or not range_:
            continue
        shape = (kind, domain.casefold(), range_.casefold())
        bucket = prop_groups.setdefault(pname.casefold(), {})
        ev = [e for e in (p.get("evidence") or []) if isinstance(e, str)]
        al = [a for a in (p.get("aliases") or []) if isinstance(a, str)]
        if shape not in bucket:
            bucket[shape] = {
                **p,
                "name": pname,
                "kind": kind,
                "domain": domain,
                "range": range_,
                "description": str(p.get("description") or "").strip(),
                "evidence": list(dict.fromkeys(ev)),
                "aliases": list(dict.fromkeys(al)),
            }
        else:
            cur = bucket[shape]
            cur["evidence"] = list(dict.fromkeys([*cur["evidence"], *ev]))
            cur["aliases"] = list(dict.fromkeys([*cur["aliases"], *al]))
            if not cur["description"] and p.get("description"):
                cur["description"] = str(p.get("description")).strip()

    used_names: set[str] = set(class_by_key)
    props: list[dict[str, Any]] = []
    for pname_lower in sorted(prop_groups):
        variants = sorted(
            prop_groups[pname_lower].values(),
            key=lambda item: (-len(item["evidence"]), item["domain"], item["range"], item["kind"], item["name"]),
        )
        for idx, item in enumerate(variants):
            desired = item["name"]
            if idx > 0:
                desired = _unique_prop_name(desired, item["domain"], item["range"], used_names)
            elif desired.casefold() in used_names:
                desired = _unique_prop_name(desired, item["domain"], item["range"], used_names)
            used_names.add(desired.casefold())
            item["name"] = desired
            props.append(item)

    # 3. Fold redundant range-suffixed object properties (`managesProject` -> `manages`) and passive `...By` forms.
    folded_into: dict[str, str] = {}
    obj_props = [p for p in props if p["kind"] == "object"]
    for p in obj_props:
        r_pascal = _pascal(p["range"])
        if r_pascal and p["name"].endswith(r_pascal) and len(p["name"]) > len(r_pascal) + 2:
            base = p["name"][:-len(r_pascal)]
            target = next(
                (
                    other for other in obj_props
                    if other["name"] != p["name"]
                    and other["domain"] == p["domain"]
                    and other["range"] == p["range"]
                    and (other["name"].casefold() == base.casefold() or other["name"].casefold().endswith(base.casefold()))
                ),
                None,
            )
            if target is not None:
                folded_into[p["name"]] = target["name"]

    for p in obj_props:
        if not p["name"].endswith("By") or p["name"] in folded_into:
            continue
        root = _lexical_root(p["name"])
        if not root:
            continue
        counterpart = next(
            (
                other for other in obj_props
                if other["name"] != p["name"]
                and other["name"] not in folded_into
                and other["domain"] == p["range"]
                and other["range"] == p["domain"]
                and _lexical_root(other["name"]) == root
            ),
            None,
        )
        if counterpart is not None:
            folded_into[p["name"]] = counterpart["name"]

    if folded_into:
        by_name = {p["name"]: p for p in props}
        for src_name, dst_name in folded_into.items():
            while dst_name in folded_into:
                dst_name = folded_into[dst_name]
            src = by_name.get(src_name)
            dst = by_name.get(dst_name)
            if src and dst and src is not dst:
                dst["evidence"] = list(dict.fromkeys([*dst["evidence"], *src["evidence"]]))
                dst["aliases"] = list(dict.fromkeys([*dst["aliases"], src_name, *src["aliases"]]))
        props = [p for p in props if p["name"] not in folded_into]

    # 4. Collapse empty wrapper entities when supported by evidenced scalar headers.
    scalar_keys = evidenced_scalar_keys(evidence_input)
    id_keys = evidenced_identifier_keys(evidence_input)
    if scalar_keys:
        remove_classes: set[str] = set()
        remove_props: set[str] = set()
        promoted: list[dict[str, Any]] = []
        for c in list(class_groups.values()):
            cname = c["name"]
            if _type_key(cname) in id_keys or c.get("seed"):
                continue
            incoming = [p for p in props if p["kind"] == "object" and p["range"] == cname and p["domain"] != cname]
            outgoing = [p for p in props if p["kind"] == "datatype" and p["domain"] == cname]
            other = [
                p for p in props
                if (p["domain"] == cname or (p["kind"] == "object" and p["range"] == cname))
                and p not in incoming and p not in outgoing
            ]
            labels = [
                p for p in outgoing
                if p["range"] == "String"
                and (
                    p["name"].casefold() in {"name", "value", "label"}
                    or _type_key(p["name"]) == _type_key(cname)
                    or p["name"].endswith("Name")
                )
            ]
            if len(incoming) != 1 or len(outgoing) != 1 or len(labels) != 1 or other:
                continue
            link, label = incoming[0], labels[0]
            raw_pred = (
                label["name"]
                if label["name"].casefold() not in {"name", "value", "label"} and not label["name"].endswith("Name")
                else _camel(cname)
            )
            pred = raw_pred if link["name"] == "has" or link["name"].startswith("has") else link["name"]
            link_stripped = link["name"][3:] if link["name"].startswith("has") and len(link["name"]) > 3 else link["name"]
            if not ({_type_key(cname), _type_key(link_stripped), _type_key(pred)} & scalar_keys):
                continue
            existing = next(
                (p for p in props if p["name"].casefold() == pred.casefold() and p["domain"] == link["domain"] and p["kind"] == "datatype"),
                None,
            )
            merged_ev = list(dict.fromkeys([*link["evidence"], *label["evidence"], *c["evidence"]]))
            merged_al = list(dict.fromkeys([*link["aliases"], *label["aliases"], *c["aliases"]]))
            if existing is not None:
                existing["evidence"] = list(dict.fromkeys([*existing["evidence"], *merged_ev]))
                existing["aliases"] = list(dict.fromkeys([*existing["aliases"], *merged_al]))
            else:
                used_names.discard(cname.casefold())
                used_names.discard(pred.casefold())
                new_name = _unique_prop_name(pred, link["domain"], "String", used_names)
                used_names.add(new_name.casefold())
                promoted.append({
                    "name": new_name,
                    "kind": "datatype",
                    "domain": link["domain"],
                    "range": "String",
                    "description": label["description"] or link["description"] or c["description"],
                    "evidence": merged_ev,
                    "aliases": merged_al,
                })
            remove_classes.add(cname.casefold())
            remove_props.update({link["name"], label["name"]})

        if remove_classes:
            class_groups = {k: v for k, v in class_groups.items() if k not in remove_classes}
            props = [p for p in props if p["name"] not in remove_props] + promoted

    # 5. Add evidenced role properties and identifier properties when requested.
    if add_evidenced and evidence_input is not None:
        props = _add_evidenced_role_properties(class_groups, props, evidence_input, id_keys, used_names)
        props = _add_evidenced_identifier_properties(class_groups, props, id_keys, used_names)

    # 6. Append extraction guidance and clean aliases.
    all_identifiers = {v["name"].casefold() for v in class_groups.values()} | {p["name"].casefold() for p in props}
    final_classes: list[dict[str, Any]] = []
    for c in class_groups.values():
        c["aliases"] = _clean_aliases(c.get("aliases"), c["name"], all_identifiers)
        final_classes.append(c)

    final_props: list[dict[str, Any]] = []
    for p in props:
        if append_guidance:
            p["description"] = append_extraction_guidance(
                p["name"], p["kind"], p["domain"], p["range"], p["description"],
            )
        p["aliases"] = _clean_aliases(p.get("aliases"), p["name"], all_identifiers)
        final_props.append(p)

    return {"classes": final_classes, "properties": final_props}


def _add_evidenced_identifier_properties(
    class_groups: dict[str, dict[str, Any]],
    props: list[dict[str, Any]],
    id_keys: dict[str, list[str]],
    used_names: set[str],
) -> list[dict[str, Any]]:
    by_case = {p["name"].casefold(): p for p in props}
    for c in class_groups.values():
        cname = c["name"]
        ckey = _type_key(cname)
        if ckey not in id_keys:
            continue
        eids = id_keys[ckey] or list(c.get("evidence") or [])
        if not eids:
            continue
        pred = f"{_camel(cname)}Id"
        desc = (
            f"Identifier for {cname}. Copy the identifier verbatim; use it as the entity label."
        )
        cur = by_case.get(pred.casefold())
        if cur is None:
            used_names.add(pred.casefold())
            new_prop = {
                "name": pred,
                "kind": "datatype",
                "domain": cname,
                "range": "String",
                "description": desc,
                "evidence": list(eids),
                "aliases": [],
            }
            props.append(new_prop)
            by_case[pred.casefold()] = new_prop
        elif cur["domain"] == cname and cur["kind"] == "datatype" and cur["range"] == "String":
            cur["evidence"] = list(dict.fromkeys([*cur["evidence"], *eids]))
    return props


def _add_evidenced_role_properties(
    class_groups: dict[str, dict[str, Any]],
    props: list[dict[str, Any]],
    evidence_input: list[Passage] | str | None,
    id_keys: dict[str, list[str]],
    used_names: set[str],
) -> list[dict[str, Any]]:
    class_by_tkey = {_type_key(c["name"]): c["name"] for c in class_groups.values()}
    id_field_re = re.compile(r"^(.+?)\s+(?:ID|identifier)$", flags=re.IGNORECASE)
    primary_re = re.compile(r"^Primary\s+(.+)$", flags=re.IGNORECASE)

    candidate_roles: dict[tuple[str, str, str], set[str]] = {}
    ambiguous: set[tuple[str, str]] = set()

    for eid, text in _iter_passages(evidence_input):
        for line in text.splitlines():
            fields = _delimited_fields(line)
            if not fields:
                continue
            owners = [
                m.group(1).strip()
                for f in fields
                if not f.casefold().startswith("primary ")
                for m in [id_field_re.fullmatch(f)]
                if m is not None
            ]
            if not owners:
                continue
            for f in fields:
                m = primary_re.fullmatch(f)
                if m is None:
                    continue
                words = m.group(1).split()
                is_id = words[-1].casefold() in {"id", "identifier"}
                if is_id:
                    words = words[:-1]
                if not words:
                    continue
                phrase = " ".join(words)
                tkey = _type_key(phrase)
                target_cls = class_by_tkey.get(tkey)
                plausible_owners = {
                    class_by_tkey[_type_key(o)]
                    for o in owners
                    if _type_key(o) in class_by_tkey and _type_key(o) != tkey
                }
                if len(plausible_owners) != 1:
                    ambiguous.add((target_cls or _pascal(phrase), "object" if target_cls else "datatype"))
                    continue
                owner_cls = next(iter(plausible_owners))
                kind = "object" if target_cls is not None else "datatype"
                range_ = target_cls if target_cls is not None else "String"
                key = (owner_cls, target_cls or _pascal(phrase), kind)
                candidate_roles.setdefault(key, set()).update([eid] if eid else [])

    for (owner_cls, target_name, kind), eids in sorted(candidate_roles.items()):
        if (target_name, kind) in ambiguous:
            continue
        owner_evidence = class_groups.get(owner_cls.casefold(), {}).get("evidence") or []
        use_eids = sorted(eids) or list(owner_evidence)
        if not use_eids:
            continue
        desired = f"primary{_pascal(target_name)}"
        if any(p["name"].casefold() == desired.casefold() and p["domain"] == owner_cls for p in props):
            continue
        pname = _unique_prop_name(desired, owner_cls, target_name if kind == "object" else "String", used_names)
        used_names.add(pname.casefold())
        props.append({
            "name": pname,
            "kind": kind,
            "domain": owner_cls,
            "range": target_name if kind == "object" else "String",
            "description": f"Primary { _header_phrase(target_name).lower() } for {owner_cls}.",
            "evidence": use_eids,
            "aliases": [],
        })
    return props


def canonicalize_ontology(
    ontology: Ontology,
    evidence_input: list[Passage] | str | None = None,
    *,
    add_evidenced: bool = True,
    append_guidance: bool = True,
) -> Ontology:
    """Run deterministic canonicalization over an `Ontology` instance and return a new canonical `Ontology`."""
    seeds = Ontology(
        version=0,
        classes=[c for c in ontology.classes if c.seed],
        properties=[p for p in ontology.properties if p.seed],
    )
    raw = canonicalize_raw(
        ontology.to_dict(),
        evidence_input,
        add_evidenced=add_evidenced,
        append_guidance=append_guidance,
    )
    cleaned, _ = hygiene.clean(
        raw,
        None,
        seeds if (seeds.classes or seeds.properties) else None,
        version=ontology.version,
        origin="revise",
    )
    return cleaned
