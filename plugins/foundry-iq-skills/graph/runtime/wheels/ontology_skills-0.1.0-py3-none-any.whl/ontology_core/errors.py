"""Error codes, the one next step for each, and the blocked/error envelope.

Every failure the plugin reports is a `Blocked` exception carrying a code from
`CODES`. The CLI and optional Apps layer turn it into
`{"status", "error_code", "error", "next_step"}` and exit with `EXIT_BLOCKED`.
`next_step` templates use `{placeholders}`; any placeholder the raiser does not
supply is rendered as `<name>` so the step is still readable.
"""

from __future__ import annotations

import string
import traceback
from typing import Any

EXIT_OK = 0
EXIT_BLOCKED = 2

_PLAN_AGAIN = "`ontology-build plan …` again, then approve the new plan ID"
_REINSTALL = ("use a Python version the plugin supports (listed in its README) to run "
              "the supplied distribution's "
              '`python -I "<plugin-root>/graph/runtime/bootstrap.py" setup ontology`; '
              "for source development, reinstall into your explicit venv")
_SIGN_IN = "az login --tenant {tenant_id}  # {tenant_name}"

CODES: dict[str, str] = {
    "CONFIG_MISSING": (
        "ontology-build connect --tenant-id … --topic-graph-output … --accept-current-source --model-endpoint … "
        "--model-deployment … --model-input-price-per-1m … --model-output-price-per-1m …"),
    "CONFIG_CONFLICT": "use a new `--state-dir` for a different generation or model",
    "MODEL_PRICE_UNKNOWN": (
        "pass --build-args with the file Entity Graph connect saved (it carries the chat model's "
        "list price), or both price flags if the user gives them; never look prices up"),
    "TENANT_REQUIRED": "pass `--tenant-id <guid>` (the tenant that owns the original source index)",
    "TENANT_MISMATCH": _SIGN_IN,
    "AZ_NOT_SIGNED_IN": _SIGN_IN,
    "AZ_CLI_MISSING": "install Azure CLI, then `az login --tenant {tenant_id}`",
    "STATE_DIR_UNWRITABLE": "choose a writable `--state-dir`",
    "STATE_INCOMPATIBLE": "this state dir was written by another tool version; use a new `--state-dir`",
    "STATE_LOCKED": "wait for pid {pid} on {host}, or `ontology-build reconcile` if it is not running",
    "JOURNAL_DRIFT": "inspect the listed files; restore them or re-import as a new version",
    "TOPICGRAPH_INPUT_INVALID": "connect a Topic Graph build output folder with --topic-graph-output in a new --state-dir",
    "TOPICGRAPH_OUTPUT_INVALID": (
        "pass the Topic Graph build output folder (it contains an `ontology` folder); "
        "add --structure-id or --labels-id when it holds more than one"),
    "TOPICGRAPH_INPUT_CHANGED": "restore the connected inputs, or connect a new --state-dir and plan again",
    "SOURCE_CURRENT_READ_REQUIRED": (
        "passage text is read from the source index as it is now; if that is acceptable, "
        "pass --accept-current-source"),
    "TOPICGRAPH_STRUCTURE_INVALID": "restore the complete, unmodified Topic Graph build output folder, or rebuild it",
    "TOPICGRAPH_LEGACY_FORM": (
        "rebuild the topic graph with the pinned Topic Graph build tool, then reconnect and rebuild the ontology"),
    "ONTOLOGY_STATE_OUTDATED": (
        "rebuild the topic graph with the pinned Topic Graph build tool, then run connect with a new "
        "--state-dir and plan again"),
    "TOPICGRAPH_LABELS_INVALID": "restore the topic labels file, or pass --labels-id to choose one that matches the structure",
    "TOPICGRAPH_DESCRIPTOR_INVALID": "rerun connect with --topic-graph-output and a new --state-dir",
    "TOPICGRAPH_PIN_MISMATCH": "restore the connected Topic Graph output, or connect a new --state-dir and plan again",
    "SOURCE_INDEX_CONFIG": "the source endpoint, index or field mapping recorded by the Topic Graph build is unusable; rebuild it",
    "SOURCE_INDEX_SCHEMA": "restore the source schema or bind a reviewed new input; this adapter never changes schemas",
    "SOURCE_INDEX_AUTH": "sign in to the connected tenant with an account that can read the source index",
    "SOURCE_INDEX_REQUEST": "check source availability and read access, then rerun the same command",
    "SOURCE_INDEX_ROWS": "restore the source rows; missing, blank or invalid evidence cannot be silently skipped",
    "SOURCE_INDEX_FILTER": "use a filterable source key to preserve the recorded source filter",
    "PLAN_STALE": _PLAN_AGAIN,
    "LEVEL_OUT_OF_RANGE": "`ontology-build inspect` to see the levels",
    "PASSAGE_BUDGET_TOO_SMALL": "raise `--passages` to at least {n} or pick a broader (smaller) `--level`",
    "PLAN_NOT_FOUND": "`ontology-build plan …` and use the printed plan ID",
    "PLAN_ID_MISMATCH": "`ontology-build plan …` and use the printed plan ID",
    "APPROVAL_REQUIRED": (
        "add `--plan-id {id} --approved-budget-usd {usd} --approve-model-calls` after the user approves"),
    "BUDGET_ABOVE_PLAN_CAP": "approve at most ${cap}, or re-plan with a larger `--model-max-spend-usd`",
    "BUDGET_BELOW_ESTIMATE": "approve at least ${estimate}, or re-plan with fewer `--passages`",
    "BUDGET_CAP_BELOW_ESTIMATE": "ontology-build plan --model-max-spend-usd {min_cap}{flags}",
    "BUDGET_EXHAUSTED": "re-plan with a larger cap and approve it; finished calls are reused and not charged again",
    "PLAN_ALREADY_EXECUTED": "`ontology-build review --version {n}`",
    "RUN_INCOMPLETE": "rerun the same `propose`, `critique` or `refine` command to resume; finished calls are reused and not charged again",
    "MODEL_ACCESS_DENIED": "ask an owner to assign Cognitive Services OpenAI User on {account}",
    "MODEL_DEPLOYMENT_NOT_FOUND": "fix `--model-deployment` and rerun connect",
    "MODEL_THROTTLED": "rerun the same command to resume; finished calls are reused and not charged again",
    "MODEL_OUTPUT_INVALID": ("the model was already asked twice; rerun the same command to ask once more "
                             "(finished calls are reused and not charged again); if it repeats, re-plan with a smaller `--shard-chars`"),
    "JUDGE_INCOMPLETE": "review the retained critique warnings; repair the judgment before preparing a new plan",
    "MODEL_OUTPUT_TRUNCATED": "re-plan with a larger `--model-max-output-tokens` or a smaller `--shard-chars`",
    "VERSION_NOT_FOUND": "`ontology-build status`",
    "SCHEMA_ID_MISMATCH": "the version changed on disk; `ontology-build import` it as a new version",
    "NOT_APPROVED": "`ontology-build approve --version {n} --schema-id {id}`",
    "IMPORT_UNSUPPORTED_FORMAT": "use .owl/.rdf/.xml/.ttl/.nt/.json",
    "IMPORT_HAS_IMPORTS": "inline the imported terms and remove `owl:imports`",
    "IMPORT_INVALID": "fix the file (no DOCTYPE/ENTITY, ≤ 5 MB, well-formed)",
    "PROFILE_VIOLATION": "`ontology-consume check {file}` and fix the listed items",
    "BASE_IRI_INVALID": "pass a `--base-iri` that ends with `#` and has no whitespace, quotes or angle brackets",
    "OUTPUT_EXISTS": "choose another `--output` or pass `--force`",
    "EXPORT_FORMAT_UNSUPPORTED": "pass a .jsonld `--output` path; export writes OWL in JSON-LD",
    "JSONLD_EXPORT_UNSUPPORTED": "revise the ontology to use only the supported flat class/property profile",
    "JSONLD_PROFILE_VIOLATION": "inspect the profile violations and reduce or revise the ontology before export",
    "EMPTY_ONTOLOGY": "the result had no valid classes; review the hygiene report",
    "NO_CURRENT": "`ontology-build approve --version <n> --schema-id <id>` to record the current ontology",
    "CURRENT_INVALID": "re-approve or re-export the version to rewrite the current pointer",
    "CURRENT_AMBIGUOUS": "pass --state-dir for the ontology run you mean; each state folder keeps its own current pointer",
    "QUERY_FILE_INVALID": "one JSON object per line with `id` and `query`",
    "NOT_IMPLEMENTED": "this verb is not available in this build; " + _REINSTALL,
    "INTERNAL_ERROR": "rerun with `--json` and file an issue with the output",
    # doctor: one code per check; the doctor fills {detail} placeholders where useful
    "DOCTOR_CLI_VERSION": _REINSTALL,
    "DOCTOR_PYTHON": _REINSTALL,
    "DOCTOR_AZURE_SIGNIN": _SIGN_IN,
    "DOCTOR_STATE_DIR": "fix permissions or choose another `--state-dir`",
    "DOCTOR_JOURNAL": "`ontology-build reconcile`",
    "DOCTOR_TOPICGRAPH_OUTPUT": "restore the connected Topic Graph build output folder (topic structure and topic labels)",
    "DOCTOR_SOURCE_INDEX": "check read access to the source index and its recorded field mapping",
    "DOCTOR_TOPICGRAPH_TOPICS": "restore the complete Topic Graph build output folder, then reconnect and plan again",
    "DOCTOR_MODEL_DATA_PLANE": (
        'ask an owner to run: `az role assignment create --role "Cognitive Services OpenAI User" '
        "--assignee {you} --scope {account}`; otherwise fix `--model-endpoint`"),
    "DOCTOR_MODEL_DEPLOYMENT": "fix `--model-deployment`, or check `--subscription-id/--model-resource-group`",
}

INTERNAL_ERROR = "INTERNAL_ERROR"


class _Keep(dict):
    def __missing__(self, key: str) -> str:
        return f"<{key}>"


def render_next_step(code: str, **fmt: Any) -> str:
    """Fill the `next_step` template for `code`; unknown codes are an internal error."""
    if code not in CODES:
        raise KeyError(f"unknown error code {code!r}")
    return string.Formatter().vformat(CODES[code], (), _Keep({k: v for k, v in fmt.items() if v is not None}))


def placeholders(code: str) -> set[str]:
    return {name for _, name, _, _ in string.Formatter().parse(CODES[code]) if name}


class Blocked(Exception):
    """A gated or failed step with one error code and one next step.

    `Blocked(code, error, **fmt)`: `error` is the human sentence; `fmt` fills the
    code's `next_step` template. `details` (keyword) adds structured fields to the
    envelope under `"details"` (for example the drifted paths for JOURNAL_DRIFT).
    Pass `next_step=` only to override the table (doctor checks use this).
    `service_error` (keyword) is the parsed failed-service response from `service_errors.describe`; it is
    emitted as `"service_error"` in the envelope so the caller can correct the request or explain it.
    """

    def __init__(self, code: str, error: str = "", /, *, details: dict[str, Any] | None = None,
                 next_step: str | None = None, service_error: dict[str, Any] | None = None, **fmt: Any) -> None:
        if code not in CODES:
            raise KeyError(f"unknown error code {code!r}")
        self.code = code
        self.error = error or code.replace("_", " ").lower()
        self.details = details or {}
        self.service_error = service_error or None
        self.fmt = fmt
        self.next_step = next_step or render_next_step(code, **fmt)
        super().__init__(f"{code}: {self.error}")

    def envelope(self) -> dict[str, Any]:
        return envelope(self.code, self.error, self.next_step, details=self.details,
                        service_error=self.service_error)


def envelope(code: str, error: str, next_step: str, *, details: dict[str, Any] | None = None,
             service_error: dict[str, Any] | None = None) -> dict[str, Any]:
    """The blocked/error result object. INTERNAL_ERROR uses status "error"; every other code "blocked"."""
    body: dict[str, Any] = {
        "status": "error" if code == INTERNAL_ERROR else "blocked",
        "error_code": code,
        "error": error,
        "next_step": next_step,
    }
    if details:
        body["details"] = details
    if service_error:
        body["service_error"] = service_error
    return body


def internal_error(exc: BaseException, *, include_traceback: bool) -> dict[str, Any]:
    """Envelope for an unexpected exception. The traceback is included only in --json output; a parsed
    service error (SDK/HTTP exceptions) is always included."""
    from ontology_core import service_errors

    details = None
    if include_traceback:
        details = {"traceback": "".join(traceback.format_exception(exc))}
    service_error = service_errors.from_exception(exc)
    error = f"{type(exc).__name__}: {exc}"
    if service_error and service_error.get("message") and str(service_error["message"]) not in error:
        error += f" ({service_errors.summary(service_error)})"
    return envelope(INTERNAL_ERROR, error, CODES[INTERNAL_ERROR], details=details, service_error=service_error)


def to_envelope(exc: BaseException, *, include_traceback: bool = False) -> dict[str, Any]:
    if isinstance(exc, Blocked):
        return exc.envelope()
    return internal_error(exc, include_traceback=include_traceback)
